import { sql } from "drizzle-orm";
import {
  bigint,
  boolean,
  check,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

const id = () =>
  text("id")
    .primaryKey()
    .$defaultFn(() => crypto.randomUUID());
const createdAt = () => timestamp("created_at", { withTimezone: true }).notNull().defaultNow();

/* ---------------- Kullanıcılar ---------------- */
export const users = pgTable("users", {
  id: id(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  // CUSTOMER | PROVIDER | FLEET_OWNER | RESTAURANT_OWNER | ADMIN | SUPER_ADMIN
  role: text("role").notNull(),
  /** Yalnızca tuzlu özet (scrypt); düz metin parola hiçbir zaman saklanmaz. */
  passwordHash: text("password_hash"),
  isSuspended: boolean("is_suspended").notNull().default(false),
  suspendedReason: text("suspended_reason"),
  createdAt: createdAt(),
});

/* ---------------- Filolar ---------------- */
export const fleets = pgTable("fleets", {
  id: id(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  ownerUserId: text("owner_user_id").notNull(),
  description: text("description"),
  city: text("city").notNull().default("İstanbul"),
  // DIRECT_ALLOWED | FLEET_APPROVAL_REQUIRED | FLEET_ONLY
  directPolicy: text("direct_policy").notNull().default("FLEET_APPROVAL_REQUIRED"),
  showMembersPublicly: boolean("show_members_publicly").notNull().default(true),
  isVerified: boolean("is_verified").notNull().default(false),
  accent: text("accent").notNull().default("#ff6b35"),
  phonePublic: text("phone_public"),
  website: text("website"),
  opensAt: text("opens_at").notNull().default("08:00"),
  closesAt: text("closes_at").notNull().default("22:00"),
  capacityLabel: text("capacity_label"),
  servicePackages: text("service_packages").array().notNull().default(sql`ARRAY[]::text[]`),
  serviceAreas: text("service_areas").array().notNull().default(sql`ARRAY[]::text[]`),
  createdAt: createdAt(),
});

/* ---------------- Hizmet sağlayıcı (Yol Arkadaşı) ---------------- */
export const providers = pgTable(
  "providers",
  {
    id: id(),
    userId: text("user_id").notNull().unique(),
    slug: text("slug").notNull().unique(),
    // COURIER | DRIVER | VEHICLE_OPERATOR
    kind: text("kind").notNull(),
    displayName: text("display_name").notNull(),
    headline: text("headline"),
    bio: text("bio"),
    // BICYCLE | MOTORCYCLE | CAR | VAN | TRUCK | COLD_CHAIN_VAN | MINIBUS
    vehicleType: text("vehicle_type").notNull(),
    vehicleLabel: text("vehicle_label"),
    serviceTypes: text("service_types").array().notNull(), // PACKAGE | FOOD | PASSENGER | RENTAL
    serviceAreas: text("service_areas").array().notNull(), // ilçe anahtarları
    highlights: text("highlights").array().notNull().default(sql`ARRAY[]::text[]`),
    fleetId: text("fleet_id"),
    isVerified: boolean("is_verified").notNull().default(false),
    // OFFLINE | AVAILABLE | BUSY | ON_TASK | PAUSED | SUSPENDED
    status: text("status").notNull().default("OFFLINE"),
    ratingAvg: doublePrecision("rating_avg").notNull().default(0),
    ratingCount: integer("rating_count").notNull().default(0),
    completedCount: integer("completed_count").notNull().default(0),
    onTimeRate: doublePrecision("on_time_rate").notNull().default(0.9),
    lateCancelRate: doublePrecision("late_cancel_rate").notNull().default(0),
    maxConcurrent: integer("max_concurrent").notNull().default(1),
    acceptsInstant: boolean("accepts_instant").notNull().default(true),
    acceptsScheduled: boolean("accepts_scheduled").notNull().default(true),
    acceptsRental: boolean("accepts_rental").notNull().default(false),
    baseFareMinor: bigint("base_fare_minor", { mode: "number" }).notNull().default(6000),
    perKmMinor: bigint("per_km_minor", { mode: "number" }).notNull().default(1500),
    rentalHourlyMinor: bigint("rental_hourly_minor", { mode: "number" }),
    currency: text("currency").notNull().default("TRY"),
    // ÖZEL: ham konum asla public serializer'dan çıkmaz
    lastLat: doublePrecision("last_lat"),
    lastLng: doublePrecision("last_lng"),
    lastSeenAt: timestamp("last_seen_at", { withTimezone: true }),
    phonePrivate: text("phone_private"),
    hue: integer("hue").notNull().default(20),
    visibility: text("visibility").notNull().default("PUBLIC"),
    createdAt: createdAt(),
  },
  (t) => [index("providers_status_idx").on(t.status), index("providers_fleet_idx").on(t.fleetId)],
);

/* ---------------- Talep (tüm modların kökü) ---------------- */
export const serviceRequests = pgTable(
  "service_requests",
  {
    id: id(),
    code: text("code").notNull().unique(),
    customerId: text("customer_id").notNull(),
    mode: text("mode").notNull(), // INSTANT_CALL | SCHEDULED | INSTANT_RENT
    strategy: text("strategy").notNull().default("AUTO"), // AUTO | FAVORITE | MANUAL_PROVIDER | MANUAL_FLEET
    status: text("status").notNull().default("QUOTED"),
    serviceType: text("service_type").notNull(), // PACKAGE | FOOD | PASSENGER | RENTAL
    vehicleTypeReq: text("vehicle_type_req"),
    pickupArea: text("pickup_area").notNull(),
    pickupDetail: text("pickup_detail"),
    dropoffArea: text("dropoff_area"),
    dropoffDetail: text("dropoff_detail"),
    scheduledStart: timestamp("scheduled_start", { withTimezone: true }),
    scheduledEnd: timestamp("scheduled_end", { withTimezone: true }),
    rentalHours: integer("rental_hours"),
    preferredProviderId: text("preferred_provider_id"),
    preferredFleetId: text("preferred_fleet_id"),
    quotedPriceMinor: bigint("quoted_price_minor", { mode: "number" }),
    finalPriceMinor: bigint("final_price_minor", { mode: "number" }),
    currency: text("currency").notNull().default("TRY"),
    note: text("note"),
    deliveryOtp: text("delivery_otp").notNull(),
    idempotencyKey: text("idempotency_key").notNull().unique(),
    linkedOrderId: text("linked_order_id"),
    otpAttempts: integer("otp_attempts").notNull().default(0),
    otpLockedAt: timestamp("otp_locked_at", { withTimezone: true }),
    createdAt: createdAt(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("requests_customer_idx").on(t.customerId, t.createdAt),
    index("requests_status_idx").on(t.status),
  ],
);

export const matchingCandidates = pgTable(
  "matching_candidates",
  {
    id: id(),
    requestId: text("request_id").notNull(),
    providerId: text("provider_id").notNull(),
    fleetId: text("fleet_id"),
    score: doublePrecision("score").notNull(),
    breakdown: jsonb("breakdown").$type<Record<string, number>>().notNull(),
    etaSeconds: integer("eta_seconds").notNull(),
    distanceM: integer("distance_m").notNull(),
    priceMinor: bigint("price_minor", { mode: "number" }).notNull(),
    rank: integer("rank").notNull(),
    // null | FLEET_PENDING | OFFERED | ACCEPTED | DECLINED | TIMEOUT | SKIPPED
    response: text("response"),
    offeredAt: timestamp("offered_at", { withTimezone: true }),
    offerExpiresAt: timestamp("offer_expires_at", { withTimezone: true }),
    respondedAt: timestamp("responded_at", { withTimezone: true }),
  },
  (t) => [
    uniqueIndex("candidate_req_provider_uq").on(t.requestId, t.providerId),
    index("candidate_provider_idx").on(t.providerId, t.response),
  ],
);

export const assignments = pgTable(
  "assignments",
  {
    id: id(),
    requestId: text("request_id").notNull().unique(), // çift kesin atama imkânsız
    providerId: text("provider_id").notNull(),
    fleetId: text("fleet_id"),
    state: text("state").notNull().default("CONFIRMED"), // CONFIRMED | IN_PROGRESS | COMPLETED | CANCELLED
    acceptedAt: timestamp("accepted_at", { withTimezone: true }).notNull().defaultNow(),
    startedAt: timestamp("started_at", { withTimezone: true }),
    completedAt: timestamp("completed_at", { withTimezone: true }),
    cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  },
  (t) => [
    uniqueIndex("assignment_one_active_uq")
      .on(t.providerId)
      .where(sql`state = 'IN_PROGRESS'`),
  ],
);

export const requestEvents = pgTable(
  "request_events",
  {
    id: id(),
    requestId: text("request_id").notNull(),
    actorId: text("actor_id"),
    actorRole: text("actor_role"),
    fromState: text("from_state"),
    toState: text("to_state").notNull(),
    message: text("message"),
    createdAt: createdAt(),
  },
  (t) => [index("events_req_idx").on(t.requestId, t.createdAt)],
);

/* ---------------- Favoriler & Değerlendirmeler ---------------- */
export const favorites = pgTable(
  "favorites",
  {
    id: id(),
    customerId: text("customer_id").notNull(),
    targetType: text("target_type").notNull(), // PROVIDER | FLEET
    targetId: text("target_id").notNull(),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("fav_uq").on(t.customerId, t.targetType, t.targetId)],
);

export const reviews = pgTable(
  "reviews",
  {
    id: id(),
    authorId: text("author_id").notNull(),
    targetType: text("target_type").notNull().default("PROVIDER"),
    targetId: text("target_id").notNull(),
    sourceId: text("source_id").notNull(), // service_request id
    rating: integer("rating").notNull(),
    catTime: integer("cat_time"),
    catCommunication: integer("cat_communication"),
    catCare: integer("cat_care"),
    catProfessionalism: integer("cat_professionalism"),
    body: text("body"),
    status: text("status").notNull().default("PUBLISHED"), // PUBLISHED | HIDDEN
    moderationReason: text("moderation_reason"),
    createdAt: createdAt(),
  },
  (t) => [
    uniqueIndex("review_uq").on(t.authorId, t.sourceId, t.targetType, t.targetId),
    index("review_target_idx").on(t.targetType, t.targetId),
    check("review_rating_ck", sql`${t.rating} BETWEEN 1 AND 5`),
  ],
);

/* ---------------- Bildirim (outbox) & Audit ---------------- */
export const notifications = pgTable(
  "notifications",
  {
    id: id(),
    userId: text("user_id").notNull(),
    title: text("title").notNull(),
    body: text("body"),
    link: text("link"),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index("notif_user_idx").on(t.userId, t.createdAt)],
);

export const auditLogs = pgTable("audit_logs", {
  id: id(),
  actorId: text("actor_id"),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  reason: text("reason"),
  meta: jsonb("meta").$type<Record<string, unknown>>(),
  createdAt: createdAt(),
});

/* ---------------- Restoran / Yemek ---------------- */
export const restaurants = pgTable(
  "restaurants",
  {
    id: id(),
    slug: text("slug").notNull().unique(),
    ownerUserId: text("owner_user_id").notNull(),
    name: text("name").notNull(),
    tagline: text("tagline"),
    description: text("description"),
    cuisines: text("cuisines").array().notNull(),
    tags: text("tags").array().notNull().default(sql`ARRAY[]::text[]`),
    coverUrl: text("cover_url"),
    logoHue: integer("logo_hue").notNull().default(15),
    deliveryAreas: text("delivery_areas").array().notNull(),
    isOpen: boolean("is_open").notNull().default(true),
    opensAt: text("opens_at").notNull().default("10:00"),
    closesAt: text("closes_at").notNull().default("23:00"),
    prepMinutes: integer("prep_minutes").notNull().default(25),
    deliveryFeeMinor: bigint("delivery_fee_minor", { mode: "number" }).notNull().default(2500),
    smallBasketFeeMinor: bigint("small_basket_fee_minor", { mode: "number" }).notNull().default(1500),
    smallBasketThresholdMinor: bigint("small_basket_threshold_minor", { mode: "number" }).notNull().default(25000),
    minBasketMinor: bigint("min_basket_minor", { mode: "number" }).notNull().default(15000),
    currency: text("currency").notNull().default("TRY"),
    ratingAvg: doublePrecision("rating_avg").notNull().default(0),
    ratingCount: integer("rating_count").notNull().default(0),
    isVerified: boolean("is_verified").notNull().default(false),
    phonePublic: text("phone_public"),
    website: text("website"),
    addressPublic: text("address_public"),
    hasVegan: boolean("has_vegan").notNull().default(false),
    hasHalal: boolean("has_halal").notNull().default(false),
    campaignTitle: text("campaign_title"),
    campaignDetail: text("campaign_detail"),
    // ACTIVE | SUSPENDED
    status: text("status").notNull().default("ACTIVE"),
    visibility: text("visibility").notNull().default("PUBLIC"),
    createdAt: createdAt(),
  },
  (t) => [index("restaurants_status_idx").on(t.status)],
);

export const menuCategories = pgTable(
  "menu_categories",
  {
    id: id(),
    restaurantId: text("restaurant_id").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    position: integer("position").notNull().default(0),
    isActive: boolean("is_active").notNull().default(true),
    timeFrom: text("time_from"),
    timeTo: text("time_to"),
    createdAt: createdAt(),
  },
  (t) => [index("cat_rest_idx").on(t.restaurantId, t.position)],
);

export const products = pgTable(
  "products",
  {
    id: id(),
    restaurantId: text("restaurant_id").notNull(),
    categoryId: text("category_id").notNull(),
    name: text("name").notNull(),
    description: text("description"),
    imageUrl: text("image_url"),
    priceMinor: bigint("price_minor", { mode: "number" }).notNull(),
    discountPriceMinor: bigint("discount_price_minor", { mode: "number" }),
    allergens: text("allergens").array().notNull().default(sql`ARRAY[]::text[]`),
    ingredients: text("ingredients"),
    calories: integer("calories"),
    prepMinutes: integer("prep_minutes"),
    stock: integer("stock").notNull().default(99),
    // DRAFT | PUBLISHED | OFF | ARCHIVED
    status: text("status").notNull().default("PUBLISHED"),
    isVegetarian: boolean("is_vegetarian").notNull().default(false),
    isVegan: boolean("is_vegan").notNull().default(false),
    isSpicy: boolean("is_spicy").notNull().default(false),
    currency: text("currency").notNull().default("TRY"),
    createdAt: createdAt(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("prod_cat_idx").on(t.categoryId), index("prod_rest_idx").on(t.restaurantId)],
);

export const productOptionGroups = pgTable(
  "product_option_groups",
  {
    id: id(),
    productId: text("product_id").notNull(),
    name: text("name").notNull(),
    required: boolean("required").notNull().default(false),
    minSelect: integer("min_select").notNull().default(0),
    maxSelect: integer("max_select").notNull().default(1),
    position: integer("position").notNull().default(0),
  },
  (t) => [index("optgrp_prod_idx").on(t.productId, t.position)],
);

export const productOptions = pgTable(
  "product_options",
  {
    id: id(),
    groupId: text("group_id").notNull(),
    name: text("name").notNull(),
    priceDeltaMinor: bigint("price_delta_minor", { mode: "number" }).notNull().default(0),
    isDefault: boolean("is_default").notNull().default(false),
    position: integer("position").notNull().default(0),
  },
  (t) => [index("opt_group_idx").on(t.groupId, t.position)],
);

export const carts = pgTable(
  "carts",
  {
    id: id(),
    customerId: text("customer_id").notNull().unique(),
    restaurantId: text("restaurant_id").notNull(),
    createdAt: createdAt(),
  },
  (t) => [index("cart_rest_idx").on(t.restaurantId)],
);

export const cartItems = pgTable(
  "cart_items",
  {
    id: id(),
    cartId: text("cart_id").notNull(),
    productId: text("product_id").notNull(),
    qty: integer("qty").notNull().default(1),
    optionIds: text("option_ids").array().notNull().default(sql`ARRAY[]::text[]`),
    note: text("note"),
    unitPriceMinor: bigint("unit_price_minor", { mode: "number" }).notNull(),
    nameSnapshot: text("name_snapshot").notNull(),
    optionsSnapshot: text("options_snapshot").notNull().default(""),
    createdAt: createdAt(),
  },
  (t) => [index("cartitem_cart_idx").on(t.cartId)],
);

export const orders = pgTable(
  "orders",
  {
    id: id(),
    code: text("code").notNull().unique(),
    customerId: text("customer_id").notNull(),
    restaurantId: text("restaurant_id").notNull(),
    status: text("status").notNull().default("ORDER_PLACED"),
    subtotalMinor: bigint("subtotal_minor", { mode: "number" }).notNull(),
    deliveryFeeMinor: bigint("delivery_fee_minor", { mode: "number" }).notNull(),
    serviceFeeMinor: bigint("service_fee_minor", { mode: "number" }).notNull().default(0),
    smallBasketFeeMinor: bigint("small_basket_fee_minor", { mode: "number" }).notNull().default(0),
    discountMinor: bigint("discount_minor", { mode: "number" }).notNull().default(0),
    tipMinor: bigint("tip_minor", { mode: "number" }).notNull().default(0),
    totalMinor: bigint("total_minor", { mode: "number" }).notNull(),
    currency: text("currency").notNull().default("TRY"),
    deliveryArea: text("delivery_area").notNull(),
    addressDetail: text("address_detail"),
    note: text("note"),
    paymentMethod: text("payment_method").notNull().default("SANDBOX_CARD"),
    // SANDBOX_CARD | CASH_ON_DELIVERY | SANDBOX_WALLET
    deliveryOtp: text("delivery_otp").notNull(),
    courierRequestId: text("courier_request_id"),
    courierPreference: text("courier_preference"), // AUTO | FAVORITE | MANUAL_PROVIDER | MANUAL_FLEET
    preferredProviderId: text("preferred_provider_id"),
    preferredFleetId: text("preferred_fleet_id"),
    etaMinutes: integer("eta_minutes"),
    idempotencyKey: text("idempotency_key").notNull().unique(),
    placedAt: timestamp("placed_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("orders_cust_idx").on(t.customerId, t.placedAt), index("orders_rest_idx").on(t.restaurantId, t.status)],
);

export const orderItems = pgTable("order_items", {
  id: id(),
  orderId: text("order_id").notNull(),
  productId: text("product_id").notNull(),
  nameSnapshot: text("name_snapshot").notNull(),
  optionsSnapshot: text("options_snapshot").notNull().default(""),
  qty: integer("qty").notNull(),
  unitPriceMinor: bigint("unit_price_minor", { mode: "number" }).notNull(),
  lineTotalMinor: bigint("line_total_minor", { mode: "number" }).notNull(),
  note: text("note"),
});

export const orderEvents = pgTable(
  "order_events",
  {
    id: id(),
    orderId: text("order_id").notNull(),
    fromState: text("from_state"),
    toState: text("to_state").notNull(),
    actorId: text("actor_id"),
    actorRole: text("actor_role"),
    message: text("message"),
    createdAt: createdAt(),
  },
  (t) => [index("orderev_idx").on(t.orderId, t.createdAt)],
);

/* ---------------- Medya (private -> moderasyon -> public) ---------------- */
export const mediaPosts = pgTable(
  "media_posts",
  {
    id: id(),
    ownerType: text("owner_type").notNull(), // PROVIDER | FLEET | RESTAURANT
    ownerId: text("owner_id").notNull(),
    userId: text("user_id").notNull(),
    caption: text("caption"),
    mediaType: text("media_type").notNull().default("IMAGE"), // IMAGE | VIDEO | TEXT
    // DRAFT | PENDING_REVIEW | APPROVED | PUBLISHED | REJECTED | ARCHIVED
    status: text("status").notNull().default("PENDING_REVIEW"),
    privatePath: text("private_path"),
    publicUrl: text("public_url"),
    mime: text("mime"),
    bytes: integer("bytes"),
    width: integer("width"),
    height: integer("height"),
    durationS: integer("duration_s"),
    sha256: text("sha256"),
    exifStripped: boolean("exif_stripped").notNull().default(false),
    scanned: boolean("scanned").notNull().default(false),
    rightsDeclaration: boolean("rights_declaration").notNull().default(false),
    viewCount: integer("view_count").notNull().default(0),
    favoriteCount: integer("favorite_count").notNull().default(0),
    reportCount: integer("report_count").notNull().default(0),
    moderationReason: text("moderation_reason"),
    moderationCaseId: text("moderation_case_id"),
    publishedAt: timestamp("published_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index("media_owner_idx").on(t.ownerType, t.ownerId, t.status)],
);

export const moderationCases = pgTable(
  "moderation_cases",
  {
    id: id(),
    kind: text("kind").notNull(), // MEDIA | REVIEW | PROFILE | REPORT | APPEAL
    targetType: text("target_type").notNull(),
    targetId: text("target_id").notNull(),
    // OPEN | APPROVED | REJECTED | HIDDEN | ARCHIVED
    status: text("status").notNull().default("OPEN"),
    reason: text("reason"),
    policyRef: text("policy_ref"),
    decidedBy: text("decided_by"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index("modcase_kind_idx").on(t.kind, t.status)],
);

export const contentReports = pgTable(
  "content_reports",
  {
    id: id(),
    reporterId: text("reporter_id").notNull(),
    targetType: text("target_type").notNull(), // PROVIDER | FLEET | RESTAURANT | REVIEW | MEDIA
    targetId: text("target_id").notNull(),
    // SPAM | HARASSMENT | PII | MISLEADING | ILLEGAL | SAFETY | COPYRIGHT | OTHER
    reason: text("reason").notNull(),
    detail: text("detail"),
    status: text("status").notNull().default("OPEN"), // OPEN | RESOLVED | DISMISSED
    caseId: text("case_id"),
    createdAt: createdAt(),
  },
  (t) => [index("report_status_idx").on(t.status), uniqueIndex("report_uq").on(t.reporterId, t.targetType, t.targetId, t.reason)],
);

/* ---------------- Değerlendirme: yanıt / itiraz / sürüm ---------------- */
export const reviewResponses = pgTable(
  "review_responses",
  {
    id: id(),
    reviewId: text("review_id").notNull().unique(),
    responderId: text("responder_id").notNull(),
    responderRole: text("responder_role").notNull(),
    body: text("body").notNull(),
    status: text("status").notNull().default("PUBLISHED"), // PUBLISHED | UNDER_REVIEW | HIDDEN
    createdAt: createdAt(),
  },
  (t) => [index("reviewresp_idx").on(t.reviewId)],
);

export const reviewRevisions = pgTable("review_revisions", {
  id: id(),
  reviewId: text("review_id").notNull(),
  rating: integer("rating").notNull(),
  body: text("body"),
  editedBy: text("edited_by").notNull(),
  createdAt: createdAt(),
});

export const reviewAppeals = pgTable(
  "review_appeals",
  {
    id: id(),
    reviewId: text("review_id").notNull(),
    appellantId: text("appellant_id").notNull(),
    appellantRole: text("appellant_role").notNull(),
    reason: text("reason").notNull(),
    // OPEN | ACCEPTED | REJECTED
    status: text("status").notNull().default("OPEN"),
    decisionNote: text("decision_note"),
    decidedBy: text("decided_by"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index("appeal_status_idx").on(t.status), uniqueIndex("appeal_uq").on(t.reviewId, t.appellantId)],
);

/* ---------------- Başvurular ---------------- */
export const partnerApplications = pgTable(
  "partner_applications",
  {
    id: id(),
    kind: text("kind").notNull(), // RESTAURANT | FLEET
    name: text("name").notNull(),
    contactName: text("contact_name").notNull(),
    email: text("email").notNull(),
    phone: text("phone"),
    city: text("city").notNull(),
    areas: text("areas").array().notNull().default(sql`ARRAY[]::text[]`),
    description: text("description"),
    taxNo: text("tax_no"),
    // PENDING | APPROVED | REJECTED | NEEDS_INFO
    status: text("status").notNull().default("PENDING"),
    reviewerId: text("reviewer_id"),
    decisionNote: text("decision_note"),
    decidedAt: timestamp("decided_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index("app_status_idx").on(t.kind, t.status)],
);

/* ---------------- Bağlama duyarlı mesajlaşma ---------------- */
export const conversations = pgTable(
  "conversations",
  {
    id: id(),
    // REQUEST (görev/sipariş) | FLEET_INTERNAL (filo içi)
    contextType: text("context_type").notNull(),
    contextId: text("context_id").notNull(),
    pairKey: text("pair_key").notNull(),
    // ACTIVE | CLOSED
    status: text("status").notNull().default("ACTIVE"),
    closedReason: text("closed_reason"),
    lastMessageAt: timestamp("last_message_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("conv_context_pair_uq").on(t.contextType, t.contextId, t.pairKey), index("conv_last_idx").on(t.lastMessageAt)],
);

export const conversationParticipants = pgTable(
  "conversation_participants",
  {
    id: id(),
    conversationId: text("conversation_id").notNull(),
    userId: text("user_id").notNull(),
    role: text("role").notNull(),
    lastReadAt: timestamp("last_read_at", { withTimezone: true }),
    muted: boolean("muted").notNull().default(false),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("conv_part_uq").on(t.conversationId, t.userId), index("conv_part_user_idx").on(t.userId)],
);

export const messages = pgTable(
  "messages",
  {
    id: id(),
    conversationId: text("conversation_id").notNull(),
    senderId: text("sender_id"), // SYSTEM_NOTICE için null
    // TEXT | LOCATION_PIN | SYSTEM_NOTICE
    type: text("type").notNull().default("TEXT"),
    body: text("body").notNull(),
    masked: boolean("masked").notNull().default(false),
    isRead: boolean("is_read").notNull().default(false),
    deliveredAt: timestamp("delivered_at", { withTimezone: true }),
    readAt: timestamp("read_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [index("msg_conv_idx").on(t.conversationId, t.createdAt)],
);

export type Conversation = typeof conversations.$inferSelect;
export type ConversationParticipant = typeof conversationParticipants.$inferSelect;
export type MessageRow = typeof messages.$inferSelect;

/* ---------------- Dashboard: oturum, vardiya, filo ve destek ---------------- */
export const authSessions = pgTable(
  "auth_sessions",
  {
    tokenHash: text("token_hash").primaryKey(),
    userId: text("user_id").notNull(),
    createdAt: createdAt(),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  },
  (t) => [index("auth_sessions_user_idx").on(t.userId), index("auth_sessions_expires_idx").on(t.expiresAt)],
);

/** PIN başarısız denemeleri: IP hash'i + genel sayaç; yatay ölçeklemede de kilit kalıcıdır. */
export const authPinAttempts = pgTable("auth_pin_attempts", {
  key: text("key").primaryKey(),
  failures: integer("failures").notNull().default(0),
  windowStartedAt: timestamp("window_started_at", { withTimezone: true }).notNull().defaultNow(),
  cooldownUntil: timestamp("cooldown_until", { withTimezone: true }),
});

export const providerShifts = pgTable(
  "provider_shifts",
  {
    id: id(),
    providerId: text("provider_id").notNull(),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    endedAt: timestamp("ended_at", { withTimezone: true }),
  },
  (t) => [
    index("provider_shifts_provider_start_idx").on(t.providerId, t.startedAt),
    uniqueIndex("provider_shifts_one_open_idx").on(t.providerId).where(sql`${t.endedAt} IS NULL`),
  ],
);

export const fleetInvitations = pgTable(
  "fleet_invitations",
  {
    id: id(),
    fleetId: text("fleet_id").notNull(),
    providerId: text("provider_id").notNull(),
    createdBy: text("created_by").notNull(),
    status: text("status").notNull().default("PENDING"), // PENDING | ACCEPTED | DECLINED | CANCELLED
    createdAt: createdAt(),
    respondedAt: timestamp("responded_at", { withTimezone: true }),
  },
  (t) => [
    index("fleet_invitations_fleet_idx").on(t.fleetId, t.status),
    index("fleet_invitations_provider_idx").on(t.providerId, t.status),
    uniqueIndex("fleet_invitations_pending_idx").on(t.fleetId, t.providerId).where(sql`${t.status} = 'PENDING'`),
  ],
);

export const fleetDutySlots = pgTable(
  "fleet_duty_slots",
  {
    id: id(),
    fleetId: text("fleet_id").notNull(),
    providerId: text("provider_id").notNull(),
    vehicleType: text("vehicle_type").notNull(),
    vehicleLabel: text("vehicle_label"),
    startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
    endsAt: timestamp("ends_at", { withTimezone: true }).notNull(),
    status: text("status").notNull().default("PLANNED"), // PLANNED | CANCELLED
    createdBy: text("created_by").notNull(),
    createdAt: createdAt(),
  },
  (t) => [index("fleet_duty_fleet_start_idx").on(t.fleetId, t.startsAt), index("fleet_duty_provider_start_idx").on(t.providerId, t.startsAt)],
);

export const supportCases = pgTable(
  "support_cases",
  {
    id: id(),
    customerId: text("customer_id").notNull(),
    sourceType: text("source_type").notNull(), // REQUEST | ORDER
    sourceId: text("source_id").notNull(),
    category: text("category").notNull(), // DELIVERY | OTP | CANCELLATION | OTHER
    detail: text("detail").notNull(),
    status: text("status").notNull().default("OPEN"), // OPEN | IN_REVIEW | RESOLVED | REJECTED
    resolution: text("resolution"),
    resolvedBy: text("resolved_by"),
    createdAt: createdAt(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
    resolvedAt: timestamp("resolved_at", { withTimezone: true }),
  },
  (t) => [index("support_customer_idx").on(t.customerId, t.createdAt), index("support_status_idx").on(t.status, t.createdAt)],
);

/* ---------------- Finans, evrak ve platform ayarları ---------------- */
export const platformSettings = pgTable("platform_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedBy: text("updated_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

/** Kurye hakediş defteri: teslim kodu doğrulanınca tahakkuk eder. Gerçek para transferi yapılmaz. */
export const providerEarnings = pgTable(
  "provider_earnings",
  {
    id: id(),
    providerId: text("provider_id").notNull(),
    fleetId: text("fleet_id"),
    requestId: text("request_id").notNull().unique(),
    grossMinor: bigint("gross_minor", { mode: "number" }).notNull(),
    commissionBps: integer("commission_bps").notNull(),
    commissionMinor: bigint("commission_minor", { mode: "number" }).notNull(),
    netMinor: bigint("net_minor", { mode: "number" }).notNull(),
    currency: text("currency").notNull().default("TRY"),
    // ACCRUED | APPROVED_FOR_PAYOUT | PAID
    status: text("status").notNull().default("ACCRUED"),
    approvedBy: text("approved_by"),
    approvedAt: timestamp("approved_at", { withTimezone: true }),
    payoutId: text("payout_id"),
    earnedAt: timestamp("earned_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("earnings_provider_idx").on(t.providerId, t.earnedAt), index("earnings_status_idx").on(t.status), index("earnings_payout_idx").on(t.payoutId)],
);

/** Kurye evrakları: dosya yalnızca özel depoda; herkese açık profilde asla gösterilmez. */
export const providerDocuments = pgTable(
  "provider_documents",
  {
    id: id(),
    providerId: text("provider_id").notNull(),
    // LICENSE | REGISTRATION | CRIMINAL_RECORD
    docType: text("doc_type").notNull(),
    // SUBMITTED | APPROVED | REJECTED
    status: text("status").notNull().default("SUBMITTED"),
    privatePath: text("private_path").notNull(),
    mime: text("mime").notNull(),
    reviewNote: text("review_note"),
    reviewedBy: text("reviewed_by"),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("provider_doc_type_uq").on(t.providerId, t.docType), index("provider_doc_status_idx").on(t.status)],
);

/**
 * Ödeme hesabı (IBAN). Yalnızca hak sahibi ve SUPER_ADMIN için; herkese açık profillerde ve
 * normal API serializer'larda asla dönmez. Sunucu yalnızca maskeli hali (TR12 **** 1234) gösterir.
 */
export const payoutAccounts = pgTable(
  "payout_accounts",
  {
    id: id(),
    // COURIER (providerId) | FLEET (fleetId)
    beneficiaryType: text("beneficiary_type").notNull(),
    beneficiaryId: text("beneficiary_id").notNull(),
    ibanPrivate: text("iban_private").notNull(),
    holderName: text("holder_name").notNull(),
    updatedBy: text("updated_by"),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("payout_account_beneficiary_uq").on(t.beneficiaryType, t.beneficiaryId)],
);

/**
 * Ödeme emri: periyot bazında hakediş kalemlerini gruplar.
 * Statü akışı: PENDING → PAID (transfer kaydı) / HOLD (geçici blok). Gerçek banka entegrasyonu
 * olmadığı için PAID, "ödeme emri verildi ve kayda alındı" anlamına gelir; bankaya para göndermez.
 */
export const payouts = pgTable(
  "payouts",
  {
    id: id(),
    beneficiaryType: text("beneficiary_type").notNull(), // COURIER | FLEET
    beneficiaryId: text("beneficiary_id").notNull(),
    period: text("period").notNull(), // Örn. 2026-W44
    periodStart: timestamp("period_start", { withTimezone: true }).notNull(),
    periodEnd: timestamp("period_end", { withTimezone: true }).notNull(),
    totalOrders: integer("total_orders").notNull(),
    grossMinor: bigint("gross_minor", { mode: "number" }).notNull(),
    commissionMinor: bigint("commission_minor", { mode: "number" }).notNull(),
    netMinor: bigint("net_minor", { mode: "number" }).notNull(),
    currency: text("currency").notNull().default("TRY"),
    // PENDING | PAID | HOLD
    status: text("status").notNull().default("PENDING"),
    ibanMasked: text("iban_masked"),
    reference: text("reference"),
    note: text("note"),
    processedBy: text("processed_by"),
    processedAt: timestamp("processed_at", { withTimezone: true }),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("payout_period_uq").on(t.beneficiaryType, t.beneficiaryId, t.period), index("payout_status_idx").on(t.status, t.createdAt)],
);

export type PayoutAccount = typeof payoutAccounts.$inferSelect;
export type Payout = typeof payouts.$inferSelect;
export type ProviderEarning = typeof providerEarnings.$inferSelect;
export type ProviderDocument = typeof providerDocuments.$inferSelect;

export type AuthSession = typeof authSessions.$inferSelect;
export type ProviderShift = typeof providerShifts.$inferSelect;
export type FleetInvitation = typeof fleetInvitations.$inferSelect;
export type FleetDutySlot = typeof fleetDutySlots.$inferSelect;
export type SupportCase = typeof supportCases.$inferSelect;

export type User = typeof users.$inferSelect;
export type Restaurant = typeof restaurants.$inferSelect;
export type Order = typeof orders.$inferSelect;
export type Product = typeof products.$inferSelect;
export type MediaPost = typeof mediaPosts.$inferSelect;
export type ReviewRow = typeof reviews.$inferSelect;
export type Provider = typeof providers.$inferSelect;
export type Fleet = typeof fleets.$inferSelect;
export type ServiceRequest = typeof serviceRequests.$inferSelect;
export type Candidate = typeof matchingCandidates.$inferSelect;
export type Assignment = typeof assignments.$inferSelect;
