"use client";

import Link from "next/link";

export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="tr">
      <body style={{ margin: 0, background: "#0e1324", color: "#fff", fontFamily: "Inter, system-ui, sans-serif" }}>
        <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 }}>
          <div style={{ maxWidth: 520, textAlign: "center" }}>
            <div style={{ fontSize: 34 }}>🛠️</div>
            <h1 style={{ fontSize: 28, fontWeight: 900, margin: "12px 0 6px" }}>Bir şeyler ters gitti</h1>
            <p style={{ color: "rgba(255,255,255,0.65)", fontSize: 14, lineHeight: 1.6 }}>
              Uygulama beklenmeyen bir hata aldı. Verileriniz güvende; lütfen tekrar deneyin. Sorun sürerse destek ekibine başvurun.
            </p>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 20, flexWrap: "wrap" }}>
              <button onClick={reset} style={{ background: "#ff5b23", color: "#fff", border: 0, borderRadius: 999, padding: "11px 22px", fontWeight: 800, cursor: "pointer" }}>Tekrar dene</button>
              <Link href="/" style={{ background: "transparent", color: "#fff", border: "1px solid rgba(255,255,255,0.25)", borderRadius: 999, padding: "11px 22px", fontWeight: 800, textDecoration: "none" }}>Ana sayfaya dön</Link>
              <Link href="/destek" style={{ background: "transparent", color: "#fff", border: "1px solid rgba(255,255,255,0.25)", borderRadius: 999, padding: "11px 22px", fontWeight: 800, textDecoration: "none" }}>Destek al</Link>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
