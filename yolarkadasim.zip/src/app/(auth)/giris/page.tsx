import Link from "next/link";
import { ArrowLeft, Bike, Building2, CircleCheck, LockKeyhole, ShieldCheck, ShoppingBag } from "lucide-react";
import { Logo } from "@/components/Header";
import { AuthGate } from "@/components/auth/AuthGate";
import { getDemoAccountsAction } from "@/actions/auth-mode-actions";
import type { AccessMode } from "@/lib/auth-mode-types";
import { getAccessMode, pinConfigured, pinDisabledReason } from "@/lib/auth-mode";
import { dashboardHome } from "@/lib/dashboard-config";
import { getPublicSession } from "@/lib/session";

export const metadata = { title: "Giriş Yap — YolArkadaşı", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

function safeNext(next: string | undefined): string | undefined {
  if (!next || !next.startsWith("/") || next.startsWith("//") || next.includes("\\") || next.startsWith("/giris")) return undefined;
  return next;
}

export default async function Giris({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  // Mod ve demo listesi yalnızca sunucuda belirlenir; istemciye sır veya env değeri gönderilmez.
  const mode: AccessMode = getAccessMode();
  const current = await getPublicSession();
  const demoAccounts = mode === "0" ? await getDemoAccountsAction() : [];

  return (
    <main className="road-pattern-dark relative min-h-screen overflow-hidden bg-ink text-white">
      <div className="pointer-events-none absolute -left-32 top-16 h-96 w-96 rounded-full bg-signal/20 blur-[130px]" />
      <div className="pointer-events-none absolute -right-32 bottom-10 h-96 w-96 rounded-full bg-signal/10 blur-[130px]" />

      <div className="container-x relative grid min-h-screen items-center gap-10 py-10 lg:grid-cols-[1fr_460px]">
        <section className="flex flex-col justify-between gap-8">
          <div className="flex items-center justify-between gap-4">
            <Logo />
            <Link href="/" className="inline-flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3.5 py-2 text-xs font-bold text-white/80 transition hover:border-signal/40 hover:text-white">
              <ArrowLeft size={14} className="text-signal" aria-hidden="true" /> Ana siteye dön
            </Link>
          </div>

          <div className="max-w-lg">
            <div className="eyebrow">TEK KAPI · AKILLI YÖNLENDİRME</div>
            <h1 className="h-display mt-4 text-4xl sm:text-6xl">Her yolun<br /><span className="text-signal">tek girişi var.</span></h1>
            <p className="mt-5 text-sm leading-relaxed text-white/65 sm:text-base">
              Giriş yöntemi ortam yapılandırmasıyla belirlenir: demo hesap seçimi, e-posta &amp; parola veya yönetici PIN&apos;i.
              Rol seçmenize gerek kalmaz; doğru panele otomatik yönlendirilirsiniz.
            </p>
            <div className="mt-7 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { Icon: ShoppingBag, label: "Müşteri", sub: "/dashboard/musteri" },
                { Icon: Bike, label: "Kurye", sub: "/dashboard/kurye" },
                { Icon: Building2, label: "Filo", sub: "/dashboard/filo" },
                { Icon: ShieldCheck, label: "Yönetim", sub: "/admin" },
              ].map(({ Icon, label, sub }) => (
                <div key={label} className="rounded-2xl bg-white/[0.05] p-3 ring-1 ring-white/10">
                  <Icon size={17} className="text-signal" aria-hidden="true" />
                  <span className="mt-2 block text-xs font-extrabold">{label}</span>
                  <span className="block font-mono text-[10px] text-white/40">{sub}</span>
                </div>
              ))}
            </div>
          </div>

          <p className="flex items-center gap-2 text-xs text-white/45">
            <LockKeyhole size={14} className="shrink-0 text-signal" aria-hidden="true" />
            Oturum çerezinde rol veya kullanıcı kimliği taşınmaz; yalnızca SHA-256 özeti veritabanında saklanan opak token kullanılır.
          </p>
        </section>

        <section className="w-full">
          {current.authenticated && (
            <div className="mb-4 flex items-start gap-2.5 rounded-2xl border border-white/15 bg-white/[0.06] p-3.5 text-xs">
              <CircleCheck size={16} className="mt-0.5 shrink-0 text-signal" aria-hidden="true" />
              <span>
                <b>{current.user.name}</b> olarak oturumunuz açık.{" "}
                <Link href={dashboardHome(current.user.role)} className="font-bold text-signal underline">Panele geç →</Link>
              </span>
            </div>
          )}
          <AuthGate
            mode={mode}
            demoAccounts={demoAccounts.map((a) => ({ id: a.id, name: a.name, role: a.role }))}
            pinReady={pinConfigured()}
            pinReason={pinDisabledReason()}
            next={safeNext(one(sp.next))}
          />
        </section>
      </div>
    </main>
  );
}
