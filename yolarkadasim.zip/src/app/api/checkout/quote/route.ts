import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { checkoutQuote } from "@/lib/food";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export const Schema = z.object({
  deliveryArea: z.string().min(2),
  addressDetail: z.string().max(300).optional(),
  note: z.string().max(300).optional(),
  tipMinor: z.number().int().min(0).max(50000).optional(),
  paymentMethod: z.enum(["SANDBOX_CARD", "CASH_ON_DELIVERY"]).optional(),
});

export async function POST(req: Request) {
  return handle(async () => checkoutQuote(await getSession(), await parseBody(req, Schema)));
}
