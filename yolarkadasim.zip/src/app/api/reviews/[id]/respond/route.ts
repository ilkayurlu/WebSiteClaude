import { z } from "zod";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { respondToReview } from "@/lib/review-ops";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`resp:${s.user.id}`, 20, 60_000);
    const { body } = await parseBody(req, z.object({ body: z.string().trim().min(10, "Yanıt en az 10 karakter.").max(1500) }));
    return respondToReview(s, (await params).id, body);
  });
}
