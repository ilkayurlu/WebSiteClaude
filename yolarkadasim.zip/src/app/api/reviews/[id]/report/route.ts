import { z } from "zod";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { reportReview } from "@/lib/review-ops";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`rrep:${s.user.id}`, 15, 60_000);
    const b = await parseBody(req, z.object({ reason: z.enum(["SPAM", "HARASSMENT", "PII", "MISLEADING", "ILLEGAL", "OTHER"]), detail: z.string().max(500).optional() }));
    return reportReview(s, (await params).id, b.reason, b.detail);
  });
}
