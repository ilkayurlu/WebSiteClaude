import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { editOwnReview } from "@/lib/review-ops";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const b = await parseBody(req, z.object({ rating: z.number().int().min(1).max(5).optional(), body: z.string().max(1000).optional() }));
    return editOwnReview(s, (await params).id, b);
  });
}
