import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { appealReview } from "@/lib/review-ops";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const { reason } = await parseBody(req, z.object({ reason: z.string().trim().min(20, "İtiraz gerekçesi en az 20 karakter.").max(1500) }));
    return appealReview(s, (await params).id, reason);
  });
}
