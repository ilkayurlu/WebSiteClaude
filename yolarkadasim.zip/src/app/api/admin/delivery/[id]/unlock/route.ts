import { z } from "zod";
import { unlockDeliveryCode } from "@/lib/delivery";
import { assertSameOrigin, handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    assertSameOrigin(req);
    const b = await parseBody(req, z.object({ reason: z.string().max(500) }));
    return unlockDeliveryCode(await getSession(), (await params).id, b.reason);
  });
}
