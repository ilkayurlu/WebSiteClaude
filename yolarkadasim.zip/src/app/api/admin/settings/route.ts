import { z } from "zod";
import { updateCommission } from "@/lib/admin-actions";
import { assertSameOrigin, handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function PATCH(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    const b = await parseBody(req, z.object({ commissionBps: z.number().int("Oran tam sayı (baz puan) olmalı.").min(0, "Komisyon %0 ile %40 arasında olmalı.").max(4000, "Komisyon %0 ile %40 arasında olmalı."), reason: z.string().max(500) }));
    return updateCommission(await getSession(), b.commissionBps, b.reason);
  });
}
