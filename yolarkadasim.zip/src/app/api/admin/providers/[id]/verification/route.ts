import { z } from "zod";
import { decideProviderVerification } from "@/lib/admin-actions";
import { assertSameOrigin, handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    assertSameOrigin(req);
    const b = await parseBody(req, z.object({ action: z.enum(["APPROVE_ALL", "REJECT_ALL"]), note: z.string().max(500).optional() }));
    return decideProviderVerification(await getSession(), (await params).id, b.action, b.note);
  });
}
