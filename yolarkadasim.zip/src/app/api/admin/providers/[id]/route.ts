import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { providers } from "@/db/schema";
import { audit } from "@/lib/engine";
import { handle, HttpError, parseBody } from "@/lib/http";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("ADMIN");
    const { action, reason } = await parseBody(req, z.object({ action: z.enum(["suspend", "reinstate", "verify"]), reason: z.string().trim().min(5, "Gerekçe zorunlu (en az 5 karakter).") }));
    const id = (await params).id;
    const [p] = await db.select().from(providers).where(eq(providers.id, id)).limit(1);
    if (!p) throw new HttpError(404, "Sağlayıcı bulunamadı.");
    const patch = action === "suspend" ? { status: "SUSPENDED" } : action === "reinstate" ? { status: "OFFLINE" } : { isVerified: true };
    await db.update(providers).set(patch).where(eq(providers.id, id));
    await audit(db, s.user.id, `provider.${action}`, "provider", id, reason);
    return { ok: true };
  });
}
