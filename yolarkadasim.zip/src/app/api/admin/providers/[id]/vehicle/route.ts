import { z } from "zod";
import { changeProviderVehicle } from "@/lib/admin-actions";
import { assertSameOrigin, handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    assertSameOrigin(req);
    const b = await parseBody(req, z.object({ vehicleType: z.enum(["BICYCLE", "MOTORCYCLE", "CAR", "VAN", "TRUCK", "COLD_CHAIN_VAN", "MINIBUS"]), vehicleLabel: z.string().max(60).default(""), reason: z.string().max(500) }));
    return changeProviderVehicle(await getSession(), (await params).id, b.vehicleType, b.vehicleLabel, b.reason);
  });
}
