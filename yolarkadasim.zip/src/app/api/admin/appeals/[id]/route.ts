import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { decideAppeal } from "@/lib/review-ops";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("ADMIN");
    const b = await parseBody(req, z.object({ decision: z.enum(["ACCEPTED", "REJECTED"]), note: z.string().trim().min(5, "Karar gerekçesi zorunlu.").max(500) }));
    return decideAppeal(s, (await params).id, b.decision, b.note);
  });
}
