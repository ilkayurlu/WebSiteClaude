import { z } from "zod";
import { assertSameOrigin, handle, parseBody } from "@/lib/http";
import { periodOf, processPayout } from "@/lib/payouts";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

/** Geriye dönük uyumluluk: haftalık onay isteği yeni ödeme emri akışına yönlendirilir (SUPER_ADMIN). */
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    const s = await getSession();
    const b = await parseBody(req, z.object({ providerId: z.uuid(), weekStart: z.iso.datetime({ offset: true }), note: z.string().max(300).optional(), beneficiaryType: z.enum(["COURIER", "FLEET"]).default("COURIER") }));
    const period = periodOf(new Date(b.weekStart), "week");
    const r = await processPayout(s, { beneficiaryType: b.beneficiaryType, beneficiaryId: b.providerId, period: period.label, granularity: "week" }, b.note);
    return { ok: true, reference: r.reference, netMinor: r.netMinor };
  });
}
