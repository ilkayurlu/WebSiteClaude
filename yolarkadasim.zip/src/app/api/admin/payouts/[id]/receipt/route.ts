import { eq } from "drizzle-orm";
import { db } from "@/db";
import { fleets, payouts, providers, users } from "@/db/schema";
import { handle, HttpError } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

/** Dekont (düz metin). Resmi fatura değildir; IBAN maskeli, kişisel veri yok. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const { id } = await params;
    const [p] = await db.select().from(payouts).where(eq(payouts.id, id)).limit(1);
    if (!p) throw new HttpError(404, "Dekont bulunamadı.");
    const owner = p.beneficiaryType === "FLEET"
      ? (await db.select({ userId: fleets.ownerUserId, name: fleets.name }).from(fleets).where(eq(fleets.id, p.beneficiaryId)).limit(1))[0]
      : (await db.select({ userId: providers.userId, name: providers.displayName }).from(providers).where(eq(providers.id, p.beneficiaryId)).limit(1))[0];
    if (s.user.role !== "SUPER_ADMIN" && owner?.userId !== s.user.id) throw new HttpError(403, "Bu dekonta erişim yetkiniz yok.");
    if (p.status !== "PAID") throw new HttpError(409, "Dekont yalnızca ödenen kayıtlar için hazırlanır.");
    const [by] = p.processedBy ? await db.select({ name: users.name }).from(users).where(eq(users.id, p.processedBy)).limit(1) : [];
    const fmt = (m: number) => (m / 100).toFixed(2) + " TL";
    const lines = [
      "YOLARKADAŞI — HAKEDİŞ ÖDEME DEKONTU",
      "(Resmi fatura/e-fatura değildir)",
      "",
      `Referans      : ${p.reference ?? "-"}`,
      `Hak sahibi    : ${owner?.name ?? "-"} (${p.beneficiaryType === "FLEET" ? "Filo" : "Kurye"})`,
      `Dönem         : ${p.period}`,
      `Görev adedi   : ${p.totalOrders}`,
      `Brüt tutar    : ${fmt(p.grossMinor)}`,
      `Komisyon      : -${fmt(p.commissionMinor)}`,
      `Net ödenecek  : ${fmt(p.netMinor)}`,
      `IBAN (maskeli): ${p.ibanMasked ?? "-"}`,
      `İşleyen       : ${by?.name ?? "-"}`,
      `Tarih         : ${p.processedAt?.toISOString() ?? "-"}`,
      p.note ? `Not           : ${p.note}` : "",
      "",
      "Banka transferi muhasebe birimi tarafından bu referansla yürütülür.",
    ].filter((l) => l !== null);
    return new Response(lines.join("\n"), { headers: { "Content-Type": "text/plain; charset=utf-8", "Content-Disposition": `inline; filename="dekont-${p.reference ?? p.id}.txt"`, "Cache-Control": "private, no-store" } });
  });
}
