import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { moderateMedia } from "@/lib/media";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("ADMIN");
    const b = await parseBody(req, z.object({ action: z.enum(["approve", "reject", "hide", "archive"]), reason: z.string().trim().min(5, "Gerekçe zorunlu (en az 5 karakter).").max(500), policyRef: z.string().max(12).optional() }));
    return moderateMedia(s, (await params).id, b.action, b.reason, b.policyRef);
  });
}
