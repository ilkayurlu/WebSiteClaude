import { readFile } from "node:fs/promises";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaPosts } from "@/db/schema";
import { HttpError, handle } from "@/lib/http";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

/** Özel depolamadaki dosya: yalnızca moderasyon yetkisi olan oturuma, kısa ömürlü ve no-store ile sunulur. */
export async function GET(_r: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    await requireRole("ADMIN");
    const id = (await params).id;
    const [post] = await db.select().from(mediaPosts).where(eq(mediaPosts.id, id)).limit(1);
    if (!post?.privatePath) throw new HttpError(404, "Dosya bulunamadı.");
    const abs = path.resolve(process.cwd(), post.privatePath);
    if (!abs.startsWith(path.join(process.cwd(), "storage", "private"))) throw new HttpError(403, "Geçersiz dosya yolu.");
    const buf = await readFile(abs);
    return new Response(buf, {
      headers: {
        "Content-Type": post.mime ?? "application/octet-stream",
        "Cache-Control": "private, no-store, max-age=0",
        "Content-Disposition": `inline; filename="${post.id}"`,
      },
    });
  });
}
