import { z } from "zod";
import { adminAssignProvider } from "@/lib/engine";
import { assertSameOrigin, handle, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    assertSameOrigin(req);
    const s = await getSession();
    rateLimit(`manual-assign:${s.user.id}`, 30, 60_000);
    const b = await parseBody(req, z.object({ providerId: z.uuid("Kurye seçin."), reason: z.string().max(500) }));
    return adminAssignProvider(s, (await params).id, b.providerId, b.reason);
  });
}
