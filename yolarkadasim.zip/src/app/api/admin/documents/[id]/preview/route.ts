import { readFile } from "node:fs/promises";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { providerDocuments } from "@/db/schema";
import { handle, HttpError } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

/** Evrak önizleme: yalnızca platform yöneticisi; önbelleğe alınmaz, script çalıştırılamaz. */
export async function GET(_r: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    if (s.user.role !== "SUPER_ADMIN") throw new HttpError(403, "Evraklar yalnızca platform yöneticisine açıktır.");
    const [doc] = await db.select().from(providerDocuments).where(eq(providerDocuments.id, (await params).id)).limit(1);
    if (!doc) throw new HttpError(404, "Evrak bulunamadı.");
    const root = path.join(process.cwd(), "storage", "private");
    const abs = path.resolve(/* turbopackIgnore: true */ process.cwd(), doc.privatePath);
    if (!abs.startsWith(root)) throw new HttpError(403, "Geçersiz dosya yolu.");
    const buf = await readFile(abs);
    return new Response(buf, { headers: { "Content-Type": doc.mime, "Cache-Control": "private, no-store", "Content-Security-Policy": "sandbox; default-src 'none'; style-src 'unsafe-inline'", "X-Content-Type-Options": "nosniff" } });
  });
}
