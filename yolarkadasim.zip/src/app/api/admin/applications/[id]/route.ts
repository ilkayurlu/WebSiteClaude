import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { notifications, partnerApplications } from "@/db/schema";
import { audit } from "@/lib/engine";
import { handle, HttpError, parseBody } from "@/lib/http";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("ADMIN");
    const b = await parseBody(req, z.object({ action: z.enum(["APPROVED", "REJECTED", "NEEDS_INFO"]), note: z.string().trim().min(5, "Karar notu zorunlu.").max(500) }));
    const id = (await params).id;
    const [a] = await db.select().from(partnerApplications).where(eq(partnerApplications.id, id)).limit(1);
    if (!a) throw new HttpError(404, "Başvuru bulunamadı.");
    if (a.status !== "PENDING") throw new HttpError(409, "Bu başvuru zaten karara bağlanmış.");
    await db.update(partnerApplications).set({ status: b.action, decisionNote: b.note, reviewerId: s.user.id, decidedAt: new Date() }).where(eq(partnerApplications.id, id));
    await audit(db, s.user.id, `application.${b.action.toLowerCase()}`, "partner_application", id, b.note);
    await db.insert(notifications).values({ userId: s.user.id, title: `Başvuru ${b.action === "APPROVED" ? "onaylandı" : b.action === "REJECTED" ? "reddedildi" : "bilgi bekliyor"}`, body: `${a.name}: ${b.note}`, link: "/admin/basvurular" });
    return { ok: true };
  });
}
