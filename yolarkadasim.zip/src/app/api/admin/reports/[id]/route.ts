import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { resolveReport } from "@/lib/review-ops";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("ADMIN");
    const b = await parseBody(req, z.object({ action: z.enum(["RESOLVED", "DISMISSED"]), note: z.string().trim().min(5, "Karar notu zorunlu.").max(500) }));
    return resolveReport(s, (await params).id, b.action, b.note);
  });
}
