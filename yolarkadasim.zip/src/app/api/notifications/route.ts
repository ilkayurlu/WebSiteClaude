import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { handle } from "@/lib/http";
import { getNotifications } from "@/lib/queries";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET() {
  return handle(async () => {
    const s = await getSession();
    return getNotifications(s.user.id);
  });
}

export async function POST() {
  return handle(async () => {
    const s = await getSession();
    await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.userId, s.user.id), isNull(notifications.readAt)));
    return { ok: true };
  });
}
