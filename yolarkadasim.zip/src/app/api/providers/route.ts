import { handle } from "@/lib/http";
import { listProviders } from "@/lib/queries";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return handle(async () => {
    await ensureSeed();
    const u = new URL(req.url);
    const items = await listProviders({
      area: u.searchParams.get("area") ?? undefined,
      vehicle: u.searchParams.get("vehicle") ?? undefined,
      service: u.searchParams.get("service") ?? undefined,
      mode: u.searchParams.get("mode") ?? undefined,
      onlyAvailable: u.searchParams.get("available") === "1",
    });
    return { items };
  });
}
