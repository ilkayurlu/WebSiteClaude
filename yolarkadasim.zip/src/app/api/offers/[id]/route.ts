import { z } from "zod";
import { providerRespond } from "@/lib/engine";
import { handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const { action } = await parseBody(req, z.object({ action: z.enum(["accept", "decline"]) }));
    return providerRespond(s, (await params).id, action);
  });
}
