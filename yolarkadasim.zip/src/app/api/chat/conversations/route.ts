import { z } from "zod";
import { createOrGetConversation, listConversations, unreadTotal } from "@/lib/chat";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z
  .object({
    requestId: z.string().min(1).optional(),
    orderId: z.string().min(1).optional(),
    providerUserId: z.string().min(1).optional(),
    participantIds: z.array(z.string().min(1)).max(2).optional(),
  })
  .refine((v) => v.requestId || v.orderId || v.providerUserId || v.participantIds, { message: "Bir görev, sipariş veya üye seçin." });

export async function GET(req: Request) {
  return handle(async () => {
    const s = await getSession();
    const url = new URL(req.url);
    if (url.searchParams.get("summary") === "1") return { unread: await unreadTotal(s) };
    return { items: await listConversations(s) };
  });
}

export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`chat-open:${s.user.id}`, 30, 60_000);
    const body = await parseBody(req, Schema);
    return createOrGetConversation(s, body);
  });
}
