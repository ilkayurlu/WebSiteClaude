import { z } from "zod";
import { setMuted } from "@/lib/chat";
import { handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const { muted } = await parseBody(req, z.object({ muted: z.boolean() }));
    return setMuted(s, (await params).id, muted);
  });
}
