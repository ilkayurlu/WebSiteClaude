import { markAsRead } from "@/lib/chat";
import { handle } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => markAsRead(await getSession(), (await params).id));
}
