import { streamDelta, streamReceipts, streamSnapshot } from "@/lib/chat";
import { HttpError } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

/**
 * SSE — serverless dostu gerçek zamanlı katman.
 * Kanal: chat-[conversationId]; abonelik sunucuda katılımcılık doğrulanarak açılır.
 * İstemci (EventSource) koparsa otomatik yeniden bağlanır; bağlantı 50 sn'de bir yenilenir.
 */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();
  const id = (await params).id;

  let snapshot: Awaited<ReturnType<typeof streamSnapshot>>;
  try {
    snapshot = await streamSnapshot(session, id);
  } catch (e) {
    const status = e instanceof HttpError ? e.status : 500;
    const message = e instanceof HttpError ? e.message : "Sohbet akışı açılamadı.";
    return Response.json({ error: message }, { status });
  }

  const encoder = new TextEncoder();
  let timer: ReturnType<typeof setInterval> | null = null;
  let lifetime: ReturnType<typeof setTimeout> | null = null;
  let closed = false;

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      const send = (payload: Record<string, unknown>) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`));
        } catch {
          cleanup();
        }
      };
      const cleanup = () => {
        if (closed) return;
        closed = true;
        if (timer) clearInterval(timer);
        if (lifetime) clearTimeout(lifetime);
        try {
          controller.close();
        } catch {
          /* zaten kapalı */
        }
      };

      controller.enqueue(encoder.encode("retry: 2000\n\n"));
      let cursor = snapshot.messages.length ? snapshot.messages[0].createdAt : new Date().toISOString();
      const seen = new Set<string>(snapshot.messages.map((m) => m.id));
      let lastReceipts = "";
      send({ kind: "init", channel: `chat-${id}`, ...snapshot });

      let ticking = false;
      timer = setInterval(async () => {
        if (closed || ticking) return;
        ticking = true;
        try {
          const delta = await streamDelta(id, cursor, seen);
          if (delta.messages.length) {
            for (const m of delta.messages) seen.add(m.id);
            send({ kind: "messages", messages: delta.messages });
          }
          const receipts = await streamReceipts(id, session.user.id);
          const serialized = JSON.stringify(receipts);
          if (serialized !== lastReceipts) {
            lastReceipts = serialized;
            send({ kind: "receipts", ...receipts });
          }
        } catch {
          send({ kind: "error", message: "Akış geçici olarak kesildi, yeniden bağlanılıyor." });
        } finally {
          ticking = false;
        }
      }, 1800);

      // Uzun ömürlü bağlantıları serverless sınırı içinde tut
      lifetime = setTimeout(() => {
        send({ kind: "reconnect" });
        cleanup();
      }, 50_000);

      req.signal.addEventListener("abort", cleanup);
    },
    cancel() {
      closed = true;
      if (timer) clearInterval(timer);
      if (lifetime) clearTimeout(lifetime);
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
