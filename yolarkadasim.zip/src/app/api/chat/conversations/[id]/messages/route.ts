import { z } from "zod";
import { getMessages, sendMessage } from "@/lib/chat";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const SendSchema = z.object({
  content: z.string().min(1, "Mesaj boş olamaz.").max(1200),
  type: z.enum(["TEXT", "LOCATION_PIN"]).optional(),
  senderId: z.string().min(1),
});

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const url = new URL(req.url);
    const page = Number(url.searchParams.get("page") ?? "0") || 0;
    const limit = Number(url.searchParams.get("limit") ?? "40") || 40;
    return getMessages(s, (await params).id, { page, limit });
  });
}

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`chat-send:${s.user.id}`, 30, 60_000);
    const body = await parseBody(req, SendSchema);
    return sendMessage(s, { conversationId: (await params).id, senderId: body.senderId, content: body.content, type: body.type });
  });
}
