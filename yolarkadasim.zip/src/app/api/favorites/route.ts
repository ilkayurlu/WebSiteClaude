import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { favorites, fleets, providers, restaurants } from "@/db/schema";
import { handle, HttpError, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    if (s.user.role !== "CUSTOMER") throw new HttpError(403, "Favoriler müşteri hesabına özeldir.");
    const { targetType, targetId } = await parseBody(req, z.object({ targetType: z.enum(["PROVIDER", "FLEET", "RESTAURANT"]), targetId: z.string().min(1) }));
    const table = targetType === "PROVIDER" ? providers : targetType === "FLEET" ? fleets : restaurants;
    const [exists] = await db.select({ id: table.id }).from(table).where(eq(table.id, targetId)).limit(1);
    if (!exists) throw new HttpError(404, "Hedef bulunamadı.");
    const where = and(eq(favorites.customerId, s.user.id), eq(favorites.targetType, targetType), eq(favorites.targetId, targetId));
    const [f] = await db.select().from(favorites).where(where).limit(1);
    if (f) {
      await db.delete(favorites).where(eq(favorites.id, f.id));
      return { favorite: false };
    }
    await db.insert(favorites).values({ customerId: s.user.id, targetType, targetId }).onConflictDoNothing();
    return { favorite: true };
  });
}
