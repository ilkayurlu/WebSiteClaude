import { z } from "zod";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { placeOrder } from "@/lib/food";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const Checkout = z.object({
  deliveryArea: z.string().min(2),
  addressDetail: z.string().max(300).optional(),
  note: z.string().max(300).optional(),
  tipMinor: z.number().int().min(0).max(50000).optional(),
  paymentMethod: z.enum(["SANDBOX_CARD", "CASH_ON_DELIVERY"]).optional(),
});

const Schema = Checkout.extend({
  courierPreference: z.enum(["AUTO", "FAVORITE", "MANUAL_PROVIDER", "MANUAL_FLEET"]).optional(),
  preferredProviderId: z.string().optional(),
  preferredFleetId: z.string().optional(),
});

export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`order:${s.user.id}`, 10, 60_000);
    const key = req.headers.get("Idempotency-Key") ?? "";
    const body = await parseBody(req, Schema);
    return placeOrder(s, { ...body, idempotencyKey: key });
  });
}
