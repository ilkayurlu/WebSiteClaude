import { z } from "zod";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { rateOrder } from "@/lib/food";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const star = z.number().int().min(1, "Puan 1-5 arası olmalı.").max(5, "Puan 1-5 arası olmalı.");

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`rate:${s.user.id}`, 10, 60_000);
    const body = await parseBody(req, z.object({ rating: star, catTime: star.optional(), catCommunication: star.optional(), catCare: star.optional(), catProfessionalism: star.optional(), body: z.string().max(1000).optional() }));
    return rateOrder(s, (await params).id, body);
  });
}
