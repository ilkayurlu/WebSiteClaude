import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { cancelOrder } from "@/lib/food";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const { reason } = await parseBody(req, z.object({ reason: z.string().max(300).optional() }));
    return cancelOrder(await getSession(), (await params).id, reason);
  });
}
