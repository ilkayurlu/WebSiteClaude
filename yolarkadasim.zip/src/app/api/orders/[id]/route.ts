import { handle, HttpError } from "@/lib/http";
import { getOrderView } from "@/lib/food";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(_r: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const v = await getOrderView(await getSession(), (await params).id);
    if (!v) throw new HttpError(404, "Sipariş bulunamadı.");
    return v;
  });
}
