import { z } from "zod";
import { db } from "@/db";
import { partnerApplications } from "@/db/schema";
import { isValidAreaSlug } from "@/lib/geo";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  kind: z.enum(["RESTAURANT", "FLEET"]),
  name: z.string().trim().min(2, "İşletme adı en az 2 karakter.").max(80),
  contactName: z.string().trim().min(2, "Yetkili adı gerekli.").max(80),
  email: z.string().email("Geçerli bir e-posta girin.").max(160),
  phone: z.string().max(32).optional(),
  city: z.string().trim().min(2, "Şehir gerekli.").max(60),
  areas: z.array(z.string().refine(isValidAreaSlug, "Geçersiz bölge. İl ve ilçe seçimini kontrol edin.")).min(1, "En az bir hizmet bölgesi seçin.").max(120),
  description: z.string().max(2000).optional(),
  taxNo: z.string().max(120).optional(),
});

export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`app:${s.user.id}`, 5, 3600_000);
    const b = await parseBody(req, Schema);
    const [row] = await db.insert(partnerApplications).values(b).returning();
    return { id: row.id, status: row.status, message: "Başvurunuz alındı. Operasyon ekibi 2 iş günü içinde dönüş yapar." };
  });
}
