import { z } from "zod";
import { createSupportCase } from "@/lib/dashboard-actions";
import { assertSameOrigin, handle, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    const session = await getSession();
    rateLimit(`case:${session.user.id}`, 8, 3_600_000);
    const body = await parseBody(req, z.object({ sourceType: z.enum(["ORDER", "REQUEST"]), sourceId: z.uuid(), category: z.enum(["DELIVERY", "OTP", "CANCELLATION", "OTHER"]), detail: z.string().trim().min(12).max(1000) }));
    return createSupportCase(session, body);
  });
}
