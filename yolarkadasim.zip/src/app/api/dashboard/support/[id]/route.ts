import { z } from "zod";
import { resolveSupportCase } from "@/lib/dashboard-actions";
import { assertSameOrigin, handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    assertSameOrigin(req);
    const session = await getSession();
    const body = await parseBody(req, z.object({ status: z.enum(["IN_REVIEW", "RESOLVED", "REJECTED"]), resolution: z.string().trim().min(12).max(1000) }));
    return resolveSupportCase(session, (await params).id, body);
  });
}
