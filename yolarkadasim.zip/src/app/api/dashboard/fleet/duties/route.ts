import { z } from "zod";
import { scheduleFleetDuty } from "@/lib/dashboard-actions";
import { assertSameOrigin, handle, HttpError, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
const vehicles = ["BICYCLE", "MOTORCYCLE", "CAR", "VAN", "TRUCK", "COLD_CHAIN_VAN", "MINIBUS"] as const;
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    const session = await getSession();
    rateLimit(`fleet-duty:${session.user.id}`, 30, 60_000);
    const body = await parseBody(req, z.object({ providerId: z.uuid(), startsAt: z.iso.datetime({ offset: true }), endsAt: z.iso.datetime({ offset: true }), vehicleType: z.enum(vehicles), vehicleLabel: z.string().max(70).optional() }));
    const start = new Date(body.startsAt), end = new Date(body.endsAt);
    if (isNaN(start.getTime()) || isNaN(end.getTime())) throw new HttpError(422, "Geçerli başlangıç ve bitiş zamanı girin.");
    return scheduleFleetDuty(session, { providerId: body.providerId, startsAt: start, endsAt: end, vehicleType: body.vehicleType, vehicleLabel: body.vehicleLabel });
  });
}
