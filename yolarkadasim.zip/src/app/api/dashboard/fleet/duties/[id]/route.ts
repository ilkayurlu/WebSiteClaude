import { cancelFleetDuty } from "@/lib/dashboard-actions";
import { assertSameOrigin, handle } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => { assertSameOrigin(req); return cancelFleetDuty(await getSession(), (await params).id); });
}
