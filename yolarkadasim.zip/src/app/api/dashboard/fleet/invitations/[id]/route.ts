import { z } from "zod";
import { answerFleetInvitation } from "@/lib/dashboard-actions";
import { assertSameOrigin, handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    assertSameOrigin(req);
    const session = await getSession();
    const { action } = await parseBody(req, z.object({ action: z.enum(["ACCEPTED", "DECLINED", "CANCELLED"]) }));
    return answerFleetInvitation(session, (await params).id, action);
  });
}
