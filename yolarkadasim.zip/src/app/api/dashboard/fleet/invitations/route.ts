import { z } from "zod";
import { inviteFleetProvider } from "@/lib/dashboard-actions";
import { assertSameOrigin, handle, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    const session = await getSession();
    rateLimit(`fleet-invite:${session.user.id}`, 12, 3_600_000);
    const { email } = await parseBody(req, z.object({ email: z.email().max(180) }));
    return inviteFleetProvider(session, email);
  });
}
