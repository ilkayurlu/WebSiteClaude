import { cookies } from "next/headers";
import { getDashboardPulse } from "@/lib/dashboard-data";
import { HttpError } from "@/lib/http";
import { getSession, lookupSessionUser, SESSION_COOKIE } from "@/lib/session";

export const dynamic = "force-dynamic";

/** Node/SSE: oturum yetkisi her yayından önce yeniden doğrulanır; istemci koparsa yeniden bağlanır. */
export async function GET(request: Request) {
  let session: Awaited<ReturnType<typeof getSession>>;
  try {
    session = await getSession();
  } catch (error) {
    return Response.json({ error: error instanceof HttpError ? error.message : "Kimlik doğrulanamadı." }, { status: error instanceof HttpError ? error.status : 500 });
  }
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  const encoder = new TextEncoder();
  let interval: ReturnType<typeof setInterval> | undefined;
  let life: ReturnType<typeof setTimeout> | undefined;
  let stopped = false;
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let previous = "";
      let working = false;
      const stop = () => {
        if (stopped) return;
        stopped = true;
        if (interval) clearInterval(interval);
        if (life) clearTimeout(life);
        try { controller.close(); } catch { /* istemci bağlantıyı kapatmış */ }
      };
      const emit = (data: unknown) => {
        if (stopped) return;
        try { controller.enqueue(encoder.encode(`event: dashboard\ndata: ${JSON.stringify(data)}\n\n`)); }
        catch { stop(); }
      };
      const tick = async () => {
        if (stopped || working) return;
        working = true;
        try {
          if (!await lookupSessionUser(token)) return stop();
          const pulse = await getDashboardPulse(session);
          if (pulse.signature !== previous) { previous = pulse.signature; emit(pulse); }
        } catch {
          // SSE'nin yeniden bağlanabilmesi için akışı sonlandır; hassas hata detayını gönderme.
          stop();
        } finally { working = false; }
      };
      controller.enqueue(encoder.encode("retry: 2500\n\n"));
      void tick();
      interval = setInterval(() => void tick(), 3500);
      life = setTimeout(stop, 48_000);
      request.signal.addEventListener("abort", stop, { once: true });
    },
    cancel() { stopped = true; if (interval) clearInterval(interval); if (life) clearTimeout(life); },
  });
  return new Response(stream, { headers: { "Content-Type": "text/event-stream; charset=utf-8", "Cache-Control": "no-cache, no-transform", Connection: "keep-alive", "X-Accel-Buffering": "no" } });
}
