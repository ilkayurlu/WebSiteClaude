import { getDashboardPulse } from "@/lib/dashboard-data";
import { getSession } from "@/lib/session";
import { handle } from "@/lib/http";

export const dynamic = "force-dynamic";
export async function GET() {
  return handle(async () => getDashboardPulse(await getSession()));
}
