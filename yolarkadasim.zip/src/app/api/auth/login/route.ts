import { cookies, headers } from "next/headers";
import { z } from "zod";
import { db } from "@/db";
import { audit } from "@/lib/engine";
import { assertSameOrigin, handle, HttpError, parseBody, rateLimit } from "@/lib/http";
import { closeProviderAvailability, issueSession, lookupSessionUser, revokeSession, SESSION_COOKIE, SESSION_TTL_SECONDS } from "@/lib/session";
import { authenticateUniversal } from "@/lib/universal-auth";
import { getAccessMode } from "@/lib/auth-mode";

export const dynamic = "force-dynamic";

const Schema = z.object({
  email: z.string().trim().min(3, "E-posta gerekli.").max(180),
  password: z.string().min(1, "Parola gerekli.").max(200),
  next: z.string().max(200).optional(),
});

/** Ortak giriş (REST). `universalLoginAction` ile birebir aynı çekirdeği kullanır. */
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    if (getAccessMode() !== "1") throw new HttpError(403, "E-posta ve parola girişi bu ortamda kapalı.");
    const body = await parseBody(req, Schema);
    const h = await headers();
    const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip")?.trim() || "unknown";
    rateLimit(`login:${ip}`, 15, 60_000);

    const { user, redirectTo, via } = await authenticateUniversal({ ...body, ip });

    const jar = await cookies();
    const prev = await lookupSessionUser(jar.get(SESSION_COOKIE)?.value);
    if (prev && prev.id !== user.id && prev.role === "PROVIDER") await closeProviderAvailability(prev.id);
    await revokeSession(jar.get(SESSION_COOKIE)?.value);

    const token = await issueSession(user.id);
    jar.set(SESSION_COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: SESSION_TTL_SECONDS,
    });
    await audit(db, user.id, via === "root" ? "auth.login_root" : "auth.login_password", "user", user.id, "Ortak giriş kapısıyla oturum açıldı (REST)", { role: user.role, via });
    return { ok: true, redirectTo, role: user.role, via };
  });
}
