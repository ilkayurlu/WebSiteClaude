import { cookies, headers } from "next/headers";
import { z } from "zod";
import { audit } from "@/lib/engine";
import { assertSameOrigin, handle, HttpError, parseBody, rateLimit } from "@/lib/http";
import { authenticateRoot } from "@/lib/root-auth";
import { getAccessMode } from "@/lib/auth-mode";
import { demoEnabled, issueSession, lookupSessionUser, revokeSession, SESSION_COOKIE, SESSION_TTL_SECONDS } from "@/lib/session";
import { db } from "@/db";

export const dynamic = "force-dynamic";

const Schema = z.object({
  email: z.string().trim().min(3, "E-posta gerekli.").max(180),
  password: z.string().min(1, "Parola gerekli.").max(200),
});

/**
 * Acil durum kök girişi (REST). Server Action ile aynı `authenticateRoot` çekirdeğini kullanır;
 * operasyon araçları ve izleme için test edilebilir bir yüzey sağlar.
 * Yanıtta parola veya hassas veri dönmez; yalnızca opak oturum çerezi basılır.
 */
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    if (getAccessMode() !== "1") throw new HttpError(403, "Kök parola girişi bu ortamda kapalı.");
    const body = await parseBody(req, Schema);
    const ip = (await headers()).get("x-forwarded-for")?.split(",")[0]?.trim() ?? (await headers()).get("x-real-ip")?.trim() ?? "unknown";
    rateLimit(`root-login:${ip}`, 12, 60_000);

    const user = await authenticateRoot({ email: body.email, password: body.password, ip });

    const jar = await cookies();
    const previous = await lookupSessionUser(jar.get(SESSION_COOKIE)?.value);
    await revokeSession(jar.get(SESSION_COOKIE)?.value);

    const token = await issueSession(user.id);
    jar.set(SESSION_COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: SESSION_TTL_SECONDS,
    });
    await audit(db, user.id, "root_auth.success", "auth", user.id, "Kök girişle SUPER_ADMIN oturumu açıldı (REST)", { email: user.email, previousRole: previous?.role ?? null, demoMode: demoEnabled() });
    return { ok: true, role: user.role, home: "/admin" };
  });
}
