import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { handle, HttpError, parseBody, rateLimit } from "@/lib/http";
import { ensureSeed } from "@/lib/seed";
import { closeProviderAvailability, demoEnabled, issueSession, lookupSessionUser, revokeSession, SESSION_COOKIE, SESSION_TTL_SECONDS } from "@/lib/session";
import { dashboardHome } from "@/lib/dashboard-config";

export const dynamic = "force-dynamic";

function assertSameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  if (origin && origin !== new URL(req.url).origin) throw new HttpError(403, "Güvenli olmayan istek kaynağı.");
}

/** Yalnızca açıkça etkinleştirilmiş DEMO ortamında hesap seçimi. Gerçek ortamda kimlik sağlayıcısı gerekir. */
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    if (!demoEnabled()) throw new HttpError(403, "Demo hesap geçişi bu ortamda kapalı.");
    await ensureSeed();
    rateLimit(`signin:${req.headers.get("x-forwarded-for")?.split(",")[0] ?? "unknown"}`, 15, 60_000);
    const { userId } = await parseBody(req, z.object({ userId: z.string().uuid() }));
    const [user] = await db.select({ id: users.id, role: users.role }).from(users).where(eq(users.id, userId)).limit(1);
    if (!user) throw new HttpError(404, "Kullanıcı bulunamadı.");
    const jar = await cookies();
    const oldToken = jar.get(SESSION_COOKIE)?.value;
    const oldUser = await lookupSessionUser(oldToken);
    if (oldUser?.role === "PROVIDER" && oldUser.id !== user.id) await closeProviderAvailability(oldUser.id);
    await revokeSession(oldToken);
    const token = await issueSession(user.id);
    jar.set(SESSION_COOKIE, token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: SESSION_TTL_SECONDS });
    return { ok: true, role: user.role, home: dashboardHome(user.role) };
  });
}

export async function DELETE(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    const jar = await cookies();
    const token = jar.get(SESSION_COOKIE)?.value;
    const user = await lookupSessionUser(token);
    if (user?.role === "PROVIDER") await closeProviderAvailability(user.id);
    await revokeSession(token);
    jar.delete(SESSION_COOKIE);
    return { ok: true, home: "/giris" };
  });
}
