import { z } from "zod";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { addToCart } from "@/lib/food";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  restaurantId: z.string().min(1),
  productId: z.string().min(1),
  qty: z.number().int().min(1).max(20),
  optionIds: z.array(z.string()).max(12).optional(),
  note: z.string().max(200).optional(),
});

export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`cart:${s.user.id}`, 60, 60_000);
    const body = await parseBody(req, Schema);
    return addToCart(s, body);
  });
}
