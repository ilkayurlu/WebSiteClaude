import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { removeCartItem, updateCartItem } from "@/lib/food";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const body = await parseBody(req, z.object({ qty: z.number().int().min(1).max(20).optional(), note: z.string().max(200).optional() }));
    return updateCartItem(s, (await params).id, body);
  });
}

export async function DELETE(_r: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => removeCartItem(await getSession(), (await params).id));
}
