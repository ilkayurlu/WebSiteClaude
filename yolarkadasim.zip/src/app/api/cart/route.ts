import { handle } from "@/lib/http";
import { clearCart, getCartView } from "@/lib/food";
import { getSession } from "@/lib/session";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  return handle(async () => {
    await ensureSeed();
    const s = await getSession();
    return (await getCartView(s)) ?? { empty: true };
  });
}
export async function DELETE() {
  return handle(async () => clearCart(await getSession()));
}
