import { getDistrict, getNeighborhoods } from "@/lib/geo-data";
import { handle, HttpError } from "@/lib/http";

export const dynamic = "force-dynamic";

/** Mahalleler talep anında, yalnızca seçilen ilçe için döner (tüm ülke istemciye indirilmez). */
export async function GET(req: Request) {
  return handle(async () => {
    const url = new URL(req.url);
    const districtId = url.searchParams.get("districtId") ?? "";
    const district = getDistrict(districtId);
    if (!district) throw new HttpError(404, "İlçe bulunamadı.");
    const q = url.searchParams.get("q") ?? undefined;
    const items = getNeighborhoods(district.id, q);
    return new Response(JSON.stringify({ districtId: district.id, total: district.neighborhoodCount, items }), {
      headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=3600, stale-while-revalidate=86400" },
    });
  });
}
