import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { providers } from "@/db/schema";
import { normalizeAreaSlug } from "@/lib/geo-data";
import { handle } from "@/lib/http";

export const dynamic = "force-dynamic";

/** Seçilen ilçedeki müsait sağlayıcı sayısı — canlı eşleştirme önizlemesi. */
export async function GET(req: Request) {
  return handle(async () => {
    const raw = new URL(req.url).searchParams.get("area") ?? "";
    const area = normalizeAreaSlug(raw);
    if (!area) return { area: null, available: 0, total: 0 };
    const [row] = await db
      .select({
        total: sql<number>`count(*)::int`,
        available: sql<number>`count(*) filter (where ${providers.status} = 'AVAILABLE')::int`,
      })
      .from(providers)
      .where(and(sql`${area} = ANY(${providers.serviceAreas})`, eq(providers.visibility, "PUBLIC"), sql`${providers.status} <> 'SUSPENDED'`));
    return { area, available: row?.available ?? 0, total: row?.total ?? 0 };
  });
}
