import { searchStreets } from "@/lib/geo-data";
import { handle } from "@/lib/http";

export const dynamic = "force-dynamic";

/** Cadde/sokak önerileri. Resmî cadde verisi bağlı değildir; serbest giriş her zaman geçerlidir. */
export async function GET(req: Request) {
  return handle(async () => {
    const url = new URL(req.url);
    const items = searchStreets(url.searchParams.get("neighborhoodId") ?? "", url.searchParams.get("q") ?? "");
    return { items, source: "suggestion" as const };
  });
}
