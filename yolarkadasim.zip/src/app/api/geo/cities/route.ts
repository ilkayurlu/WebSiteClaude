import { getCities } from "@/lib/geo-data";
import { handle } from "@/lib/http";

export const dynamic = "force-dynamic";
const CACHE = "public, max-age=86400, stale-while-revalidate=604800";

export async function GET() {
  return handle(async () => new Response(JSON.stringify({ items: getCities() }), { headers: { "Content-Type": "application/json", "Cache-Control": CACHE } }));
}
