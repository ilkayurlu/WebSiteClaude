import { getDistricts } from "@/lib/geo-data";
import { handle, HttpError } from "@/lib/http";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return handle(async () => {
    const cityCode = new URL(req.url).searchParams.get("cityCode") ?? "";
    const items = getDistricts(cityCode);
    if (!items.length) throw new HttpError(404, "Bu il için ilçe bulunamadı.");
    return new Response(JSON.stringify({ items }), { headers: { "Content-Type": "application/json", "Cache-Control": "public, max-age=86400, stale-while-revalidate=604800" } });
  });
}
