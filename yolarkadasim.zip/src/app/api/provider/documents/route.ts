import { uploadProviderDocument } from "@/lib/admin-actions";
import { DOC_TYPES, type DocType } from "@/lib/admin-data";
import { assertSameOrigin, handle, HttpError, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";
export async function POST(req: Request) {
  return handle(async () => {
    assertSameOrigin(req);
    const s = await getSession();
    rateLimit(`doc-upload:${s.user.id}`, 10, 3_600_000);
    let form: FormData;
    try { form = await req.formData(); } catch { throw new HttpError(400, "Evrak form-data olarak gönderilmeli."); }
    const docType = form.get("docType");
    const file = form.get("file");
    if (typeof docType !== "string" || !(DOC_TYPES as readonly string[]).includes(docType)) throw new HttpError(422, "Evrak türü seçin.");
    if (!(file instanceof File)) throw new HttpError(422, "Bir dosya seçin.");
    return uploadProviderDocument(s, docType as DocType, file);
  });
}
