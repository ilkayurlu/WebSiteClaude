import { z } from "zod";
import { handle, HttpError, parseBody, rateLimit } from "@/lib/http";
import { applyProviderPresence } from "@/lib/provider-presence";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const finiteNumber = z.number().refine((v) => Number.isFinite(v), "Geçersiz konum bilgisi.");

/** Heartbeat + durum geçişi + sessiz konum güncelleme. Vardiya yalnızca açık shift kayıtlarından hesaplanır. */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    if (!s.providerId) throw new HttpError(403, "Yalnızca hizmet sağlayıcılar.");
    rateLimit(`presence:${s.user.id}`, 90, 60_000);
    const { status, coords } = await parseBody(
      req,
      z.object({
        status: z.enum(["AVAILABLE", "OFFLINE", "PAUSED"]).optional(),
        coords: z
          .object({
            lat: finiteNumber.min(-90, "Geçersiz konum bilgisi.").max(90, "Geçersiz konum bilgisi."),
            lng: finiteNumber.min(-180, "Geçersiz konum bilgisi.").max(180, "Geçersiz konum bilgisi."),
          })
          .optional(),
      }),
    );
    const result = await applyProviderPresence(s.providerId, { ...(status ? { status } : {}), ...(coords ? { coords } : {}) });
    return { ok: true, status: result.status };
  });
}
