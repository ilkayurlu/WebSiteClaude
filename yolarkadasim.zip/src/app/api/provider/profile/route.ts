import { z } from "zod";
import { isValidAreaSlug } from "@/lib/geo";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { updateProviderProfile } from "@/lib/profile";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z
  .object({
    displayName: z.string().trim().min(2, "Ad en az 2 karakter.").max(60).optional(),
    headline: z.string().trim().max(90, "Unvan en fazla 90 karakter.").optional(),
    bio: z.string().trim().max(1200, "Tanıtım en fazla 1200 karakter.").optional(),
    vehicleLabel: z.string().trim().max(60).optional(),
    serviceTypes: z.array(z.enum(["PACKAGE", "FOOD", "PASSENGER", "RENTAL"])).max(4).optional(),
    serviceAreas: z.array(z.string().refine(isValidAreaSlug, "Geçersiz bölge. İl ve ilçe seçimini kontrol edin.")).min(1, "En az bir bölge seçin.").max(120).optional(),
    highlights: z.array(z.string().trim().min(2).max(40)).max(8).optional(),
    acceptsInstant: z.boolean().optional(),
    acceptsScheduled: z.boolean().optional(),
    acceptsRental: z.boolean().optional(),
    rentalHourlyMinor: z.number().int().min(0).max(5000000).nullish(),
    baseFareMinor: z.number().int().min(0).max(500000).optional(),
    perKmMinor: z.number().int().min(0).max(100000).optional(),
    hue: z.number().int().min(0).max(359).optional(),
  })
  .refine((v) => Object.keys(v).length > 0, { message: "Güncellenecek bir alan gönderin." });

export async function PATCH(req: Request) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`profile:${s.user.id}`, 20, 60_000);
    return updateProviderProfile(s, await parseBody(req, Schema));
  });
}
