import { z } from "zod";
import { cancelRequest } from "@/lib/engine";
import { handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const { reason } = await parseBody(req, z.object({ reason: z.string().max(300).optional() }));
    return cancelRequest(s, (await params).id, reason);
  });
}
