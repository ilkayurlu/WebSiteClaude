import { z } from "zod";
import { selectAndSubmit } from "@/lib/engine";
import { handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  strategy: z.enum(["AUTO", "FAVORITE", "MANUAL_PROVIDER", "MANUAL_FLEET"]),
  providerId: z.string().optional(),
  fleetId: z.string().optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const body = await parseBody(req, Schema);
    const r = await selectAndSubmit(s, (await params).id, body);
    return { ...r, message: r.status === "EXPIRED" ? "Şu anda uygun sağlayıcı bulunamadı." : "Talebiniz iletildi. Onay bekleniyor." };
  });
}
