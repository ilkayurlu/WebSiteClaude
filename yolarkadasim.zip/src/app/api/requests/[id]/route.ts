import { sweepExpired } from "@/lib/engine";
import { handle, HttpError } from "@/lib/http";
import { getRequestView } from "@/lib/queries";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    await sweepExpired();
    const v = await getRequestView(s, (await params).id);
    if (!v) throw new HttpError(404, "Talep bulunamadı.");
    return v;
  });
}
