import { z } from "zod";
import { submitReview } from "@/lib/engine";
import { handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const star = z.number().int().min(1, "Puan 1-5 arası olmalı.").max(5, "Puan 1-5 arası olmalı.");
const Schema = z.object({
  rating: star,
  catTime: star.optional(),
  catCommunication: star.optional(),
  catCare: star.optional(),
  catProfessionalism: star.optional(),
  body: z.string().max(1000, "Yorum en fazla 1000 karakter.").optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const body = await parseBody(req, Schema);
    return submitReview(s, (await params).id, body);
  });
}
