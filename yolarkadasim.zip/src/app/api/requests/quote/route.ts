import { z } from "zod";
import { createQuote } from "@/lib/engine";
import { isValidAreaSlug } from "@/lib/geo";
import { handle, HttpError, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";
import { getFavoriteIds } from "@/lib/queries";

export const dynamic = "force-dynamic";

const areaKey = z.string().refine(isValidAreaSlug, "Geçersiz bölge. İl ve ilçe seçimini kontrol edin.");
const Schema = z.object({
  mode: z.enum(["INSTANT_CALL", "SCHEDULED", "INSTANT_RENT"], { message: "Geçersiz mod." }),
  serviceType: z.enum(["PACKAGE", "FOOD", "PASSENGER", "RENTAL"], { message: "Geçersiz hizmet tipi." }),
  vehicleTypeReq: z.enum(["BICYCLE", "MOTORCYCLE", "CAR", "VAN", "TRUCK", "COLD_CHAIN_VAN", "MINIBUS"]).nullish(),
  pickupArea: areaKey,
  pickupDetail: z.string().max(200).nullish(),
  dropoffArea: areaKey.nullish(),
  dropoffDetail: z.string().max(200).nullish(),
  scheduledStart: z.string().nullish(),
  rentalHours: z.number().int().min(1, "En az 1 saat.").max(12, "En fazla 12 saat.").nullish(),
  note: z.string().max(500).nullish(),
});

export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    const body = await parseBody(req, Schema);
    const key = req.headers.get("Idempotency-Key") ?? "";
    if (key.length < 8) throw new HttpError(400, "Idempotency-Key başlığı zorunlu.");
    const favs = (await getFavoriteIds(s.user.id)).providers;
    return createQuote(s, { ...body, idempotencyKey: key, favoriteProviderIds: favs });
  });
}
