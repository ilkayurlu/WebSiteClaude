import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { merchantCreateCategory } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  name: z.string().trim().min(2, "Kategori adı en az 2 karakter.").max(60),
  description: z.string().max(200).optional(),
  position: z.number().int().min(0).max(999).optional(),
  timeFrom: z.string().regex(/^\d{2}:\d{2}$/, "Saat formatı SS:DD olmalı.").optional(),
  timeTo: z.string().regex(/^\d{2}:\d{2}$/, "Saat formatı SS:DD olmalı.").optional(),
});

export async function POST(req: Request) {
  return handle(async () => merchantCreateCategory(await requireRole("RESTAURANT_OWNER", "ADMIN"), await parseBody(req, Schema)));
}
