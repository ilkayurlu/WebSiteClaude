import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { merchantToggleOpen } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  return handle(async () => {
    const s = await requireRole("RESTAURANT_OWNER", "ADMIN");
    const { isOpen } = await parseBody(req, z.object({ isOpen: z.boolean() }));
    return merchantToggleOpen(s, isOpen);
  });
}
