import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { merchantAddOptionGroup } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  productId: z.string().min(1),
  name: z.string().trim().min(2).max(60),
  required: z.boolean(),
  maxSelect: z.number().int().min(1).max(8),
  options: z.array(z.object({ name: z.string().trim().min(1).max(60), priceDeltaMinor: z.number().int().min(0).max(100000), isDefault: z.boolean().optional() })).min(1, "En az bir seçenek ekleyin.").max(12),
});

export async function POST(req: Request) {
  return handle(async () => {
    const s = await requireRole("RESTAURANT_OWNER", "ADMIN");
    const b = await parseBody(req, Schema);
    return merchantAddOptionGroup(s, b.productId, b);
  });
}
