import { handle } from "@/lib/http";
import { merchantDeleteOptionGroup } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function DELETE(_r: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => merchantDeleteOptionGroup(await requireRole("RESTAURANT_OWNER", "ADMIN"), (await params).id));
}
