import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { merchantProductAction } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("RESTAURANT_OWNER", "ADMIN");
    const { action } = await parseBody(req, z.object({ action: z.enum(["publish", "off", "archive", "soldout", "instock"]) }));
    return merchantProductAction(s, (await params).id, action);
  });
}
