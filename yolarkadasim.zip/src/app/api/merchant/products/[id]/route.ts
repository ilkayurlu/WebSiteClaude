import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { merchantSaveProduct } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  categoryId: z.string().min(1),
  name: z.string().trim().min(2).max(80),
  description: z.string().max(600).optional(),
  imageUrl: z.string().max(500).optional(),
  priceMinor: z.number().int().min(100).max(5000000),
  discountPriceMinor: z.number().int().min(0).max(5000000).nullish(),
  stock: z.number().int().min(0).max(100000).optional(),
  allergens: z.array(z.string().max(40)).max(12).optional(),
  calories: z.number().int().min(0).max(20000).nullish(),
  prepMinutes: z.number().int().min(0).max(240).nullish(),
  isVegan: z.boolean().optional(),
  isVegetarian: z.boolean().optional(),
  isSpicy: z.boolean().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "OFF", "ARCHIVED"]).optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("RESTAURANT_OWNER", "ADMIN");
    const body = await parseBody(req, Schema);
    return merchantSaveProduct(s, { ...body, id: (await params).id });
  });
}
