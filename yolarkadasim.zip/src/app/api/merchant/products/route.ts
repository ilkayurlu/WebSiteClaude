import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { merchantSaveProduct } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  id: z.string().optional(),
  categoryId: z.string().min(1, "Kategori seçin."),
  name: z.string().trim().min(2, "Ürün adı en az 2 karakter.").max(80),
  description: z.string().max(600).optional(),
  imageUrl: z.string().url("Geçerli bir görsel adresi girin.").max(500).optional(),
  priceMinor: z.number().int().min(100, "Fiyat en az 1 TL.").max(5000000),
  discountPriceMinor: z.number().int().min(0).max(5000000).nullish(),
  stock: z.number().int().min(0).max(100000).optional(),
  allergens: z.array(z.string().max(40)).max(12).optional(),
  calories: z.number().int().min(0).max(20000).nullish(),
  prepMinutes: z.number().int().min(0).max(240).nullish(),
  isVegan: z.boolean().optional(),
  isVegetarian: z.boolean().optional(),
  isSpicy: z.boolean().optional(),
  status: z.enum(["DRAFT", "PUBLISHED", "OFF", "ARCHIVED"]).optional(),
});

export async function POST(req: Request) {
  return handle(async () => merchantSaveProduct(await requireRole("RESTAURANT_OWNER", "ADMIN"), await parseBody(req, Schema)));
}
