import { z } from "zod";
import { handle, parseBody } from "@/lib/http";
import { merchantOrderAction } from "@/lib/food";
import { requireRole } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await requireRole("RESTAURANT_OWNER", "ADMIN");
    const { action, reason } = await parseBody(req, z.object({ action: z.enum(["accept", "reject", "prepare", "ready", "reopen"]), reason: z.string().max(300).optional() }));
    return merchantOrderAction(s, (await params).id, action, reason);
  });
}
