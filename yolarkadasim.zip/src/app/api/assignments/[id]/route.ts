import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { assignments } from "@/db/schema";
import { verifyDeliveryCode } from "@/lib/delivery";
import { assignmentAction } from "@/lib/engine";
import { handle, HttpError, parseBody, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const { action, otp } = await parseBody(req, z.object({ action: z.enum(["start", "complete", "cancel"]), otp: z.string().max(8).optional() }));
    const id = (await params).id;
    if (action !== "complete") return assignmentAction(s, id, action, otp);
    // Tamamlama her zaman 3 hak kurallı doğrulamadan geçer.
    rateLimit(`otp:${s.user.id}`, 12, 60_000);
    const [a] = await db.select({ requestId: assignments.requestId, providerId: assignments.providerId }).from(assignments).where(eq(assignments.id, id)).limit(1);
    if (!a || a.providerId !== s.providerId) throw new HttpError(404, "Görev bulunamadı.");
    const result = await verifyDeliveryCode(s, a.requestId, otp ?? "");
    if (!result.ok) throw new HttpError(result.locked ? 423 : 422, result.error);
    return { ok: true };
  });
}
