import { handle } from "@/lib/http";
import { listRestaurants } from "@/lib/food";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  return handle(async () => {
    await ensureSeed();
    const u = new URL(req.url);
    const num = (k: string) => (u.searchParams.get(k) ? Number(u.searchParams.get(k)) : undefined);
    const items = await listRestaurants({
      area: u.searchParams.get("area") ?? undefined,
      cuisine: u.searchParams.get("cuisine") ?? undefined,
      openNow: u.searchParams.get("open") === "1",
      vegan: u.searchParams.get("vegan") === "1",
      halal: u.searchParams.get("halal") === "1",
      campaign: u.searchParams.get("campaign") === "1",
      maxFee: num("maxFee"),
      maxPrep: num("maxPrep"),
      minRating: num("minRating"),
      q: u.searchParams.get("q") ?? undefined,
      sort: (u.searchParams.get("sort") as "rating" | "fast" | "cheap") ?? undefined,
    });
    return { items };
  });
}
