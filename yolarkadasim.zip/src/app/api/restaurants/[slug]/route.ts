import { handle, HttpError } from "@/lib/http";
import { getRestaurantPage } from "@/lib/food";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(_r: Request, { params }: { params: Promise<{ slug: string }> }) {
  return handle(async () => {
    await ensureSeed();
    const p = await getRestaurantPage((await params).slug);
    if (!p) throw new HttpError(404, "İşletme bulunamadı.");
    return p;
  });
}
