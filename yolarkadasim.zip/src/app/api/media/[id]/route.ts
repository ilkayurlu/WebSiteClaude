import { handle } from "@/lib/http";
import { deleteOwnMedia } from "@/lib/media";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function DELETE(_r: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => deleteOwnMedia(await getSession(), (await params).id));
}
