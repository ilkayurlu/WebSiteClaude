import { z } from "zod";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { reportContent } from "@/lib/media";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`report:${s.user.id}`, 15, 60_000);
    const b = await parseBody(req, z.object({ reason: z.enum(["SPAM", "HARASSMENT", "PII", "MISLEADING", "ILLEGAL", "SAFETY", "COPYRIGHT", "OTHER"]), detail: z.string().max(500).optional() }));
    return reportContent(s, { targetType: "MEDIA", targetId: (await params).id, reason: b.reason, detail: b.detail });
  });
}
