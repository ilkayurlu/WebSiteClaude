import { readFile } from "node:fs/promises";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaPosts } from "@/db/schema";
import { HttpError, handle } from "@/lib/http";

export const dynamic = "force-dynamic";

/** Yayınlanmış medya: durum kontrolü sunucuda yapılır; onaysız içerik 404 döner. */
export async function GET(_r: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const id = (await params).id;
    const [post] = await db.select().from(mediaPosts).where(eq(mediaPosts.id, id)).limit(1);
    if (!post || post.status !== "PUBLISHED" || !post.privatePath) throw new HttpError(404, "İçerik bulunamadı.");
    const abs = path.resolve(process.cwd(), post.privatePath);
    const root = path.join(process.cwd(), "storage", "private");
    if (!abs.startsWith(root)) throw new HttpError(403, "Geçersiz dosya yolu.");
    const buf = await readFile(abs);
    return new Response(buf, {
      headers: {
        "Content-Type": post.mime ?? "application/octet-stream",
        "Cache-Control": "public, max-age=31536000, immutable",
        "X-Content-Type-Options": "nosniff",
      },
    });
  });
}
