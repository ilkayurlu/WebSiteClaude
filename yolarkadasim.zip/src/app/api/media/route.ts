import { handle, HttpError, rateLimit } from "@/lib/http";
import { createMediaPost } from "@/lib/media";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

/** Private bucket → moderasyon → public. Yalnızca gerçek dosya türü kabul edilir. */
export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`media:${s.user.id}`, 10, 60_000);
    let form: FormData;
    try {
      form = await req.formData();
    } catch {
      throw new HttpError(400, "Dosya form-data olarak gönderilmeli.");
    }
    const file = form.get("file");
    if (!(file instanceof File)) throw new HttpError(422, "Bir dosya seçin.");
    const caption = typeof form.get("caption") === "string" ? (form.get("caption") as string) : undefined;
    if (caption && caption.length > 500) throw new HttpError(422, "Açıklama en fazla 500 karakter.");
    const rights = form.get("rights") === "1" || form.get("rights") === "true";
    return createMediaPost(s, file, { caption, rightsDeclaration: rights });
  });
}
