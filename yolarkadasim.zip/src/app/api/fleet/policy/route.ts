import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { fleets } from "@/db/schema";
import { audit } from "@/lib/engine";
import { handle, HttpError, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function PATCH(req: Request) {
  return handle(async () => {
    const s = await getSession();
    if (!s.fleetId) throw new HttpError(403, "Yalnızca filo yöneticileri.");
    const body = await parseBody(req, z.object({ directPolicy: z.enum(["DIRECT_ALLOWED", "FLEET_APPROVAL_REQUIRED", "FLEET_ONLY"]).optional(), showMembersPublicly: z.boolean().optional() }));
    await db.update(fleets).set(body).where(eq(fleets.id, s.fleetId));
    await audit(db, s.user.id, "fleet.policy_update", "fleet", s.fleetId, undefined, body);
    return { ok: true };
  });
}
