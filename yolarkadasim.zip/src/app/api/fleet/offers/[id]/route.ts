import { z } from "zod";
import { fleetRespond } from "@/lib/engine";
import { handle, parseBody } from "@/lib/http";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  return handle(async () => {
    const s = await getSession();
    const { action, providerId } = await parseBody(req, z.object({ action: z.enum(["approve", "decline", "reassign"]), providerId: z.string().optional() }));
    return fleetRespond(s, (await params).id, action, providerId);
  });
}
