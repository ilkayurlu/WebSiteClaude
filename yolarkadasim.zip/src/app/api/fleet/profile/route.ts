import { z } from "zod";
import { isValidAreaSlug } from "@/lib/geo";
import { handle, parseBody } from "@/lib/http";
import { updateFleetProfile } from "@/lib/profile";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

const Schema = z.object({
  name: z.string().trim().min(2).max(80).optional(),
  description: z.string().trim().max(2000).optional(),
  phonePublic: z.string().trim().max(32).optional(),
  website: z.string().trim().max(200).optional(),
  servicePackages: z.array(z.string().trim().min(3).max(120)).max(8).optional(),
  serviceAreas: z.array(z.string().refine(isValidAreaSlug, "Geçersiz bölge. İl ve ilçe seçimini kontrol edin.")).max(120).optional(),
  capacityLabel: z.string().trim().max(60).optional(),
});

export async function PATCH(req: Request) {
  return handle(async () => updateFleetProfile(await getSession(), await parseBody(req, Schema)));
}
