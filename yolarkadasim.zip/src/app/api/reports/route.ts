import { z } from "zod";
import { handle, parseBody, rateLimit } from "@/lib/http";
import { reportContent } from "@/lib/media";
import { getSession } from "@/lib/session";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  return handle(async () => {
    const s = await getSession();
    rateLimit(`rep:${s.user.id}`, 15, 60_000);
    const b = await parseBody(req, z.object({ targetType: z.enum(["PROVIDER", "FLEET", "RESTAURANT", "MEDIA", "REVIEW"]), targetId: z.string().min(1), reason: z.enum(["SPAM", "HARASSMENT", "PII", "MISLEADING", "ILLEGAL", "SAFETY", "COPYRIGHT", "OTHER"]), detail: z.string().max(500).optional() }));
    if (b.targetType === "REVIEW") throw new z.ZodError([{ code: "custom", path: ["targetType"], message: "Yorum bildirimleri /api/reviews/[id]/report üzerinden yapılır." }] as never);
    return reportContent(s, b);
  });
}
