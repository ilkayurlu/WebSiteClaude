import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "YolArkadaşı — Kurye, Sürücü & Filo Çağırma Platformu",
  description: "Güvendiğin yol arkadaşını seç, yemek siparişi ver veya filonu yönet. Güvenli ve şeffaf teslimat deneyimi.",
};

export const viewport: Viewport = { themeColor: "#0e1324" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="tr"><body className="min-h-screen bg-paper text-ink antialiased">{children}</body></html>;
}
