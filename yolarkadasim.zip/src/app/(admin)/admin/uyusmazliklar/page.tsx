import Link from "next/link";
import { desc, eq, inArray } from "drizzle-orm";
import { AlertTriangle, ArrowRight, CircleHelp, KeyRound, Lock, XCircle } from "lucide-react";
import { db } from "@/db";
import { requestEvents, serviceRequests, supportCases, users } from "@/db/schema";
import { ApiButton } from "@/components/client";
import { failedOtpAttempts, lockedDeliveries } from "@/lib/admin-data";
import { requireSuperAdminPage } from "@/lib/admin-auth";
import { MAX_OTP_ATTEMPTS } from "@/lib/delivery";
import { dateTime } from "@/lib/labels";
import { maskName } from "@/lib/queries";

export const metadata = { title: "Uyuşmazlık Merkezi" };
const CATEGORY: Record<string, string> = { DELIVERY: "Teslimat / gecikme", OTP: "Teslim kodu", CANCELLATION: "İptal / iade", OTHER: "Diğer" };
const STATUS: Record<string, { label: string; cls: string }> = {
  OPEN: { label: "Açık", cls: "bg-signal/10 text-signal" },
  IN_REVIEW: { label: "İncelemede", cls: "bg-sun/15 text-[#8a6100]" },
  RESOLVED: { label: "Çözüldü", cls: "bg-mint/12 text-[#0c8a5a]" },
  REJECTED: { label: "Reddedildi", cls: "bg-ink/5 text-ink/55" },
};

export default async function AdminDisputes() {
  await requireSuperAdminPage("/admin/uyusmazliklar");
  const [cases, locked, failed, cancels] = await Promise.all([
    db.select({ c: supportCases, customer: users.name }).from(supportCases).innerJoin(users, eq(users.id, supportCases.customerId)).orderBy(desc(supportCases.createdAt)).limit(60),
    lockedDeliveries(),
    failedOtpAttempts(),
    db.select({ e: requestEvents, code: serviceRequests.code, id: serviceRequests.id }).from(requestEvents).innerJoin(serviceRequests, eq(serviceRequests.id, requestEvents.requestId)).where(inArray(requestEvents.toState, ["CANCELLED_BY_CUSTOMER", "CANCELLED_BY_PROVIDER", "CANCELLED_BY_OPS"])).orderBy(desc(requestEvents.createdAt)).limit(15),
  ]);
  const open = cases.filter(({ c }) => c.status === "OPEN" || c.status === "IN_REVIEW");
  return (
    <div className="px-4 py-8 sm:px-8">
      <div className="mb-6"><div className="eyebrow">İPTAL · TESLİM KODU · ŞİKAYET</div><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Uyuşmazlık merkezi</h1><p className="mt-1 max-w-3xl text-sm text-ink/55">Teslim kodu 3 kez hatalı girilen teslimatlar otomatik kilitlenir ve vaka açılır. Kilit açma ve vaka kararları gerekçe ister, denetim izine yazılır ve taraflara bildirilir. Özel mesaj içerikleri burada gösterilmez.</p></div>
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {[{ icon: CircleHelp, label: "Açık vaka", n: open.length }, { icon: Lock, label: "Kilitli teslimat", n: locked.length }, { icon: KeyRound, label: "Hatalı kod denemesi süren", n: failed.length }, { icon: XCircle, label: "Son iptaller", n: cancels.length }].map(({ icon: Icon, label, n }) => (
          <div key={label} className="rounded-[20px] border border-line bg-white p-4"><div className="flex items-center justify-between text-xs font-bold text-ink/55">{label}<Icon size={16} className="text-signal" /></div><div className="mt-1 text-3xl font-black">{n}</div></div>
        ))}
      </div>

      <div className="mt-7 grid gap-6 xl:grid-cols-[minmax(0,1fr)_360px]">
        <section>
          <h2 className="mb-3 flex items-center gap-2 text-lg font-extrabold"><CircleHelp size={18} className="text-signal" /> Vaka kuyruğu</h2>
          <div className="space-y-3">
            {cases.map(({ c, customer }) => (
              <article key={c.id} className={`rounded-[18px] border bg-white p-4 ${c.status === "OPEN" ? "border-signal/35" : "border-line"}`}>
                <div className="flex flex-wrap items-center gap-2"><span className={`rounded-full px-2 py-0.5 text-[10px] font-black ${STATUS[c.status]?.cls}`}>{STATUS[c.status]?.label ?? c.status}</span><b className="text-xs">{CATEGORY[c.category] ?? c.category}</b><span className="ml-auto text-[11px] text-ink/45">{dateTime(c.createdAt)}</span></div>
                <div className="mt-2 text-xs text-ink/55">{maskName(customer)} · {c.sourceType === "ORDER" ? "Sipariş" : "Görev"} · <Link href={c.sourceType === "ORDER" ? `/siparis/${c.sourceId}` : `/talep/${c.sourceId}`} className="font-bold text-signal hover:underline">İşlemi incele →</Link></div>
                <p className="mt-2 whitespace-pre-wrap break-words rounded-xl bg-paper p-3 text-xs leading-relaxed text-ink/75">{c.detail}</p>
                {c.resolution && <p className="mt-2 rounded-xl border border-line p-3 text-xs text-ink/70"><b>Karar:</b> {c.resolution}</p>}
                {(c.status === "OPEN" || c.status === "IN_REVIEW") && (
                  <div className="mt-3 flex flex-wrap gap-2">
                    {c.status === "OPEN" && <ApiButton url={`/api/dashboard/support/${c.id}`} body={{ status: "IN_REVIEW" }} prompt={{ label: "İnceleme notu (en az 12 karakter):", field: "resolution" }} className="btn-ghost btn-sm">İncelemeye al</ApiButton>}
                    <ApiButton url={`/api/dashboard/support/${c.id}`} body={{ status: "RESOLVED" }} prompt={{ label: "Müşteriye iletilecek çözüm ve gerekçe (en az 12 karakter):", field: "resolution" }} className="btn-primary btn-sm">Çözüldü</ApiButton>
                    <ApiButton url={`/api/dashboard/support/${c.id}`} body={{ status: "REJECTED" }} prompt={{ label: "Ret gerekçesi (en az 12 karakter):", field: "resolution" }} className="btn-danger btn-sm">Reddet</ApiButton>
                  </div>
                )}
              </article>
            ))}
            {cases.length === 0 && <div className="rounded-[18px] border border-line bg-white px-6 py-12 text-center"><CircleHelp size={24} className="mx-auto text-signal" /><b className="mt-3 block text-sm">Henüz uyuşmazlık kaydı yok</b><p className="mt-1 text-xs text-ink/55">Müşteri bildirimleri ve otomatik teslim kodu kilitleri burada görünür.</p></div>}
          </div>
        </section>
        <aside className="space-y-4">
          <div className="rounded-[20px] border border-line bg-white p-5">
            <h3 className="flex items-center gap-2 text-sm font-extrabold"><Lock size={16} className="text-signal" /> Kilitli teslimatlar</h3>
            <div className="mt-3 space-y-2">
              {locked.map((l) => (
                <div key={l.id} className="rounded-xl bg-paper p-3 text-xs">
                  <div className="flex items-center justify-between"><Link href={`/talep/${l.id}`} className="font-mono font-black hover:text-signal">{l.code}</Link><span className="font-bold text-rose">{l.attempts}/{MAX_OTP_ATTEMPTS} hata</span></div>
                  <div className="mt-1 text-ink/50">{l.providerName ?? "Kurye"} · {dateTime(l.lockedAt)}</div>
                  <div className="mt-2"><ApiButton url={`/api/admin/delivery/${l.id}/unlock`} prompt={{ label: "Kilit açma gerekçesi (müşteriyle teyit edildi mi? en az 10 karakter):", field: "reason" }} className="btn-primary btn-sm">Kilidi aç · 3 hak ver</ApiButton></div>
                </div>
              ))}
              {locked.length === 0 && <p className="text-xs text-ink/50">Kilitli teslimat yok.</p>}
            </div>
          </div>
          <div className="rounded-[20px] border border-line bg-white p-5">
            <h3 className="flex items-center gap-2 text-sm font-extrabold"><AlertTriangle size={16} className="text-signal" /> Hatalı deneme süren teslimatlar</h3>
            <div className="mt-3 space-y-1.5">{failed.map((f) => <Link key={f.id} href={`/talep/${f.id}`} className="flex items-center justify-between rounded-lg bg-paper px-3 py-2 text-xs hover:bg-paper-2"><b className="font-mono">{f.code}</b><span className="font-bold text-signal">{f.attempts}/{MAX_OTP_ATTEMPTS}</span></Link>)}{failed.length === 0 && <p className="text-xs text-ink/50">Yok.</p>}</div>
          </div>
          <div className="rounded-[20px] border border-line bg-white p-5">
            <h3 className="flex items-center gap-2 text-sm font-extrabold"><XCircle size={16} className="text-signal" /> Son iptaller</h3>
            <div className="mt-3 space-y-1.5">{cancels.map(({ e, code, id }) => <Link key={e.id} href={`/talep/${id}`} className="block rounded-lg bg-paper px-3 py-2 text-xs hover:bg-paper-2"><b className="font-mono">{code}</b> · {e.toState === "CANCELLED_BY_PROVIDER" ? "Kurye iptali" : e.toState === "CANCELLED_BY_OPS" ? "Operasyon iptali" : "Müşteri iptali"}<span className="block text-[10px] text-ink/45">{dateTime(e.createdAt)}{e.message ? ` · ${e.message}` : ""}</span></Link>)}{cancels.length === 0 && <p className="text-xs text-ink/50">İptal kaydı yok.</p>}</div>
            <Link href="/admin/audit" className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-signal hover:underline">Denetim izi <ArrowRight size={12} /></Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
