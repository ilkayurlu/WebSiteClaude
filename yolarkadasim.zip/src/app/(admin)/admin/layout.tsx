import type { Metadata } from "next";
import type { ReactNode } from "react";
import { eq, inArray, sql } from "drizzle-orm";
import { Activity, Database, ShieldCheck } from "lucide-react";
import { db } from "@/db";
import { mediaPosts, providerDocuments, serviceRequests, supportCases } from "@/db/schema";
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { requireAdminArea } from "@/lib/admin-auth";

export const metadata: Metadata = { title: { template: "%s · Yönetim", default: "Yönetim Paneli · YolArkadaşı" }, robots: { index: false, follow: false } };

async function systemStatus() {
  try {
    const [[docs], [cases], [tasks], [media]] = await Promise.all([
      db.select({ n: sql<number>`count(distinct ${providerDocuments.providerId})::int` }).from(providerDocuments).where(eq(providerDocuments.status, "SUBMITTED")),
      db.select({ n: sql<number>`count(*)::int` }).from(supportCases).where(inArray(supportCases.status, ["OPEN", "IN_REVIEW"])),
      db.select({ n: sql<number>`count(*) filter (where ${serviceRequests.status}='EXPIRED' or ${serviceRequests.otpLockedAt} is not null)::int`, active: sql<number>`count(*) filter (where ${serviceRequests.status} in ('MATCHING','OFFERED','CONFIRMED','IN_PROGRESS'))::int` }).from(serviceRequests).where(sql`${serviceRequests.updatedAt} > now() - interval '24 hours'`),
      db.select({ n: sql<number>`count(*)::int` }).from(mediaPosts).where(eq(mediaPosts.status, "PENDING_REVIEW")),
    ]);
    return { db: true, approvals: docs?.n ?? 0, cases: cases?.n ?? 0, tasks: tasks?.n ?? 0, active: tasks?.active ?? 0, media: media?.n ?? 0 };
  } catch {
    return { db: false, approvals: 0, cases: 0, tasks: 0, active: 0, media: 0 };
  }
}

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const s = await requireAdminArea();
  const st = await systemStatus();
  const now = new Intl.DateTimeFormat("tr-TR", { dateStyle: "medium", timeStyle: "short", timeZone: "Europe/Istanbul" }).format(new Date());
  return (
    <div className="min-h-screen bg-ink lg:pl-[264px]">
      <AdminSidebar role={s.user.role} name={s.user.name} badges={{ approvals: st.approvals, cases: st.cases, tasks: st.tasks, media: st.media }} />
      <div className="sticky top-0 z-30 flex min-h-16 flex-wrap items-center justify-between gap-3 border-b border-white/10 bg-ink/95 px-4 py-3 pl-16 text-white backdrop-blur lg:pl-7">
        <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold">
          <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 ${st.db ? "bg-mint/15 text-[#7fe3b7]" : "bg-rose/20 text-rose"}`}><Database size={12} className="text-signal" aria-hidden="true" /> Veritabanı {st.db ? "çevrimiçi" : "erişilemiyor"}</span>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-white/75"><Activity size={12} className="text-signal" aria-hidden="true" /> {st.active} aktif görev</span>
          {st.tasks > 0 && <span className="inline-flex items-center gap-1.5 rounded-full bg-signal/20 px-2.5 py-1 text-signal">⚠ {st.tasks} müdahale bekleyen görev</span>}
          {st.cases > 0 && <span className="inline-flex items-center gap-1.5 rounded-full bg-signal/20 px-2.5 py-1 text-signal">{st.cases} açık uyuşmazlık</span>}
        </div>
        <div className="flex items-center gap-2 text-[11px] text-white/50"><ShieldCheck size={13} className="text-signal" aria-hidden="true" /> {s.user.role === "SUPER_ADMIN" ? "SUPER_ADMIN" : "ADMIN"} · {now}</div>
      </div>
      <main className="min-h-[calc(100vh-4rem)] rounded-tl-none bg-paper lg:rounded-tl-[28px]">{children}</main>
    </div>
  );
}
