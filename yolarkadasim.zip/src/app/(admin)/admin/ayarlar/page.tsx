import Link from "next/link";
import { ArrowRight, Clock3, KeyRound, Lock, Settings, ShieldCheck } from "lucide-react";
import { CommissionForm } from "@/components/admin/CommissionForm";
import { getCommissionBps } from "@/lib/finance";
import { requireSuperAdminPage } from "@/lib/admin-auth";
import { FLEET_TTL_S, OFFER_TTL_S, REVIEW_WINDOW_DAYS } from "@/lib/engine";
import { MAX_OTP_ATTEMPTS } from "@/lib/delivery";
import { demoEnabled } from "@/lib/session";

export const metadata = { title: "Sistem Ayarları" };
export default async function AdminSettings() {
  await requireSuperAdminPage("/admin/ayarlar");
  const bps = await getCommissionBps();
  const rules = [
    { icon: Clock3, label: "Kurye teklif yanıt süresi", value: `${OFFER_TTL_S} saniye` },
    { icon: Clock3, label: "Filo onay süresi", value: `${FLEET_TTL_S} saniye` },
    { icon: Lock, label: "Teslim kodu deneme hakkı", value: `${MAX_OTP_ATTEMPTS} hata sonrası kilit + uyuşmazlık kaydı` },
    { icon: ShieldCheck, label: "Değerlendirme süresi", value: `Teslimden sonra ${REVIEW_WINDOW_DAYS} gün` },
    { icon: KeyRound, label: "Demo hesap girişi", value: demoEnabled() ? "Açık (DISABLE_DEMO_ACCOUNTS=true ile kapatılır)" : "Kapalı" },
  ];
  return (
    <div className="px-4 py-8 sm:px-8">
      <div className="mb-6"><div className="eyebrow">PLATFORM YAPILANDIRMASI</div><h1 className="mt-2 flex items-center gap-2 text-3xl font-black tracking-tight sm:text-4xl"><Settings size={28} className="text-signal" /> Sistem ayarları</h1><p className="mt-1 max-w-2xl text-sm text-ink/55">Değiştirilebilir ayarlar gerekçe ister ve denetim izine yazılır. Güvenlik kuralları kod düzeyinde sabittir.</p></div>
      <div className="grid gap-6 xl:grid-cols-2">
        <CommissionForm currentBps={bps} />
        <div className="rounded-[22px] border border-line bg-white p-5">
          <h3 className="font-extrabold">Sabit operasyon kuralları</h3>
          <div className="mt-3 divide-y divide-line">{rules.map(({ icon: Icon, label, value }) => <div key={label} className="flex items-start gap-3 py-3 text-sm"><Icon size={16} className="mt-0.5 text-signal" /><span className="flex-1 text-ink/60">{label}</span><b className="max-w-[55%] text-right">{value}</b></div>)}</div>
          <Link href="/admin/audit" className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-signal hover:underline">Ayar değişiklik geçmişi <ArrowRight size={12} /></Link>
        </div>
      </div>
    </div>
  );
}
