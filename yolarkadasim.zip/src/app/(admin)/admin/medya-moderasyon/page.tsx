import Image from "next/image";
import Link from "next/link";
import { AdminHead } from "@/components/AdminNav";
import { ApiButton } from "@/components/client";
import { AdminOnly } from "@/components/AdminGuard";
import { EmptyState, Pill } from "@/components/ui";
import { MEDIA_POLICY, MEDIA_STATUS, dateTime } from "@/lib/labels";
import { moderationQueue } from "@/lib/media";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Medya Moderasyonu — Operasyon" };

export default async function AdminMedia() {
  const s = await getSession();
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) return <AdminOnly />;
  const { posts, cases, logs } = await moderationQueue();

  return (
    <div className="container-x py-10">
      <AdminHead
        active="/admin/medya-moderasyon"
        title="Medya moderasyonu"
        desc="Yüklenen her dosya önce özel alanda saklanır; EXIF/GPS temizlenir, dosya türü magic-byte ile doğrulanır. Onaylanan içerik herkese açık alana kopyalanır. Karar verirken politika maddesini seçin — gerekçe zorunludur."
      />

      <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
        <div>
          <h2 className="mb-3 flex items-center gap-2 text-lg font-extrabold">
            İnceleme kuyruğu <span className="rounded-full bg-paper-2 px-2 py-0.5 text-sm">{posts.length}</span>
          </h2>
          {posts.length === 0 ? (
            <EmptyState icon="✅" title="Kuyruk temiz" description="İnceleme bekleyen medya yok. Yeni yüklemeler buraya otomatik düşer." />
          ) : (
            <div className="grid gap-4 sm:grid-cols-2">
              {posts.map((p) => (
                <div key={p.id} className="card overflow-hidden">
                  <div className="relative aspect-[4/3] bg-paper">
                    {p.privatePath ? (
                      <>
                        <Image src={`/api/admin/media/${p.id}/preview`} alt={p.caption ?? "İnceleme bekleyen içerik"} fill className="object-cover" sizes="(max-width:640px) 100vw, 400px" unoptimized />
                        <span className="absolute left-2 top-2 rounded-full bg-ink/80 px-2 py-0.5 text-[10px] font-bold text-white">🔒 Özel depolama · yalnızca moderasyon</span>
                      </>
                    ) : p.publicUrl ? (
                      <Image src={p.publicUrl} alt={p.caption ?? "İçerik"} fill className="object-cover" sizes="(max-width:640px) 100vw, 400px" />
                    ) : (
                      <div className="flex h-full items-center justify-center text-xs text-ink/45">Dosya bulunamadı</div>
                    )}
                  </div>
                  <div className="p-4">
                    <div className="flex items-center justify-between gap-2">
                      <div className="min-w-0">
                        <div className="truncate font-bold">{p.ownerName}</div>
                        <div className="text-[11px] text-ink/45">{p.ownerType === "PROVIDER" ? "Sağlayıcı" : p.ownerType === "FLEET" ? "Filo" : "İşletme"} · {dateTime(p.createdAt)}</div>
                      </div>
                      <Pill tone={MEDIA_STATUS[p.status]?.tone ?? "amber"}>{MEDIA_STATUS[p.status]?.label}</Pill>
                    </div>
                    {p.caption && <p className="mt-2 line-clamp-2 text-sm text-ink/70">{p.caption}</p>}
                    <div className="mt-2 flex flex-wrap gap-1.5 text-[11px]">
                      <span className="chip !px-2 !py-0.5">{p.mime}</span>
                      <span className="chip !px-2 !py-0.5">{Math.round((p.bytes ?? 0) / 1024)} KB</span>
                      <span className="chip !px-2 !py-0.5">{p.exifStripped ? "✓ EXIF temizlendi" : "EXIF yok"}</span>
                      <span className="chip !px-2 !py-0.5">{p.scanned ? "✓ Tarandı" : "Taranmadı"}</span>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {MEDIA_POLICY.map((pol) => (
                        <ApiButton key={pol.ref} url={`/api/admin/media/${p.id}`} body={{ action: "approve", policyRef: pol.ref }} className="btn-mint btn-sm" prompt={{ label: `Onay notu (${pol.ref} ${pol.label}):`, field: "reason" }}>✓ {pol.ref}</ApiButton>
                      ))}
                      <ApiButton url={`/api/admin/media/${p.id}`} body={{ action: "reject" }} className="btn-danger btn-sm" prompt={{ label: "Ret gerekçesi ve politika maddesi (zorunlu):", field: "reason" }}>Reddet</ApiButton>
                      <ApiButton url={`/api/admin/media/${p.id}`} body={{ action: "hide" }} className="btn-ghost btn-sm" prompt={{ label: "Gizleme gerekçesi (zorunlu):", field: "reason" }}>Gizle</ApiButton>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <aside className="space-y-4">
          <div className="card p-5">
            <h3 className="font-extrabold">Politika maddeleri</h3>
            <div className="mt-3 space-y-2">
              {MEDIA_POLICY.map((p) => (
                <div key={p.ref} className="rounded-xl bg-paper px-3 py-2 text-xs">
                  <b className="text-signal">{p.ref} · {p.label}</b>
                  <div className="mt-0.5 text-ink/65">{p.desc}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="card p-5">
            <h3 className="font-extrabold">Açık vakalar ({cases.length})</h3>
            <div className="mt-3 space-y-2 text-sm">
              {cases.length === 0 && <p className="text-ink/50">Açık vaka yok.</p>}
              {cases.slice(0, 10).map((c) => (
                <div key={c.id} className="rounded-xl bg-paper px-3 py-2">
                  <div className="flex items-center gap-2"><Pill tone="amber">{c.kind}</Pill><span className="text-xs text-ink/55">{dateTime(c.createdAt)}</span></div>
                  <div className="mt-1 text-xs text-ink/70">{c.reason}</div>
                </div>
              ))}
            </div>
            <Link href="/admin/raporlanan-icerikler" className="btn-ghost btn-sm mt-4 w-full">Raporlanan içerikler →</Link>
          </div>
          <div className="card p-5">
            <h3 className="font-extrabold">Son medya kararları</h3>
            <div className="mt-3 space-y-2 text-xs">
              {logs.filter((l) => l.action.startsWith("media.")).slice(0, 8).map((l) => (
                <div key={l.id} className="rounded-lg bg-paper px-2.5 py-1.5">
                  <code className="font-bold">{l.action}</code> <span className="text-ink/45">{dateTime(l.createdAt)}</span>
                  {l.reason && <div className="text-ink/65">“{l.reason}”</div>}
                </div>
              ))}
              {!logs.some((l) => l.action.startsWith("media.")) && <p className="text-ink/50">Henüz karar yok.</p>}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

/** Özel alandaki dosya yalnızca moderasyon yetkisiyle, sunucu üzerinden imzalı biçimde okunur. */
function PreviewPrivate({ post }: { post: { id: string; mime: string | null; caption: string | null; ownerName: string; bytes: number | null } }) {
  return (
    <div className="flex h-full flex-col items-center justify-center gap-1 bg-ink/5 p-3 text-center">
      <span className="text-2xl">🔒</span>
      <span className="text-xs font-bold">Özel depolama</span>
      <span className="text-[11px] text-ink/55">Onaylanınca herkese açık sürüm oluşturulur. {post.ownerName}</span>
    </div>
  );
}
