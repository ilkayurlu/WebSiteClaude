"use client";

import Link from "next/link";

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <div className="container-x py-20">
      <div className="card road-pattern mx-auto max-w-xl px-8 py-12 text-center">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-rose/10 text-2xl" aria-hidden="true">🛠️</div>
        <h1 className="text-2xl font-black tracking-tight">Bir şeyler ters gitti</h1>
        <p className="mt-2 text-sm leading-relaxed text-ink/60">
          Bu bölüm şu anda yüklenemedi. Verileriniz güvende; sayfayı yenileyebilir veya destek merkezine başvurabilirsiniz.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button type="button" onClick={reset} className="btn-primary">↻ Tekrar dene</button>
          <Link href="/" className="btn-ink">Ana sayfaya dön</Link>
          <Link href="/destek" className="btn-ghost">💬 Destek al</Link>
        </div>
      </div>
    </div>
  );
}
