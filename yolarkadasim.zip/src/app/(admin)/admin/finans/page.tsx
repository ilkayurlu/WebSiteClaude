import Link from "next/link";
import { ArrowRight, Info, Percent } from "lucide-react";
import { FinancePayoutTable } from "@/components/admin/FinancePayoutTable";
import { requireSuperAdminPage } from "@/lib/admin-auth";
import { getCommissionBps } from "@/lib/finance";
import { listPayoutRecords, type PeriodGranularity } from "@/lib/payouts";

export const metadata = { title: "Finans & Hakediş" };

export default async function AdminFinance({ searchParams }: { searchParams: Promise<{ periyot?: string }> }) {
  await requireSuperAdminPage("/admin/finans");
  const { periyot } = await searchParams;
  const granularity: PeriodGranularity = periyot === "ay" ? "month" : "week";
  const [records, commissionBps] = await Promise.all([listPayoutRecords(granularity), getCommissionBps()]);
  return (
    <div className="px-4 py-8 sm:px-8">
      <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="eyebrow">GMV · KOMİSYON · HAKEDİŞ · ÖDEME ÇIKIŞI</div>
          <h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Finans</h1>
          <p className="mt-1 max-w-3xl text-sm text-ink/55">
            Hakediş, teslim kodu doğrulanan her görevde deftere tahakkuk eder; filo üyelerinin kazancı filo hakedişi, bağımsız kuryelerinki kurye hakedişi olarak ayrışır.
            Ödeme emirleri {granularity === "week" ? "ISO haftası" : "takvim ayı"} bazında gruplanır.
          </p>
        </div>
        <Link href="/admin/ayarlar" className="btn-ghost btn-sm"><Percent size={13} className="text-signal" /> Komisyon %{(commissionBps / 100).toFixed(1)}</Link>
      </div>
      <FinancePayoutTable records={records} granularity={granularity} commissionBps={commissionBps} />
      <div className="mt-6 flex items-start gap-3 rounded-2xl border border-line bg-white p-5 text-xs leading-relaxed text-ink/60">
        <Info size={16} className="mt-0.5 shrink-0 text-signal" />
        <div>
          <b className="text-ink">Muhasebe notu.</b> Tutarlar kuruş cinsinden tam sayı saklanır; komisyon görev anındaki oranla aşağı yuvarlanır, net = brüt − komisyon. Vergi/stopaj ve gerçek banka transferi bu ortamda bağlı değildir; “Ödendi” durumu ödeme emrinin kayda alındığını belirtir.
          <Link href="/admin/audit" className="ml-1 inline-flex items-center gap-1 font-bold text-signal hover:underline">Onay kayıtları <ArrowRight size={12} /></Link>
        </div>
      </div>
    </div>
  );
}
