import Link from "next/link";
import { ArrowRight, Building2, ShieldCheck, Truck, UsersRound } from "lucide-react";
import { adminFleets } from "@/lib/admin-data";
import { requireSuperAdminPage } from "@/lib/admin-auth";
import { FLEET_POLICY, money } from "@/lib/labels";

export const metadata = { title: "Filolar" };
export default async function AdminFleets() {
  await requireSuperAdminPage("/admin/filolar");
  const fleets = await adminFleets();
  return (
    <div className="px-4 py-8 sm:px-8">
      <div className="mb-6"><div className="eyebrow">KURUMSAL İŞ ORTAKLARI</div><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Filolar</h1><p className="mt-1 max-w-2xl text-sm text-ink/55">Filo ekip durumu, doğrulanmamış üyeler ve brüt görev hacmi. Üyelerin kişisel telefon ve konumları bu ekranda gösterilmez.</p></div>
      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {fleets.map((f) => (
          <article key={f.id} className="overflow-hidden rounded-[22px] border border-line bg-white">
            <div className="h-1.5" style={{ background: f.accent }} />
            <div className="p-5">
              <div className="flex items-start justify-between gap-2"><div className="flex items-center gap-2"><Building2 size={18} className="text-signal" /><h2 className="font-extrabold">{f.name}</h2></div>{f.isVerified && <span className="inline-flex items-center gap-1 rounded-full bg-signal/10 px-2 py-0.5 text-[10px] font-bold text-signal"><ShieldCheck size={11} /> Doğrulanmış</span>}</div>
              <p className="mt-1 text-xs text-ink/55">Sahibi: {f.ownerName} · {f.city} · {FLEET_POLICY[f.directPolicy]?.label}</p>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-paper p-2"><UsersRound size={14} className="mx-auto text-signal" /><b className="mt-1 block">{f.members}</b><span className="text-[10px] text-ink/50">üye</span></div>
                <div className="rounded-xl bg-paper p-2"><Truck size={14} className="mx-auto text-signal" /><b className="mt-1 block">{f.available}</b><span className="text-[10px] text-ink/50">müsait</span></div>
                <div className="rounded-xl bg-paper p-2"><ShieldCheck size={14} className="mx-auto text-signal" /><b className="mt-1 block">{f.unverified}</b><span className="text-[10px] text-ink/50">doğrulanmamış</span></div>
              </div>
              <div className="mt-3 text-xs text-ink/60">Brüt görev hacmi: <b className="text-ink">{money(f.grossMinor)}</b> · {f.onTask} üye görevde</div>
              <div className="mt-4 flex flex-wrap gap-2"><Link href={`/filolar/${f.slug}`} className="btn-ghost btn-sm">Vitrin <ArrowRight size={12} className="text-signal" /></Link><Link href="/admin/kuryeler" className="btn-ghost btn-sm">Üye evrakları <ArrowRight size={12} className="text-signal" /></Link><Link href="/admin/finans" className="btn-ghost btn-sm">Hakedişler <ArrowRight size={12} className="text-signal" /></Link></div>
            </div>
          </article>
        ))}
        {fleets.length === 0 && <div className="rounded-[22px] border border-line bg-white p-10 text-center text-sm text-ink/55 md:col-span-3">Kayıtlı filo yok. Filo başvuruları <Link href="/admin/basvurular" className="font-bold text-signal">başvurular</Link> ekranında.</div>}
      </div>
    </div>
  );
}
