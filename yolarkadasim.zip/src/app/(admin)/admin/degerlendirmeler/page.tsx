import { AdminHead } from "@/components/AdminNav";
import { ApiButton } from "@/components/client";
import { PanelTabs } from "@/components/RestaurantView";
import { EmptyState, Pill, StarRow } from "@/components/ui";
import { REPORT_REASONS, dateTime, timeAgo } from "@/lib/labels";
import { reviewModerationData } from "@/lib/review-ops";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Değerlendirme Moderasyonu — Operasyon" };

export default async function AdminReviews() {
  const s = await getSession();
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) return <Forbidden />;
  const data = await reviewModerationData("all");

  const ReviewCard = ({ r }: { r: (typeof data.items)[number] }) => (
    <div className="card p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <div className="flex items-center gap-2"><StarRow value={r.rating} /><b>{r.targetName}</b><Pill tone={r.targetType === "RESTAURANT" ? "blue" : "slate"}>{r.targetType === "RESTAURANT" ? "İşletme" : "Sağlayıcı"}</Pill></div>
          <div className="text-xs text-ink/45">{r.author} · {timeAgo(r.createdAt)} {r.reportCount > 0 && <span className="ml-1 font-bold text-rose">· {r.reportCount} bildirim</span>}</div>
        </div>
        <Pill tone={r.status === "PUBLISHED" ? "green" : "red"}>{r.status === "PUBLISHED" ? "Yayında" : "Gizli"}</Pill>
      </div>
      {r.body && <p className="mt-2 text-sm text-ink/75">{r.body}</p>}
      {r.reason && <p className="mt-1 text-xs text-ink/45">Moderasyon gerekçesi: {r.reason}</p>}
      {r.response && <div className="mt-2 rounded-xl border-l-2 border-signal bg-paper px-3 py-2 text-xs">Yanıt: {r.response}</div>}
      <div className="mt-3 flex flex-wrap gap-1.5">
        {r.status === "PUBLISHED" ? (
          <>
            <ApiButton url={`/api/admin/reviews/${r.id}`} body={{ action: "hide" }} className="btn-danger btn-sm" prompt={{ label: "Gizleme gerekçesi (zorunlu, kullanıcıya bildirilir):", field: "reason" }}>Gizle</ApiButton>
            <ApiButton url={`/api/admin/reviews/${r.id}`} body={{ action: "mask_pii" }} className="btn-ghost btn-sm" prompt={{ label: "Maskeleme gerekçesi (zorunlu):", field: "reason" }}>Kişisel veriyi maskele</ApiButton>
          </>
        ) : (
          <ApiButton url={`/api/admin/reviews/${r.id}`} body={{ action: "publish" }} className="btn-mint btn-sm" prompt={{ label: "Yeniden yayın gerekçesi:", field: "reason" }}>Yeniden yayınla</ApiButton>
        )}
      </div>
    </div>
  );

  return (
    <div className="container-x py-10">
      <AdminHead
        active="/admin/degerlendirmeler"
        title="Değerlendirme moderasyonu"
        desc="Puanlar değiştirilemez; yalnızca görünürlük ve kişisel veri maskeleme yapılabilir. Her işlem gerekçe ister ve denetim izine yazılır. Olumsuz yorum, sadece olumsuz olduğu için gizlenmez."
      />
      <PanelTabs
        tabs={[
          { key: "all", label: "Tümü", count: data.items.length },
          { key: "reported", label: "Bildirilenler", count: data.reports.filter((r) => r.status === "OPEN").length },
          { key: "appeals", label: "İtirazlar", count: data.appeals.filter((a) => a.status === "OPEN").length },
          { key: "log", label: "İşlem kayıtları", count: data.logs.length },
        ]}
        panels={{
          all: data.items.length ? <div className="grid gap-4 lg:grid-cols-2">{data.items.map((r) => <ReviewCard key={r.id} r={r} />)}</div> : <EmptyState icon="⭐" title="Henüz değerlendirme yok" description="Değerlendirmeler yalnızca tamamlanan hizmet ve teslim edilen siparişlerden sonra oluşur." />,
          reported: (
            <div className="space-y-3">
              {data.reports.length === 0 && <EmptyState icon="⚑" title="Bildirilen yorum yok" description="Kullanıcı bildirimleri burada gerekçe ve bildiren bilgisiyle listelenir." />}
              {data.reports.map((r) => (
                <div key={r.id} className="card flex flex-wrap items-center gap-3 p-4">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2"><Pill tone={r.status === "OPEN" ? "amber" : r.status === "RESOLVED" ? "green" : "slate"}>{r.status === "OPEN" ? "Açık" : r.status === "RESOLVED" ? "Çözüldü" : "Reddedildi"}</Pill><b className="text-sm">{REPORT_REASONS[r.reason] ?? r.reason}</b></div>
                    <div className="mt-1 text-xs text-ink/55">{r.reporter} · {dateTime(r.createdAt)}{r.detail ? ` — “${r.detail}”` : ""}</div>
                  </div>
                  {r.status === "OPEN" && (
                    <>
                      <ApiButton url={`/api/admin/reports/${r.id}`} body={{ action: "RESOLVED" }} className="btn-danger btn-sm" prompt={{ label: "Karar notu (zorunlu):", field: "note" }}>İhlal var</ApiButton>
                      <ApiButton url={`/api/admin/reports/${r.id}`} body={{ action: "DISMISSED" }} className="btn-ghost btn-sm" prompt={{ label: "Red gerekçesi (zorunlu):", field: "note" }}>Reddet</ApiButton>
                    </>
                  )}
                </div>
              ))}
            </div>
          ),
          appeals: (
            <div className="space-y-3">
              {data.appeals.length === 0 && <EmptyState icon="⚖" title="İtiraz yok" description="Sağlayıcı, filo ve işletmeler yalnızca kendi profillerine gelen değerlendirmelere itiraz edebilir." />}
              {data.appeals.map((a) => (
                <div key={a.id} className="card p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    <Pill tone={a.status === "OPEN" ? "amber" : a.status === "ACCEPTED" ? "green" : "slate"}>{a.status === "OPEN" ? "Karar bekliyor" : a.status === "ACCEPTED" ? "Kabul edildi" : "Reddedildi"}</Pill>
                    <b className="text-sm">{a.appellant}</b>
                    <span className="text-xs text-ink/45">{dateTime(a.createdAt)}</span>
                  </div>
                  <p className="mt-2 text-sm text-ink/75">{a.reason}</p>
                  {a.note && <p className="mt-1 text-xs text-ink/50">Karar: {a.note}</p>}
                  {a.status === "OPEN" && (
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      <ApiButton url={`/api/admin/appeals/${a.id}`} body={{ decision: "ACCEPTED" }} className="btn-mint btn-sm" prompt={{ label: "Kabul gerekçesi (zorunlu):", field: "note" }}>İtirazı kabul et</ApiButton>
                      <ApiButton url={`/api/admin/appeals/${a.id}`} body={{ decision: "REJECTED" }} className="btn-ghost btn-sm" prompt={{ label: "Ret gerekçesi (zorunlu):", field: "note" }}>İtirazı reddet</ApiButton>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ),
          log: (
            <div className="card divide-y divide-line">
              {data.logs.length === 0 && <div className="p-6 text-center text-sm text-ink/50">Henüz moderasyon işlemi yok.</div>}
              {data.logs.map((l) => (
                <div key={l.id} className="px-4 py-2.5 text-sm">
                  <code className="rounded bg-paper px-1.5 py-0.5 text-xs font-bold">{l.action}</code>
                  <span className="ml-2 text-xs text-ink/55">{dateTime(l.createdAt)}</span>
                  {l.reason && <div className="mt-0.5 text-xs text-ink/65">“{l.reason}”</div>}
                </div>
              ))}
            </div>
          ),
        }}
        initial="all"
      />
    </div>
  );
}

function Forbidden() {
  return (
    <div className="container-x py-20">
      <div className="mx-auto max-w-xl">
        <EmptyState icon="🛡️" title="Yetkiniz yok" description="Bu sayfa yalnızca operasyon ekibine açıktır. Sağ üstten “Operasyon Ekibi” hesabına geçin." actions={[{ label: "Ana sayfa", href: "/", primary: true }]} />
      </div>
    </div>
  );
}
