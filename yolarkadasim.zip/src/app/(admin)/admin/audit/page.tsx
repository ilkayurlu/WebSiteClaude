import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, users } from "@/db/schema";
import { AdminHead } from "@/components/AdminNav";
import { AdminOnly } from "@/components/AdminGuard";
import { EmptyState } from "@/components/ui";
import { dateTime } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Denetim İzi — Operasyon" };

const GROUPS = [
  { key: "review", label: "Değerlendirme", match: (a: string) => a.startsWith("review.") || a.startsWith("appeal.") },
  { key: "media", label: "Medya", match: (a: string) => a.startsWith("media.") || a === "content.report" },
  { key: "fleet", label: "Filo", match: (a: string) => a.startsWith("fleet.") },
  { key: "profile", label: "Profil", match: (a: string) => a.startsWith("profile.") || a.startsWith("provider.") || a.startsWith("fleet_profile.") },
  { key: "request", label: "Talep", match: (a: string) => a.startsWith("request.") },
  { key: "application", label: "Başvuru", match: (a: string) => a.startsWith("application.") },
];

export default async function AdminAudit() {
  const s = await getSession();
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) return <AdminOnly />;
  const rows = await db.select({ l: auditLogs, actor: users.name }).from(auditLogs).leftJoin(users, eq(users.id, auditLogs.actorId)).orderBy(desc(auditLogs.createdAt)).limit(200);
  const [counts] = await db.select({ n: sql<number>`count(*)::int` }).from(auditLogs);

  return (
    <div className="container-x py-10">
      <AdminHead
        active="/admin/audit"
        title="Denetim izi"
        desc={`Toplam ${counts?.n ?? 0} kayıt. Rol, politika ve içerik kararları; işlemi yapan, zaman, gerekçe ve önceki/yeni durum ile saklanır. Kayıtlar salt okunurdur.`}
      />
      {rows.length === 0 ? (
        <EmptyState icon="🧾" title="Henüz denetim kaydı yok" description="Moderasyon, filo politikası ve profil değişiklikleri yapıldıkça burada listelenir." actions={[{ label: "Değerlendirme moderasyonu", href: "/admin/degerlendirmeler", primary: true }]} />
      ) : (
        <>
          <div className="mb-4 flex flex-wrap gap-2">
            {GROUPS.map((g) => (
              <span key={g.key} className="chip">{g.label}: <b className="ml-1">{rows.filter((r) => g.match(r.l.action)).length}</b></span>
            ))}
          </div>
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="border-b border-line bg-paper/60 text-left text-xs uppercase tracking-wider text-ink/50">
                <tr>
                  <th className="px-4 py-3">İşlem</th>
                  <th className="hidden px-4 py-3 sm:table-cell">Yetkili</th>
                  <th className="hidden px-4 py-3 md:table-cell">Hedef</th>
                  <th className="px-4 py-3">Gerekçe</th>
                  <th className="px-4 py-3 text-right">Zaman</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {rows.map(({ l, actor }) => (
                  <tr key={l.id} className="transition hover:bg-paper/60">
                    <td className="px-4 py-2.5"><code className="rounded bg-paper px-1.5 py-0.5 text-xs font-bold">{l.action}</code></td>
                    <td className="hidden px-4 py-2.5 text-ink/70 sm:table-cell">{actor ?? "sistem"}</td>
                    <td className="hidden px-4 py-2.5 text-xs text-ink/50 md:table-cell">{l.entityType} · {l.entityId.slice(0, 8)}…</td>
                    <td className="max-w-xs px-4 py-2.5 text-xs text-ink/70">{l.reason ?? "—"}</td>
                    <td className="whitespace-nowrap px-4 py-2.5 text-right text-xs text-ink/45">{dateTime(l.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
