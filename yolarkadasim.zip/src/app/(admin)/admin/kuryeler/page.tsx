import { CourierApprovalTable } from "@/components/admin/CourierApprovalTable";
import { courierVerifications } from "@/lib/admin-data";
import { requireSuperAdminPage } from "@/lib/admin-auth";

export const metadata = { title: "Kurye & Sağlayıcı Yönetimi" };
export default async function AdminCouriers() {
  await requireSuperAdminPage("/admin/kuryeler");
  const couriers = await courierVerifications();
  return (
    <div className="px-4 py-8 sm:px-8">
      <div className="mb-6"><div className="eyebrow">DOĞRULAMA · ENGELLEME · ARAÇ</div><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Kurye & sağlayıcı yönetimi</h1><p className="mt-1 max-w-3xl text-sm text-ink/55">Ehliyet, ruhsat ve adli sicil evraklarını özel depodan önizleyip onaylayın. Doğrulama rozeti yalnızca üç evrak da onaylandığında verilir. Ret ve engelleme gerekçe ister; her karar denetim izine yazılır ve kuryeye bildirilir. Demo ortamındaki örnek belgeler açıkça “DEMO” damgalıdır.</p></div>
      <CourierApprovalTable couriers={couriers} />
    </div>
  );
}
