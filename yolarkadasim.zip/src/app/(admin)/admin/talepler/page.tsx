import { LiveTaskMonitor } from "@/components/admin/LiveTaskMonitor";
import { liveTasks } from "@/lib/admin-data";
import { requireSuperAdminPage } from "@/lib/admin-auth";
import { sweepExpired } from "@/lib/engine";
import { areaLabelWithCity } from "@/lib/geo";

export const metadata = { title: "Canlı Görev Takibi" };
export default async function AdminTasks() {
  await requireSuperAdminPage("/admin/talepler");
  await sweepExpired();
  const tasks = await liveTasks();
  return (
    <div className="px-4 py-8 sm:px-8">
      <div className="mb-6"><div className="eyebrow">SİPARİŞLER & GÖREVLER</div><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Canlı görev takibi</h1><p className="mt-1 max-w-3xl text-sm text-ink/55">Son 24 saatin açık görevleri. Kurye bulamayan, uzun süre kabul edilmeyen, başlatılmayan veya teslim kodu kilitlenen işler önceliklendirilir. Manuel atama sunucuda bölge/araç/müsaitlik kontrolünden geçer.</p></div>
      <LiveTaskMonitor tasks={tasks} areas={[...new Set(tasks.map((t) => t.pickupKey))].map((key) => ({ key, name: areaLabelWithCity(key) }))} />
    </div>
  );
}
