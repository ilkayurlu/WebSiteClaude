import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { partnerApplications } from "@/db/schema";
import { AdminHead } from "@/components/AdminNav";
import { AdminOnly } from "@/components/AdminGuard";
import { ApiButton } from "@/components/client";
import { EmptyState, Pill } from "@/components/ui";
import { areaName } from "@/lib/geo";
import { dateTime, timeAgo } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "İş Ortağı Başvuruları — Operasyon" };

const STATUS: Record<string, { label: string; tone: string }> = {
  PENDING: { label: "Karar bekliyor", tone: "amber" },
  APPROVED: { label: "Onaylandı", tone: "green" },
  REJECTED: { label: "Reddedildi", tone: "red" },
  NEEDS_INFO: { label: "Bilgi bekleniyor", tone: "blue" },
};

export default async function AdminApplications() {
  const s = await getSession();
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) return <AdminOnly />;
  const [rows, [stat]] = await Promise.all([
    db.select().from(partnerApplications).orderBy(desc(partnerApplications.createdAt)).limit(60),
    db.select({ pending: sql<number>`count(*) filter (where ${partnerApplications.status}='PENDING')::int`, total: sql<number>`count(*)::int` }).from(partnerApplications),
  ]);

  return (
    <div className="container-x py-10">
      <AdminHead
        active="/admin/basvurular"
        title="İş ortağı başvuruları"
        desc={`Restoran ve filo başvuruları. ${stat?.pending ?? 0} başvuru karar bekliyor. Telefon ve vergi numarası yalnızca bu ekranda görünür, herkese açık profile taşınmaz.`}
      />
      {rows.length === 0 ? (
        <EmptyState icon="🤝" title="Henüz başvuru yok" description="Başvuru formu /basvuru adresinde; müşteriler ve iş ortakları buradan başvurabilir." actions={[{ label: "Başvuru formunu gör", href: "/basvuru", primary: true }]} />
      ) : (
        <div className="grid gap-4 lg:grid-cols-2">
          {rows.map((a) => (
            <div key={a.id} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="font-extrabold">{a.name}</h2>
                    <Pill tone={a.kind === "FLEET" ? "blue" : "slate"}>{a.kind === "FLEET" ? "Filo" : "Restoran"}</Pill>
                  </div>
                  <div className="text-xs text-ink/55">{a.contactName} · {a.city} · {timeAgo(a.createdAt)}</div>
                </div>
                <Pill tone={STATUS[a.status]?.tone ?? "slate"}>{STATUS[a.status]?.label ?? a.status}</Pill>
              </div>
              {a.description && <p className="mt-2 text-sm text-ink/70">{a.description}</p>}
              <div className="mt-3 flex flex-wrap gap-1.5">
                {a.areas.map((x) => <span key={x} className="chip !px-2 !py-0.5">📍 {areaName(x)}</span>)}
              </div>
              <div className="mt-3 grid gap-1 rounded-xl bg-paper px-3 py-2 text-xs text-ink/60">
                <span>✉️ {a.email}</span>
                {a.phone && <span>📞 {a.phone}</span>}
                {a.taxNo && <span>🧾 {a.taxNo}</span>}
              </div>
              {a.decisionNote && <div className="mt-2 text-xs text-ink/55">Karar: “{a.decisionNote}” · {a.decidedAt ? dateTime(a.decidedAt) : ""}</div>}
              {a.status === "PENDING" && (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <ApiButton url={`/api/admin/applications/${a.id}`} body={{ action: "APPROVED" }} className="btn-mint btn-sm" prompt={{ label: "Onay notu (zorunlu):", field: "note" }}>Onayla</ApiButton>
                  <ApiButton url={`/api/admin/applications/${a.id}`} body={{ action: "NEEDS_INFO" }} className="btn-ghost btn-sm" prompt={{ label: "İstenen bilgi (zorunlu):", field: "note" }}>Bilgi iste</ApiButton>
                  <ApiButton url={`/api/admin/applications/${a.id}`} body={{ action: "REJECTED" }} className="btn-danger btn-sm" prompt={{ label: "Ret gerekçesi (zorunlu):", field: "note" }}>Reddet</ApiButton>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
