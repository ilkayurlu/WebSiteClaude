import Link from "next/link";
import { AdminHead } from "@/components/AdminNav";
import { AdminOnly } from "@/components/AdminGuard";
import { ApiButton } from "@/components/client";
import { EmptyState, Pill } from "@/components/ui";
import { REPORT_REASONS, dateTime, timeAgo } from "@/lib/labels";
import { profileReports } from "@/lib/review-ops";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Raporlanan İçerikler — Operasyon" };

const TARGET_LINK: Record<string, (id: string) => string> = {
  PROVIDER: () => "/kesfet",
  FLEET: () => "/filolar",
  RESTAURANT: () => "/yemek",
  MEDIA: () => "/admin/medya-moderasyon",
};

export default async function AdminReports() {
  const s = await getSession();
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) return <AdminOnly />;
  const reports = await profileReports();
  const open = reports.filter((r) => r.status === "OPEN");

  return (
    <div className="container-x py-10">
      <AdminHead
        active="/admin/raporlanan-icerikler"
        title="Raporlanan içerikler"
        desc="Profil, işletme, filo ve medya bildirimleri. Her karar gerekçe ister; bildirimde bulunan kullanıcıya bilgi verilmez, yalnızca denetim kaydına yazılır."
      />
      <div className="grid gap-4 sm:grid-cols-3">
        <div className="card p-4"><div className="label">Açık</div><div className="text-3xl font-black">{open.length}</div></div>
        <div className="card p-4"><div className="label">Çözüldü</div><div className="text-3xl font-black text-mint">{reports.filter((r) => r.status === "RESOLVED").length}</div></div>
        <div className="card p-4"><div className="label">Reddedildi</div><div className="text-3xl font-black text-ink/45">{reports.filter((r) => r.status === "DISMISSED").length}</div></div>
      </div>

      <div className="mt-6 space-y-3">
        {reports.length === 0 && <EmptyState icon="⚑" title="Bildirim yok" description="Kullanıcılar profil, medya ve işletme sayfalarındaki “Bildir” düğmesiyle bildirim oluşturur." />}
        {reports.map((r) => (
          <div key={r.id} className="card flex flex-wrap items-center gap-3 p-4">
            <Pill tone={r.status === "OPEN" ? "amber" : r.status === "RESOLVED" ? "green" : "slate"}>{r.status === "OPEN" ? "Açık" : r.status === "RESOLVED" ? "Çözüldü" : "Reddedildi"}</Pill>
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2 text-sm">
                <b>{r.targetName}</b>
                <span className="chip !px-2 !py-0.5">{r.targetType === "PROVIDER" ? "Sağlayıcı" : r.targetType === "FLEET" ? "Filo" : r.targetType === "RESTAURANT" ? "İşletme" : "Medya"}</span>
                <span className="font-semibold text-rose">{REPORT_REASONS[r.reason] ?? r.reason}</span>
              </div>
              <div className="mt-0.5 text-xs text-ink/55">{timeAgo(r.createdAt)} · {dateTime(r.createdAt)}{r.detail ? ` — “${r.detail}”` : ""}</div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              <Link href={TARGET_LINK[r.targetType]?.(r.targetId) ?? "/admin"} className="btn-ghost btn-sm">İncele</Link>
              {r.status === "OPEN" && (
                <>
                  <ApiButton url={`/api/admin/reports/${r.id}`} body={{ action: "RESOLVED" }} className="btn-danger btn-sm" prompt={{ label: "İhlal kararı ve yapılan işlem (zorunlu):", field: "note" }}>İhlal var</ApiButton>
                  <ApiButton url={`/api/admin/reports/${r.id}`} body={{ action: "DISMISSED" }} className="btn-ghost btn-sm" prompt={{ label: "Red gerekçesi (zorunlu):", field: "note" }}>İhlal yok</ApiButton>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
