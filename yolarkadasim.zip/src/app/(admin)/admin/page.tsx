import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { ArrowRight, BadgeCheck, CircleHelp, Clock3, PackageCheck, Route, Timer, TrendingUp, Truck, Wallet } from "lucide-react";
import { db } from "@/db";
import { auditLogs, users } from "@/db/schema";
import { MetricCard } from "@/components/admin/MetricCard";
import { adminKpis, courierVerifications, liveTasks } from "@/lib/admin-data";
import { requireSuperAdminPage } from "@/lib/admin-auth";
import { dateTime, money } from "@/lib/labels";

export const metadata = { title: "Genel Bakış" };
export default async function AdminHome() {
  await requireSuperAdminPage("/admin");
  const [k, tasks, couriers, logs] = await Promise.all([
    adminKpis(), liveTasks(), courierVerifications(),
    db.select({ id: auditLogs.id, action: auditLogs.action, reason: auditLogs.reason, createdAt: auditLogs.createdAt, actor: users.name }).from(auditLogs).leftJoin(users, eq(users.id, auditLogs.actorId)).orderBy(desc(auditLogs.createdAt)).limit(8),
  ]);
  const urgent = tasks.filter((t) => t.priority !== "NORMAL");
  const pendingCouriers = couriers.filter((c) => c.status !== "SUSPENDED" && Object.values(c.documents).some((d) => d?.status === "SUBMITTED"));
  return (
    <div className="px-4 py-8 sm:px-8">
      <div className="mb-7"><div className="eyebrow">PLATFORM KONTROL MERKEZİ</div><h1 className="mt-2 text-3xl font-black tracking-tight sm:text-4xl">Genel bakış</h1><p className="mt-1 max-w-2xl text-sm text-ink/55">Tüm sayılar canlı veritabanından hesaplanır. Para transferi, SMS ve gerçek ödeme sağlayıcısı bu ortamda bağlı değildir.</p></div>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard icon={Wallet} title="Bugünkü GMV" value={money(k.gmvTodayMinor)} detail="Bugün tamamlanan görev + teslim edilen sipariş (İstanbul saati)" />
        <MetricCard icon={Truck} title="Aktif kurye" value={String(k.activeCouriers)} detail={`${k.availableCouriers} müsait · ${k.totalCouriers} kayıtlı sağlayıcı`} />
        <MetricCard icon={PackageCheck} title="Bugün tamamlanan" value={String(k.completedToday)} detail={`${k.activeTasks} görev şu an aktif`} />
        <MetricCard icon={Timer} title="Ort. teslimat süresi" value={k.avgMinutes != null ? `${k.avgMinutes} dk` : "—"} detail={k.etaRate != null ? `ETA başarımı %${k.etaRate} (kabulden alışa, ${k.etaSample} görev · 7 gün)` : "Son 7 günde ölçülebilir görev yok"} trend={k.etaRate != null ? { label: k.etaRate >= 80 ? "Hedefte" : "Hedefin altında", tone: k.etaRate >= 80 ? "up" : "down" } : undefined} />
      </div>
      <div className="mt-8 grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-6">
          <section className="rounded-[22px] border border-line bg-white">
            <div className="flex items-center justify-between border-b border-line px-5 py-4"><h2 className="flex items-center gap-2 font-extrabold"><Route size={17} className="text-signal" /> Müdahale bekleyen görevler</h2><Link href="/admin/talepler" className="inline-flex items-center gap-1 text-xs font-bold text-signal hover:underline">Canlı monitör <ArrowRight size={13} /></Link></div>
            <div className="divide-y divide-line">
              {urgent.slice(0, 6).map((t) => (
                <Link key={t.id} href="/admin/talepler" className="flex flex-wrap items-center gap-3 px-5 py-3 text-sm transition hover:bg-paper">
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-black ${t.priority === "CRITICAL" ? "bg-rose/10 text-rose" : "bg-signal/10 text-signal"}`}>{t.priority === "CRITICAL" ? "KRİTİK" : "GECİKME"}</span>
                  <b className="font-mono">{t.code}</b><span className="text-xs text-ink/55">{t.pickup} → {t.dropoff}</span>
                  <span className="ml-auto text-xs font-semibold text-ink/60">{t.reason}</span>
                </Link>
              ))}
              {urgent.length === 0 && <p className="px-5 py-8 text-center text-sm text-ink/50">Şu an müdahale gerektiren görev yok. ✓</p>}
            </div>
          </section>
          <section className="rounded-[22px] border border-line bg-white">
            <div className="flex items-center justify-between border-b border-line px-5 py-4"><h2 className="flex items-center gap-2 font-extrabold"><BadgeCheck size={17} className="text-signal" /> Evrak onayı bekleyen kuryeler</h2><Link href="/admin/kuryeler" className="inline-flex items-center gap-1 text-xs font-bold text-signal hover:underline">Kurye yönetimi <ArrowRight size={13} /></Link></div>
            <div className="divide-y divide-line">
              {pendingCouriers.slice(0, 5).map((c) => (
                <Link key={c.providerId} href="/admin/kuryeler" className="flex items-center gap-3 px-5 py-3 text-sm transition hover:bg-paper"><b>{c.name}</b><span className="text-xs text-ink/50">{Object.values(c.documents).filter((d) => d?.status === "SUBMITTED").length} evrak incelemede</span><ArrowRight size={13} className="ml-auto text-signal" /></Link>
              ))}
              {pendingCouriers.length === 0 && <p className="px-5 py-8 text-center text-sm text-ink/50">İnceleme bekleyen evrak yok.</p>}
            </div>
          </section>
        </div>
        <aside className="space-y-4">
          <div className="rounded-[22px] bg-ink p-5 text-white">
            <h3 className="flex items-center gap-2 text-sm font-extrabold"><TrendingUp size={16} className="text-signal" /> Hızlı erişim</h3>
            <div className="mt-3 space-y-1.5">
              {[{ href: "/admin/uyusmazliklar", label: "Uyuşmazlıklar", n: k.openCases, icon: CircleHelp }, { href: "/admin/finans", label: "Haftalık hakediş listesi", n: null, icon: Wallet }, { href: "/admin/medya-moderasyon", label: "Medya moderasyonu", n: null, icon: Clock3 }].map(({ href, label, n, icon: Icon }) => (
                <Link key={href} href={href} className="flex items-center gap-2 rounded-xl bg-white/[.06] px-3 py-2.5 text-xs font-bold transition hover:bg-white/[.12]"><Icon size={14} className="text-signal" /><span className="flex-1">{label}</span>{n ? <span className="rounded-md bg-signal px-1.5 text-[10px]">{n}</span> : <ArrowRight size={12} className="text-signal" />}</Link>
              ))}
            </div>
          </div>
          <div className="rounded-[22px] border border-line bg-white p-5">
            <h3 className="text-sm font-extrabold">Son yönetim kararları</h3>
            <div className="mt-3 space-y-2">
              {logs.map((l) => <div key={l.id} className="rounded-xl bg-paper px-3 py-2 text-[11px]"><code className="font-bold">{l.action}</code><div className="text-ink/45">{l.actor ?? "sistem"} · {dateTime(l.createdAt)}</div>{l.reason && <div className="mt-0.5 line-clamp-2 text-ink/65">{l.reason}</div>}</div>)}
              {logs.length === 0 && <p className="text-xs text-ink/50">Henüz kayıt yok.</p>}
            </div>
            <Link href="/admin/audit" className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-signal hover:underline">Tüm denetim izi <ArrowRight size={12} /></Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
