import Link from "next/link";
import { ApplicationForm } from "@/components/ApplicationForm";
import { getPublicSession as getSession } from "@/lib/session";

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

export const metadata = { title: "İş Ortağı Başvurusu — YolArkadaşı" };

export default async function Apply({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  await getSession();
  const kind = one(sp.kind) === "FLEET" ? "FLEET" : "RESTAURANT";
  return (
    <div className="container-x py-12">
      <div className="mx-auto max-w-3xl">
        <div className="eyebrow">İş ortağı başvurusu</div>
        <h1 className="mt-1 text-4xl font-black tracking-tight">{kind === "FLEET" ? "Filonuzu platforma taşıyın" : "İşletmenizi platforma taşıyın"}</h1>
        <p className="mt-2 text-ink/60">
          Başvurular operasyon ekibi tarafından incelenir; belge ve bölge doğrulaması sonrası hesabınız açılır. Ortalama dönüş süresi 2 iş günüdür.
        </p>
        <div className="mt-6 flex gap-2">
          <Link href="/basvuru?kind=RESTAURANT" className={`btn ${kind === "RESTAURANT" ? "btn-ink" : "btn-ghost"}`}>🍽️ Restoran / market</Link>
          <Link href="/basvuru?kind=FLEET" className={`btn ${kind === "FLEET" ? "btn-ink" : "btn-ghost"}`}>🚚 Filo / lojistik</Link>
        </div>
        <div className="mt-6">
          <ApplicationForm kind={kind} />
        </div>
        <div className="card mt-8 grid gap-4 p-6 sm:grid-cols-3">
          {[
            ["1", "Başvuru", "Bilgilerinizi gönderin, operasyon kaydını oluşturalım."],
            ["2", "Doğrulama", "Vergi levhası, ruhsat ve bölge bilgisi kontrol edilir."],
            ["3", "Aktivasyon", "Paneliniz açılır; menü/filo verisini girmeye başlarsınız."],
          ].map(([n, t, d]) => (
            <div key={n}>
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-signal text-sm font-black text-white">{n}</div>
              <div className="mt-2 font-extrabold">{t}</div>
              <div className="text-sm text-ink/60">{d}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
