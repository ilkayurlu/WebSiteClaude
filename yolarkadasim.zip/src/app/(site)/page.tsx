import Image from "next/image";
import Link from "next/link";
import { listRestaurants } from "@/lib/food";
import { ProviderCard } from "@/components/ProviderCard";
import { Avatar, EmptyState, SectionHead, Stars } from "@/components/ui";
import { FLEET_POLICY, MODES } from "@/lib/labels";
import { getFavoriteIds, listFleets, listProviders } from "@/lib/queries";
import { getPublicSession as getSession } from "@/lib/session";

export default async function Home() {
  const s = await getSession();
  const [nearby, all, fleetList, foodList] = await Promise.all([
    listProviders({ area: "kadikoy", onlyAvailable: true }),
    listProviders({ onlyAvailable: true }),
    listFleets(),
    listRestaurants({ area: "kadikoy" }),
  ]);
  const favs = s.user.role === "CUSTOMER" ? await getFavoriteIds(s.user.id) : { providers: [] as string[], fleets: [] as string[], restaurants: [] as string[] };
  const nearest = nearby[0];
  const availableCount = all.length;

  return (
    <>
      {/* HERO */}
      <section className="road-pattern-dark relative overflow-hidden bg-ink text-white">
        <div className="pointer-events-none absolute -left-40 top-20 h-96 w-96 rounded-full bg-signal/20 blur-[120px]" />
        <div className="pointer-events-none absolute -right-20 -top-20 h-96 w-96 rounded-full bg-sky/20 blur-[120px]" />
        <div className="container-x relative grid items-center gap-12 py-16 lg:grid-cols-[1.1fr_1fr] lg:py-24">
          <div className="fade-up">
            <div className="chip-dark mb-6">
              <span className="pulse-dot h-2 w-2 rounded-full bg-mint text-mint" /> Şu an {availableCount} sağlayıcı müsait
            </div>
            <h1 className="h-display text-5xl sm:text-6xl lg:text-7xl">
              Yol arkadaşını seç.
              <br />
              <span className="bg-gradient-to-r from-signal to-signal-2 bg-clip-text text-transparent">Gerisi yolda.</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg text-white/65">
              Güvendiğin kuryeyi, sürücüyü ya da filoyu profilinden tanı. Hemen çağır, ileri tarihe randevu oluştur veya araçlı kişiyi saatlik kirala — ya da en yakın uygun sağlayıcıyı sistem bulsun.
            </p>
            <div className="mt-8 grid max-w-xl grid-cols-2 gap-3 sm:grid-cols-4">
              {(["INSTANT_CALL", "SCHEDULED", "INSTANT_RENT"] as const).map((m, i) => (
                <Link
                  key={m}
                  href={`/talep/yeni?mode=${m}`}
                  className={`group rounded-2xl p-4 transition hover:-translate-y-0.5 ${i === 0 ? "bg-signal text-white shadow-[0_12px_30px_-10px_rgba(255,91,35,0.8)]" : "bg-white/[0.06] ring-1 ring-white/10 hover:bg-white/10"}`}
                >
                  <div className="text-lg leading-none" aria-hidden="true">{MODES[m].icon}</div>
                  <div className="mt-2 text-sm font-extrabold leading-tight">{MODES[m].label}</div>
                </Link>
              ))}
              <Link href="/kesfet" className="group rounded-2xl bg-white/[0.06] p-4 ring-1 ring-white/10 transition hover:-translate-y-0.5 hover:bg-white/10">
                <div className="text-lg leading-none" aria-hidden="true">🔎</div>
                <div className="mt-2 text-sm font-extrabold leading-tight">Hemen Ara</div>
              </Link>
            </div>
          </div>

          <div className="relative">
            <div className="relative aspect-[4/3.4] overflow-hidden rounded-[2rem] ring-1 ring-white/10">
              <Image src="/images/hero.jpg" alt="İstanbul'da kurye ve sürücüler" fill priority className="object-cover" sizes="(max-width:1024px) 100vw, 45vw" />
              <div className="absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-transparent" />
            </div>
            {nearest ? (
              <Link href={`/kuryeler/${nearest.slug}`} className="fade-up absolute -bottom-6 left-4 right-4 flex items-center gap-3 rounded-2xl bg-white p-3.5 text-ink shadow-2xl sm:left-auto sm:right-[-1rem] sm:w-[22rem]">
                <Avatar name={nearest.displayName} hue={nearest.hue} size={48} status={nearest.status} />
                <div className="min-w-0 flex-1">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-mint">En yakın kurye burada · Kadıköy</div>
                  <div className="truncate font-extrabold">{nearest.displayName}</div>
                  <div className="flex items-center gap-2 text-xs text-ink/55">
                    <Stars value={nearest.ratingAvg} count={nearest.ratingCount} /> · {nearest.distance}
                  </div>
                </div>
                <div className="rounded-xl bg-ink px-3 py-2 text-center text-white">
                  <div className="text-base font-black leading-none">{nearest.eta?.replace("~", "")}</div>
                  <div className="text-[9px] uppercase tracking-wider text-white/50">uzakta</div>
                </div>
              </Link>
            ) : (
              <div className="absolute -bottom-6 left-4 right-4 rounded-2xl bg-white p-4 text-sm text-ink shadow-2xl">Kadıköy&apos;de şu an müsait sağlayıcı yok — randevu oluşturabilirsiniz.</div>
            )}
          </div>
        </div>
        <div className="dash-road h-[3px]" />
      </section>

      {/* KİM GETİRSİN */}
      <section className="container-x py-20">
        <SectionHead eyebrow="Tek ekranda üç yol" title="Kim getirsin? Sen karar ver." />
        <div className="grid gap-4 md:grid-cols-4">
          {[
            { i: "🎯", t: "En yakın uygun", d: "Bölge, mesafe, araç uyumu, yük ve dakiklik skoruyla sistem seçer." },
            { i: "♥", t: "Favorilerimden", d: "Güvendiğin yol arkadaşın müsaitse ona gider; değilse otomatik yedek." },
            { i: "👆", t: "Kendim seçeyim", d: "Uygun adayları ETA bandı ve fiyatla karşılaştır, istediğini seç." },
            { i: "🏢", t: "Filo seçeyim", d: "Kurumsal filoya ilet; filo politikasına göre onay veya yönlendirme." },
          ].map((x, i) => (
            <div key={x.t} className="card p-6">
              <div className="flex items-center justify-between">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-paper text-base" aria-hidden="true">{x.i}</span>
                <span className="font-mono text-xs font-bold text-ink/25">0{i + 1}</span>
              </div>
              <h3 className="mt-4 font-extrabold">{x.t}</h3>
              <p className="mt-1 text-sm text-ink/60">{x.d}</p>
            </div>
          ))}
        </div>
        <div className="mt-6 rounded-2xl border border-dashed border-ink/20 bg-white/50 p-4 text-sm text-ink/70">
          <b>Şeffaflık:</b> Hiçbir mod kesin atama garantisi vermez. Önce <span className="font-bold text-sun">“Talebiniz iletildi”</span>, sağlayıcı veya filo kabul ettiğinde <span className="font-bold text-mint">“Onaylandı”</span> görürsünüz.
        </div>
      </section>

      {/* MÜSAİT */}
      <section className="container-x">
        <SectionHead
          eyebrow="Canlı"
          title="Şu an müsait yol arkadaşları"
          action={<Link href="/kesfet" className="btn-ghost btn-sm">Tümünü gör →</Link>}
        />
        {all.length ? (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {all.slice(0, 6).map((p) => (
              <ProviderCard key={p.id} p={p} canFavorite={s.user.role === "CUSTOMER"} isFavorite={favs.providers.includes(p.id)} />
            ))}
          </div>
        ) : (
          <EmptyState icon="🌙" title="Şu an müsait sağlayıcı yok" description="Randevu oluşturarak ileri bir saat için talep bırakabilirsiniz." actions={[{ label: "Randevu oluştur", href: "/talep/yeni?mode=SCHEDULED", primary: true }]} />
        )}
      </section>

      {/* YEMEK */}
      <section className="container-x py-4">
        <SectionHead
          eyebrow="Yemek & market"
          title="Bölgenizdeki işletmelerden sipariş verin"
          action={<Link href="/yemek" className="btn-ghost btn-sm">Tüm restoranlar →</Link>}
        />
        {foodList.length ? (
          <div className="grid gap-4 md:grid-cols-3">
            {foodList.slice(0, 3).map((r) => (
              <Link key={r.id} href={`/restoranlar/${r.slug}`} className="card card-hover overflow-hidden">
                <div className="relative aspect-[16/9] bg-paper">
                  {r.coverUrl && <Image src={r.coverUrl} alt={r.name} fill className="object-cover" sizes="(max-width:768px) 100vw, 33vw" />}
                  <span className={`absolute left-3 top-3 rounded-full px-2.5 py-1 text-[11px] font-bold text-white ${r.openNow ? "bg-mint" : "bg-ink/80"}`}>{r.openNow ? "Açık" : "Kapalı"}</span>
                </div>
                <div className="p-4">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="truncate font-extrabold">{r.name}</h3>
                    <span className="shrink-0 text-xs font-bold text-ink/60">⏱ ~{r.etaMinutes} dk</span>
                  </div>
                  <p className="mt-0.5 line-clamp-1 text-xs text-ink/55">{r.tagline}</p>
                </div>
              </Link>
            ))}
          </div>
        ) : (
          <EmptyState icon="🍽️" title="Bu bölgede henüz işletme yok" description="Adresinizi değiştirebilir veya işletmenizi platforma ekleyebilirsiniz." actions={[{ label: "Bölgeleri gör", href: "/yemek", primary: true }, { label: "İşletme başvurusu", href: "/basvuru?kind=RESTAURANT" }]} />
        )}
      </section>

      {/* FİLOLAR */}
      <section className="container-x py-20">
        <SectionHead eyebrow="Kurumsal" title="Filolar" action={<Link href="/filolar" className="btn-ghost btn-sm">Filolar →</Link>} />
        <div className="grid gap-4 md:grid-cols-3">
          {fleetList.map((f) => (
            <Link key={f.id} href={`/filolar/${f.slug}`} className="card card-hover overflow-hidden">
              <div className="h-2" style={{ background: f.accent }} />
              <div className="p-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-extrabold">{f.name}</h3>
                  {f.isVerified && <span className="chip">✓ Doğrulanmış</span>}
                </div>
                <p className="mt-1 line-clamp-2 text-sm text-ink/60">{f.description}</p>
                <div className="mt-4 flex flex-wrap gap-2 text-xs">
                  <span className="chip">👥 {f.members} üye</span>
                  <span className="chip">🟢 {f.available} müsait</span>
                  <span className="chip">⚙ {FLEET_POLICY[f.directPolicy]?.label}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* GÜVEN */}
      <section className="container-x">
        <div className="card-ink road-pattern-dark grid gap-8 overflow-hidden p-8 sm:p-12 md:grid-cols-[1fr_1.4fr]">
          <div>
            <div className="eyebrow">Güven & gizlilik</div>
            <h2 className="mt-2 text-3xl font-black tracking-tight">Konumun senin. Puanlar gerçek.</h2>
            <p className="mt-3 text-white/60">Platform; sağlayıcıların boştaki konumunu, telefonlarını ve adreslerini hiçbir zaman açık etmez.</p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            {[
              ["📍", "Yalnızca ETA bandı", "Müşteri “~10 dk / 2,3 km” görür; ham koordinat asla."],
              ["⭐", "Sahte puana kapalı", "Yalnızca tamamlanan görev, tek sefer, 14 gün içinde puanlanır."],
              ["🔐", "Teslim kodu", "Görev, müşterideki 4 haneli kodla tamamlanır."],
              ["🧾", "Denetim izi", "Moderasyon ve filo kararları gerekçesiyle kayıt altında."],
            ].map(([i, t, d]) => (
              <div key={t} className="rounded-2xl bg-white/[0.05] p-4 ring-1 ring-white/10">
                <div className="text-base leading-none" aria-hidden="true">{i}</div>
                <div className="mt-2 font-bold">{t}</div>
                <div className="mt-0.5 text-sm text-white/55">{d}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
