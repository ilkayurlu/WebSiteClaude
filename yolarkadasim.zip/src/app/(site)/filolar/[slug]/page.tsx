import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaPosts } from "@/db/schema";
import { FavoriteButton } from "@/components/client";
import { MediaGrid, ReportButton } from "@/components/media-client";
import { PanelTabs } from "@/components/RestaurantView";
import { ProviderCard } from "@/components/ProviderCard";
import { EmptyState } from "@/components/ui";
import { FLEET_POLICY, MODES, VEHICLES } from "@/lib/labels";
import { getFavoriteIds, getFleetPage } from "@/lib/queries";
import { getPublicSession as getSession } from "@/lib/session";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const d = await getFleetPage((await params).slug);
  if (!d) return { title: "Filo bulunamadı — YolArkadaşı" };
  return { title: `${d.fleet.name} — Filo profili · YolArkadaşı`, description: d.fleet.description ?? undefined };
}

export default async function FleetProfile({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const s = await getSession();
  const data = await getFleetPage(slug);
  if (!data) notFound();
  const { fleet: f, members } = data;
  const isCustomer = s.user.role === "CUSTOMER";
  const isOwner = s.fleetId === f.id;
  const favs = isCustomer ? await getFavoriteIds(s.user.id) : { providers: [] as string[], fleets: [] as string[], restaurants: [] as string[] };
  const media = await db.select().from(mediaPosts).where(and(eq(mediaPosts.ownerType, "FLEET"), eq(mediaPosts.ownerId, f.id), eq(mediaPosts.status, "PUBLISHED"))).orderBy(desc(mediaPosts.publishedAt));
  const vehicles = [...new Set(members.map((m) => m.vehicleType))];
  const avgRating = members.filter((m) => m.ratingCount > 0);
  const teamRating = avgRating.length ? avgRating.reduce((a, m) => a + m.ratingAvg * m.ratingCount, 0) / avgRating.reduce((a, m) => a + m.ratingCount, 0) : 0;
  const teamReviews = members.reduce((a, m) => a + m.ratingCount, 0);
  const teamJobs = members.reduce((a, m) => a + m.completedCount, 0);

  return (
    <div>
      <div className="road-pattern-dark text-white" style={{ background: `linear-gradient(120deg, ${f.accent} -20%, #0e1324 60%)` }}>
        <div className="container-x py-14">
          <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
            <div className="flex items-center gap-5">
              <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-white text-4xl font-black shadow-xl" style={{ color: f.accent }}>{f.name[0]}</div>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-4xl font-black tracking-tight">{f.name}</h1>
                  {f.isVerified && <span className="chip-dark">✓ Doğrulanmış filo</span>}
                </div>
                <p className="mt-1 max-w-xl text-white/70">{f.description}</p>
                <div className="mt-2 flex flex-wrap gap-1.5 text-xs text-white/60">
                  <span>🏙 {f.city}</span>
                  <span>· ⏰ {f.opensAt}–{f.closesAt}</span>
                  <span>· 👥 {data.memberCount} üye</span>
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {isCustomer && <FavoriteButton targetType="FLEET" targetId={f.id} initial={favs.fleets.includes(f.id)} />}
              {(isCustomer || ["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) && !isOwner && <ReportButton targetType="FLEET" targetId={f.id} label="Filoyu bildir" />}
              {isOwner && <Link href="/filo" className="btn border border-white/25 bg-white/10 text-white hover:bg-white/20">Filo paneli</Link>}
            </div>
          </div>
          <div className="mt-8 flex flex-wrap gap-2">
            {(["INSTANT_CALL", "SCHEDULED", "INSTANT_RENT"] as const).map((m, i) => (
              <Link key={m} href={`/talep/yeni?mode=${m}&fleet=${f.slug}`} className={i === 0 ? "btn-primary" : "btn border border-white/25 bg-white/10 text-white hover:bg-white/20"}>
                <span aria-hidden="true">{MODES[m].icon}</span> {MODES[m].label}
              </Link>
            ))}
          </div>
        </div>
      </div>

      <div className="container-x py-10">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="card p-5"><div className="label">Şu an müsait</div><div className="text-3xl font-black text-mint">{data.availableCount}</div><div className="text-xs text-ink/50">{data.memberCount} üye içinden</div></div>
          <div className="card p-5"><div className="label">Ekip puanı</div><div className="text-3xl font-black">{teamRating ? `★ ${teamRating.toFixed(1).replace(".", ",")}` : "—"}</div><div className="text-xs text-ink/50">{teamReviews} değerlendirme</div></div>
          <div className="card p-5"><div className="label">Tamamlanan görev</div><div className="text-3xl font-black">{teamJobs}</div><div className="text-xs text-ink/50">tüm üyeler</div></div>
          <div className="card p-5"><div className="label">Talep politikası</div><div className="font-extrabold">{FLEET_POLICY[f.policy]?.label}</div><div className="mt-1 text-xs text-ink/55">{FLEET_POLICY[f.policy]?.desc}</div></div>
        </div>

        <div className="mt-8">
          <PanelTabs
            initial="team"
            tabs={[
              { key: "team", label: "Ekip", count: members.length },
              { key: "about", label: "Hakkında" },
              { key: "services", label: "Hizmet & kapasite" },
              { key: "media", label: "Medya", count: media.length },
              { key: "info", label: "Kurumsal bilgiler" },
            ]}
            panels={{
              team: members.length ? (
                <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  {members.map((p) => <ProviderCard key={p.id} p={p} canFavorite={isCustomer} isFavorite={favs.providers.includes(p.id)} />)}
                </div>
              ) : (
                <EmptyState icon="🔒" title="Ekip listesi gizli" description="Bu filo üyelerini herkese açık göstermiyor. Talebinizi doğrudan filoya iletebilirsiniz; atamayı filo yöneticisi yapar." actions={[{ label: "Filoyu seç", href: `/talep/yeni?mode=INSTANT_CALL&fleet=${f.slug}`, primary: true }]} />
              ),
              about: (
                <div className="card p-6">
                  <h2 className="text-lg font-extrabold">{f.name} hakkında</h2>
                  <p className="mt-2 leading-relaxed text-ink/70">{f.description}</p>
                  <div className="mt-5 grid gap-4 sm:grid-cols-2">
                    <div>
                      <div className="label">Çalışma modeli</div>
                      <ul className="space-y-1.5 text-sm text-ink/70">
                        <li>• Talepler {FLEET_POLICY[f.policy]?.label.toLowerCase()} işleyişiyle yönetilir.</li>
                        <li>• Üyelerin bireysel profilleri {f.showMembersPublicly ? "herkese açık" : "gizli"}.</li>
                        <li>• Filo kararları denetim izine yazılır.</li>
                      </ul>
                    </div>
                    <div>
                      <div className="label">Gizlilik</div>
                      <ul className="space-y-1.5 text-sm text-ink/70">
                        <li>• Çalışanların telefon, belge ve ev adresi hiçbir ekranda gösterilmez.</li>
                        <li>• Canlı konum yalnızca görevdeki üyeler için ve görev taraflarına açıktır.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              ),
              services: (
                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="card p-6">
                    <h2 className="font-extrabold">Araç türleri</h2>
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {vehicles.map((v) => <span key={v} className="chip">{VEHICLES[v]?.icon} {VEHICLES[v]?.label} <b className="ml-1">{members.filter((m) => m.vehicleType === v).length}</b></span>)}
                    </div>
                    <div className="mt-4">
                      <div className="label">Hizmet türleri</div>
                      <div className="flex flex-wrap gap-1.5">
                        {[...new Set(members.flatMap((m) => m.serviceTypes))].map((x) => <span key={x} className="chip">{x === "PACKAGE" ? "📦 Paket" : x === "FOOD" ? "🍲 Yemek" : x === "PASSENGER" ? "🧳 Yolcu" : "⏱ Kiralama"}</span>)}
                      </div>
                    </div>
                  </div>
                  <div className="card p-6">
                    <h2 className="font-extrabold">Hizmet paketleri & kapasite</h2>
                    {f.servicePackages && f.servicePackages.length ? (
                      <ul className="mt-3 space-y-2">
                        {f.servicePackages.map((pkg) => <li key={pkg} className="rounded-xl bg-paper px-3 py-2 text-sm">{pkg}</li>)}
                      </ul>
                    ) : (
                      <p className="mt-3 text-sm text-ink/55">Bu filo henüz paket tanımı yayınlamadı. Talep oluşturduğunuzda fiyat sunucuda hesaplanır.</p>
                    )}
                    {f.capacityLabel && <div className="mt-3 text-sm"><b>Kapasite:</b> {f.capacityLabel}</div>}
                    <Link href={`/talep/yeni?mode=INSTANT_RENT&fleet=${f.slug}`} className="btn-ghost btn-sm mt-4">⏱ Saatlik kiralama talebi →</Link>
                  </div>
                </div>
              ),
              media: (
                <div className="card p-6">
                  <h2 className="font-extrabold">Filo medyası</h2>
                  <p className="text-xs text-ink/55">Araçlar, operasyon merkezi ve paketleme standartları. İçerikler moderasyondan geçer.</p>
                  <div className="mt-4"><MediaGrid items={media} canReport={isCustomer || ["ADMIN", "SUPER_ADMIN"].includes(s.user.role)} /></div>
                </div>
              ),
              info: (
                <div className="card divide-y divide-line">
                  {[
                    ["Filo adı", f.name],
                    ["Şehir", f.city],
                    ["Çalışma saatleri", `${f.opensAt} – ${f.closesAt}`],
                    ["Kurumsal telefon", f.phonePublic ?? "Yayın izni yok — talep sonrası uygulama içinden ulaşılır."],
                    ["Web sitesi", f.website ?? "—"],
                    ["Doğrulama", f.isVerified ? "Operasyon tarafından doğrulandı" : "Doğrulama bekliyor"],
                    ["Üye görünürlüğü", f.showMembersPublicly ? "Ekip vitrinleri herkese açık" : "Yalnızca filo bilgisi görünür"],
                  ].map(([k, v]) => (
                    <div key={k as string} className="flex flex-col gap-0.5 px-5 py-3 text-sm sm:flex-row sm:items-center sm:justify-between">
                      <span className="text-ink/55">{k}</span>
                      <span className="font-bold">{v as string}</span>
                    </div>
                  ))}
                  <div className="px-5 py-4">
                    <div className="text-xs text-ink/50">Filo ile çalışmak için:</div>
                    <div className="mt-2 flex flex-wrap gap-2">
                      <Link href={`/talep/yeni?mode=INSTANT_CALL&fleet=${f.slug}`} className="btn-primary btn-sm">Talep oluştur</Link>
                      <Link href="/basvuru?kind=FLEET" className="btn-ghost btn-sm">Kendi filonuzu ekleyin</Link>
                    </div>
                  </div>
                </div>
              ),
            }}
          />
        </div>
      </div>
    </div>
  );
}
