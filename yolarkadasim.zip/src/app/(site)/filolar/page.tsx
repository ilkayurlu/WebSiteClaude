import Link from "next/link";
import { EmptyState } from "@/components/ui";
import { FLEET_POLICY } from "@/lib/labels";
import { listFleets } from "@/lib/queries";
import { getPublicSession as getSession } from "@/lib/session";

export default async function Filolar() {
  await getSession();
  const list = await listFleets();
  return (
    <div className="container-x py-12">
      <div className="eyebrow">Kurumsal</div>
      <h1 className="mt-1 text-4xl font-black tracking-tight">Filolar</h1>
      <p className="mt-2 max-w-2xl text-ink/60">Filoya talep ilettiğinizde, filonun politikasına göre üye doğrudan kabul eder ya da dispatcher onaylayıp en uygun üyeye yönlendirir.</p>
      <div className="mt-8 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {list.length === 0 && <div className="md:col-span-3"><EmptyState title="Henüz filo yok" description="Platforma kayıtlı filo bulunmuyor." /></div>}
        {list.map((f) => (
          <Link key={f.id} href={`/filolar/${f.slug}`} className="card card-hover overflow-hidden">
            <div className="road-pattern-dark relative h-28" style={{ background: `linear-gradient(135deg, ${f.accent}, #0e1324)` }}>
              <div className="absolute bottom-3 left-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-2xl font-black shadow-lg" style={{ color: f.accent }}>{f.name[0]}</div>
            </div>
            <div className="p-5">
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-extrabold">{f.name}</h2>
                {f.isVerified && <span className="flex h-4 w-4 items-center justify-center rounded-full bg-sky text-[9px] text-white">✓</span>}
              </div>
              <p className="mt-1 text-sm text-ink/60">{f.description}</p>
              <div className="mt-4 grid grid-cols-3 gap-2 text-center">
                <div className="rounded-xl bg-paper p-2"><div className="font-black">{f.members}</div><div className="text-[10px] uppercase text-ink/45">üye</div></div>
                <div className="rounded-xl bg-paper p-2"><div className="font-black text-mint">{f.available}</div><div className="text-[10px] uppercase text-ink/45">müsait</div></div>
                <div className="rounded-xl bg-paper p-2"><div className="font-black">{f.rating ? f.rating.toFixed(1) : "—"}</div><div className="text-[10px] uppercase text-ink/45">puan</div></div>
              </div>
              <div className="mt-3 text-xs text-ink/55">⚙ {FLEET_POLICY[f.directPolicy]?.label}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
