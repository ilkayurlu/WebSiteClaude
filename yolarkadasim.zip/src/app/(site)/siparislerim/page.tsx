import Link from "next/link";
import { EmptyState } from "@/components/ui";
import { listCustomerOrders } from "@/lib/food";
import { ORDER_STATUS, dateTime, money } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Siparişlerim — YolArkadaşı" };

export default async function MyOrders() {
  const s = await getSession();
  if (s.user.role !== "CUSTOMER") {
    return (
      <div className="container-x py-20">
        <div className="mx-auto max-w-xl">
          <EmptyState icon="🧾" title="Bu sayfa müşteri siparişleri içindir" description="Sağ üstten bir müşteri hesabına geçin." actions={[{ label: "Yemek sayfası", href: "/yemek", primary: true }]} />
        </div>
      </div>
    );
  }
  const orders = await listCustomerOrders(s.user.id);
  const active = orders.filter((o) => ["ORDER_PLACED", "RESTAURANT_ACCEPTED", "PREPARING", "READY_FOR_PICKUP", "COURIER_ASSIGNED", "OUT_FOR_DELIVERY"].includes(o.status));
  const past = orders.filter((o) => !active.includes(o));

  const Card = ({ o }: { o: (typeof orders)[number] }) => (
    <Link href={`/siparis/${o.id}`} className="card card-hover flex flex-wrap items-center gap-4 p-4">
      <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-paper text-base">{ORDER_STATUS[o.status]?.step >= 6 ? "✅" : "🍽️"}</span>
      <span className="min-w-0 flex-1">
        <span className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm font-black">{o.code}</span>
          <span className={`rounded-full px-2.5 py-1 text-xs font-bold tone-${ORDER_STATUS[o.status]?.tone ?? "slate"}`}>{ORDER_STATUS[o.status]?.label}</span>
        </span>
        <span className="mt-0.5 block truncate text-sm text-ink/60">{o.restaurantName} · {dateTime(o.placedAt)}</span>
      </span>
      <span className="text-right">
        <span className="block font-black">{money(o.totalMinor)}</span>
        <span className="block text-xs text-ink/45">{o.paymentMethod === "CASH_ON_DELIVERY" ? "Kapıda nakit" : "Kart (sandbox)"}</span>
      </span>
    </Link>
  );

  return (
    <div className="container-x py-10">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="eyebrow">Hesabım</div>
          <h1 className="mt-1 text-4xl font-black tracking-tight">Siparişlerim</h1>
        </div>
        <div className="flex gap-2">
          <Link href="/yemek" className="btn-primary">🍽️ Yeni sipariş</Link>
          <Link href="/taleplerim" className="btn-ghost">Kurye taleplerim</Link>
        </div>
      </div>

      <div className="mt-8 grid gap-8 lg:grid-cols-2">
        <section>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-ink/50">Aktif ({active.length})</h2>
          {active.length ? (
            <div className="space-y-3">{active.map((o) => <Card key={o.id} o={o} />)}</div>
          ) : (
            <EmptyState icon="🛵" title="Aktif siparişiniz yok" description="Bölgenizdeki açık işletmelerden sipariş verebilirsiniz." actions={[{ label: "Yemek sayfası", href: "/yemek", primary: true }]} />
          )}
        </section>
        <section>
          <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-ink/50">Geçmiş ({past.length})</h2>
          {past.length ? (
            <div className="space-y-3">{past.map((o) => <Card key={o.id} o={o} />)}</div>
          ) : (
            <div className="rounded-2xl border border-dashed border-line p-6 text-center text-sm text-ink/50">Henüz geçmiş sipariş yok.</div>
          )}
        </section>
      </div>
    </div>
  );
}
