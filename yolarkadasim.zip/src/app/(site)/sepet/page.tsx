import Link from "next/link";
import { CartQty, Checkout } from "@/components/food-client";
import { ApiButton } from "@/components/client";
import { EmptyState } from "@/components/ui";
import { getCartView, getFavoriteRestaurants } from "@/lib/food-favorites";
import { getCartView as cartView } from "@/lib/food";
import { getFavoriteIds } from "@/lib/queries";
import { areaName } from "@/lib/geo";
import { money } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Sepetim — YolArkadaşı" };

export default async function CartPage() {
  const s = await getSession();
  if (s.user.role !== "CUSTOMER") {
    return (
      <div className="container-x py-20">
        <div className="mx-auto max-w-xl">
          <EmptyState icon="🧺" title="Sepet müşteri hesapları içindir" description="Sağ üstteki hesap menüsünden bir müşteri hesabına geçerek sipariş akışını deneyebilirsiniz." actions={[{ label: "Yemek sayfası", href: "/yemek", primary: true }]} />
        </div>
      </div>
    );
  }
  const cart = await cartView(s);
  const favs = await getFavoriteIds(s.user.id);
  const favRest = await getFavoriteRestaurants(favs.restaurants);
  const favProviderId = favs.providers[0] ?? null;

  if (!cart || !cart.items.length) {
    return (
      <div className="container-x py-16">
        <div className="mx-auto max-w-2xl">
          <EmptyState
            icon="🧺"
            title="Sepetiniz boş"
            description={favRest.length ? "Favori işletmelerinizden birinin menüsüne göz atarak başlayabilirsiniz." : "Bir işletme seçin, menüden ürün ekleyin. Fiyatlar ödeme adımında sunucuda yeniden doğrulanır."}
            actions={[{ label: "Restoranları keşfet", href: "/yemek", primary: true }, { label: "Kurye çağır", href: "/talep/yeni" }]}
          />
          {favRest.length > 0 && (
            <div className="mt-6 grid gap-3 sm:grid-cols-2">
              {favRest.map((r) => (
                <Link key={r.id} href={`/restoranlar/${r.slug}`} className="card card-hover flex items-center gap-3 p-4">
                  <span className="flex h-11 w-11 items-center justify-center rounded-xl text-lg font-black text-white" style={{ background: `hsl(${r.logoHue} 70% 45%)` }}>{r.name[0]}</span>
                  <span>
                    <span className="block font-extrabold">{r.name}</span>
                    <span className="block text-xs text-ink/55">{r.isOpen ? "Açık" : "Kapalı"} · {r.deliveryAreas.slice(0, 2).map(areaName).join(", ")}</span>
                  </span>
                </Link>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }

  const r = cart.cart.restaurant;
  return (
    <div className="container-x py-10">
      <div className="eyebrow">Sepet</div>
      <h1 className="mt-1 text-4xl font-black tracking-tight">{r.name}</h1>
      <Link href={`/restoranlar/${r.slug}`} className="text-sm font-semibold text-ink/55 hover:text-signal">← Menüye dön</Link>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-4">
          {!r.openNow && (
            <div className="card border-sun/40 bg-sun/10 p-4 text-sm font-semibold text-[#7a5500]">
              Bu işletme şu anda siparişe kapalı. Çalışma saatleri {r.opensAt ?? ""}–{r.closesAt ?? ""}. Sepetinizi saklayabilir, açıldığında sipariş verebilirsiniz.
            </div>
          )}
          {cart.items.map((i) => (
            <div key={i.id} className={`card flex flex-wrap items-center gap-4 p-4 ${i.available ? "" : "border-rose/40"}`}>
              <div className="min-w-0 flex-1">
                <div className="font-extrabold">{i.name}</div>
                {i.options && <div className="text-xs text-ink/55">{i.options}</div>}
                {i.note && <div className="mt-0.5 text-xs text-ink/45">Not: {i.note}</div>}
                {!i.available && <div className="mt-1 text-xs font-bold text-rose">Bu ürün şu anda tükenmiş veya pasif — siparişe dahil edilemez.</div>}
              </div>
              <CartQty itemId={i.id} qty={i.qty} stock={i.stock} />
              <div className="w-24 text-right font-black">{money(i.lineTotalMinor)}</div>
              <ApiButton url={`/api/cart/items/${i.id}`} method="DELETE" className="btn-ghost btn-sm" confirm="Ürünü sepetten çıkarılsın mı?">Sil</ApiButton>
            </div>
          ))}
          <div className="flex items-center justify-between">
            <ApiButton url="/api/cart" method="DELETE" className="btn-danger btn-sm" confirm="Sepet tamamen boşaltılsın mı?">Sepeti boşalt</ApiButton>
            <div className="text-sm text-ink/60">Ara toplam: <b className="text-ink">{money(cart.subtotalMinor)}</b></div>
          </div>
        </div>
        <div>
          <Checkout
            initialCart={{ cart: { id: cart.cart.id, restaurant: r }, items: cart.items, subtotalMinor: cart.subtotalMinor }}
            favoriteProviderId={favProviderId}
          />
        </div>
      </div>
    </div>
  );
}
