import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { assignments, mediaPosts, serviceRequests } from "@/db/schema";
import { FavoriteButton } from "@/components/client";
import { MediaGrid, ReportButton, ReviewActions } from "@/components/media-client";
import { PanelTabs } from "@/components/RestaurantView";
import { OpenChatButton } from "@/components/chat/ChatSheet";
import { Avatar, EmptyState, ProviderStatusPill, StarRow, Stars, VehicleChip } from "@/components/ui";
import { areaName } from "@/lib/geo";
import { FLEET_POLICY, KINDS, SERVICES, money, timeAgo } from "@/lib/labels";
import { getFavoriteIds, getProviderPage } from "@/lib/queries";
import { getPublicSession as getSession } from "@/lib/session";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const data = await getProviderPage((await params).slug);
  if (!data) return { title: "Profil bulunamadı — YolArkadaşı" };
  const p = data.provider;
  return {
    title: `${p.displayName} — ${p.headline ?? KINDS[p.kind]} · YolArkadaşı`,
    description: p.bio?.slice(0, 155) ?? undefined,
    openGraph: { title: `${p.displayName} · YolArkadaşı`, description: p.headline ?? undefined },
  };
}

export default async function ProviderProfile({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const data = await getProviderPage(slug);
  if (!data) notFound();
  const { provider: p, reviews, categories, distribution } = data;
  const s = await getSession();
  const isCustomer = s.user.role === "CUSTOMER";
  const isOwner = s.providerId === p.id;
  const isAdmin = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role);
  const favs = isCustomer ? await getFavoriteIds(s.user.id) : { providers: [] as string[], fleets: [] as string[], restaurants: [] as string[] };
  const fleetOnly = p.fleet?.policy === "FLEET_ONLY";
  const suspended = p.status === "SUSPENDED";
  const maxDist = Math.max(1, ...distribution.map((d) => d.n));

  const media = await db
    .select()
    .from(mediaPosts)
    .where(and(eq(mediaPosts.ownerType, "PROVIDER"), eq(mediaPosts.ownerId, p.id), eq(mediaPosts.status, "PUBLISHED")))
    .orderBy(desc(mediaPosts.publishedAt));

  // İletişim sekmesi yalnızca gerçek hizmet ilişkisinde açılır
  const relation = isCustomer
    ? await db
        .select({ id: assignments.id, state: assignments.state, requestId: assignments.requestId })
        .from(assignments)
        .innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId))
        .where(and(eq(assignments.providerId, p.id), eq(serviceRequests.customerId, s.user.id)))
        .orderBy(desc(assignments.acceptedAt))
        .limit(3)
    : [];
  const activeRelation = relation.find((r) => r.state === "CONFIRMED" || r.state === "IN_PROGRESS");

  const actions = [
    { mode: "INSTANT_CALL", label: "Hemen Çağır", icon: "⚡", enabled: p.acceptsInstant && p.status === "AVAILABLE", hint: p.status === "AVAILABLE" ? "Şimdi, tek görev" : "Şu an müsait değil" },
    { mode: "SCHEDULED", label: "Randevu Oluştur", icon: "📅", enabled: p.acceptsScheduled, hint: "İleri tarihli" },
    { mode: "INSTANT_RENT", label: "Hemen Kirala", icon: "⏱", enabled: p.acceptsRental && p.status === "AVAILABLE", hint: p.acceptsRental ? `${money(p.rentalHourlyMinor)}/saat` : "Kiralama yok" },
  ];

  const badges = [
    ...(p.isVerified ? [{ icon: "✓", label: "Kimlik ve belge doğrulaması", tone: "blue" as const, desc: "Operasyon ekibi tarafından onaylandı." }] : []),
    ...p.highlights.map((h) => ({ icon: "✦", label: h, tone: "slate" as const, desc: "Sağlayıcının beyanı — belge gerektiren rozetler doğrulanmadan gösterilmez." })),
    ...(p.completedCount >= 50 ? [{ icon: "🏅", label: `${p.completedCount} tamamlanan görev`, tone: "green" as const, desc: "Gerçek görev verisinden hesaplanır." }] : []),
    ...(p.onTimeRate >= 0.95 ? [{ icon: "⏱", label: `%${Math.round(p.onTimeRate * 100)} zamanında teslim`, tone: "green" as const, desc: "Son görevlerin zamanında teslim oranı." }] : []),
  ];

  const faq = [
    { q: `${p.displayName} hangi bölgelerde hizmet veriyor?`, a: `Hizmet bölgeleri: ${p.serviceAreas.map(areaName).join(", ")}. Bölge dışı talepler eşleştirmede elenir.` },
    { q: "Hangi hizmetleri veriyor?", a: `${p.serviceTypes.map((x) => SERVICES[x]?.label).join(", ")} · araç: ${p.vehicleLabel}.` },
    { q: "Talebim kesin atanır mı?", a: "Hayır. Talep önce “iletildi” durumuna geçer; sağlayıcı veya filo kabul ettiğinde “onaylandı” olur. Reddedilirse sıradaki uygun adaya geçilir." },
    { q: "Telefon numarasını görebilir miyim?", a: "Hayır. İletişim yalnızca aktif görev süresince platform üzerinden kurulur; numara hiçbir zaman gösterilmez." },
    { q: "Ücret nasıl hesaplanıyor?", a: `Açılış ${money(p.baseFareMinor)} + km başı ${money(p.perKmMinor)}. Kiralamada saatlik ${money(p.rentalHourlyMinor)}. Kesin tutar kabul anında sunucuda hesaplanır.` },
  ];

  return (
    <div>
      <div className="road-pattern-dark relative h-52 sm:h-60" style={{ background: `linear-gradient(120deg, hsl(${p.hue} 70% 22%), hsl(${(p.hue + 60) % 360} 55% 12%))` }}>
        <svg className="absolute inset-0 h-full w-full opacity-30" preserveAspectRatio="none" viewBox="0 0 800 200" aria-hidden="true">
          <path d="M-20 160 C 150 60, 260 200, 420 110 S 700 40, 820 90" stroke="#ff5b23" strokeWidth="3" fill="none" strokeDasharray="14 10" />
        </svg>
        {p.fleet && (
          <div className="container-x relative flex h-full items-start justify-end pt-5">
            <Link href={`/filolar/${p.fleet.slug}`} className="chip-dark">🏢 {p.fleet.name}</Link>
          </div>
        )}
      </div>

      <div className="container-x">
        <div className="-mt-16">
          <div className="card relative p-6 sm:p-7">
            <div className="flex flex-col gap-5 sm:flex-row sm:items-end">
              <div className="-mt-20 sm:-mt-24"><Avatar name={p.displayName} hue={p.hue} size={112} status={p.status} /></div>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-3xl font-black tracking-tight">{p.displayName}</h1>
                  {p.isVerified && <span className="chip !border-sky/30 !bg-sky/10 !text-sky">✓ Doğrulanmış</span>}
                  <ProviderStatusPill status={p.status} />
                </div>
                <p className="mt-1 text-ink/60">@{p.slug} · {KINDS[p.kind]} · {p.headline}</p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {isCustomer && <FavoriteButton targetType="PROVIDER" targetId={p.id} initial={favs.providers.includes(p.id)} />}
                {(isCustomer || isAdmin) && !isOwner && <ReportButton targetType="PROVIDER" targetId={p.id} label="Profili bildir" />}
                {isOwner && <Link href="/panel/profil" className="btn-ink">✎ Vitrinimi düzenle</Link>}
              </div>
            </div>

            <div className="mt-6 grid grid-cols-3 divide-x divide-line rounded-2xl bg-paper py-4 text-center">
              <div><div className="text-2xl font-black">{p.ratingCount ? p.ratingAvg.toFixed(1).replace(".", ",") : "—"}</div><div className="text-xs text-ink/50">{p.ratingCount ? `${p.ratingCount} değerlendirme` : "Henüz değerlendirme yok"}</div></div>
              <div><div className="text-2xl font-black">{p.completedCount}</div><div className="text-xs text-ink/50">tamamlanan görev</div></div>
              <div><div className="text-2xl font-black">%{Math.round(p.onTimeRate * 100)}</div><div className="text-xs text-ink/50">zamanında</div></div>
            </div>

            {suspended ? (
              <div className="mt-6 rounded-2xl bg-rose/10 p-4 text-sm font-semibold text-rose">Bu profil şu anda hizmet vermiyor. Benzer sağlayıcıları keşfetmek için keşif sayfasını kullanabilirsiniz.</div>
            ) : fleetOnly ? (
              <div className="mt-6 flex flex-col items-start gap-3 rounded-2xl border border-dashed border-ink/20 p-4 sm:flex-row sm:items-center">
                <div className="flex-1 text-sm"><b>Filo üzerinden hizmet verir.</b> {FLEET_POLICY.FLEET_ONLY.desc}</div>
                <Link href={`/talep/yeni?mode=INSTANT_CALL&fleet=${p.fleet?.slug}`} className="btn-primary">🏢 {p.fleet?.name} ile çağır</Link>
              </div>
            ) : (
              <div className="mt-6 grid gap-3 sm:grid-cols-3">
                {actions.map((a, i) =>
                  a.enabled ? (
                    <Link key={a.mode} href={`/talep/yeni?mode=${a.mode}&provider=${p.slug}`} className={`${i === 0 ? "btn-primary" : "btn-ink"} !flex-col !gap-0 !rounded-2xl !py-3`}>
                      <span className="text-sm"><span className="mr-1" aria-hidden="true">{a.icon}</span>{a.label}</span>
                      <span className="mt-0.5 text-[11px] font-medium opacity-70">{a.hint}</span>
                    </Link>
                  ) : (
                    <div key={a.mode} className="btn border border-dashed border-line !flex-col !gap-0 !rounded-2xl !py-3 text-ink/40">
                      <span className="text-sm"><span className="mr-1" aria-hidden="true">{a.icon}</span>{a.label}</span>
                      <span className="mt-0.5 text-[11px] font-medium">{a.hint}</span>
                    </div>
                  ),
                )}
              </div>
            )}
            {p.fleet && p.fleet.policy === "FLEET_APPROVAL_REQUIRED" && !fleetOnly && (
              <p className="mt-3 text-xs text-ink/55">ℹ️ Bu sağlayıcıya gelen talepler önce <b>{p.fleet.name}</b> filo onayına düşer.</p>
            )}
          </div>
        </div>

        <div className="mt-8">
          <PanelTabs
            initial="overview"
            tabs={[
              { key: "overview", label: "Genel bakış" },
              { key: "about", label: "Hakkında" },
              { key: "services", label: "Hizmetler" },
              { key: "media", label: "Medya & tanıtım", count: media.length },
              { key: "reviews", label: "Değerlendirmeler", count: reviews.length },
              { key: "badges", label: "Rozetler", count: badges.length },
              { key: "faq", label: "Sık sorulanlar" },
              { key: "contact", label: "İletişim" },
            ]}
            panels={{
              overview: (
                <div className="grid gap-5 lg:grid-cols-3">
                  <div className="card p-5 lg:col-span-2">
                    <h2 className="font-extrabold">Öne çıkanlar</h2>
                    <div className="scrollbar-none mt-3 flex gap-2.5 overflow-x-auto pb-1">
                      <div className="card flex min-w-[190px] items-center gap-3 p-3.5">
                        <span className="text-lg" aria-hidden="true">🚘</span>
                        <div><div className="text-[11px] font-bold uppercase text-ink/45">Araç</div><div className="text-sm font-bold">{p.vehicleLabel}</div></div>
                      </div>
                      {p.highlights.map((h) => (
                        <div key={h} className="card flex min-w-[170px] items-center gap-2.5 p-3.5">
                          <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-signal/10 text-sm text-signal" aria-hidden="true">✦</span>
                          <div className="text-sm font-bold">{h}</div>
                        </div>
                      ))}
                    </div>
                    <p className="mt-4 leading-relaxed text-ink/70">{p.bio}</p>
                  </div>
                  <div className="card p-5">
                    <h2 className="font-extrabold">Puan dağılımı</h2>
                    {p.ratingCount ? (
                      <div className="mt-3 space-y-2">
                        {distribution.map((d) => (
                          <div key={d.star} className="flex items-center gap-2 text-xs">
                            <span className="w-6 font-bold">{d.star}★</span>
                            <div className="h-2 flex-1 overflow-hidden rounded-full bg-paper-2"><div className="h-full rounded-full bg-sun" style={{ width: `${(d.n / maxDist) * 100}%` }} /></div>
                            <span className="w-5 text-right text-ink/50">{d.n}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="mt-3 text-sm text-ink/55">Henüz değerlendirme yok. Yeni sağlayıcılar için sahte puan göstermiyoruz.</p>
                    )}
                    <div className="mt-4 border-t border-line pt-3">
                      <div className="text-sm font-extrabold">Tahmini ücret</div>
                      <div className="mt-1 text-xs text-ink/60">Açılış <b>{money(p.baseFareMinor)}</b> · km <b>{money(p.perKmMinor)}</b>{p.acceptsRental ? ` · saat <b>${money(p.rentalHourlyMinor)}</b>` : ""}</div>
                    </div>
                  </div>
                </div>
              ),
              about: (
                <div className="card p-6">
                  <h2 className="text-lg font-extrabold">Hakkında</h2>
                  <p className="mt-2 leading-relaxed text-ink/70">{p.bio ?? "Bu sağlayıcı henüz tanıtım metni eklemedi."}</p>
                  <div className="mt-5 grid gap-4 sm:grid-cols-2">
                    <div>
                      <div className="label">Çalışma tarzı</div>
                      <ul className="space-y-1.5 text-sm text-ink/70">
                        <li>• {p.acceptsInstant ? "Anlık çağrıları kabul eder" : "Anlık çağrı kabul etmiyor"}</li>
                        <li>• {p.acceptsScheduled ? "Randevulu görevler alır" : "Randevu kabul etmiyor"}</li>
                        <li>• {p.acceptsRental ? `Saatlik kiralama: ${money(p.rentalHourlyMinor)}` : "Saatlik kiralama sunmuyor"}</li>
                        <li>• Eş zamanlı görev kapasitesi: {p.completedCount > 0 ? "aktif görev sırasında yeni teklif almaz" : "tek görev"}</li>
                      </ul>
                    </div>
                    <div>
                      <div className="label">Gizlilik</div>
                      <ul className="space-y-1.5 text-sm text-ink/70">
                        <li>• Telefon numarası hiçbir kullanıcıya gösterilmez.</li>
                        <li>• Boştaki konumu paylaşılmaz; müşteriye yalnızca tahmini varış bandı gösterilir.</li>
                        <li>• Canlı konum yalnızca aktif görevdeki taraflara açıktır.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              ),
              services: (
                <div className="grid gap-5 sm:grid-cols-2">
                  <div className="card p-6">
                    <h2 className="font-extrabold">Hizmet türleri</h2>
                    <div className="mt-3 space-y-2">
                      {p.serviceTypes.map((x) => (
                        <div key={x} className="flex items-start gap-3 rounded-xl bg-paper px-3 py-2.5">
                          <span className="text-base" aria-hidden="true">{SERVICES[x]?.icon}</span>
                          <div><div className="text-sm font-bold">{SERVICES[x]?.label}</div><div className="text-xs text-ink/55">{SERVICES[x]?.desc}</div></div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-4 flex flex-wrap gap-1.5"><VehicleChip type={p.vehicleType} label={p.vehicleLabel} /></div>
                  </div>
                  <div className="card p-6">
                    <h2 className="font-extrabold">Hizmet bölgeleri & ücret</h2>
                    <div className="mt-3 flex flex-wrap gap-1.5">{p.serviceAreas.map((a) => <span key={a} className="chip">📍 {areaName(a)}</span>)}</div>
                    <div className="mt-4 space-y-1.5 text-sm">
                      <div className="flex justify-between"><span className="text-ink/55">Açılış ücreti</span><b>{money(p.baseFareMinor)}</b></div>
                      <div className="flex justify-between"><span className="text-ink/55">Km başı</span><b>{money(p.perKmMinor)}</b></div>
                      {p.acceptsRental && <div className="flex justify-between"><span className="text-ink/55">Saatlik kiralama</span><b>{money(p.rentalHourlyMinor)}</b></div>}
                    </div>
                    <p className="mt-3 text-[11px] text-ink/45">Kesin tutar, sağlayıcı talebi kabul ettiğinde sunucuda hesaplanır ve sipariş özetine yazılır.</p>
                    <Link href={`/kesfet?area=${p.serviceAreas[0]}`} className="btn-ghost btn-sm mt-4">Bu bölgedeki diğer sağlayıcılar →</Link>
                  </div>
                </div>
              ),
              media: (
                <div className="card p-6">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <h2 className="font-extrabold">Medya & tanıtım</h2>
                      <p className="text-xs text-ink/55">Tüm içerikler moderasyondan geçer; EXIF/GPS bilgileri temizlenir.</p>
                    </div>
                    {isOwner && <Link href="/panel/profil" className="btn-ghost btn-sm">İçerik yükle</Link>}
                  </div>
                  <div className="mt-4"><MediaGrid items={media} canReport={isCustomer || isAdmin} /></div>
                </div>
              ),
              reviews: (
                <div className="grid gap-5 lg:grid-cols-[300px_1fr]">
                  <div className="card h-fit p-5">
                    <div className="flex items-center gap-2"><Stars value={p.ratingAvg} count={p.ratingCount} size="lg" /></div>
                    {categories && (
                      <div className="mt-4 space-y-2.5">
                        {[["Zamanında", categories.time], ["İletişim", categories.communication], ["Özen", categories.care], ["Profesyonellik", categories.professionalism]].map(([l, v]) => (
                          <div key={l as string}>
                            <div className="flex justify-between text-xs font-semibold"><span>{l}</span><span>{(v as number).toFixed(1).replace(".", ",")}</span></div>
                            <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-paper-2"><div className="h-full rounded-full bg-signal" style={{ width: `${((v as number) / 5) * 100}%` }} /></div>
                          </div>
                        ))}
                      </div>
                    )}
                    <p className="mt-4 text-[11px] text-ink/45">Yalnızca tamamlanan gerçek görevler puanlanır. Ortalama veritabanında yeniden hesaplanır; admin puan değiştiremez.</p>
                  </div>
                  <div className="card divide-y divide-line">
                    {reviews.length === 0 && <div className="p-8"><EmptyState icon="⭐" title="Henüz değerlendirme yok" description="İlk görevi tamamlayan müşteri buraya yorum bırakabilir." /></div>}
                    {reviews.map((r) => (
                      <div key={r.id} className="p-5">
                        <div className="flex items-center justify-between gap-3">
                          <div>
                            <div className="text-sm font-bold">{r.author} <span className="ml-1 rounded-full bg-mint/12 px-2 py-0.5 text-[10px] font-bold text-[#0c8a5a]">Doğrulanmış görev</span></div>
                            <div className="text-[11px] text-ink/45">{timeAgo(r.createdAt)}</div>
                          </div>
                          <StarRow value={r.rating} />
                        </div>
                        {r.body && <p className="mt-2 text-sm text-ink/75">{r.body}</p>}
                        <ReviewActions reviewId={r.id} canRespond={isOwner || isAdmin} canAppeal={isOwner} isAuthor={false} />
                      </div>
                    ))}
                  </div>
                </div>
              ),
              badges: (
                <div className="card p-6">
                  <h2 className="font-extrabold">Rozetler ve doğrulamalar</h2>
                  <p className="text-xs text-ink/55">Belge gerektiren rozetler yalnızca operasyon doğrulamasından sonra görünür.</p>
                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    {badges.map((b) => (
                      <div key={b.label} className="flex items-start gap-3 rounded-xl bg-paper p-4">
                        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white text-sm shadow-sm" aria-hidden="true">{b.icon}</span>
                        <div><div className="text-sm font-bold">{b.label}</div><div className="mt-0.5 text-xs text-ink/55">{b.desc}</div></div>
                      </div>
                    ))}
                    {badges.length === 0 && <div className="text-sm text-ink/55 sm:col-span-2">Bu profil için doğrulanmış rozet bulunmuyor.</div>}
                  </div>
                </div>
              ),
              faq: (
                <div className="card divide-y divide-line">
                  {faq.map((f) => (
                    <details key={f.q} className="group px-5 py-4">
                      <summary className="cursor-pointer text-sm font-bold">{f.q}<span className="float-right text-ink/35 transition group-open:rotate-45">＋</span></summary>
                      <p className="mt-2 text-sm text-ink/65">{f.a}</p>
                    </details>
                  ))}
                </div>
              ),
              contact: (
                <div className="card p-6">
                  <h2 className="font-extrabold">İletişim</h2>
                  {activeRelation ? (
                    <>
                      <div className="mt-3 rounded-xl bg-mint/10 p-4 text-sm font-semibold text-[#0c8a5a]">Bu sağlayıcıyla aktif göreviniz var. Uygulama içi iletişim görev süresince ve teslimden 48 saat sonra açık kalır.</div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <OpenChatButton requestId={activeRelation.requestId} label="💬 Mesaj gönder" className="btn-primary" />
                        <Link href={`/talep/${activeRelation.requestId}`} className="btn-ghost">Görev ekranını aç →</Link>
                      </div>
                    </>
                  ) : (
                    <>
                      <p className="mt-2 text-sm text-ink/65">Rastgele mesajlaşmaya izin vermiyoruz; iletişim yalnızca aktif hizmet ilişkisinde açılır. Talep oluşturduğunuzda sağlayıcı atandığında görev ekranı üzerinden iletişim kurabilirsiniz.</p>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {!fleetOnly && <Link href={`/talep/yeni?mode=INSTANT_CALL&provider=${p.slug}`} className="btn-primary btn-sm">⚡ Hemen çağır</Link>}
                        {p.fleet && <Link href={`/filolar/${p.fleet.slug}`} className="btn-ghost btn-sm">Filo kurumsal iletişim →</Link>}
                        <Link href="/destek" className="btn-ghost btn-sm">💬 Destek</Link>
                      </div>
                      {relation.length > 0 && (
                        <div className="mt-5 border-t border-line pt-4">
                          <div className="text-xs font-bold uppercase tracking-wider text-ink/45">Geçmiş görevleriniz</div>
                          <div className="mt-2 space-y-1.5">
                            {relation.map((r) => <Link key={r.id} href={`/talep/${r.requestId}`} className="block rounded-xl bg-paper px-3 py-2 text-sm hover:bg-paper-2">Görev kaydı · {r.state === "COMPLETED" ? "tamamlandı" : r.state === "CANCELLED" ? "iptal edildi" : "devam ediyor"}</Link>)}
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>
              ),
            }}
          />
        </div>
      </div>
    </div>
  );
}
