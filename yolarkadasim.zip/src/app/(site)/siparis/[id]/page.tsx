import Link from "next/link";
import { notFound } from "next/navigation";
import { ApiButton, AutoRefresh } from "@/components/client";
import { OrderRating } from "@/components/food-client";
import { OpenChatButton } from "@/components/chat/ChatSheet";
import { Avatar, EmptyState, Pill } from "@/components/ui";
import { getOrderView } from "@/lib/food";
import { sweepExpired } from "@/lib/engine";
import { areaName } from "@/lib/geo";
import { ORDER_STATUS, dateTime, money } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";

const STEPS = ["ORDER_PLACED", "RESTAURANT_ACCEPTED", "PREPARING", "READY_FOR_PICKUP", "COURIER_ASSIGNED", "OUT_FOR_DELIVERY", "DELIVERED"];

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const s = await getSession();
  await sweepExpired();
  const v = await getOrderView(s, (await params).id);
  if (!v) notFound();
  const { order: o, restaurant: r, items, events, courier, requestId, viewer, review, canReview } = v;
  const step = ORDER_STATUS[o.status]?.step ?? -1;
  const failed = step < 0;

  return (
    <div className="container-x py-10">
      {!failed && o.status !== "DELIVERED" && <AutoRefresh ms={4000} />}
      <Link href="/siparislerim" className="text-sm font-semibold text-ink/50 hover:text-ink">← Siparişlerim</Link>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="font-mono text-3xl font-black tracking-tight">{o.code}</h1>
            <Pill tone={ORDER_STATUS[o.status]?.tone ?? "slate"}>{ORDER_STATUS[o.status]?.label}</Pill>
          </div>
          <p className="mt-1 text-ink/60">
            {r && <Link href={`/restoranlar/${r.slug}`} className="font-semibold hover:text-signal">{r.name}</Link>} · {dateTime(o.placedAt)} · {areaName(o.deliveryArea)}
          </p>
        </div>
        <div className="flex gap-2">
          {viewer.isCustomer && o.status === "ORDER_PLACED" && (
            <ApiButton url={`/api/orders/${o.id}/cancel`} className="btn-danger btn-sm" confirm="Siparişi iptal etmek istiyor musunuz? Stok geri bırakılır.">İptal et</ApiButton>
          )}
          {viewer.isAdmin && !["DELIVERED", "CANCELLED", "REFUNDED"].includes(o.status) && (
            <ApiButton url={`/api/merchant/orders/${o.id}`} body={{ action: "reopen" }} prompt={{ label: "İnceleme gerekçesi (zorunlu):", field: "reason" }} className="btn-danger btn-sm">İncelemeye al</ApiButton>
          )}
        </div>
      </div>

      {viewer.isCustomer && (
        <div className={`card mt-5 p-4 text-sm font-semibold tone-${ORDER_STATUS[o.status]?.tone ?? "slate"}`}>{ORDER_STATUS[o.status]?.customer}</div>
      )}

      {/* Durum şeridi */}
      <div className="card mt-5 overflow-x-auto p-5">
        <div className="flex min-w-[640px] items-start">
          {STEPS.map((k, i) => {
            const done = !failed && step >= i;
            return (
              <div key={k} className="flex flex-1 items-start last:flex-none">
                <div className="flex w-24 flex-col items-center gap-1.5 text-center">
                  <span className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-black ${done ? (i === step && o.status !== "DELIVERED" ? "bg-signal text-white shadow-[0_0_0_5px_rgba(255,91,35,0.16)]" : "bg-ink text-white") : "bg-paper-2 text-ink/35"}`}>
                    {done && i < step ? "✓" : i + 1}
                  </span>
                  <span className={`text-[11px] font-bold leading-tight ${done ? "text-ink" : "text-ink/35"}`}>{ORDER_STATUS[k].label}</span>
                </div>
                {i < STEPS.length - 1 && <div className={`mt-4 h-0.5 flex-1 rounded ${!failed && i < step ? "bg-ink" : "bg-paper-2"}`} />}
              </div>
            );
          })}
        </div>
        {failed && (
          <div className="mt-4 rounded-xl bg-rose/10 p-3 text-sm font-semibold text-rose">
            {ORDER_STATUS[o.status]?.customer}
            {events.filter((e) => e.message).slice(-1)[0]?.message ? ` — ${events.filter((e) => e.message).slice(-1)[0]?.message}` : ""}
          </div>
        )}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_340px]">
        <div className="space-y-5">
          {courier && (
            <div className="card flex flex-wrap items-center gap-4 p-5">
              <Avatar name={courier.name} hue={courier.hue} size={56} />
              <div className="min-w-0 flex-1">
                <div className="text-[11px] font-bold uppercase tracking-wider text-mint">Kuryeniz</div>
                <Link href={`/kuryeler/${courier.slug}`} className="font-extrabold hover:text-signal">{courier.name}</Link>
                <div className="text-xs text-ink/55">★ {courier.ratingCount ? courier.ratingAvg.toFixed(1) : "yeni"} · {courier.headline}</div>
              </div>
              {requestId && viewer.isCustomer && o.status !== "DELIVERED" && <OpenChatButton requestId={requestId} label="💬 Kuryeye yaz" className="btn-ink btn-sm" />}
              {requestId && <Link href={`/talep/${requestId}`} className="btn-ghost btn-sm">Canlı takip →</Link>}
              {viewer.isCustomer && o.deliveryOtp && o.status !== "DELIVERED" && (
                <div className="rounded-2xl bg-paper px-4 py-2 text-center">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-ink/50">Teslim kodu</div>
                  <div className="font-mono text-xl font-black tracking-[0.25em] text-signal">{o.deliveryOtp}</div>
                </div>
              )}
            </div>
          )}

          {!courier && ["READY_FOR_PICKUP"].includes(o.status) && (
            <div className="card border-sun/40 bg-sun/[0.07] p-5">
              <div className="font-extrabold">🛵 Kurye aranıyor</div>
              <p className="mt-1 text-sm text-ink/70">Siparişiniz hazır. Uygun kurye bulunana kadar sistem sırayla teklif gönderir; reddedilen teklifler otomatik olarak sıradaki adaya geçer.</p>
              {requestId && <Link href={`/talep/${requestId}`} className="btn-ghost btn-sm mt-3">Eşleştirme detayını gör →</Link>}
            </div>
          )}

          <div className="card overflow-hidden">
            <div className="border-b border-line px-5 py-3 font-extrabold">Sipariş içeriği</div>
            <div className="divide-y divide-line">
              {items.map((i) => (
                <div key={i.id} className="flex items-start gap-3 px-5 py-3 text-sm">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-paper font-bold">{i.qty}×</span>
                  <span className="min-w-0 flex-1">
                    <span className="block font-bold">{i.nameSnapshot}</span>
                    {i.optionsSnapshot && <span className="block text-xs text-ink/55">{i.optionsSnapshot}</span>}
                    {i.note && <span className="block text-xs text-ink/45">Not: {i.note}</span>}
                  </span>
                  <span className="font-bold">{money(i.lineTotalMinor)}</span>
                </div>
              ))}
            </div>
            <div className="space-y-1 border-t border-line bg-paper/60 px-5 py-4 text-sm">
              <Line k="Ara toplam" v={money(o.subtotalMinor)} />
              <Line k="Teslimat ücreti" v={money(o.deliveryFeeMinor)} />
              {o.smallBasketFeeMinor > 0 && <Line k="Küçük sepet bedeli" v={money(o.smallBasketFeeMinor)} />}
              {o.tipMinor > 0 && <Line k="Bahşiş" v={money(o.tipMinor)} />}
              {o.discountMinor > 0 && <Line k="İndirim" v={`-${money(o.discountMinor)}`} />}
              <div className="mt-2 flex justify-between border-t border-line pt-2 text-base font-black"><span>Toplam</span><span>{money(o.totalMinor)}</span></div>
              <div className="text-xs text-ink/50">{o.paymentMethod === "CASH_ON_DELIVERY" ? "Kapıda nakit ödeme" : "Kart ile ödeme (sandbox — gerçek tahsilat yapılmaz)"} · tahmini teslim {o.etaMinutes} dk</div>
            </div>
          </div>

          {canReview && <OrderRating orderId={o.id} restaurantName={r?.name ?? "İşletme"} />}
          {review && (
            <div className="card p-5">
              <div className="text-sm font-extrabold">Değerlendirmeniz</div>
              <div className="mt-1 text-sun">{"★".repeat(review.rating)}<span className="text-ink/15">{"★".repeat(5 - review.rating)}</span></div>
              {review.body && <p className="mt-1 text-sm text-ink/70">{review.body}</p>}
              {r && <Link href={`/restoranlar/${r.slug}`} className="btn-ghost btn-sm mt-3">İşletme yorumlarını gör</Link>}
            </div>
          )}
          {o.status === "DELIVERED" && !review && !canReview && (
            <EmptyState icon="⭐" title="Değerlendirme süresi doldu" description="Sipariş tesliminden sonraki 14 gün içinde değerlendirme yapılabilir." />
          )}
          {o.status === "DELIVERED" && r && (
            <Link href={`/restoranlar/${r.slug}`} className="card card-hover flex items-center justify-between p-4 font-bold">↻ Tekrar sipariş ver</Link>
          )}
        </div>

        <aside className="space-y-4">
          <div className="card p-5">
            <div className="text-sm font-extrabold">Teslimat bilgileri</div>
            <div className="mt-3 space-y-2 text-sm">
              <Line k="Bölge" v={areaName(o.deliveryArea)} />
              <Line k="Adres" v={o.addressDetail ?? "Detay verilmedi"} />
              {o.note && <Line k="Not" v={o.note} />}
              <Line k="Kurye tercihi" v={o.courierPreference === "AUTO" ? "Sistem seçti" : o.courierPreference === "FAVORITE" ? "Favori kurye" : "Filo"} />
            </div>
            <p className="mt-3 text-[11px] text-ink/45">Adresiniz yalnızca sipariş sürecindeki taraflarla paylaşılır; herkese açık profilde görünmez.</p>
          </div>
          <div className="card p-5">
            <div className="text-sm font-extrabold">Sipariş geçmişi</div>
            <ol className="relative mt-4 space-y-4 border-l-2 border-paper-2 pl-4">
              {events.map((e) => (
                <li key={e.id} className="relative">
                  <span className="absolute -left-[23px] top-1 h-3 w-3 rounded-full border-2 border-white bg-signal" />
                  <div className="text-xs font-bold">{ORDER_STATUS[e.toState]?.label ?? e.toState}</div>
                  {e.message && <div className="text-xs text-ink/60">{e.message}</div>}
                  <div className="text-[10px] text-ink/40">{dateTime(e.createdAt)} · {e.actorRole}</div>
                </li>
              ))}
            </ol>
          </div>
          <div className="card p-5">
            <div className="text-sm font-extrabold">Yardım</div>
            <div className="mt-2 flex flex-col gap-2">
              <Link href="/destek" className="btn-ghost btn-sm w-full">💬 Destek al</Link>
              {r && <Link href={`/restoranlar/${r.slug}`} className="btn-ghost btn-sm w-full">🍽️ İşletme profili</Link>}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-3 text-sm">
      <span className="text-ink/55">{k}</span>
      <span className="max-w-[60%] text-right font-bold">{v}</span>
    </div>
  );
}
