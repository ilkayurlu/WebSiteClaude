import Link from "next/link";
import { EmptyState } from "@/components/ui";
import { MEDIA_POLICY } from "@/lib/labels";
import { getPublicSession as getSession } from "@/lib/session";

export const metadata = { title: "Destek — YolArkadaşı" };

const FAQ = [
  { q: "Kurye talebimi nasıl iptal ederim?", a: "Talep detay sayfasındaki “İptal et” düğmesini kullanın. Görev başladıktan sonra iptal için operasyon ekibi devreye girer ve gerekçe kaydı alınır." },
  { q: "Siparişim gecikti, ne yapmalıyım?", a: "Sipariş sayfasındaki canlı durumu kontrol edin. Kurye atandıysa canlı takip bağlantısından görev adımını görebilirsiniz. Gecikme 15 dakikayı aşarsa “Destek” üzerinden bildirim oluşturun." },
  { q: "Değerlendirmemi değiştirebilir miyim?", a: "Evet, ilk 48 saat içinde puan ve yorumunuzu düzenleyebilirsiniz. Eski sürüm denetim kaydı olarak saklanır." },
  { q: "Bir profili veya içeriği nasıl bildiririm?", a: "Profil, medya ve yorum sayfalarındaki “Bildir” düğmesini kullanın. Bildirimler moderasyon kuyruğuna düşer ve gerekçeli kararla sonuçlanır." },
  { q: "Konumum paylaşılıyor mu?", a: "Hayır. Sağlayıcıların boştaki konumu yalnızca yaklaşık mesafe ve tahmini varış bandı olarak hesaplanır; ham koordinat hiçbir kullanıcıya gösterilmez." },
];

export default async function Support() {
  const s = await getSession();
  return (
    <div className="container-x py-12">
      <div className="mx-auto max-w-3xl">
        <div className="eyebrow">Destek</div>
        <h1 className="mt-1 text-4xl font-black tracking-tight">Nasıl yardımcı olabiliriz?</h1>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <Link href="/siparislerim" className="card card-hover p-5"><div className="font-extrabold">🧾 Siparişlerim</div><div className="text-sm text-ink/55">Aktif ve geçmiş siparişlerinizi görüntüleyin, durumu izleyin.</div></Link>
          <Link href="/taleplerim" className="card card-hover p-5"><div className="font-extrabold">🛵 Kurye taleplerim</div><div className="text-sm text-ink/55">Talep durumunu görün, iptal edin veya değerlendirin.</div></Link>
          <Link href="/kesfet" className="card card-hover p-5"><div className="font-extrabold">🔎 Sağlayıcı bul</div><div className="text-sm text-ink/55">Bölgenizdeki müsait kurye ve sürücüleri listeleyin.</div></Link>
          <Link href="/basvuru" className="card card-hover p-5"><div className="font-extrabold">🤝 İş ortağı ol</div><div className="text-sm text-ink/55">İşletme veya filo başvurusu yapın.</div></Link>
        </div>

        <h2 className="mb-3 mt-10 text-2xl font-black tracking-tight">Sık sorulanlar</h2>
        <div className="card divide-y divide-line">
          {FAQ.map((f) => (
            <details key={f.q} className="group px-5 py-4">
              <summary className="cursor-pointer font-bold">
                {f.q}
                <span className="float-right text-ink/35 transition group-open:rotate-45">＋</span>
              </summary>
              <p className="mt-2 text-sm text-ink/65">{f.a}</p>
            </details>
          ))}
        </div>

        <h2 className="mb-3 mt-10 text-2xl font-black tracking-tight">İçerik politikası</h2>
        <div className="grid gap-3 sm:grid-cols-2">
          {MEDIA_POLICY.map((p) => (
            <div key={p.ref} className="card p-4">
              <div className="text-xs font-black text-signal">{p.ref} · {p.label}</div>
              <p className="mt-1 text-sm text-ink/65">{p.desc}</p>
            </div>
          ))}
        </div>

        <div className="mt-10">
          <EmptyState
            icon="📮"
            title="Sorunuz burada yanıtlanmadı mı?"
            description="Demo ortamında gerçek e-posta ve telefon hattı bağlı değildir. İhlal bildirimleri için ilgili sayfadaki “Bildir” düğmesini kullanın; talepler moderasyon kuyruğuna düşer ve denetim kaydına yazılır."
            actions={["ADMIN", "SUPER_ADMIN"].includes(s.user.role) ? [{ label: "Operasyon paneli", href: s.user.role === "SUPER_ADMIN" ? "/admin" : "/dashboard/admin", primary: true }, { label: "Raporlanan içerikler", href: "/admin/raporlanan-icerikler" }] : [{ label: "İçerik bildir", href: "/kesfet", primary: true }, { label: "Siparişlerim", href: "/siparislerim" }]}
          />
        </div>
      </div>
    </div>
  );
}
