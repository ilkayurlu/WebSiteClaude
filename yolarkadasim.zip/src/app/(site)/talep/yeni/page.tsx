import { eq } from "drizzle-orm";
import { db } from "@/db";
import { fleets, providers } from "@/db/schema";
import { NewRequestWizard } from "@/components/NewRequestWizard";
import { EmptyState } from "@/components/ui";
import { requirePageSession as getSession } from "@/lib/session";
import { resolveArea } from "@/lib/geo";

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

export default async function NewRequest({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const s = await getSession();
  if (s.user.role !== "CUSTOMER") {
    return (
      <div className="container-x py-20">
        <div className="mx-auto max-w-xl">
          <EmptyState icon="👤" title="Talep oluşturmak için müşteri hesabı gerekir" description="Sağ üstteki hesap menüsünden bir demo müşteri hesabına geçebilirsiniz (ör. Elif Yılmaz)." />
        </div>
      </div>
    );
  }
  const m = one(sp.mode);
  const mode = m === "SCHEDULED" || m === "INSTANT_RENT" ? m : "INSTANT_CALL";
  const slug = one(sp.provider);
  const fleetSlug = one(sp.fleet);
  const [prov] = slug ? await db.select().from(providers).where(eq(providers.slug, slug)).limit(1) : [];
  const [fleet] = fleetSlug ? await db.select().from(fleets).where(eq(fleets.slug, fleetSlug)).limit(1) : [];

  return (
    <div className="container-x py-10">
      <div className="eyebrow">Yeni talep</div>
      <h1 className="mt-1 text-4xl font-black tracking-tight">Yola çıkalım</h1>
      <p className="mb-8 mt-2 text-ink/60">Birkaç adımda talebini oluştur; uygun yol arkadaşlarını sunucu taraflı eşleştirme ile listeleyelim.</p>
      <NewRequestWizard
        initialMode={mode}
        initialDistrict={(() => {
          const area = resolveArea(one(sp.pickup) ?? prov?.serviceAreas?.[0]);
          return area ? { cityCode: area.cityCode, cityName: area.cityName, districtId: area.districtId, districtName: area.name, slug: area.slug, lat: area.lat, lng: area.lng, approx: area.approx } : undefined;
        })()}
        pref={{
          provider: prov && prov.visibility !== "HIDDEN"
            ? { id: prov.id, slug: prov.slug, displayName: prov.displayName, hue: prov.hue, serviceTypes: prov.serviceTypes, serviceAreas: prov.serviceAreas, vehicleType: prov.vehicleType, headline: prov.headline, rentalHourlyMinor: prov.rentalHourlyMinor }
            : null,
          fleet: fleet ? { id: fleet.id, slug: fleet.slug, name: fleet.name } : null,
        }}
      />
    </div>
  );
}
