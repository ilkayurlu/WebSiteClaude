import Link from "next/link";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { fleets } from "@/db/schema";
import { ApiButton, AutoRefresh, Countdown } from "@/components/client";
import { OtpComplete, ReviewForm, WhoDelivers } from "@/components/RequestClient";
import { OpenChatButton } from "@/components/chat/ChatSheet";
import { Avatar, EmptyState, Pill, RequestStatusPill, Stars, VehicleChip } from "@/components/ui";
import { FLEET_TTL_S, OFFER_TTL_S, sweepExpired } from "@/lib/engine";
import { areaName } from "@/lib/geo";
import { MODES, REQUEST_STATUS, SERVICES, STRATEGIES, dateTime, money } from "@/lib/labels";
import { getRequestView } from "@/lib/queries";
import { requirePageSession as getSession } from "@/lib/session";

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

const FLOW = [
  { key: "QUOTED", label: "Teklif" },
  { key: "OFFERED", label: "İletildi" },
  { key: "CONFIRMED", label: "Onaylandı" },
  { key: "IN_PROGRESS", label: "Yolda" },
  { key: "COMPLETED", label: "Tamamlandı" },
];
const ACTIVE = ["MATCHING", "OFFERED", "CONFIRMED", "IN_PROGRESS"];

export default async function RequestPage({ params, searchParams }: { params: Promise<{ id: string }>; searchParams: SP }) {
  const { id } = await params;
  const sp = await searchParams;
  const s = await getSession();
  await sweepExpired();
  const v = await getRequestView(s, id);
  if (!v) notFound();
  const { request: r, candidates, assignment: a, events, viewer, review } = v;
  const fleetRows = await db.select({ id: fleets.id, slug: fleets.slug }).from(fleets);
  const fleetIdsBySlug = Object.fromEntries(fleetRows.map((f) => [f.slug, f.id]));

  const flowIdx = Math.max(0, FLOW.findIndex((f) => f.key === (r.status === "MATCHING" ? "OFFERED" : r.status)));
  const cancelled = r.status.startsWith("CANCELLED") || r.status === "EXPIRED";
  const current = candidates.find((c) => c.response === "OFFERED" || c.response === "FLEET_PENDING");
  const canCancel = viewer.isCustomer && ["QUOTED", "MATCHING", "OFFERED", "CONFIRMED"].includes(r.status);

  return (
    <div className="container-x py-10">
      {ACTIVE.includes(r.status) && <AutoRefresh ms={3500} />}

      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <Link href={viewer.isCustomer ? "/taleplerim" : viewer.isProvider ? "/panel" : viewer.isFleet ? "/filo" : "/admin"} className="text-sm font-semibold text-ink/50 hover:text-ink">← Geri</Link>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <h1 className="font-mono text-3xl font-black tracking-tight">{r.code}</h1>
            <RequestStatusPill status={r.status} />
            <Pill tone="slate">{MODES[r.mode]?.icon} {MODES[r.mode]?.label}</Pill>
          </div>
          <p className="mt-1 text-ink/60">
            {SERVICES[r.serviceType]?.icon} {SERVICES[r.serviceType]?.label} · {areaName(r.pickupArea)}
            {r.dropoffArea ? ` → ${areaName(r.dropoffArea)}` : ""} · {dateTime(r.createdAt)}
          </p>
        </div>
        <div className="flex gap-2">
          {canCancel && <ApiButton url={`/api/requests/${r.id}/cancel`} body={{}} className="btn-danger btn-sm" confirm="Talebi iptal etmek istediğinize emin misiniz?">İptal et</ApiButton>}
          {viewer.isAdmin && ACTIVE.includes(r.status) && (
            <ApiButton url={`/api/requests/${r.id}/cancel`} className="btn-danger btn-sm" prompt={{ label: "Operasyon iptal gerekçesi (zorunlu):", field: "reason" }}>Ops iptali</ApiButton>
          )}
        </div>
      </div>

      {/* İlerleme */}
      <div className="card mt-6 p-5">
        <div className="flex items-center">
          {FLOW.map((f, i) => {
            const done = !cancelled && i <= flowIdx;
            return (
              <div key={f.key} className="flex flex-1 items-center last:flex-none">
                <div className="flex flex-col items-center gap-1.5">
                  <span className={`flex h-8 w-8 items-center justify-center rounded-full text-xs font-black ${done ? (i === flowIdx && r.status !== "COMPLETED" ? "bg-signal text-white shadow-[0_0_0_5px_rgba(255,91,35,0.18)]" : "bg-ink text-white") : "bg-paper-2 text-ink/35"}`}>
                    {done && (i < flowIdx || r.status === "COMPLETED") ? "✓" : i + 1}
                  </span>
                  <span className={`text-[11px] font-bold ${done ? "text-ink" : "text-ink/35"}`}>{f.label}</span>
                </div>
                {i < FLOW.length - 1 && <div className={`mx-2 mb-5 h-0.5 flex-1 rounded ${!cancelled && i < flowIdx ? "bg-ink" : "bg-paper-2"}`} />}
              </div>
            );
          })}
        </div>
        {viewer.isCustomer && (
          <div className={`mt-4 rounded-xl p-3 text-sm font-semibold tone-${REQUEST_STATUS[r.status]?.tone ?? "slate"}`}>{REQUEST_STATUS[r.status]?.customer}</div>
        )}
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          {/* QUOTED: seçim */}
          {r.status === "QUOTED" && viewer.isCustomer && (candidates.length ? (
            <WhoDelivers requestId={r.id} candidates={candidates} prefer={one(sp.prefer)} preferFleet={one(sp.fleet)} fleetIdsBySlug={fleetIdsBySlug} />
          ) : (
            <EmptyState icon="🌙" title="Bu talep için şu an uygun sağlayıcı yok" description="Bölge, araç veya müsaitlik koşullarına uyan kimse bulunamadı. Randevu oluşturarak ileri bir saat seçebilirsiniz." actions={[{ label: "Randevu oluştur", href: "/talep/yeni?mode=SCHEDULED", primary: true }, { label: "Yeni talep", href: "/talep/yeni" }]} />
          ))}

          {/* OFFERED */}
          {r.status === "OFFERED" && current && (
            <div className="card-ink road-pattern-dark overflow-hidden p-6">
              <div className="flex items-center justify-between">
                <div className="eyebrow">{current.response === "FLEET_PENDING" ? "Filo onayı bekleniyor" : "Talebiniz iletildi"}</div>
                {current.offerExpiresAt && <div className="rounded-full bg-white px-3 py-1"><Countdown until={current.offerExpiresAt} total={current.response === "FLEET_PENDING" ? FLEET_TTL_S : OFFER_TTL_S} /></div>}
              </div>
              <div className="mt-5 flex items-center gap-4">
                <div className="relative">
                  <span className="absolute inset-0 animate-ping rounded-full bg-signal/30" />
                  <Avatar name={current.provider.displayName} hue={current.provider.hue} size={64} />
                </div>
                <div className="flex-1">
                  <div className="text-xl font-extrabold">{current.provider.displayName}</div>
                  <div className="text-sm text-white/60">{current.response === "FLEET_PENDING" ? `${current.provider.fleet?.name} dispatcher'ı onaylayacak veya başka üyeye yönlendirecek` : "Kabul etmesi bekleniyor"}</div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-black">{current.eta}</div>
                  <div className="text-xs text-white/50">{money(current.priceMinor)}</div>
                </div>
              </div>
              <div className="dash-road mt-6 h-[3px] rounded" />
              <p className="mt-3 text-xs text-white/50">Yanıt gelmezse veya reddedilirse sıradaki uygun adaya otomatik geçilir. Bu henüz kesin atama değildir.</p>
            </div>
          )}

          {/* Atama */}
          {a && ["CONFIRMED", "IN_PROGRESS", "COMPLETED"].includes(r.status) && (
            <div className="card overflow-hidden">
              <div className={`px-6 py-3 text-sm font-bold text-white ${r.status === "COMPLETED" ? "bg-ink" : r.status === "IN_PROGRESS" ? "bg-sky" : "bg-mint"}`}>
                {r.status === "CONFIRMED" ? "✅ Onaylandı — kesin atama" : r.status === "IN_PROGRESS" ? "🛵 Görev sürüyor" : "🏁 Görev tamamlandı"}
              </div>
              <div className="flex flex-col gap-5 p-6 sm:flex-row sm:items-center">
                <Avatar name={a.provider.displayName} hue={a.provider.hue} size={72} status={a.provider.status} />
                <div className="flex-1">
                  <Link href={`/kuryeler/${a.provider.slug}`} className="text-xl font-extrabold hover:text-signal">{a.provider.displayName}</Link>
                  <div className="text-sm text-ink/55">{a.provider.headline}</div>
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <Stars value={a.provider.ratingAvg} count={a.provider.ratingCount} />
                    <VehicleChip type={a.provider.vehicleType} label={a.provider.vehicleLabel} />
                    {a.provider.fleet && <span className="chip">🏢 {a.provider.fleet.name}</span>}
                  </div>
                </div>
                {viewer.isCustomer && ["CONFIRMED", "IN_PROGRESS"].includes(r.status) && (
                  <OpenChatButton requestId={r.id} label="💬 Mesaj gönder" className="btn-ink btn-sm" />
                )}
                {viewer.isCustomer && r.deliveryOtp && r.status !== "COMPLETED" && (
                  <div className="rounded-2xl bg-paper p-4 text-center">
                    <div className="text-[10px] font-bold uppercase tracking-wider text-ink/50">Teslim kodu</div>
                    <div className="mt-1 font-mono text-3xl font-black tracking-[0.3em] text-signal">{r.deliveryOtp}</div>
                    <div className="text-[10px] text-ink/45">Yalnızca teslimde paylaşın</div>
                  </div>
                )}
              </div>
              {viewer.isProvider && a.providerId === s.providerId && (
                <div className="flex flex-wrap items-center gap-3 border-t border-line bg-paper/50 px-6 py-4">
                  {a.state === "CONFIRMED" && (
                    <>
                      <ApiButton url={`/api/assignments/${a.id}`} body={{ action: "start" }} className="btn-primary">🚀 Görevi başlat</ApiButton>
                      <ApiButton url={`/api/assignments/${a.id}`} body={{ action: "cancel" }} className="btn-danger btn-sm" confirm="Görevi iptal etmek iptal oranınızı etkiler. Emin misiniz?">İptal</ApiButton>
                    </>
                  )}
                  {a.state === "IN_PROGRESS" && <OtpComplete assignmentId={a.id} />}
                  <OpenChatButton requestId={r.id} label="💬 Müşteriyle yazış" className="btn-ghost btn-sm" />
                  {(r.pickupDetail || r.dropoffDetail || r.note) && (
                    <div className="w-full text-xs text-ink/60">
                      {r.pickupDetail && <div>🟠 Alış: {r.pickupDetail}</div>}
                      {r.dropoffDetail && <div>🏁 Varış: {r.dropoffDetail}</div>}
                      {r.note && <div>📝 {r.note}</div>}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {r.status === "COMPLETED" && viewer.isCustomer && a && !review && <ReviewForm requestId={r.id} providerName={a.provider.displayName} />}
          {review && (
            <div className="card p-5">
              <div className="text-sm font-extrabold">Değerlendirmeniz</div>
              <div className="mt-1 text-sun">{"★".repeat(review.rating)}<span className="text-ink/15">{"★".repeat(5 - review.rating)}</span></div>
              {review.body && <p className="mt-1 text-sm text-ink/70">{review.body}</p>}
              {review.status === "HIDDEN" && <p className="mt-1 text-xs text-rose">Bu değerlendirme moderasyon tarafından gizlendi.</p>}
            </div>
          )}

          {r.status === "EXPIRED" && viewer.isCustomer && (
            <EmptyState icon="⏳" title="Şu anda uygun sağlayıcı bulunamadı" description="Tüm adaylar meşgul ya da yanıt vermedi. Randevu oluşturmak ister misiniz?" actions={[{ label: "Randevu oluştur", href: "/talep/yeni?mode=SCHEDULED", primary: true }, { label: "Tekrar dene", href: "/talep/yeni" }]} />
          )}

          {/* Adaylar (şeffaflık) */}
          {candidates.length > 0 && r.status !== "QUOTED" && (viewer.isCustomer || viewer.isAdmin) && (
            <div className="card p-6">
              <h3 className="font-extrabold">Eşleştirme sırası</h3>
              <p className="text-xs text-ink/50">Skor: bölge, mesafe, araç uyumu, yük, dakiklik, Bayes puan, iptal oranı, favori</p>
              <div className="mt-4 space-y-2">
                {candidates.map((c) => (
                  <div key={c.id} className="flex items-center gap-3 rounded-xl border border-line p-3">
                    <span className="w-5 text-center font-mono text-xs font-bold text-ink/40">#{c.rank}</span>
                    <Avatar name={c.provider.displayName} hue={c.provider.hue} size={32} />
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm font-bold">{c.provider.displayName}</div>
                      <div className="text-[11px] text-ink/50">{c.eta} · {money(c.priceMinor)} · skor {c.score.toFixed(1)}</div>
                    </div>
                    <Pill tone={c.response === "ACCEPTED" ? "green" : c.response === "OFFERED" || c.response === "FLEET_PENDING" ? "amber" : c.response ? "red" : "slate"}>
                      {({ ACCEPTED: "Kabul", OFFERED: "Teklifte", FLEET_PENDING: "Filo onayında", DECLINED: "Reddetti", TIMEOUT: "Zaman aşımı", SKIPPED: "Atlandı" } as Record<string, string>)[c.response ?? ""] ?? "Sırada"}
                    </Pill>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <aside className="space-y-4">
          <div className="card p-5">
            <div className="text-sm font-extrabold">Detaylar</div>
            <div className="mt-3 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-ink/55">Seçim</span><b>{STRATEGIES[r.strategy]}</b></div>
              {r.scheduledStart && <div className="flex justify-between"><span className="text-ink/55">{r.mode === "INSTANT_RENT" ? "Başlangıç" : "Randevu"}</span><b>{dateTime(r.scheduledStart)}</b></div>}
              {r.rentalHours && <div className="flex justify-between"><span className="text-ink/55">Süre</span><b>{r.rentalHours} saat</b></div>}
              <div className="flex justify-between"><span className="text-ink/55">{r.finalPriceMinor ? "Kesin tutar" : "Tahmini tutar"}</span><b>{money(r.finalPriceMinor ?? r.quotedPriceMinor)}</b></div>
            </div>
          </div>
          <div className="card p-5">
            <div className="text-sm font-extrabold">Olay günlüğü</div>
            <ol className="relative mt-4 space-y-4 border-l-2 border-paper-2 pl-4">
              {events.map((e) => (
                <li key={e.id} className="relative">
                  <span className="absolute -left-[23px] top-1 h-3 w-3 rounded-full border-2 border-white bg-signal" />
                  <div className="text-xs font-bold">{REQUEST_STATUS[e.toState]?.label ?? e.toState}</div>
                  {e.message && <div className="text-xs text-ink/60">{e.message}</div>}
                  <div className="text-[10px] text-ink/40">{dateTime(e.createdAt)} · {e.actorRole}</div>
                </li>
              ))}
            </ol>
          </div>
        </aside>
      </div>
    </div>
  );
}
