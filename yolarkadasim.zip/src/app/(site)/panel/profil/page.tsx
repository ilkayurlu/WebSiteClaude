import Link from "next/link";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { mediaPosts, providers } from "@/db/schema";
import { ProviderProfileForm } from "@/components/ProfileForm";
import { MediaStudio } from "@/components/media-client";
import { EmptyState } from "@/components/ui";
import { FAQ_PROVIDER } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Profil Vitrini — Sağlayıcı Paneli" };

export default async function ProviderProfilePage() {
  const s = await getSession();
  if (!s.providerId) {
    return (
      <div className="container-x py-20">
        <div className="mx-auto max-w-xl">
          <EmptyState icon="🪪" title="Profil vitrini" description="Bu sayfa hizmet sağlayıcı hesaplarına açıktır. Sağ üstten bir sağlayıcı hesabına geçin." actions={[{ label: "Sağlayıcı paneli", href: "/panel", primary: true }]} />
        </div>
      </div>
    );
  }
  const [p] = await db.select().from(providers).where(eq(providers.id, s.providerId)).limit(1);
  if (!p) return null;
  const media = await db.select().from(mediaPosts).where(and(eq(mediaPosts.ownerType, "PROVIDER"), eq(mediaPosts.ownerId, p.id))).orderBy(sql`${mediaPosts.createdAt} DESC`);

  return (
    <div className="container-x py-10">
      <Link href="/panel" className="text-sm font-semibold text-ink/50 hover:text-ink">← Panele dön</Link>
      <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="eyebrow">Vitrin</div>
          <h1 className="mt-1 text-4xl font-black tracking-tight">Profilinizi yönetin</h1>
          <p className="mt-2 max-w-2xl text-ink/60">
            Herkese açık profilinizde telefon, adres, kimlik veya konum bilgisi gösterilmez. Aşağıdaki alanlar müşterilerin gördüğü vitrini oluşturur.
          </p>
        </div>
        <Link href={`/kuryeler/${p.slug}`} className="btn-ghost">Herkese açık görünüm →</Link>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[1fr_360px]">
        <div className="space-y-6">
          <ProviderProfileForm provider={p} />
          <div className="card p-5">
            <h2 className="font-extrabold">Medya ve tanıtım</h2>
            <p className="mb-4 text-sm text-ink/55">Teslimat özeni, aracınız, bölge bilgilendirmeleri. Müşteri verisi içeren görseller reddedilir.</p>
            <MediaStudio items={media} />
          </div>
        </div>
        <aside className="space-y-4">
          <div className="card p-5">
            <h2 className="font-extrabold">Sık sorulanlar</h2>
            <div className="mt-3 space-y-3">
              {FAQ_PROVIDER.map((f) => (
                <details key={f.q} className="group rounded-xl bg-paper px-3 py-2">
                  <summary className="cursor-pointer text-sm font-bold">{f.q}</summary>
                  <p className="mt-1 text-sm text-ink/65">{f.a}</p>
                </details>
              ))}
            </div>
          </div>
          <div className="card-ink road-pattern-dark p-5">
            <h2 className="font-extrabold">Profil kuralları</h2>
            <ul className="mt-3 space-y-2 text-sm text-white/70">
              <li>✓ Doğrulanabilir bilgiler yazın; “garantili en hızlı” gibi iddialar kullanmayın.</li>
              <li>✓ Görsellerde plaka, müşteri adresi veya yüz görünmesin.</li>
              <li>✓ Hizmet bölgelerinizi güncel tutun; bölge dışı talepler skorunuzu düşürür.</li>
              <li>✓ Değerlendirmelere profesyonel yanıt verin; yanıtınız moderasyona tabidir.</li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
