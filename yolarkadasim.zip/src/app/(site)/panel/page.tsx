import Link from "next/link";
import { ApiButton, AutoRefresh, Countdown } from "@/components/client";
import { ProviderStatusToggle } from "@/components/dashboard/ProviderStatusToggle";
import { serverStatusToUi } from "@/lib/provider-status-ui";
import { OtpComplete } from "@/components/RequestClient";
import { OpenChatButton } from "@/components/chat/ChatSheet";
import { Avatar, EmptyState, Pill, ProviderStatusPill, Stat } from "@/components/ui";
import { OFFER_TTL_S, sweepExpired } from "@/lib/engine";
import { areaName } from "@/lib/geo";
import { FLEET_POLICY, MODES, SERVICES, dateTime, money } from "@/lib/labels";
import { getProviderPanel } from "@/lib/queries";
import { requirePageSession as getSession } from "@/lib/session";

export default async function ProviderPanel() {
  const s = await getSession();
  if (!s.providerId) {
    return <div className="container-x py-20"><div className="mx-auto max-w-xl"><EmptyState icon="🛵" title="Sağlayıcı paneli" description="Bu panel hizmet sağlayıcılara özeldir. Sağ üstten bir sağlayıcı hesabına geçin (ör. Ahmet Kaya)." /></div></div>;
  }
  await sweepExpired();
  const { provider: p, fleet, offers, pendingFleet, tasks, earnings } = await getProviderPanel(s.providerId);
  if (!p) return null;
  const activeTasks = tasks.filter((t) => t.a.state === "CONFIRMED" || t.a.state === "IN_PROGRESS");
  const done = tasks.filter((t) => t.a.state === "COMPLETED" || t.a.state === "CANCELLED");

  return (
    <div>
      <AutoRefresh ms={4000} />
      <section className="road-pattern-dark bg-ink text-white">
        <div className="container-x flex flex-col gap-6 py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <Avatar name={p.displayName} hue={p.hue} size={72} status={p.status} />
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-3xl font-black tracking-tight">Merhaba, {p.displayName.split(" ")[0]}</h1>
                <ProviderStatusPill status={p.status} />
              </div>
              <div className="mt-1 text-sm text-white/55">
                {p.headline} {fleet && <>· 🏢 {fleet.name} ({FLEET_POLICY[fleet.directPolicy]?.label})</>}
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start gap-3 md:items-end">
            <ProviderStatusToggle initialStatus={serverStatusToUi(p.status)} serverStatus={p.status} />
            <Link href={`/kuryeler/${p.slug}`} className="text-xs font-semibold text-white/60 hover:text-white">Herkese açık profilimi gör →</Link>
          </div>
        </div>
      </section>

      <div className="container-x py-8">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Stat label="Bekleyen teklif" value={offers.length} />
          <Stat label="Aktif görev" value={activeTasks.length} />
          <Stat label="Puan" value={p.ratingCount ? `★ ${p.ratingAvg.toFixed(1)}` : "Yeni"} sub={`${p.ratingCount} değerlendirme`} />
          <Stat label="Platform kazancı" value={money(earnings)} sub="tamamlanan görevler" />
        </div>
        {fleet && (
          <div className="card mt-4 flex flex-wrap items-center justify-between gap-3 p-4">
            <div className="text-sm">
              <b>🏢 {fleet.name} içi kanal</b>
              <span className="ml-2 text-ink/55">Vardiya ve operasyon konuşmaları görevden bağımsızdır.</span>
            </div>
            <OpenChatButton label="💬 Filo yöneticisine yaz" className="btn-ink btn-sm" />
          </div>
        )}

        <div className="mt-8 grid gap-8 lg:grid-cols-2">
          <section>
            <h2 className="mb-3 flex items-center gap-2 text-lg font-extrabold">
              Gelen teklifler {offers.length > 0 && <span className="pulse-dot h-2 w-2 rounded-full bg-signal text-signal" />}
            </h2>
            {offers.length === 0 && pendingFleet.length === 0 && (
              <EmptyState icon="📡" title={p.status === "AVAILABLE" ? "Teklif bekleniyor" : "Şu an teklif almıyorsunuz"} description={p.status === "AVAILABLE" ? "Müsaitsiniz; yeni teklifler burada geri sayımla görünecek." : "Teklif almak için durumunuzu “Müsait” yapın."} />
            )}
            <div className="space-y-3">
              {offers.map(({ c, r }) => (
                <div key={c.id} className="card fade-up overflow-hidden border-signal/40">
                  <div className="flex items-center justify-between bg-signal px-5 py-2 text-white">
                    <span className="text-sm font-extrabold">⚡ Yeni teklif · {r.code}</span>
                    {c.offerExpiresAt && <span className="rounded-full bg-white px-2 py-0.5"><Countdown until={c.offerExpiresAt} total={OFFER_TTL_S} /></span>}
                  </div>
                  <div className="p-5">
                    <div className="flex flex-wrap gap-2">
                      <Pill tone="slate">{MODES[r.mode]?.icon} {MODES[r.mode]?.label}</Pill>
                      <Pill tone="slate">{SERVICES[r.serviceType]?.icon} {SERVICES[r.serviceType]?.label}</Pill>
                      {r.strategy !== "AUTO" && <Pill tone="green">♥ Müşteri sizi seçti</Pill>}
                    </div>
                    <div className="mt-3 flex items-center gap-3 text-sm">
                      <div className="flex flex-col items-center">
                        <span className="h-2.5 w-2.5 rounded-full bg-signal" />
                        <span className="h-6 w-0.5 bg-line" />
                        <span className="h-2.5 w-2.5 rounded-full border-2 border-ink" />
                      </div>
                      <div className="space-y-2">
                        <div className="font-bold">{areaName(r.pickupArea)} <span className="font-normal text-ink/50">· size {Math.round(c.distanceM / 100) / 10} km</span></div>
                        <div className="font-bold">{r.dropoffArea ? areaName(r.dropoffArea) : `${r.rentalHours} saat kiralama`}</div>
                      </div>
                      <div className="ml-auto text-right">
                        <div className="text-xl font-black">{money(c.priceMinor)}</div>
                        {r.scheduledStart && <div className="text-xs text-ink/50">{dateTime(r.scheduledStart)}</div>}
                      </div>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <ApiButton url={`/api/offers/${c.id}`} body={{ action: "accept" }} className="btn-mint flex-1">✓ Kabul et</ApiButton>
                      <ApiButton url={`/api/offers/${c.id}`} body={{ action: "decline" }} className="btn-ghost">Reddet</ApiButton>
                    </div>
                  </div>
                </div>
              ))}
              {pendingFleet.map(({ c, r }) => (
                <div key={c.id} className="card p-4 text-sm">
                  <b>{r.code}</b> sizin için filo onayında bekliyor · {areaName(r.pickupArea)}
                </div>
              ))}
            </div>
          </section>

          <section>
            <h2 className="mb-3 text-lg font-extrabold">Aktif görevler</h2>
            {activeTasks.length === 0 && <EmptyState icon="🧳" title="Aktif görev yok" description="Kabul ettiğiniz görevler burada başlatılır ve teslim koduyla tamamlanır." />}
            <div className="space-y-3">
              {activeTasks.map(({ a, r }) => (
                <div key={a.id} className="card p-5">
                  <div className="flex items-center justify-between">
                    <Link href={`/talep/${r.id}`} className="font-mono font-black hover:text-signal">{r.code}</Link>
                    <Pill tone={a.state === "IN_PROGRESS" ? "blue" : "green"}>{a.state === "IN_PROGRESS" ? "Yolda" : "Onaylandı"}</Pill>
                  </div>
                  <div className="mt-2 text-sm text-ink/70">
                    {areaName(r.pickupArea)} {r.dropoffArea ? `→ ${areaName(r.dropoffArea)}` : `· ${r.rentalHours} saat`} · <b>{money(r.finalPriceMinor)}</b>
                    {r.scheduledStart && r.mode === "SCHEDULED" && <> · 📅 {dateTime(r.scheduledStart)}</>}
                  </div>
                  {(r.pickupDetail || r.note) && <div className="mt-2 rounded-lg bg-paper p-2 text-xs text-ink/60">{r.pickupDetail && <div>🟠 {r.pickupDetail}</div>}{r.dropoffDetail && <div>🏁 {r.dropoffDetail}</div>}{r.note && <div>📝 {r.note}</div>}</div>}
                  <div className="mt-4 flex flex-wrap items-center gap-2">
                    {a.state === "CONFIRMED" && (
                      <>
                        <ApiButton url={`/api/assignments/${a.id}`} body={{ action: "start" }} className="btn-primary btn-sm">🚀 Başlat</ApiButton>
                        <ApiButton url={`/api/assignments/${a.id}`} body={{ action: "cancel" }} className="btn-danger btn-sm" confirm="İptal oranınızı etkiler. Emin misiniz?">İptal</ApiButton>
                      </>
                    )}
                    {a.state === "IN_PROGRESS" && <OtpComplete assignmentId={a.id} />}
                    <OpenChatButton requestId={r.id} label="💬 Müşteriyle yazış" className="btn-ghost btn-sm" />
                  </div>
                </div>
              ))}
            </div>

            <h2 className="mb-3 mt-8 text-lg font-extrabold">Geçmiş</h2>
            <div className="card divide-y divide-line">
              {done.length === 0 && <div className="p-5 text-center text-sm text-ink/50">Henüz geçmiş görev yok.</div>}
              {done.slice(0, 10).map(({ a, r }) => (
                <div key={a.id} className="flex items-center justify-between px-4 py-3 text-sm">
                  <span><span className="font-mono font-bold">{r.code}</span> <span className="text-ink/50">· {areaName(r.pickupArea)}</span></span>
                  <span className="flex items-center gap-2">
                    <b>{money(r.finalPriceMinor)}</b>
                    <Pill tone={a.state === "COMPLETED" ? "green" : "red"}>{a.state === "COMPLETED" ? "Tamam" : "İptal"}</Pill>
                  </span>
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
