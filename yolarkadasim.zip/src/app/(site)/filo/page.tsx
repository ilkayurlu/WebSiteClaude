import Link from "next/link";
import { ApiButton, AutoRefresh, Countdown } from "@/components/client";
import { PolicyForm, ReassignControl } from "@/components/FleetClient";
import { OpenChatButton } from "@/components/chat/ChatSheet";
import { MediaStudio } from "@/components/media-client";
import { Avatar, EmptyState, Pill, ProviderStatusPill, Stat } from "@/components/ui";
import { FLEET_TTL_S, sweepExpired } from "@/lib/engine";
import { areaName } from "@/lib/geo";
import { MODES, SERVICES, VEHICLES, dateTime, money } from "@/lib/labels";
import { getFleetInbox } from "@/lib/queries";
import { db } from "@/db";
import { mediaPosts } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { requirePageSession as getSession } from "@/lib/session";

export default async function FleetPanel() {
  const s = await getSession();
  if (!s.fleetId) {
    return <div className="container-x py-20"><div className="mx-auto max-w-xl"><EmptyState icon="🏢" title="Filo paneli" description="Bu panel filo yöneticilerine özeldir. Sağ üstten bir filo sahibi hesabına geçin (ör. Murat Hızlı)." /></div></div>;
  }
  await sweepExpired();
  const { fleet, members, pending, active } = await getFleetInbox(s.fleetId);
  if (!fleet) return null;
  const onTask = active.filter((x) => x.a.state === "CONFIRMED" || x.a.state === "IN_PROGRESS");
  const media = await db.select().from(mediaPosts).where(and(eq(mediaPosts.ownerType, "FLEET"), eq(mediaPosts.ownerId, fleet.id))).orderBy(sql`${mediaPosts.createdAt} DESC`);

  return (
    <div>
      <AutoRefresh ms={4000} />
      <section className="road-pattern-dark text-white" style={{ background: `linear-gradient(120deg, ${fleet.accent} -30%, #0e1324 55%)` }}>
        <div className="container-x py-10">
          <div className="eyebrow !text-white/60">Filo paneli · Dispatcher</div>
          <h1 className="mt-1 text-4xl font-black tracking-tight">{fleet.name}</h1>
          <Link href={`/filolar/${fleet.slug}`} className="mt-2 inline-block text-sm text-white/60 hover:text-white">Herkese açık filo profili →</Link>
        </div>
      </section>
      <div className="container-x py-8">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Stat label="Onay kuyruğu" value={pending.length} />
          <Stat label="Aktif görev" value={onTask.length} />
          <Stat label="Üye" value={members.length} />
          <Stat label="Müsait üye" value={members.filter((m) => m.status === "AVAILABLE").length} />
        </div>

        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_360px]">
          <div className="space-y-8">
            <section>
              <h2 className="mb-3 flex items-center gap-2 text-lg font-extrabold">Onay kuyruğu {pending.length > 0 && <span className="pulse-dot h-2 w-2 rounded-full bg-signal text-signal" />}</h2>
              {pending.length === 0 && <EmptyState icon="📥" title="Kuyruk boş" description={fleet.directPolicy === "DIRECT_ALLOWED" ? "Politikanız “Doğrudan kabul”; üyeler talepleri kendisi kabul eder, size bilgilendirme gelir." : "Filo onayı gerektiren talepler burada geri sayımla görünür."} />}
              <div className="space-y-3">
                {pending.map(({ c, r, p }) => {
                  const others = members.filter((m) => m.id !== p.id && m.status === "AVAILABLE" && m.serviceAreas.includes(r.pickupArea)).map((m) => ({ id: m.id, name: m.displayName, status: m.status }));
                  return (
                    <div key={c.id} className="card fade-up overflow-hidden">
                      <div className="flex items-center justify-between bg-ink px-5 py-2 text-white">
                        <span className="text-sm font-extrabold">{r.code} · {MODES[r.mode]?.label}</span>
                        {c.offerExpiresAt && <span className="rounded-full bg-white px-2 py-0.5"><Countdown until={c.offerExpiresAt} total={FLEET_TTL_S} /></span>}
                      </div>
                      <div className="p-5">
                        <div className="flex flex-wrap items-center gap-2 text-sm">
                          <Pill tone="slate">{SERVICES[r.serviceType]?.icon} {SERVICES[r.serviceType]?.label}</Pill>
                          <span className="font-bold">{areaName(r.pickupArea)}{r.dropoffArea ? ` → ${areaName(r.dropoffArea)}` : ` · ${r.rentalHours} saat`}</span>
                          <span className="ml-auto text-lg font-black">{money(c.priceMinor)}</span>
                        </div>
                        {r.scheduledStart && r.mode === "SCHEDULED" && <div className="mt-1 text-xs text-ink/55">📅 {dateTime(r.scheduledStart)}</div>}
                        <div className="mt-3 flex items-center gap-3 rounded-xl bg-paper p-3">
                          <Avatar name={p.displayName} hue={p.hue} size={36} status={p.status} />
                          <div className="flex-1 text-sm">
                            <div className="font-bold">{p.displayName}</div>
                            <div className="text-xs text-ink/55">{r.strategy === "AUTO" ? "Sistem önerisi" : r.strategy === "MANUAL_FLEET" ? "Müşteri filonuzu seçti" : "Müşteri bu üyeyi seçti"} · {Math.round(c.distanceM / 100) / 10} km</div>
                          </div>
                        </div>
                        <div className="mt-4 flex flex-wrap items-start gap-2">
                          <ApiButton url={`/api/fleet/offers/${c.id}`} body={{ action: "approve" }} className="btn-mint btn-sm">✓ {p.displayName.split(" ")[0]} ile onayla</ApiButton>
                          <ReassignControl candidateId={c.id} members={others} />
                          <ApiButton url={`/api/fleet/offers/${c.id}`} body={{ action: "decline" }} className="btn-ghost btn-sm">Reddet</ApiButton>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </section>

            <section>
              <h2 className="mb-3 text-lg font-extrabold">Filo görevleri</h2>
              <div className="card divide-y divide-line">
                {active.length === 0 && <div className="p-6 text-center text-sm text-ink/50">Henüz görev yok.</div>}
                {active.map(({ a, r, p }) => (
                  <Link key={a.id} href={`/talep/${r.id}`} className="flex items-center gap-3 px-4 py-3 text-sm hover:bg-paper">
                    <Avatar name={p.displayName} hue={p.hue} size={30} />
                    <span className="font-mono font-bold">{r.code}</span>
                    <span className="hidden text-ink/55 sm:inline">{p.displayName} · {areaName(r.pickupArea)}</span>
                    <span className="ml-auto font-bold">{money(r.finalPriceMinor)}</span>
                    <Pill tone={a.state === "COMPLETED" ? "green" : a.state === "IN_PROGRESS" ? "blue" : a.state === "CANCELLED" ? "red" : "amber"}>{({ CONFIRMED: "Onaylı", IN_PROGRESS: "Yolda", COMPLETED: "Tamam", CANCELLED: "İptal" } as Record<string, string>)[a.state]}</Pill>
                  </Link>
                ))}
              </div>
            </section>
          </div>

          <aside className="space-y-6">
            <div className="card p-5">
              <h3 className="mb-3 font-extrabold">Doğrudan talep politikası</h3>
              <PolicyForm policy={fleet.directPolicy} showMembers={fleet.showMembersPublicly} />
            </div>
            <div className="card p-5">
              <h3 className="mb-2 font-extrabold">Filo vitrini</h3>
              <p className="mb-3 text-xs text-white/0 text-ink/55">Araç, tesis ve operasyon görselleriniz. Yüklenen içerik moderasyondan geçince filo profilinizde yayınlanır.</p>
              <MediaStudio items={media} />
            </div>
            <div className="card p-5">
              <h3 className="mb-3 font-extrabold">Ekip durumu</h3>
              <div className="space-y-2.5">
                {members.length === 0 && <div className="text-sm text-ink/50">Henüz üye yok.</div>}
                {members.map((m) => (
                  <div key={m.id} className="flex items-center gap-3 rounded-xl p-1.5 transition hover:bg-paper">
                    <Link href={`/kuryeler/${m.slug}`} className="flex min-w-0 flex-1 items-center gap-3">
                      <Avatar name={m.displayName} hue={m.hue} size={36} status={m.status} />
                      <div className="min-w-0 flex-1">
                        <div className="truncate text-sm font-bold">{m.displayName}</div>
                        <div className="text-xs text-ink/50">{VEHICLES[m.vehicleType]?.icon} {VEHICLES[m.vehicleType]?.label}</div>
                      </div>
                    </Link>
                    <ProviderStatusPill status={m.status} />
                    <OpenChatButton providerUserId={m.userId} label="💬" className="flex h-9 w-9 items-center justify-center rounded-full border border-line text-sm transition hover:border-signal hover:bg-signal/10" />
                  </div>
                ))}
              </div>
              <p className="mt-3 text-[11px] text-ink/45">Canlı konum yalnızca görevdeki üyeler için ve yalnızca görev taraflarına açılır.</p>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
