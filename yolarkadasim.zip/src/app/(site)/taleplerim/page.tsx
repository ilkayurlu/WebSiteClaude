import Link from "next/link";
import { ProviderCard } from "@/components/ProviderCard";
import { EmptyState, RequestStatusPill, SectionHead } from "@/components/ui";
import { areaName } from "@/lib/geo";
import { MODES, dateTime, money } from "@/lib/labels";
import { getFavoriteProviders, listCustomerRequests } from "@/lib/queries";
import { requirePageSession as getSession } from "@/lib/session";

export default async function MyRequests() {
  const s = await getSession();
  if (s.user.role !== "CUSTOMER") {
    return (
      <div className="container-x py-20"><div className="mx-auto max-w-xl"><EmptyState icon="👤" title="Bu sayfa müşterilere özel" description="Sağ üstten bir müşteri hesabına geçin." /></div></div>
    );
  }
  const [reqs, favs] = await Promise.all([listCustomerRequests(s.user.id), getFavoriteProviders(s.user.id)]);
  const active = reqs.filter((r) => ["QUOTED", "MATCHING", "OFFERED", "CONFIRMED", "IN_PROGRESS"].includes(r.status));
  const past = reqs.filter((r) => !active.includes(r));

  const Row = ({ r }: { r: (typeof reqs)[number] }) => (
    <Link href={`/talep/${r.id}`} className="card card-hover flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-paper text-xl">{MODES[r.mode]?.icon}</div>
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-mono text-sm font-black">{r.code}</span>
          <RequestStatusPill status={r.status} />
        </div>
        <div className="mt-0.5 truncate text-sm text-ink/60">
          {areaName(r.pickupArea)}{r.dropoffArea ? ` → ${areaName(r.dropoffArea)}` : ` · ${r.rentalHours ?? 1} saat`} {r.providerName ? `· ${r.providerName}` : ""}
        </div>
      </div>
      <div className="text-right text-sm">
        <div className="font-black">{money(r.finalPriceMinor ?? r.quotedPriceMinor)}</div>
        <div className="text-xs text-ink/45">{dateTime(r.scheduledStart ?? r.createdAt)}</div>
      </div>
    </Link>
  );

  return (
    <div className="container-x py-10">
      <div className="flex items-end justify-between">
        <div>
          <div className="eyebrow">Hesabım</div>
          <h1 className="mt-1 text-4xl font-black tracking-tight">Taleplerim</h1>
        </div>
        <Link href="/talep/yeni" className="btn-primary">⚡ Yeni talep</Link>
      </div>

      <div className="mt-8 grid gap-10 lg:grid-cols-[1fr_380px]">
        <div className="space-y-8">
          <section>
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-ink/50">Aktif ({active.length})</h2>
            {active.length ? <div className="space-y-3">{active.map((r) => <Row key={r.id} r={r} />)}</div> : <EmptyState icon="🛣️" title="Aktif talebiniz yok" description="Hemen çağırın, randevu oluşturun veya saatlik kiralayın." actions={[{ label: "Yeni talep", href: "/talep/yeni", primary: true }]} />}
          </section>
          <section>
            <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-ink/50">Geçmiş ({past.length})</h2>
            {past.length ? <div className="space-y-3">{past.map((r) => <Row key={r.id} r={r} />)}</div> : <div className="rounded-2xl border border-dashed border-line p-6 text-center text-sm text-ink/50">Henüz geçmiş talep yok.</div>}
          </section>
        </div>
        <section>
          <SectionHead title="♥ Favorilerim" />
          {favs.length ? (
            <div className="space-y-5">{favs.map((p) => <ProviderCard key={p.id} p={p} canFavorite isFavorite />)}</div>
          ) : (
            <EmptyState icon="♡" title="Henüz favori yok" description="Güvendiğin yol arkadaşlarını profillerinden favorine ekle; talep oluştururken öncelik verilsin." actions={[{ label: "Keşfet", href: "/kesfet" }]} />
          )}
        </section>
      </div>
    </div>
  );
}
