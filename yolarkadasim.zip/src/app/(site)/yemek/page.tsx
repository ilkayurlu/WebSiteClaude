import Link from "next/link";
import Image from "next/image";
import { EmptyState, Stars } from "@/components/ui";
import { areaName, getCity, resolveArea } from "@/lib/geo";
import { AreaFilter } from "@/components/order/AreaFilter";
import { CUISINES, cuisineIcon, cuisineLabel, money } from "@/lib/labels";
import { listRestaurants } from "@/lib/food";
import { getPublicSession as getSession } from "@/lib/session";
import { ensureSeed } from "@/lib/seed";

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

function FilterToggle({ href, label, on }: { href: string; label: string; on: boolean }) {
  return <Link href={href} className={`chip !cursor-pointer transition hover:border-signal ${on ? "!border-signal !bg-signal !text-white" : ""}`}>{label}</Link>;
}

export const metadata = { title: "Yemek — YolArkadaşı", description: "Bölgenizdeki restoranları keşfedin, menüye göz atın ve sipariş verin." };

export default async function Yemek({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  await ensureSeed();
  const s = await getSession();
  const rawArea = one(sp.area);
  const area = rawArea ?? (one(sp.city) ? "" : "istanbul-kadikoy");
  const cityCode = one(sp.city) ?? resolveArea(area)?.cityCode ?? "34";
  const scopeLabel = area ? areaName(area) : (getCity(cityCode)?.name ?? "Türkiye");
  const f = {
    area: area || undefined,
    cityCode,
    cuisine: one(sp.cuisine),
    openNow: one(sp.open) === "1",
    vegan: one(sp.vegan) === "1",
    halal: one(sp.halal) === "1",
    campaign: one(sp.campaign) === "1",
    maxPrep: one(sp.maxPrep) ? Number(one(sp.maxPrep)) : undefined,
    minRating: one(sp.minRating) ? Number(one(sp.minRating)) : undefined,
    sort: (one(sp.sort) as "rating" | "fast" | "cheap" | undefined) ?? undefined,
    q: one(sp.q),
  };
  const list = await listRestaurants(f);

  const link = (patch: Record<string, string | undefined>) => {
    const p = new URLSearchParams();
    const merged = { area, cuisine: f.cuisine, open: f.openNow ? "1" : undefined, vegan: f.vegan ? "1" : undefined, halal: f.halal ? "1" : undefined, campaign: f.campaign ? "1" : undefined, maxPrep: f.maxPrep ? String(f.maxPrep) : undefined, minRating: f.minRating ? String(f.minRating) : undefined, sort: f.sort, q: f.q, ...patch };
    for (const [k, v] of Object.entries(merged)) if (v) p.set(k, v);
    return `/yemek?${p.toString()}`;
  };

  return (
    <div>
      <section className="border-b border-line bg-white">
        <div className="container-x py-10">
          <div className="eyebrow">Yemek & market</div>
          <h1 className="mt-1 text-4xl font-black tracking-tight">{scopeLabel} çevresinde sipariş</h1>
          <p className="mt-2 max-w-2xl text-ink/60">Menü, fiyat ve teslimat bilgileri işletmelerin kendi verisidir. Uydurma puan, sahte indirim veya tahmini olmayan süre göstermiyoruz.</p>

          <form className="mt-6 grid gap-3 lg:grid-cols-[1.4fr_1fr_1fr_auto]">
            <input name="q" defaultValue={f.q ?? ""} className="input" placeholder="Restoran veya mutfak ara…" aria-label="Ara" />
            <AreaFilter cityCode={cityCode} areaSlug={area} />
            <select name="cuisine" defaultValue={f.cuisine ?? ""} className="input" aria-label="Mutfak">
              <option value="">Tüm mutfaklar</option>
              {CUISINES.map((c) => <option key={c.key} value={c.key}>{c.icon} {c.label}</option>)}
            </select>
            <button className="btn-ink">Ara</button>
            <select name="sort" defaultValue={f.sort ?? ""} className="input" aria-label="Sıralama">
              <option value="">Önerilen sıralama</option>
              <option value="rating">Puana göre</option>
              <option value="fast">En hızlı teslimat</option>
              <option value="cheap">En düşük teslimat ücreti</option>
            </select>
            <select name="maxPrep" defaultValue={f.maxPrep ?? ""} className="input" aria-label="Hazırlık süresi">
              <option value="">Tüm hazırlık süreleri</option>
              <option value="15">15 dk ve altı</option>
              <option value="25">25 dk ve altı</option>
            </select>
            <select name="minRating" defaultValue={f.minRating ?? ""} className="input" aria-label="Puan">
              <option value="">Tüm puanlar</option>
              <option value="4">4.0 ve üzeri</option>
              <option value="4.5">4.5 ve üzeri</option>
            </select>
            <div className="hidden lg:block" />
          </form>

          <div className="mt-3 flex flex-wrap gap-2">
            <FilterToggle href={link({ open: f.openNow ? undefined : "1" })} label="🟢 Şu an açık" on={f.openNow} />
            <FilterToggle href={link({ campaign: f.campaign ? undefined : "1" })} label="🎁 Kampanyalı" on={f.campaign} />
            <FilterToggle href={link({ vegan: f.vegan ? undefined : "1" })} label="🌱 Vegan seçenek" on={f.vegan} />
            <FilterToggle href={link({ halal: f.halal ? undefined : "1" })} label="✓ Helal (işletme beyanı)" on={f.halal} />
          </div>
        </div>
      </section>

      <div className="container-x py-10">
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-ink/60"><b className="text-ink">{list.length}</b> işletme listeleniyor · {scopeLabel}</p>
          {list.length > 0 && <Link href={link({ open: undefined, campaign: undefined, vegan: undefined, halal: undefined, cuisine: undefined, maxPrep: undefined, minRating: undefined, q: undefined })} className="text-sm font-bold text-signal hover:underline">Filtreleri temizle</Link>}
        </div>

        {list.length === 0 ? (
          <EmptyState
            icon="🍽️"
            title="Henüz bu bölgede listelenen işletme yok."
            description="Adresinizi değiştirebilir, filtreleri gevşetebilir veya işletmenizi platforma ekleyebilirsiniz."
            actions={[
              { label: "Tüm bölgeleri gör", href: "/yemek", primary: true },
              { label: "İşletme başvurusu", href: "/basvuru?kind=RESTAURANT" },
              { label: "Kurye keşfet", href: "/kesfet" },
            ]}
          />
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {list.map((r) => (
              <Link key={r.id} href={`/restoranlar/${r.slug}`} className="card card-hover group overflow-hidden">
                <div className="relative aspect-[16/10] bg-paper">
                  {r.coverUrl ? (
                    <Image src={r.coverUrl} alt={r.name} fill className="object-cover transition duration-500 group-hover:scale-105" sizes="(max-width:640px) 100vw, 33vw" />
                  ) : (
                    <span className="flex h-full items-center justify-center text-4xl">{cuisineIcon(r.cuisines[0])}</span>
                  )}
                  <div className="absolute left-3 top-3 flex gap-1.5">
                    {r.openNow ? <span className="rounded-full bg-mint px-2.5 py-1 text-[11px] font-bold text-white">Açık</span> : <span className="rounded-full bg-ink/80 px-2.5 py-1 text-[11px] font-bold text-white">Kapalı · {r.opensAt}</span>}
                    {r.campaignTitle && <span className="rounded-full bg-sun px-2.5 py-1 text-[11px] font-black text-ink">🎁 Kampanya</span>}
                  </div>
                  {r.isVerified && <span className="absolute right-3 top-3 flex h-6 w-6 items-center justify-center rounded-full bg-sky text-[11px] text-white">✓</span>}
                </div>
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <h2 className="font-extrabold tracking-tight group-hover:text-signal">{r.name}</h2>
                    <Stars value={r.ratingAvg} count={r.ratingCount} />
                  </div>
                  <p className="mt-0.5 line-clamp-1 text-sm text-ink/55">{r.cuisines.map(cuisineLabel).join(" · ")}</p>
                  <div className="mt-3 flex flex-wrap gap-1.5 text-xs">
                    <span className="chip">⏱ ~{r.etaMinutes} dk</span>
                    <span className="chip">🛵 {money(r.deliveryFeeMinor)}</span>
                    <span className="chip">🧺 min {money(r.minBasketMinor)}</span>
                    {r.itemCount === 0 && <span className="chip !border-sun/40 !bg-sun/10 !text-[#7a5500]">Menü yakında</span>}
                  </div>
                  {r.tagline && <p className="mt-2 line-clamp-1 text-xs text-ink/50">{r.tagline}</p>}
                </div>
              </Link>
            ))}
          </div>
        )}

        <section className="mt-14">
          <h2 className="text-xl font-black tracking-tight">Mutfak türleri</h2>
          <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {CUISINES.map((c) => (
              <Link key={c.key} href={link({ cuisine: c.key })} className={`card p-4 text-sm font-bold transition hover:-translate-y-0.5 hover:border-signal ${f.cuisine === c.key ? "border-signal bg-signal/[0.04]" : ""}`}>
                <span className="mr-1.5">{c.icon}</span>{c.label}
              </Link>
            ))}
          </div>
        </section>

        {s.user.role !== "CUSTOMER" && (
          <div className="card mt-10 flex flex-col items-start gap-3 p-6 sm:flex-row sm:items-center">
            <div className="flex-1">
              <h3 className="font-extrabold">İşletmenizi platforma ekleyin</h3>
              <p className="text-sm text-ink/60">Menü, stok ve kampanya yönetimi; kurye ataması ve sipariş takibi dahil.</p>
            </div>
            <Link href="/basvuru?kind=RESTAURANT" className="btn-primary">Başvuru yap</Link>
          </div>
        )}
      </div>
    </div>
  );
}
