import type { ReactNode } from "react";
import { Header, Footer } from "@/components/Header";
import { ChatDockGate } from "@/components/chat/ChatDockGate";

export default function SiteLayout({ children }: { children: ReactNode }) {
  return <><Header /><main>{children}</main><Footer /><ChatDockGate /></>;
}
