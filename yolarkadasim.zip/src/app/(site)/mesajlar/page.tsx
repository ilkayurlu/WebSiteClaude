import Link from "next/link";
import { ChatWorkspace } from "@/components/chat/ChatSheet";
import { EmptyState } from "@/components/ui";
import { requirePageSession as getSession } from "@/lib/session";

export const metadata = { title: "Mesajlar — YolArkadaşı", description: "Görev ve filo içi güvenli, maskeli mesajlaşma." };

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

export default async function MessagesPage({ searchParams }: { searchParams: SP }) {
  const s = await getSession();
  const sp = await searchParams;
  if (["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) {
    return (
      <div className="container-x py-20">
        <div className="mx-auto max-w-xl">
          <EmptyState
            icon="🛡️"
            title="Mesaj içerikleri operasyona kapalıdır"
            description="Gizlilik politikası gereği admin mesaj içeriğini varsayılan olarak göremez. İnceleme talepleri moderasyon vakası olarak, gerekçe ve denetim kaydıyla yürütülür."
            actions={[{ label: "Moderasyon merkezi", href: s.user.role === "SUPER_ADMIN" ? "/admin" : "/dashboard/admin", primary: true }, { label: "Denetim izi", href: "/admin/audit" }]}
          />
        </div>
      </div>
    );
  }
  return (
    <div className="container-x py-8">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
        <div>
          <div className="eyebrow">Güvenli iletişim</div>
          <h1 className="mt-1 text-4xl font-black tracking-tight">Mesajlar</h1>
          <p className="mt-1.5 max-w-2xl text-sm text-ink/60">
            Görev sohbetleri atama onaylanınca açılır, görev bitince arşivlenir. Telefon, IBAN ve e-posta otomatik maskelenir; konum yalnızca bölge düzeyinde paylaşılır.
          </p>
        </div>
        <div className="flex gap-2">
          {s.user.role === "CUSTOMER" && <Link href="/taleplerim" className="btn-ghost btn-sm">Taleplerim</Link>}
          {s.user.role === "PROVIDER" && <Link href="/panel" className="btn-ghost btn-sm">Panelim</Link>}
          {s.user.role === "FLEET_OWNER" && <Link href="/filo" className="btn-ghost btn-sm">Filo paneli</Link>}
          <Link href="/destek" className="btn-ghost btn-sm">💬 Destek</Link>
        </div>
      </div>
      <ChatWorkspace meId={s.user.id} meRole={s.user.role} initialId={one(sp.c) ?? null} variant="page" />
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {[
          ["🔗", "Bağlama duyarlı", "Müşteri–sağlayıcı sohbeti yalnızca aktif görev üzerinden açılır; rastgele mesajlaşma yoktur."],
          ["🛡", "Otomatik maskeleme", "TR cep numaraları, IBAN ve e-posta sunucuda algılanır ve gizlenir."],
          ["✓✓", "Okundu bilgisi", "İletildi ve okundu durumları canlı olarak güncellenir; SSE kesilirse polling devreye girer."],
        ].map(([i, t, d]) => (
          <div key={t} className="card flex items-start gap-3 p-4">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-signal/10 text-sm text-signal" aria-hidden="true">{i}</span>
            <div>
              <div className="text-sm font-extrabold">{t}</div>
              <div className="mt-0.5 text-xs leading-relaxed text-ink/55">{d}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
