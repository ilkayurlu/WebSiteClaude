import Link from "next/link";
import { ProviderCard } from "@/components/ProviderCard";
import { Avatar, EmptyState } from "@/components/ui";
import { areaName, getCity, resolveArea } from "@/lib/geo";
import { AreaFilter } from "@/components/order/AreaFilter";
import { MODES, SERVICES, VEHICLES } from "@/lib/labels";
import { getFavoriteIds, listProviders } from "@/lib/queries";
import { getPublicSession as getSession } from "@/lib/session";

type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) || undefined;

export default async function Kesfet({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const rawArea = one(sp.area);
  const area = rawArea ?? (one(sp.city) ? "" : "istanbul-kadikoy");
  const cityCode = one(sp.city) ?? resolveArea(area)?.cityCode ?? "34";
  const scopeLabel = area ? areaName(area) : (getCity(cityCode)?.name ?? "Türkiye");
  const f = { area: area || undefined, cityCode, vehicle: one(sp.vehicle), service: one(sp.service), mode: one(sp.mode), onlyAvailable: one(sp.available) === "1" };
  const s = await getSession();
  const list = await listProviders(f);
  const favs = s.user.role === "CUSTOMER" ? await getFavoriteIds(s.user.id) : { providers: [] as string[], fleets: [] as string[], restaurants: [] as string[] };
  const available = list.filter((p) => p.status === "AVAILABLE" && p.etaS != null);

  return (
    <div>
      <section className="border-b border-line bg-white">
        <div className="container-x py-10">
          <div className="eyebrow">Hemen Ara</div>
          <h1 className="mt-1 text-4xl font-black tracking-tight">{scopeLabel} çevresindeki yol arkadaşları</h1>
          <p className="mt-2 text-ink/60">Konumlar asla tam gösterilmez; yalnızca tahmini varış bandı.</p>

          <form className="mt-6 grid gap-3 rounded-2xl bg-paper p-3 sm:grid-cols-2 lg:grid-cols-[1.3fr_1fr_1fr_1fr_auto_auto]">
            <AreaFilter cityCode={cityCode} areaSlug={area} />
            <select name="mode" defaultValue={f.mode ?? ""} className="input">
              <option value="">Tüm modlar</option>
              {Object.entries(MODES).map(([k, v]) => (
                <option key={k} value={k}>{v.icon} {v.label}</option>
              ))}
            </select>
            <select name="service" defaultValue={f.service ?? ""} className="input">
              <option value="">Tüm hizmetler</option>
              {Object.entries(SERVICES).map(([k, v]) => (
                <option key={k} value={k}>{v.icon} {v.label}</option>
              ))}
            </select>
            <select name="vehicle" defaultValue={f.vehicle ?? ""} className="input">
              <option value="">Tüm araçlar</option>
              {Object.entries(VEHICLES).map(([k, v]) => (
                <option key={k} value={k}>{v.icon} {v.label}</option>
              ))}
            </select>
            <label className="flex items-center gap-2 rounded-xl bg-white px-3 text-sm font-semibold ring-1 ring-line">
              <input type="checkbox" name="available" value="1" defaultChecked={f.onlyAvailable} className="accent-[#ff5b23]" /> Yalnız müsait
            </label>
            <button className="btn-ink">Ara</button>
          </form>
        </div>
      </section>

      <div className="container-x grid gap-8 py-10 lg:grid-cols-[340px_1fr]">
        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="card-ink overflow-hidden p-5">
            <div className="flex items-center justify-between">
              <div className="text-sm font-extrabold">Yakın çevre radarı</div>
              <span className="chip-dark">{available.length} müsait</span>
            </div>
            <div className="radar relative mx-auto mt-4 aspect-square w-full max-w-[280px] rounded-full bg-white/[0.03] ring-1 ring-white/10">
              <div className="radar-sweep absolute inset-0 rounded-full" />
              <div className="absolute left-1/2 top-1/2 flex h-8 w-8 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full bg-signal text-sm shadow-[0_0_0_6px_rgba(255,91,35,0.25)]">📍</div>
              {available.slice(0, 8).map((p, i) => {
                const r = Math.min(46, 12 + ((p.etaS ?? 600) / 2400) * 34);
                const ang = ((i * 137.5 + p.hue) % 360) * (Math.PI / 180);
                return (
                  <Link key={p.id} href={`/kuryeler/${p.slug}`} title={`${p.displayName} · ${p.eta}`} className="absolute -translate-x-1/2 -translate-y-1/2 transition hover:scale-110" style={{ left: `${50 + r * Math.cos(ang)}%`, top: `${50 + r * Math.sin(ang)}%` }}>
                    <Avatar name={p.displayName} hue={p.hue} size={34} />
                  </Link>
                );
              })}
            </div>
            <div className="mt-4 flex justify-between text-[10px] font-bold uppercase tracking-wider text-white/40">
              <span>iç halka ~10 dk</span>
              <span>dış halka ~40 dk</span>
            </div>
          </div>
          {available[0] && (
            <div className="card p-4">
              <div className="text-[11px] font-bold uppercase tracking-wider text-mint">En yakın uygun sağlayıcı</div>
              <div className="mt-2 flex items-center gap-3">
                <Avatar name={available[0].displayName} hue={available[0].hue} size={44} status="AVAILABLE" />
                <div className="flex-1">
                  <div className="font-extrabold">{available[0].displayName}</div>
                  <div className="text-xs text-ink/55">{available[0].eta} · {available[0].distance}</div>
                </div>
              </div>
              <Link href={`/talep/yeni?mode=INSTANT_CALL&pickup=${area}`} className="btn-primary mt-3 w-full">⚡ Sistem seçsin, hemen çağır</Link>
            </div>
          )}
        </aside>

        <section>
          <div className="mb-4 flex items-center justify-between">
            <div className="text-sm text-ink/60">
              <b className="text-ink">{list.length}</b> sağlayıcı bulundu
            </div>
          </div>
          {list.length ? (
            <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-3">
              {list.map((p) => (
                <ProviderCard key={p.id} p={p} canFavorite={s.user.role === "CUSTOMER"} isFavorite={favs.providers.includes(p.id)} />
              ))}
            </div>
          ) : (
            <EmptyState
              icon="🧭"
              title="Bu filtrelerle sağlayıcı bulunamadı"
              description="Bölgeyi değiştirmeyi veya filtreleri gevşetmeyi deneyin. İleri tarihe randevu da oluşturabilirsiniz."
              actions={[
                { label: "Filtreleri temizle", href: "/kesfet" },
                { label: "Randevu oluştur", href: "/talep/yeni?mode=SCHEDULED", primary: true },
              ]}
            />
          )}
        </section>
      </div>
    </div>
  );
}
