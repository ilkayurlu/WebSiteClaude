export default function Loading() {
  return (
    <div className="container-x py-12" aria-busy="true">
      <div className="mb-3 h-10 w-64 animate-pulse rounded-xl bg-paper-2" />
      <div className="mb-6 h-4 w-96 max-w-full animate-pulse rounded bg-paper-2" />
      <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => <div key={i} className="card h-32 animate-pulse bg-white/70" />)}
        </div>
        <div className="space-y-4">
          {Array.from({ length: 2 }).map((_, i) => <div key={i} className="card h-40 animate-pulse bg-white/70" />)}
        </div>
      </div>
      <span className="sr-only">Yükleniyor…</span>
    </div>
  );
}
