import Link from "next/link";
import { ApiButton, AutoRefresh } from "@/components/client";
import { EmptyState, Pill } from "@/components/ui";
import { listMerchantOrders } from "@/lib/food";
import { sweepExpired } from "@/lib/engine";
import { areaName } from "@/lib/geo";
import { ORDER_STATUS, dateTime, money, timeAgo } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";
import { db } from "@/db";
import { orderItems } from "@/db/schema";
import { inArray } from "drizzle-orm";

export const metadata = { title: "Sipariş Kuyruğu — İşletme" };

const QUEUES = [
  { key: "ORDER_PLACED", title: "Yeni siparişler", tone: "amber" },
  { key: "RESTAURANT_ACCEPTED", title: "Kabul edilenler", tone: "green" },
  { key: "PREPARING", title: "Hazırlanıyor", tone: "amber" },
  { key: "READY_FOR_PICKUP", title: "Kurye bekliyor", tone: "blue" },
  { key: "COURIER_ASSIGNED", title: "Kurye atandı", tone: "blue" },
  { key: "OUT_FOR_DELIVERY", title: "Yolda", tone: "blue" },
];

export default async function MerchantOrders() {
  const s = await getSession();
  if (!s.restaurantId) {
    return <div className="container-x py-20"><div className="mx-auto max-w-xl"><EmptyState icon="🧾" title="İşletme sipariş kuyruğu" description="Bu alan işletme sahiplerine açıktır. Sağ üstten bir işletme hesabına geçin." actions={[{ label: "İşletme paneli", href: "/isletme" }]} /></div></div>;
  }
  await sweepExpired();
  const orders = await listMerchantOrders(s.restaurantId);
  const items = orders.length ? await db.select().from(orderItems).where(inArray(orderItems.orderId, orders.map((o) => o.id))) : [];

  return (
    <div className="container-x py-10">
      <AutoRefresh ms={5000} />
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <Link href="/isletme" className="text-sm font-semibold text-ink/50 hover:text-ink">← İşletme paneli</Link>
          <h1 className="mt-1 text-4xl font-black tracking-tight">Sipariş kuyruğu</h1>
          <p className="mt-1 text-ink/60">Canlı akış: sayfa her 5 saniyede yenilenir. Ret işlemleri gerekçe ister ve denetim kaydına yazılır.</p>
        </div>
        <div className="flex gap-2 text-sm">
          <span className="chip">Toplam {orders.length}</span>
          <span className="chip">Teslim edilen {orders.filter((o) => o.status === "DELIVERED").length}</span>
        </div>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        {QUEUES.map((q) => {
          const list = orders.filter((o) => o.status === q.key);
          return (
            <section key={q.key}>
              <h2 className="mb-3 flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-ink/55">
                <span className={`h-2 w-2 rounded-full tone-${q.tone}`} />
                {q.title} <span className="rounded-full bg-paper-2 px-2 py-0.5 text-xs font-black text-ink">{list.length}</span>
              </h2>
              {list.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-line p-6 text-center text-xs text-ink/45">Bu kuyrukta sipariş yok.</div>
              ) : (
                <div className="space-y-3">
                  {list.map((o) => (
                    <div key={o.id} className="card fade-up p-4">
                      <div className="flex items-center justify-between">
                        <Link href={`/siparis/${o.id}`} className="font-mono text-sm font-black hover:text-signal">{o.code}</Link>
                        <span className="text-xs text-ink/45">{timeAgo(o.placedAt)}</span>
                      </div>
                      <div className="mt-1 text-sm text-ink/65">{o.customerName} · {areaName(o.deliveryArea)} · <b>{money(o.totalMinor)}</b></div>
                      <ul className="mt-2 space-y-0.5 text-xs text-ink/70">
                        {items.filter((i) => i.orderId === o.id).slice(0, 4).map((i) => (
                          <li key={i.id}>{i.qty}× {i.nameSnapshot}{i.optionsSnapshot ? ` (${i.optionsSnapshot})` : ""}</li>
                        ))}
                      </ul>
                      {o.note && <div className="mt-2 rounded-lg bg-paper px-2 py-1 text-xs text-ink/60">📝 {o.note}</div>}
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {o.status === "ORDER_PLACED" && (
                          <>
                            <ApiButton url={`/api/merchant/orders/${o.id}`} body={{ action: "accept" }} className="btn-mint btn-sm">✓ Kabul et</ApiButton>
                            <ApiButton url={`/api/merchant/orders/${o.id}`} body={{ action: "reject" }} className="btn-danger btn-sm" prompt={{ label: "Ret gerekçesi (zorunlu, müşteriye gösterilir):", field: "reason" }}>Reddet</ApiButton>
                          </>
                        )}
                        {o.status === "RESTAURANT_ACCEPTED" && <ApiButton url={`/api/merchant/orders/${o.id}`} body={{ action: "prepare" }} className="btn-primary btn-sm">👨‍🍳 Hazırlamaya başla</ApiButton>}
                        {o.status === "PREPARING" && <ApiButton url={`/api/merchant/orders/${o.id}`} body={{ action: "ready" }} className="btn-primary btn-sm">🍽️ Hazır — kurye çağır</ApiButton>}
                        {o.status === "READY_FOR_PICKUP" && <span className="text-xs text-ink/50">Kurye eşleştirmesi sürüyor…</span>}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          );
        })}
      </div>

      <section className="mt-10">
        <h2 className="mb-3 text-sm font-bold uppercase tracking-wider text-ink/55">Tamamlanan ve iptal edilen</h2>
        <div className="card divide-y divide-line">
          {orders.filter((o) => ["DELIVERED", "CANCELLED", "RESTAURANT_REJECTED", "REFUNDED", "REFUND_PENDING", "UNDER_REVIEW"].includes(o.status)).slice(0, 20).map((o) => (
            <Link key={o.id} href={`/siparis/${o.id}`} className="flex flex-wrap items-center gap-3 px-4 py-3 text-sm hover:bg-paper">
              <span className="font-mono font-bold">{o.code}</span>
              <span className="text-ink/55">{o.customerName} · {dateTime(o.placedAt)}</span>
              <span className="ml-auto font-bold">{money(o.totalMinor)}</span>
              <Pill tone={ORDER_STATUS[o.status]?.tone ?? "slate"}>{ORDER_STATUS[o.status]?.label}</Pill>
            </Link>
          ))}
          {orders.filter((o) => ["DELIVERED", "CANCELLED", "RESTAURANT_REJECTED", "REFUNDED"].includes(o.status)).length === 0 && (
            <div className="p-6 text-center text-sm text-ink/50">Henüz kapanmış sipariş yok.</div>
          )}
        </div>
      </section>
    </div>
  );
}
