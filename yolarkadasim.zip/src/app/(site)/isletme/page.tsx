import Link from "next/link";
import { db } from "@/db";
import { and, eq, sql } from "drizzle-orm";
import { mediaPosts } from "@/db/schema";
import { OpenToggle } from "@/components/food-client";
import { MediaStudio } from "@/components/media-client";
import { EmptyState, Pill, Stat } from "@/components/ui";
import { merchantDashboard } from "@/lib/food";
import { MEDIA_STATUS, PRODUCT_STATUS, money } from "@/lib/labels";
import { requirePageSession as getSession } from "@/lib/session";
import { MerchantMenuClient } from "@/components/MerchantMenuClient";

export const metadata = { title: "İşletme Paneli — YolArkadaşı" };

export default async function Merchant() {
  const s = await getSession();
  if (!s.restaurantId) {
    return (
      <div className="container-x py-20">
        <div className="mx-auto max-w-xl">
          <EmptyState icon="🍽️" title="İşletme paneli" description="Bu panel işletme sahiplerine açıktır. Sağ üstten bir işletme hesabına geçin (ör. Ocakbaşı Moda) veya başvuru yapın." actions={[{ label: "İşletme başvurusu", href: "/basvuru?kind=RESTAURANT", primary: true }, { label: "Yemek sayfası", href: "/yemek" }]} />
        </div>
      </div>
    );
  }
  const d = await merchantDashboard(s);
  if (!d) return null;
  const r = d.restaurant;
  const published = d.products.filter((p) => p.status === "PUBLISHED");
  const soldOut = published.filter((p) => p.stock === 0);
  const revenue = d.orders.filter((o) => o.status === "DELIVERED").reduce((sum, o) => sum + o.totalMinor, 0);
  const activeOrders = d.orders.filter((o) => !["DELIVERED", "CANCELLED", "RESTAURANT_REJECTED", "REFUNDED"].includes(o.status));
  const media = await db.select().from(mediaPosts).where(and(eq(mediaPosts.ownerType, "RESTAURANT"), eq(mediaPosts.ownerId, r.id))).orderBy(sql`${mediaPosts.createdAt} DESC`);

  return (
    <div>
      <section className="road-pattern-dark bg-ink text-white">
        <div className="container-x flex flex-col gap-5 py-10 md:flex-row md:items-center md:justify-between">
          <div className="flex items-center gap-4">
            <span className="flex h-16 w-16 items-center justify-center rounded-2xl text-2xl font-black" style={{ background: `hsl(${r.logoHue} 70% 45%)` }}>{r.name[0]}</span>
            <div>
              <h1 className="text-3xl font-black tracking-tight">{r.name}</h1>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-sm text-white/60">
                <span>{r.openNow ? "🟢 Siparişe açık" : "🔴 Siparişe kapalı"} · {r.opensAt}–{r.closesAt}</span>
                <Link href={`/restoranlar/${r.slug}`} className="underline decoration-white/30 hover:text-white">Herkese açık profil →</Link>
              </div>
            </div>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <OpenToggle isOpen={r.openNow} />
            <Link href="/isletme/siparisler" className="btn-primary">
              Siparişler {activeOrders.length > 0 && <span className="ml-1 rounded-full bg-white/25 px-2 py-0.5 text-xs">{activeOrders.length}</span>}
            </Link>
          </div>
        </div>
      </section>

      <div className="container-x py-8">
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          <Stat label="Yayında ürün" value={published.length} sub={`${d.products.length} toplam`} />
          <Stat label="Tükenen ürün" value={soldOut.length} sub={soldOut.length ? soldOut.slice(0, 2).map((p) => p.name).join(", ") : "stok sorunu yok"} />
          <Stat label="Aktif sipariş" value={activeOrders.length} sub={`${d.orders.length} toplam`} />
          <Stat label="Teslim edilen ciro" value={money(revenue)} sub={`${d.reviewCount} değerlendirme`} />
        </div>

        <MerchantMenuClient categories={d.categories} products={d.products} />

        <section className="mt-10 grid gap-6 lg:grid-cols-2">
          <div className="card p-5">
            <h2 className="font-extrabold">Vitrin medyası</h2>
            <p className="mb-4 text-sm text-ink/55">Mutfak, paketleme ve servis görselleri. Yüklenen her içerik önce özel alanda saklanır, EXIF/GPS temizlenir ve moderasyondan geçince yayına alınır.</p>
            <MediaStudio items={media} />
          </div>
          <div className="space-y-4">
            <div className="card p-5">
              <h2 className="font-extrabold">Menü yayın akışı</h2>
              <div className="mt-3 flex flex-wrap gap-2">
                {Object.entries(PRODUCT_STATUS).map(([k, v]) => (
                  <span key={k} className="chip">
                    {d.products.filter((p) => p.status === k).length} · {v}
                  </span>
                ))}
              </div>
              <p className="mt-3 text-xs text-ink/55">Taslak ürünler müşterilere görünmez. Pasife alınan ürün sepette uyarı verir, tükenen ürün sipariş edilemez.</p>
            </div>
            <div className="card p-5">
              <h2 className="font-extrabold">Son medya durumları</h2>
              <div className="mt-3 space-y-2">
                {media.slice(0, 5).map((m) => (
                  <div key={m.id} className="flex items-center justify-between text-sm">
                    <span className="truncate pr-2 text-ink/70">{m.caption ?? "(açıklamasız)"}</span>
                    <Pill tone={MEDIA_STATUS[m.status]?.tone ?? "slate"}>{MEDIA_STATUS[m.status]?.label}</Pill>
                  </div>
                ))}
                {media.length === 0 && <p className="text-sm text-ink/50">Henüz medya yüklemediniz.</p>}
              </div>
              <Link href="/admin/medya-moderasyon" className="btn-ghost btn-sm mt-4 hidden">Moderasyon kuyruğu</Link>
            </div>
            <div className="card p-5">
              <h2 className="font-extrabold">Sipariş akışı nasıl işler?</h2>
              <ol className="mt-3 space-y-2 text-sm text-ink/70">
                <li><b>1.</b> Sipariş geldiğinde bildiririm düşer, “Kabul et” dersiniz.</li>
                <li><b>2.</b> “Hazırlanıyor” ile mutfağa alınır.</li>
                <li><b>3.</b> “Hazır” dediğiniz anda platform uygun kuryeyi arar; müşterinin favori kurye tercihi varsa öncelik verilir.</li>
                <li><b>4.</b> Kurye teslim kodunu müşteriden alır, sipariş “Teslim edildi” olur.</li>
              </ol>
              <Link href="/isletme/siparisler" className="btn-ink mt-4 w-full">Sipariş kuyruğunu aç →</Link>
            </div>
          </div>
        </section>

        {d.products.length === 0 && (
          <div className="mt-8">
            <EmptyState icon="🍽️" title="Henüz ürün eklemediniz" description="İlk kategorinizi ve ürünlerinizi ekleyin; menünüz anında yayına alınır. Fiyat ve stok değişiklikleri sunucuda doğrulanır." />
          </div>
        )}
      </div>
    </div>
  );
}
