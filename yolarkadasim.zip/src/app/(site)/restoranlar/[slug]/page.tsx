import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { db } from "@/db";
import { carts, cartItems } from "@/db/schema";
import { eq, and, sql } from "drizzle-orm";
import { AddToCart } from "@/components/food-client";
import { MediaGrid, ReportButton, ReviewActions, PriceNote } from "@/components/media-client";
import { RestaurantTabs } from "@/components/RestaurantView";
import { EmptyState, Stars } from "@/components/ui";
import { getRestaurantPage } from "@/lib/food";
import { areaName } from "@/lib/geo";
import { cuisineLabel, dateTime, money, timeAgo } from "@/lib/labels";
import { getFavoriteIds } from "@/lib/queries";
import { getPublicSession as getSession } from "@/lib/session";
import { ensureSeed } from "@/lib/seed";
import { FavoriteButton } from "@/components/client";

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const data = await getRestaurantPage((await params).slug);
  if (!data) return { title: "İşletme bulunamadı — YolArkadaşı" };
  const r = data.restaurant;
  return {
    title: `${r.name} — ${cuisineLabel(r.cuisines[0])} · YolArkadaşı`,
    description: r.tagline ?? r.description ?? undefined,
    openGraph: { title: r.name, description: r.tagline ?? undefined, images: r.coverUrl ? [r.coverUrl] : undefined },
  };
}

export default async function RestaurantPage({ params }: { params: Promise<{ slug: string }> }) {
  await ensureSeed();
  const { slug } = await params;
  const data = await getRestaurantPage(slug);
  if (!data) notFound();
  const { restaurant: r, menu, reviews, media, stats } = data;
  const s = await getSession();
  const isCustomer = s.user.role === "CUSTOMER";
  const isMerchant = s.restaurantId === r.id;
  const isAdmin = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role);
  const canOrder = isCustomer && r.openNow && menu.length > 0;
  const favIds = isCustomer ? await getFavoriteIds(s.user.id) : { providers: [] as string[], fleets: [] as string[], restaurants: [] as string[] };

  const [cart] = isCustomer
    ? await db.select({ id: carts.id, restaurantId: carts.restaurantId }).from(carts).where(eq(carts.customerId, s.user.id)).limit(1)
    : [];
  const cartCount = cart && cart.restaurantId === r.id
    ? (await db.select({ n: sql<number>`coalesce(sum(${cartItems.qty}),0)::int` }).from(cartItems).where(eq(cartItems.cartId, cart.id)))[0]?.n ?? 0
    : 0;

  const emptyMenu = (
    <EmptyState
      icon="📋"
      title="Bu işletmenin menüsü henüz yayında değil."
      description="İşletme menüsünü hazırlıyor. Şimdilik diğer restoranlara göz atabilir veya bu işletmeyi favorilerinize ekleyebilirsiniz."
      actions={[{ label: "Diğer işletmeler", href: "/yemek", primary: true }, { label: "Kurye çağır", href: "/talep/yeni?mode=INSTANT_CALL" }]}
    />
  );

  const menuPanel = menu.length ? (
    <div className="grid gap-8 lg:grid-cols-[220px_1fr]">
      <nav aria-label="Menü kategorileri" className="lg:sticky lg:top-32 lg:self-start">
        <ul className="scrollbar-none flex gap-2 overflow-x-auto lg:flex-col lg:overflow-visible">
          {menu.map((c) => (
            <li key={c.id}>
              <a href={`#kat-${c.id}`} className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-bold text-ink/65 transition hover:bg-white hover:text-signal">
                <span className="h-1.5 w-1.5 rounded-full bg-signal/60" />
                {c.name}
                <span className="ml-auto text-xs text-ink/35">{c.products.length}</span>
              </a>
            </li>
          ))}
        </ul>
      </nav>
      <div className="space-y-10">
        {menu.map((c) => (
          <section key={c.id} id={`kat-${c.id}`} className="scroll-mt-32">
            <div className="flex flex-wrap items-baseline justify-between gap-2 border-b border-line pb-2">
              <h2 className="text-xl font-black tracking-tight">{c.name}</h2>
              {c.timeWindow && <span className="chip">{c.activeNow ? "🟢" : "⏰"} {c.timeWindow}</span>}
            </div>
            {c.description && <p className="mt-1 text-sm text-ink/55">{c.description}</p>}
            {!c.activeNow && c.timeWindow && <p className="mt-1 text-xs font-semibold text-[#7a5500]">Bu kategori yalnızca {c.timeWindow} arasında sipariş edilebilir.</p>}
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              {c.products.map((p) => {
                const soldOut = p.stock < 1;
                return (
                  <article key={p.id} className={`card flex gap-3 overflow-hidden p-3 transition hover:shadow-[0_14px_30px_-18px_rgba(14,19,36,0.35)] ${soldOut ? "opacity-70" : ""}`}>
                    <div className="relative h-28 w-24 shrink-0 overflow-hidden rounded-xl bg-paper">
                      {p.imageUrl ? <Image src={p.imageUrl} alt={p.name} fill className="object-cover" sizes="96px" /> : <span className="flex h-full items-center justify-center text-2xl">🍽️</span>}
                      {p.discountPriceMinor && <span className="absolute left-1 top-1 rounded-full bg-signal px-1.5 py-0.5 text-[10px] font-black text-white">-%{Math.round((1 - p.discountPriceMinor / p.priceMinor) * 100)}</span>}
                    </div>
                    <div className="flex min-w-0 flex-1 flex-col">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-sm font-extrabold leading-tight">{p.name}</h3>
                        <div className="shrink-0 text-right">
                          {p.discountPriceMinor ? (
                            <div>
                              <div className="text-sm font-black text-signal">{money(p.discountPriceMinor)}</div>
                              <div className="text-[11px] text-ink/40 line-through">{money(p.priceMinor)}</div>
                            </div>
                          ) : (
                            <div className="text-sm font-black">{money(p.priceMinor)}</div>
                          )}
                        </div>
                      </div>
                      <p className="mt-0.5 line-clamp-2 text-xs text-ink/55">{p.description}</p>
                      <div className="mt-1.5 flex flex-wrap gap-1">
                        {p.isVegan && <span className="chip !px-2 !py-0.5 !text-[10px]">🌱 vegan</span>}
                        {p.isVegetarian && !p.isVegan && <span className="chip !px-2 !py-0.5 !text-[10px]">🥬 vejetaryen</span>}
                        {p.isSpicy && <span className="chip !px-2 !py-0.5 !text-[10px]">🌶️ acı</span>}
                        {p.calories != null && <span className="chip !px-2 !py-0.5 !text-[10px]">{p.calories} kcal</span>}
                        {p.prepMinutes != null && <span className="chip !px-2 !py-0.5 !text-[10px]">⏱ {p.prepMinutes} dk</span>}
                        {p.groups.length > 0 && <span className="chip !px-2 !py-0.5 !text-[10px]">⚙ {p.groups.length} seçim</span>}
                      </div>
                      <div className="mt-auto flex items-center justify-between gap-2 pt-2">
                        {soldOut ? (
                          <span className="text-[11px] font-bold text-rose">Bu ürün şu anda tükenmiş görünüyor.</span>
                        ) : (
                          p.stock <= 5 && <span className="text-[11px] font-semibold text-ink/45">Son {p.stock} adet</span>
                        )}
                        <AddToCart restaurantId={r.id} product={p} closed={!canOrder && isCustomer} restaurantName={r.name} />
                      </div>
                    </div>
                  </article>
                );
              })}
            </div>
          </section>
        ))}
      </div>
    </div>
  ) : emptyMenu;

  return (
    <div>
      {/* Kapak */}
      <div className="relative h-56 sm:h-72">
        {r.coverUrl ? (
          <Image src={r.coverUrl} alt={r.name} fill priority className="object-cover" sizes="100vw" />
        ) : (
          <div className="h-full w-full" style={{ background: `linear-gradient(120deg, hsl(${r.logoHue} 70% 30%), #0e1324)` }} />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
        <div className="container-x absolute inset-x-0 bottom-0 pb-5">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
            <div className="flex items-end gap-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl text-2xl font-black text-white shadow-xl ring-4 ring-white/20" style={{ background: `hsl(${r.logoHue} 70% 40%)` }}>
                {r.name[0]}
              </div>
              <div className="text-white">
                <div className="flex flex-wrap items-center gap-2">
                  <h1 className="text-3xl font-black tracking-tight sm:text-4xl">{r.name}</h1>
                  {r.isVerified && <span className="chip-dark">✓ Doğrulanmış işletme</span>}
                  <span className={`chip-dark ${r.openNow ? "" : "!bg-rose/25"}`}>{r.openNow ? "🟢 Açık" : `🔴 Kapalı · ${r.opensAt}`}</span>
                </div>
                <p className="mt-1 text-sm text-white/70">{r.tagline}</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {isCustomer && <FavoriteButton targetType="RESTAURANT" targetId={r.id} initial={favIds.restaurants.includes(r.id)} />}
              <ReportButton targetType="RESTAURANT" targetId={r.id} label="İşletmeyi bildir" />
              {isMerchant && <Link href="/isletme" className="btn-ghost">İşletme paneli</Link>}
              {isAdmin && <Link href={s.user.role === "SUPER_ADMIN" ? "/admin" : "/dashboard/admin"} className="btn-ghost">Operasyon</Link>}
              {canOrder ? <a href="#menu" className="btn-primary">🧺 Sipariş ver</a> : <span className="btn border border-white/25 bg-white/10 text-white/60">{!r.openNow ? "Şu anda siparişe kapalı" : menu.length ? "Sepete göz atın" : "Menü yayında değil"}</span>}
            </div>
          </div>
        </div>
      </div>

      <div className="container-x py-8">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
          {[
            ["Puan", r.ratingCount ? <Stars key="s" value={r.ratingAvg} count={r.ratingCount} /> : "Henüz yok"],
            ["Teslimat", `~${r.etaMinutes} dk`],
            ["Teslimat ücreti", money(r.deliveryFeeMinor)],
            ["Min. sepet", money(r.minBasketMinor)],
            ["Çalışma saatleri", `${r.opensAt}–${r.closesAt}`],
          ].map(([k, v]) => (
            <div key={k as string} className="card px-4 py-3">
              <div className="text-[11px] font-bold uppercase tracking-wider text-ink/45">{k}</div>
              <div className="mt-0.5 text-sm font-extrabold">{v}</div>
            </div>
          ))}
        </div>
        <div className="mt-3">
          <PriceNote fee={r.deliveryFeeMinor} smallFee={r.smallBasketFeeMinor} threshold={r.smallBasketThresholdMinor} min={r.minBasketMinor} />
        </div>
        {cartCount > 0 && (
          <Link href="/sepet" className="card mt-3 flex items-center justify-between border-signal/40 bg-signal/[0.04] px-4 py-3">
            <span className="text-sm font-bold">🧺 Bu işletmeden sepetinizde {cartCount} ürün var</span>
            <span className="btn-primary btn-sm">Sepete git</span>
          </Link>
        )}

        <div id="menu" className="mt-8 scroll-mt-24">
          <RestaurantTabs
            tabs={[
              { key: "menu", label: "Menü", count: r.productCount },
              { key: "campaign", label: "Kampanyalar" },
              { key: "about", label: "Hakkında" },
              { key: "reviews", label: "Yorumlar", count: reviews.length },
              { key: "info", label: "Bilgiler" },
              { key: "photos", label: "Fotoğraflar", count: media.length },
              { key: "allergens", label: "Alerjen & içerik", count: r.allergens.length },
            ]}
            panels={{
              menu: menuPanel,
              campaign: r.campaignTitle ? (
                <div className="card overflow-hidden">
                  <div className="bg-sun/15 px-5 py-4">
                    <div className="eyebrow !text-[#7a5500]">Gerçek kampanya</div>
                    <h2 className="mt-1 text-xl font-black">{r.campaignTitle}</h2>
                  </div>
                  <div className="p-5 text-sm text-ink/70">{r.campaignDetail}</div>
                </div>
              ) : (
                <EmptyState icon="🎁" title="Şu anda aktif kampanya yok" description="İşletme kampanya tanımladığında burada görünür. Sahte indirim göstermiyoruz." actions={[{ label: "Menüye dön", href: `#${r.slug}`, primary: true }]} />
              ),
              about: (
                <div className="card p-6">
                  <h2 className="text-lg font-extrabold">{r.name} hakkında</h2>
                  <p className="mt-2 leading-relaxed text-ink/70">{r.description}</p>
                  <div className="mt-5 grid gap-4 sm:grid-cols-2">
                    <div>
                      <div className="label">Mutfak</div>
                      <div className="flex flex-wrap gap-1.5">{r.cuisines.map((c) => <span key={c} className="chip">{cuisineLabel(c)}</span>)}</div>
                    </div>
                    <div>
                      <div className="label">Öne çıkanlar</div>
                      <div className="flex flex-wrap gap-1.5">{r.tags.map((t) => <span key={t} className="chip">✦ {t}</span>)}</div>
                    </div>
                    <div>
                      <div className="label">Teslimat bölgeleri</div>
                      <div className="flex flex-wrap gap-1.5">{r.deliveryAreas.map((a) => <span key={a} className="chip">📍 {areaName(a)}</span>)}</div>
                    </div>
                    <div>
                      <div className="label">Beyanlar</div>
                      <div className="flex flex-wrap gap-1.5">
                        {r.hasVegan && <span className="chip">🌱 Vegan seçenek</span>}
                        {r.hasHalal && <span className="chip">✓ Helal (işletme beyanı)</span>}
                        {!r.hasVegan && !r.hasHalal && <span className="text-xs text-ink/50">İşletme tarafından beyan edilmiş özel beslenme bilgisi yok.</span>}
                      </div>
                    </div>
                  </div>
                  {stats.totalOrders > 0 && (
                    <div className="mt-6 grid grid-cols-3 gap-3 border-t border-line pt-5 text-center">
                      <div><div className="text-2xl font-black">{stats.totalOrders}</div><div className="text-[11px] uppercase text-ink/45">toplam sipariş</div></div>
                      <div><div className="text-2xl font-black">{stats.delivered}</div><div className="text-[11px] uppercase text-ink/45">teslim edilen</div></div>
                      <div><div className="text-2xl font-black">{money(stats.avgBasket)}</div><div className="text-[11px] uppercase text-ink/45">ortalama sepet</div></div>
                    </div>
                  )}
                </div>
              ),
              reviews: reviews.length ? (
                <div className="card divide-y divide-line">
                  {reviews.map((rv) => (
                    <div key={rv.id} className="p-5">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-sm font-bold">{rv.author} <span className="ml-1 rounded-full bg-mint/12 px-2 py-0.5 text-[10px] font-bold text-[#0c8a5a]">Doğrulanmış sipariş</span></div>
                          <div className="text-[11px] text-ink/45">{timeAgo(rv.createdAt)}</div>
                        </div>
                        <span className="text-sun">{"★".repeat(rv.rating)}<span className="text-ink/15">{"★".repeat(5 - rv.rating)}</span></span>
                      </div>
                      {rv.body && <p className="mt-2 text-sm text-ink/75">{rv.body}</p>}
                      {rv.response && (
                        <div className="mt-3 rounded-xl border-l-2 border-signal bg-paper px-3 py-2 text-sm">
                          <div className="text-[11px] font-bold uppercase text-signal">İşletme yanıtı</div>
                          {rv.response}
                        </div>
                      )}
                      <ReviewActions reviewId={rv.id} canRespond={isMerchant || isAdmin} canAppeal={isMerchant} isAuthor={false} />
                    </div>
                  ))}
                </div>
              ) : (
                <EmptyState icon="⭐" title="Henüz değerlendirme yok" description="Bu işletme hakkında yalnızca teslim edilmiş siparişlerin sahipleri yorum yapabilir. Sahte puan göstermiyoruz." />
              ),
              info: (
                <div className="card divide-y divide-line">
                  {[
                    ["Çalışma saatleri", `${r.opensAt} – ${r.closesAt}`],
                    ["Hazırlık süresi", `~${r.prepMinutes} dk`],
                    ["Teslimat ücreti", money(r.deliveryFeeMinor)],
                    ["Minimum sepet", money(r.minBasketMinor)],
                    ["Küçük sepet bedeli", `${money(r.smallBasketFeeMinor)} (${money(r.smallBasketThresholdMinor)} altı)`],
                    ["Adres", r.addressPublic ?? "İşletme adres paylaşımını açmadı."],
                    ["Telefon", r.phonePublic ?? "Yayın izni yok — sipariş sonrası uygulama içinden ulaşılır."],
                    ["Web sitesi", r.website ?? "—"],
                    ["Kategori / ürün", `${r.categoryCount} kategori · ${r.productCount} ürün`],
                  ].map(([k, v]) => (
                    <div key={k as string} className="flex flex-col gap-0.5 px-5 py-3 text-sm sm:flex-row sm:items-center sm:justify-between">
                      <span className="text-ink/55">{k}</span>
                      <span className="font-bold">{v as string}</span>
                    </div>
                  ))}
                </div>
              ),
              photos: <MediaGrid items={media} canReport={s.user.role === "CUSTOMER" || isAdmin} />,
              allergens: (
                <div className="card p-6">
                  <h2 className="text-lg font-extrabold">Alerjen ve içerik bilgileri</h2>
                  <p className="mt-1 text-sm text-ink/60">Yalnızca işletmenin ürün verisinde beyan ettiği alerjenler listelenir.</p>
                  {r.allergens.length ? (
                    <div className="mt-4 flex flex-wrap gap-2">
                      {r.allergens.map((a) => <span key={a} className="chip !border-sun/40 !bg-sun/10 !text-[#7a5500]">⚠ {a}</span>)}
                    </div>
                  ) : (
                    <div className="mt-4 rounded-xl bg-paper p-4 text-sm text-ink/60">Bu işletme henüz alerjen bilgisi girmedi. Alerjiniz varsa sipariş notuna yazın ve işletmeyle teyitleşin.</div>
                  )}
                  <div className="mt-6 space-y-3">
                    {menu.flatMap((c) => c.products).filter((p) => p.allergens.length || p.calories != null).slice(0, 12).map((p) => (
                      <div key={p.id} className="flex flex-wrap items-center gap-2 rounded-xl bg-paper px-3 py-2 text-sm">
                        <b>{p.name}</b>
                        {p.allergens.map((a) => <span key={a} className="chip !px-2 !py-0.5 !text-[10px]">{a}</span>)}
                        {p.calories != null && <span className="text-xs text-ink/50">{p.calories} kcal</span>}
                      </div>
                    ))}
                  </div>
                </div>
              ),
            }}
          />
        </div>

        {!r.openNow && (
          <div className="card mt-8 border-sun/40 bg-sun/10 p-5">
            <h3 className="font-extrabold">Bu işletme şu anda siparişe kapalı.</h3>
            <p className="mt-1 text-sm text-ink/70">Çalışma saatleri {r.opensAt}–{r.closesAt}. Menüyü inceleyebilir, açıldığında sipariş verebilirsiniz.</p>
            <div className="mt-3 flex gap-2">
              <Link href="/yemek" className="btn-primary btn-sm">Açık işletmeleri gör</Link>
              <Link href="/talep/yeni?mode=SCHEDULED" className="btn-ghost btn-sm">Kurye için randevu oluştur</Link>
            </div>
          </div>
        )}

        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {menu.length === 0 && (
            <Link href="/yemek" className="card card-hover p-5"><div className="font-extrabold">Benzer işletmeler →</div><div className="text-sm text-ink/55">{areaName(r.deliveryAreas[0])} çevresindeki diğer mutfaklar</div></Link>
          )}
          <Link href="/kesfet" className="card card-hover p-5"><div className="font-extrabold">Kendi kuryeni seç →</div><div className="text-sm text-ink/55">Bu siparişi kendi yol arkadaşınızla da taşıtabilirsiniz</div></Link>
          <Link href="/basvuru?kind=RESTAURANT" className="card card-hover p-5"><div className="font-extrabold">İşletme başvurusu →</div><div className="text-sm text-ink/55">Menünüzü platforma taşıyın</div></Link>
          <Link href="/siparislerim" className="card card-hover p-5"><div className="font-extrabold">Siparişlerim →</div><div className="text-sm text-ink/55">Geçmiş ve aktif siparişleriniz</div></Link>
        </div>
        <p className="mt-6 text-xs text-ink/45">Son menü güncellemesi: {dateTime(new Date())} · Fiyatlar işletme tarafından yönetilir, ödeme anında sunucuda doğrulanır.</p>
      </div>
    </div>
  );
}
