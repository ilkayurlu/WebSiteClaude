"use client";

import Link from "next/link";

export default function Error({ reset }: { error: Error; reset: () => void }) {
  return (
    <div className="container-x py-24">
      <div className="card road-pattern mx-auto max-w-lg px-8 py-14 text-center">
        <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-rose/10 text-3xl">🛠️</div>
        <h1 className="text-2xl font-black">Bir şeyler ters gitti</h1>
        <p className="mt-2 text-sm text-ink/60">Bu sayfa şu anda yüklenemedi. Verileriniz güvende; lütfen tekrar deneyin.</p>
        <div className="mt-6 flex justify-center gap-2">
          <button onClick={reset} className="btn-primary">Tekrar dene</button>
          <Link href="/" className="btn-ghost">Ana sayfa</Link>
          <Link href="/destek" className="btn-ghost">Destek al</Link>
        </div>
      </div>
    </div>
  );
}
