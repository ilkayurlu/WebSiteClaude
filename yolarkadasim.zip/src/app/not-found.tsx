import { EmptyState } from "@/components/ui";

export default function NotFound() {
  return (
    <div className="container-x py-24">
      <div className="mx-auto max-w-xl">
        <EmptyState
          icon="🗺️"
          title="Bu rotada bir şey bulamadık"
          description="Aradığınız profil, filo ya da talep mevcut değil veya erişim yetkiniz yok."
          actions={[
            { label: "Sağlayıcıları keşfet", href: "/kesfet", primary: true },
            { label: "Ana sayfa", href: "/" },
          ]}
        />
      </div>
    </div>
  );
}
