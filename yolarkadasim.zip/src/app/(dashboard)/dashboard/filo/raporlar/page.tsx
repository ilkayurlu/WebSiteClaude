import Link from "next/link";
import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { assignments, serviceRequests } from "@/db/schema";
import { ArrowRight, ChartNoAxesCombined, CheckCircle2, CircleHelp, Clock3, Truck, UsersRound } from "lucide-react";
import { DashboardHeading, InlineEmpty, MetricCard, MiniProgress, PanelSection } from "@/components/dashboard/Elements";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { fleetOverview, startOfTodayIstanbul } from "@/lib/dashboard-data";
import { areaName } from "@/lib/geo";
import { dateTime, money } from "@/lib/labels";
import { PayoutAccountForm } from "@/components/dashboard/PayoutAccountForm";
import { getOwnPayoutAccount } from "@/lib/payouts";

export const metadata = { title: "Filo Raporları" };
export default async function FleetReports() {
  const s = await requireDashboardRole("FLEET_OWNER");
  const d = await fleetOverview(s);
  const account = await getOwnPayoutAccount("FLEET", s.fleetId!);
  const all = await db.select({ a: assignments, r: serviceRequests }).from(assignments).innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId)).where(eq(assignments.fleetId, s.fleetId!)).orderBy(desc(assignments.acceptedAt));
  const completed = all.filter((t) => t.a.state === "COMPLETED");
  const cancelled = all.filter((t) => t.a.state === "CANCELLED");
  const gross = completed.reduce((sum, t) => sum + (t.r.finalPriceMinor ?? 0), 0);
  const rate = completed.length + cancelled.length ? Math.round(100 * completed.length / (completed.length + cancelled.length)) : null;
  const dayStart = startOfTodayIstanbul();
  const graph = Array.from({ length: 7 }, (_, idx) => { const start = new Date(dayStart.getTime() - (6 - idx) * 86400000); const next = new Date(start.getTime() + 86400000); return { day: start, amount: completed.filter((x) => x.a.completedAt && x.a.completedAt >= start && x.a.completedAt < next).reduce((sum, x) => sum + (x.r.finalPriceMinor ?? 0), 0) }; });
  const max = Math.max(...graph.map((x) => x.amount), 1);
  return <><DashboardHeading eyebrow="ŞEFFAF FİLO VERİSİ" title="Operasyon raporları" desc="Tamamlanan ve iptal edilen gerçek görevler üzerinden hesaplanır. OEE üretim metriği ve komisyon/ödeme entegrasyonu bağlı değil; sahte değer gösterilmez." action={<Link href="/dashboard/filo/operasyon" className="btn-ghost btn-sm">Operasyona dön <ArrowRight size={14} /></Link>} />
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4"><MetricCard icon={ChartNoAxesCombined} item={{ title: "Brüt görev hacmi", value: money(gross), detail: "Ödenmiş hakediş değil" }} /><MetricCard icon={CheckCircle2} accent="mint" item={{ title: "Tamamlanan", value: String(completed.length), detail: "Gerçek görevler" }} /><MetricCard icon={Truck} accent="sky" item={{ title: "İptal", value: String(cancelled.length), detail: "Kapanan görevler" }} /><MetricCard icon={UsersRound} accent="ink" item={{ title: "Tamamlama oranı", value: rate != null ? `%${rate}` : "—", detail: "OEE değil; tamam / kapanan" }} /></div>
    <div className="mt-7 grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]"><div className="space-y-7"><PanelSection eyebrow="SON 7 GÜN" title="Günlük görev hacmi"><div className="card p-5"><div className="dash-chart flex h-48 items-end gap-2 border-b border-line pb-1">{graph.map(({ day, amount }) => <div key={day.toISOString()} className="flex h-full flex-1 flex-col items-center justify-end gap-2"><div className="w-full max-w-12 rounded-t-lg bg-signal/80 transition hover:bg-signal" style={{ height: `${amount ? Math.max(8, amount / max * 145) : 3}px` }} title={money(amount)} /><span className="text-[10px] font-bold text-ink/45">{new Intl.DateTimeFormat("tr-TR", { weekday: "short", timeZone: "Europe/Istanbul" }).format(day)}</span></div>)}</div><p className="mt-3 text-xs text-ink/50">Günlük tutarlar yalnızca <b>tamamlanmış</b> görevlerden oluşur; yemek sipariş bedeli dahil değildir.</p></div></PanelSection><PanelSection title="Son görevler" eyebrow="KAYIT DÖKÜMÜ"><div className="card divide-y divide-line">{all.length ? all.slice(0, 30).map(({ a, r }) => <Link key={a.id} href={`/talep/${r.id}`} className="flex flex-wrap items-center gap-3 px-4 py-3 text-xs transition hover:bg-paper"><span className="flex-1"><b className="font-mono">{r.code}</b><span className="ml-2 text-ink/45">{areaName(r.pickupArea)} → {areaName(r.dropoffArea)}</span></span><span className="text-ink/45">{dateTime(a.completedAt ?? a.acceptedAt)}</span><b>{money(r.finalPriceMinor)}</b><span className={a.state === "COMPLETED" ? "font-bold text-[#0d8759]" : a.state === "CANCELLED" ? "font-bold text-rose" : "font-bold text-sky"}>{a.state === "COMPLETED" ? "Tamam" : a.state === "CANCELLED" ? "İptal" : "Aktif"}</span></Link>) : <div className="p-4"><InlineEmpty icon={Truck} title="Henüz görev kaydı yok" desc="Filo teklifi kabul ettiğinde burada gerçek görev verisi oluşur." href="/dashboard/filo/direkt-talepler" action="Talep havuzu" /></div>}</div></PanelSection></div><aside className="space-y-4"><PayoutAccountForm beneficiaryType="FLEET" beneficiaryId={s.fleetId!} current={account} /><div className="card p-5"><h3 className="text-sm font-extrabold">Görev kalitesi</h3><div className="mt-4 space-y-4"><MiniProgress label="Tamamlanan" value={completed.length} max={all.length} tint="mint" /><MiniProgress label="İptal" value={cancelled.length} max={all.length} /></div><p className="mt-4 text-xs text-ink/55">Tamamlama oranı: tamamlanan / (tamamlanan + iptal). Aktif görevler hesaplamaya girmez.</p></div><div className="card-ink p-5"><CircleHelp size={18} className="text-signal" /><h3 className="mt-2 text-sm font-extrabold">Komisyon dökümü</h3><p className="mt-2 text-xs leading-relaxed text-white/60">Komisyon sözleşmesi veya muhasebe sağlayıcısı bağlı olmadığı için net kazanç, komisyon ve ödeme durumu hesaplanmaz.</p><Link href="/destek" className="mt-3 inline-block text-xs font-bold text-signal hover:underline">Finans destek →</Link></div></aside></div>
  </>;
}
