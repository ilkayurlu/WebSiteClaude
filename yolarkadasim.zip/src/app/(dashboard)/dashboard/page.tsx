import { redirect } from "next/navigation";
import { requireDashboardSession } from "@/lib/dashboard-auth";
import { dashboardHome } from "@/lib/dashboard-routes";

export default async function DashboardRouter() {
  const session = await requireDashboardSession();
  redirect(dashboardHome(session.user.role));
}
