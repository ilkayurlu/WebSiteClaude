import type { Metadata } from "next";
import type { ReactNode } from "react";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { providers } from "@/db/schema";
import { DashboardShell } from "@/components/dashboard/Live";
import { requireDashboardSession } from "@/lib/dashboard-auth";
import { getDashboardPulse } from "@/lib/dashboard-data";
import { dashboardHome, type DashboardRole } from "@/lib/dashboard-routes";
import { redirect } from "next/navigation";

export const metadata: Metadata = { title: { template: "%s · YolArkadaşı Panel", default: "Panel · YolArkadaşı" }, robots: { index: false, follow: false } };

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const session = await requireDashboardSession();
  const pulse = await getDashboardPulse(session);
  if (dashboardHome(session.user.role) === "/giris") redirect("/giris");
  const [provider] = session.providerId ? await db.select({ status: providers.status }).from(providers).where(eq(providers.id, session.providerId)).limit(1) : [];
  const role = session.user.role === "SUPER_ADMIN" ? "ADMIN" : session.user.role as DashboardRole;
  return <DashboardShell role={role} userId={session.user.id} name={session.user.name} initialPulse={pulse} status={provider?.status}>{children}</DashboardShell>;
}
