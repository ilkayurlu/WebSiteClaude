import type { ReactNode } from "react";
import { requireDashboardRole } from "@/lib/dashboard-auth";

export default async function RoleLayout({ children }: { children: ReactNode }) {
  await requireDashboardRole("RESTAURANT_OWNER");
  return children;
}
