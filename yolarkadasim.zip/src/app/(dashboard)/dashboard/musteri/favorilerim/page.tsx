import Link from "next/link";
import Image from "next/image";
import { Building2, Heart, MapPinned, UtensilsCrossed } from "lucide-react";
import { ProviderCard } from "@/components/ProviderCard";
import { FavoriteButton } from "@/components/client";
import { DashboardHeading, InlineEmpty, PanelSection } from "@/components/dashboard/Elements";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { getFavoriteRestaurants } from "@/lib/food-favorites";
import { getFavoriteIds, getFavoriteProviders, listFleets } from "@/lib/queries";
import { cuisineLabel, money } from "@/lib/labels";

export const metadata = { title: "Favorilerim" };
export default async function CustomerFavorites() {
  const s = await requireDashboardRole("CUSTOMER");
  const ids = await getFavoriteIds(s.user.id);
  const [people, fleets, restaurants] = await Promise.all([getFavoriteProviders(s.user.id), listFleets(), getFavoriteRestaurants(ids.restaurants)]);
  const pickedFleets = fleets.filter((f) => ids.fleets.includes(f.id));
  return <><DashboardHeading eyebrow="BENİM YOL ARKADAŞLARIM" title="Favorilerim" desc="Sevdiğin kurye, filo ve işletmeler bir arada. Favori seçim kesin atama garantisi değildir; uygunluk ve bölge tekrar doğrulanır." action={<Link href="/kesfet" className="btn-primary"><MapPinned size={15} /> Yeni yol arkadaşı keşfet</Link>} />
    <div className="mb-7 grid grid-cols-3 gap-3"><div className="card px-4 py-3"><div className="text-xs text-ink/50">Sağlayıcı</div><div className="mt-1 text-2xl font-black">{people.length}</div></div><div className="card px-4 py-3"><div className="text-xs text-ink/50">Filo</div><div className="mt-1 text-2xl font-black">{pickedFleets.length}</div></div><div className="card px-4 py-3"><div className="text-xs text-ink/50">Restoran</div><div className="mt-1 text-2xl font-black">{restaurants.length}</div></div></div>
    <div className="space-y-9"><PanelSection title="Güvendiğim sağlayıcılar" eyebrow="KURYE · SÜRÜCÜ" action={{ label: "Keşfet", href: "/kesfet" }}><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{people.length ? people.map((p) => <ProviderCard key={p.id} p={p} canFavorite isFavorite />) : <div className="sm:col-span-2 xl:col-span-3"><InlineEmpty icon={Heart} title="Henüz favori sağlayıcı yok" desc="Keşif sayfasından bir yol arkadaşını favorine ekleyerek buradan hızlıca ulaşabilirsin." href="/kesfet" action="Sağlayıcıları keşfet" /></div>}</div></PanelSection>
    <PanelSection title="Tercih ettiğim filolar" eyebrow="KURUMSAL"><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{pickedFleets.length ? pickedFleets.map((f) => <div key={f.id} className="card overflow-hidden"><div className="h-1.5" style={{ background: f.accent }} /><div className="p-5"><div className="flex items-start justify-between gap-2"><Building2 size={20} className="text-signal" /><FavoriteButton targetType="FLEET" targetId={f.id} initial compact /></div><Link href={`/filolar/${f.slug}`} className="mt-3 block text-base font-extrabold hover:text-signal">{f.name}</Link><p className="mt-1 line-clamp-2 text-xs text-ink/55">{f.description}</p><div className="mt-3 text-xs text-ink/55">{f.members} üye · {f.available} müsait</div><Link href={`/talep/yeni?fleet=${f.slug}`} className="btn-ink btn-sm mt-4">Filoyu tercih et →</Link></div></div>) : <div className="sm:col-span-2 xl:col-span-3"><InlineEmpty icon={Building2} title="Favori filo yok" desc="Kurumsal filolara göz at, güvenilir ekibi bir sonraki gönderin için kaydet." href="/filolar" action="Filoları gör" /></div>}</div></PanelSection>
    <PanelSection title="Sevdiğim işletmeler" eyebrow="YEMEK & MARKET"><div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">{restaurants.length ? restaurants.map((r) => <div key={r.id} className="card p-5"><div className="flex items-start justify-between"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-paper text-lg">🍽️</span><FavoriteButton targetType="RESTAURANT" targetId={r.id} initial compact /></div><Link href={`/restoranlar/${r.slug}`} className="mt-3 block font-extrabold hover:text-signal">{r.name}</Link><p className="mt-1 text-xs text-ink/55">{r.isOpen ? "Siparişe açık" : "Şu an kapalı"} · Menü ve teslimat bilgilerini profilde gör</p><Link href={`/restoranlar/${r.slug}`} className="btn-ghost btn-sm mt-4">Menüye git →</Link></div>) : <div className="sm:col-span-2 xl:col-span-3"><InlineEmpty icon={UtensilsCrossed} title="Favori işletme yok" desc="Bölgenizdeki restoranları keşfedip sevdiğiniz tatları kaydedin." href="/yemek" action="Yemek sayfası" /></div>}</div></PanelSection></div>
  </>;
}
