import Link from "next/link";
import { ArrowRight, CalendarClock, ClipboardList, Plus, ReceiptText } from "lucide-react";
import { DashboardHeading, FoodOrderTile, InlineEmpty, PanelSection, TaskTile } from "@/components/dashboard/Elements";
import { SupportCaseForm } from "@/components/dashboard/Actions";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { customerOverview } from "@/lib/dashboard-data";

export const metadata = { title: "Aktif Taleplerim" };
export default async function ActiveCustomerTasks() {
  const session = await requireDashboardRole("CUSTOMER");
  const data = await customerOverview(session);
  return <><DashboardHeading eyebrow="CANLI TAKİP" title="Yoldaki işlerim" desc="Aktif görev ve siparişlerini gerçek durumlarıyla izle. Teslim kodunu yalnızca görev kesinleştiğinde ve teslim anında paylaş." action={<Link href="/talep/yeni" className="btn-primary"><Plus size={16} /> Yeni çağrı</Link>} />
    <div className="grid gap-4 sm:grid-cols-2"><Link href="/talep/yeni?mode=SCHEDULED" className="card card-hover flex items-center gap-3 p-4"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-signal/10 text-signal"><CalendarClock size={19} /></span><span className="flex-1"><b className="block text-sm">İleri tarihe randevu</b><span className="text-xs text-ink/50">Zamanı ve yol arkadaşını seç</span></span><ArrowRight size={16} className="text-signal" /></Link><Link href="/yemek" className="card card-hover flex items-center gap-3 p-4"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-signal/10 text-signal"><ReceiptText size={19} /></span><span className="flex-1"><b className="block text-sm">Yemek sipariş et</b><span className="text-xs text-ink/50">Menü, fiyat ve kurye tercihi</span></span><ArrowRight size={16} className="text-signal" /></Link></div>
    <div className="mt-8 space-y-8"><PanelSection title={`Aktif görevler (${data.activeTasks.length})`} eyebrow="KURYE · TRANSFER · KİRALAMA"><div className="space-y-3">{data.activeTasks.length ? data.activeTasks.map((t) => <div key={t.id}><TaskTile task={t} showOtp /><div className="mt-1 pl-2"><SupportCaseForm sourceType="REQUEST" sourceId={t.id} /></div></div>) : <InlineEmpty icon={ClipboardList} title="Aktif talep bulunmuyor" desc="Kurye çağırabilir, araç kiralayabilir veya ileri tarihe randevu oluşturabilirsin." href="/talep/yeni" action="Yeni talep oluştur" />}</div></PanelSection><PanelSection title={`Aktif yemek siparişleri (${data.activeOrders.length})`} eyebrow="MUTFAK · KURYE · TESLİMAT"><div className="space-y-3">{data.activeOrders.length ? data.activeOrders.map((o) => <div key={o.id}><FoodOrderTile order={o} /><div className="mt-1 pl-2"><SupportCaseForm sourceType="ORDER" sourceId={o.id} /></div></div>) : <InlineEmpty icon={ReceiptText} title="Aktif sipariş bulunmuyor" desc="Bölgenizdeki restoranları, gerçek menü ve teslimat bilgileriyle keşfedin." href="/yemek" action="Yemek keşfet" />}</div></PanelSection></div>
  </>;
}
