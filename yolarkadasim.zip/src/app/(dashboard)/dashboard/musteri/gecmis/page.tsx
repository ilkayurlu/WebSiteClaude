import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { CheckCircle2, Clock3, FileClock, MessageCircle, ReceiptText, Route } from "lucide-react";
import { db } from "@/db";
import { supportCases } from "@/db/schema";
import { SupportCaseForm } from "@/components/dashboard/Actions";
import { DashboardHeading, FoodOrderTile, InlineEmpty, PanelSection, TaskTile } from "@/components/dashboard/Elements";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { activeOrderStates, activeRequestStates, customerTasks } from "@/lib/dashboard-data";
import { listCustomerOrders } from "@/lib/food";
import { dateTime } from "@/lib/labels";

type SearchParams = Promise<{ durum?: string }>;
export const metadata = { title: "Geçmiş & Değerlendirmeler" };
export default async function CustomerHistory({ searchParams }: { searchParams: SearchParams }) {
  const session = await requireDashboardRole("CUSTOMER");
  const { durum } = await searchParams;
  const [allTaskRows, allOrderRows, cases] = await Promise.all([
    customerTasks(session), listCustomerOrders(session.user.id),
    db.select().from(supportCases).where(eq(supportCases.customerId, session.user.id)).orderBy(desc(supportCases.createdAt)).limit(30),
  ]);
  const allTasks = allTaskRows.filter((t) => !t.linkedOrderId && !activeRequestStates.includes(t.status));
  const allOrders = allOrderRows.filter((o) => !activeOrderStates.includes(o.status));
  const tasks = durum === "tamamlanan" ? allTasks.filter((t) => t.status === "COMPLETED") : durum === "iptal" ? allTasks.filter((t) => t.status !== "COMPLETED") : allTasks;
  const orders = durum === "tamamlanan" ? allOrders.filter((o) => o.status === "DELIVERED") : durum === "iptal" ? allOrders.filter((o) => o.status !== "DELIVERED") : allOrders;
  return <><DashboardHeading eyebrow="HESAP GEÇMİŞİ" title="Yolculuğunun izleri" desc="Tamamlanan ve iptal edilen işlemler, değerlendirmeler ve destek kayıtları. Gerçek fatura sağlayıcısı bağlı değil; sipariş detayını makbuz özeti olarak görüntüleyebilirsin." action={<Link href="/dashboard/musteri/cuzdan" className="btn-ghost btn-sm"><ReceiptText size={14} /> Harcama dökümü</Link>} />
    <nav aria-label="Durum filtresi" className="mb-6 flex flex-wrap gap-2">{[{ key: "", label: "Tümü" }, { key: "tamamlanan", label: "Tamamlananlar" }, { key: "iptal", label: "İptal edilenler" }].map((x) => <Link key={x.key} href={x.key ? `?durum=${x.key}` : "?"} className={`rounded-full px-4 py-2 text-xs font-bold transition ${(!durum && !x.key) || durum === x.key ? "bg-ink text-white" : "bg-white text-ink/60 ring-1 ring-line hover:ring-signal"}`}>{x.label}</Link>)}</nav>
    <div className="grid gap-8 xl:grid-cols-[minmax(0,1fr)_330px]"><div className="space-y-8">
      <PanelSection title={`Geçmiş görevler (${tasks.length})`} eyebrow="GÖREV DEFTERİ"><div className="space-y-3">{tasks.length ? tasks.map((t) => <div key={t.id}><TaskTile task={t} /><div className="mt-1 flex flex-wrap items-center gap-2 pl-2"><SupportCaseForm sourceType="REQUEST" sourceId={t.id} />{t.status === "COMPLETED" && <Link href={`/talep/${t.id}`} className="text-xs font-bold text-signal hover:underline">Deneyimini puanla →</Link>}</div></div>) : <InlineEmpty icon={FileClock} title="Bu filtrede görev yok" desc="Başka bir durum seçebilir veya ilk talebini oluşturabilirsin." href="/talep/yeni" action="Hemen çağır" />}</div></PanelSection>
      <PanelSection title={`Yemek siparişleri (${orders.length})`} eyebrow="SİPARİŞ GEÇMİŞİ"><div className="space-y-3">{orders.length ? orders.map((o) => <div key={o.id}><FoodOrderTile order={o} /><div className="mt-1 flex flex-wrap items-center gap-2 pl-2"><SupportCaseForm sourceType="ORDER" sourceId={o.id} />{o.status === "DELIVERED" && <Link href={`/siparis/${o.id}`} className="text-xs font-bold text-signal hover:underline">İşletmeyi değerlendir →</Link>}</div></div>) : <InlineEmpty icon={ReceiptText} title="Bu filtrede sipariş yok" desc="Restoranları keşfet ve ilk siparişini oluştur." href="/yemek" action="Yemek keşfet" />}</div></PanelSection>
    </div><aside className="space-y-4"><div className="card p-5"><div className="flex items-center gap-2"><MessageCircle size={17} className="text-signal" /><h3 className="text-sm font-extrabold">Destek kayıtların</h3></div><p className="mt-1 text-xs text-ink/55">Yalnızca senin açtığın vakalar listelenir.</p><div className="mt-3 space-y-2">{cases.length ? cases.map((c) => <div key={c.id} className="rounded-xl bg-paper p-3"><div className="flex items-center justify-between gap-2"><span className="text-[11px] font-bold">{({ DELIVERY: "Teslimat", OTP: "Teslim kodu", CANCELLATION: "İptal", OTHER: "Diğer" } as Record<string, string>)[c.category] ?? c.category}</span><span className={`rounded-full px-2 py-0.5 text-[10px] font-bold ${c.status === "RESOLVED" ? "bg-mint/10 text-[#0d8759]" : "bg-sun/15 text-[#795400]"}`}>{c.status === "RESOLVED" ? "Çözüldü" : c.status === "IN_REVIEW" ? "İncelemede" : c.status === "REJECTED" ? "Reddedildi" : "Açık"}</span></div><div className="mt-1 text-[10px] text-ink/45">{dateTime(c.createdAt)} · {c.sourceType === "ORDER" ? "Sipariş" : "Görev"}</div>{c.resolution && <p className="mt-2 border-t border-line pt-2 text-xs text-ink/70">{c.resolution}</p>}</div>) : <p className="rounded-xl bg-paper p-4 text-xs text-ink/50">Henüz destek kaydın yok. Bir işlemde sorun yaşarsan ilgili karttan bildirim açabilirsin.</p>}</div></div><div className="card p-5"><div className="flex items-center gap-2 text-xs font-bold text-ink/70"><CheckCircle2 size={15} className="text-signal" /> Gerçek deneyim, gerçek puan</div><p className="mt-2 text-xs leading-relaxed text-ink/55">Puanlama yalnızca tamamlanan işlemden sonra ve 14 gün içinde açılır. Yorumunu ilk 48 saatte düzenleyebilirsin.</p><Link href="/destek" className="mt-3 inline-block text-xs font-bold text-signal hover:underline">Destek merkezi →</Link></div></aside></div>
  </>;
}
