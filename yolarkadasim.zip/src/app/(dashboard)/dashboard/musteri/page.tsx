import Link from "next/link";
import { ArrowRight, CalendarClock, ChevronRight, Heart, PackageCheck, Plus, Radar, ReceiptText, Route, Sparkles, WalletCards } from "lucide-react";
import { Avatar } from "@/components/ui";
import { DashboardHeading, DeliveryCode, FoodOrderTile, InlineEmpty, MetricCard, PanelSection, TaskTile } from "@/components/dashboard/Elements";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { customerOverview } from "@/lib/dashboard-data";
import { dateTime, money, ORDER_STATUS } from "@/lib/labels";

export const metadata = { title: "Müşteri Paneli" };

export default async function CustomerHome() {
  const session = await requireDashboardRole("CUSTOMER");
  const data = await customerOverview(session);
  const latest = data.activeTasks.find((t) => t.deliveryOtp && t.providerName);
  const first = session.user.name.split(" ")[0];
  return <>
    <DashboardHeading eyebrow="KİŞİSEL ALANIN" title={`Merhaba, ${first}. 👋`} desc="Yol arkadaşların, aktif teslimatların ve siparişlerin tek güvenli ekranda." action={<Link href="/talep/yeni" className="btn-primary"><Plus size={16} /> Yeni talep oluştur</Link>} />
    <section className="dash-hero road-pattern-dark relative mb-7 overflow-hidden rounded-[24px] p-6 text-white sm:p-8">
      <div className="relative z-10 grid gap-6 md:grid-cols-[1fr_auto] md:items-center"><div><span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1 text-[11px] font-bold ring-1 ring-white/10"><span className="h-1.5 w-1.5 rounded-full bg-mint" /> HİZMETLERİN ELİNİN ALTINDA</span><h2 className="mt-4 max-w-xl text-2xl font-black leading-tight tracking-tight sm:text-3xl">Nereye gidersen git,<br /><span className="text-signal">yanında bir yol arkadaşı var.</span></h2><p className="mt-3 max-w-lg text-sm text-white/60">Hemen çağır, sonraya randevu planla veya yemek sipariş et. Kimin getireceğini sen seç.</p><div className="mt-5 flex flex-wrap gap-2"><Link href="/talep/yeni" className="btn-primary btn-sm"><Route size={14} /> Hemen çağır</Link><Link href="/talep/yeni?mode=SCHEDULED" className="btn border border-white/15 bg-white/10 text-white hover:bg-white/20 btn-sm"><CalendarClock size={14} /> Randevu planla</Link><Link href="/yemek" className="btn border border-white/15 bg-white/10 text-white hover:bg-white/20 btn-sm">🍽️ Yemek keşfet</Link></div></div><div className="hidden h-40 w-40 items-center justify-center rounded-full border border-white/10 bg-white/[.035] ring-[22px] ring-white/[.025] lg:flex"><Radar size={72} strokeWidth={1} className="text-signal/80" /></div></div>
    </section>
    <div className="grid grid-cols-2 gap-3 sm:gap-4 xl:grid-cols-4">
      <MetricCard item={{ title: "Aktif görev", value: String(data.activeTasks.length), detail: "Kurye / yolculuk talepleri" }} icon={Route} />
      <MetricCard item={{ title: "Aktif sipariş", value: String(data.activeOrders.length), detail: "Hazırlanan veya yoldaki" }} icon={ReceiptText} accent="sky" />
      <MetricCard item={{ title: "Tamamlanan", value: String(data.completedCount), detail: "Gerçek teslimatlar" }} icon={PackageCheck} accent="mint" />
      <MetricCard item={{ title: "Toplam harcama", value: money(data.spentMinor), detail: "Tamamlanan işlemler" }} icon={WalletCards} accent="ink" />
    </div>
    <div className="mt-8 grid gap-7 xl:grid-cols-[minmax(0,1fr)_330px]">
      <div className="space-y-8">
        <PanelSection title="Yoldaki görevlerin" eyebrow="CANLI TAKİP" action={{ label: "Tüm talepler", href: "/dashboard/musteri/taleplerim" }}>
          <div className="space-y-3">{data.activeTasks.length ? data.activeTasks.slice(0, 3).map((t) => <TaskTile key={t.id} task={t} showOtp />) : <InlineEmpty icon={Route} title="Şu an aktif görev yok" desc="Bir paket göndermek ya da yolculuk planlamak için yeni talep oluştur." href="/talep/yeni" action="Yol arkadaşı bul" />}</div>
        </PanelSection>
        <PanelSection title="Aktif yemek siparişleri" eyebrow="MUTFAKTAN KAPINA" action={{ label: "Siparişlerim", href: "/siparislerim" }}>
          <div className="space-y-3">{data.activeOrders.length ? data.activeOrders.slice(0, 3).map((o) => <FoodOrderTile key={o.id} order={o} />) : <InlineEmpty icon={ReceiptText} title="Aktif yemek siparişi yok" desc="Bölgenizdeki işletmelerden menü, ücret ve teslimat bilgilerini görerek sipariş verin." href="/yemek" action="Restoranları keşfet" />}</div>
        </PanelSection>
        <PanelSection title="Son hareketler" action={{ label: "Tüm geçmiş", href: "/dashboard/musteri/gecmis" }}>
          <div className="card divide-y divide-line">{data.recentTasks.slice(0, 4).map((t) => <Link key={t.id} href={`/talep/${t.id}`} className="flex items-center gap-3 px-4 py-3 transition hover:bg-paper"><span className="flex h-9 w-9 items-center justify-center rounded-xl bg-signal/10 text-signal"><Route size={16} /></span><span className="min-w-0 flex-1"><b className="block font-mono text-xs">{t.code}</b><span className="block truncate text-xs text-ink/50">{t.pickup} → {t.dropoff} · {dateTime(t.createdAt)}</span></span><span className="text-right"><b className="block text-xs">{money(t.priceMinor)}</b><span className="text-[10px] text-ink/50">{t.status === "COMPLETED" ? "Tamamlandı" : t.status.startsWith("CANCELLED") ? "İptal" : "Aktif"}</span></span><ChevronRight size={13} className="text-signal" /></Link>)}{data.recentTasks.length === 0 && <p className="p-5 text-center text-xs text-ink/55">Henüz görev hareketi yok.</p>}</div>
        </PanelSection>
      </div>
      <aside className="space-y-4">
        {latest && <div className="card p-5"><div className="eyebrow">ATANAN YOL ARKADAŞIN</div><div className="mt-3 flex items-center gap-3"><Avatar name={latest.providerName!} hue={latest.providerHue ?? 20} size={48} status="AVAILABLE" /><div className="min-w-0"><b className="block truncate text-sm">{latest.providerName}</b><span className="text-xs text-ink/50">{latest.eta ? `${latest.eta} tahmini ETA` : "Görev onaylandı"}</span></div></div><div className="mt-4"><DeliveryCode code={latest.deliveryOtp!} /></div><Link href={`/talep/${latest.id}`} className="btn-ink btn-sm mt-4 w-full">Takip ekranını aç <ArrowRight size={14} /></Link></div>}
        <div className="card p-5"><div className="flex items-center justify-between"><h3 className="font-extrabold">Kısa yollar</h3><Sparkles size={16} className="text-signal" /></div><div className="mt-3 space-y-1.5">{[{ label: "Favori yol arkadaşları", href: "/dashboard/musteri/favorilerim", icon: Heart, detail: `${data.favoriteCount} favori` }, { label: "Harcama dökümü", href: "/dashboard/musteri/cuzdan", icon: WalletCards, detail: "Gerçek işlemler" }, { label: "Yemek siparişleri", href: "/siparislerim", icon: ReceiptText, detail: `${data.activeOrders.length} aktif` }].map(({ label, href, icon: Icon, detail }) => <Link key={href} href={href} className="flex items-center gap-3 rounded-xl p-2.5 transition hover:bg-paper"><Icon size={16} className="text-signal" /><span className="flex-1 text-xs font-bold">{label}</span><span className="text-[10px] text-ink/40">{detail}</span></Link>)}</div></div>
        <div className="rounded-2xl border border-line bg-white p-5"><div className="text-[11px] font-bold uppercase tracking-[.14em] text-ink/50">GÜVENLİK NOTU</div><p className="mt-2 text-xs leading-relaxed text-ink/60">Teslim kodunu yalnızca paketi teslim alırken paylaş. Kurye telefonun veya açık adresin herkese açık profilde görünmez.</p></div>
      </aside>
    </div>
  </>;
}
