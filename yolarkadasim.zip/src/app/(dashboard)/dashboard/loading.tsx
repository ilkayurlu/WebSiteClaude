export default function DashboardLoading() {
  return <div role="status" aria-live="polite" className="mx-auto max-w-6xl animate-pulse px-5 py-8">
    <div className="h-4 w-28 rounded-lg bg-paper-2" /><div className="mt-3 h-10 w-72 rounded-xl bg-paper-2" />
    <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">{Array.from({ length: 4 }, (_, i) => <div key={i} className="card h-32 bg-white/70" />)}</div>
    <div className="mt-7 grid gap-5 lg:grid-cols-[1fr_340px]"><div className="card h-80 bg-white/70" /><div className="card h-80 bg-white/70" /></div>
    <span className="sr-only">Panel yükleniyor</span>
  </div>;
}
