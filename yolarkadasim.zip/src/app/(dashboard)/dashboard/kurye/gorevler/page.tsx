import Link from "next/link";
import { ArrowRight, CalendarDays, CheckCircle2, PackageCheck } from "lucide-react";
import { DashboardHeading, InlineEmpty, PanelSection } from "@/components/dashboard/Elements";
import { ProviderTaskCard } from "@/components/dashboard/ProviderCards";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { providerOverview } from "@/lib/dashboard-data";
import { areaName } from "@/lib/geo";
import { dateTime, money } from "@/lib/labels";

export const metadata = { title: "Görevlerim" };
export default async function CourierTasks() {
  const s = await requireDashboardRole("PROVIDER");
  const d = await providerOverview(s);
  const past = d.tasks.filter((t) => !["CONFIRMED", "IN_PROGRESS"].includes(t.a.state));
  return <><DashboardHeading eyebrow="TESLİMAT YÖNETİMİ" title="Görevlerim" desc="Yalnızca kendi görevlerini görürsün. Alıcı adı maskeli ve rota genel bölge düzeyindedir; teslim kodunu müşteri söyler." action={<Link href="/dashboard/kurye/canli-panel" className="btn-primary"><ArrowRight size={15} /> Teklif havuzu</Link>} />
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_310px]"><div className="space-y-8"><PanelSection title={`Devam eden (${d.activeTasks.length})`} eyebrow="AKTİF TESLİMATLAR"><div className="space-y-4">{d.activeTasks.length ? d.activeTasks.map((t) => <ProviderTaskCard key={t.a.id} task={t} meId={s.user.id} />) : <InlineEmpty icon={PackageCheck} title="Devam eden görev yok" desc="Yeni teklif kabul ettiğinde görev burada görünür; aktif görev sürerken başka görev başlatılamaz." href="/dashboard/kurye/canli-panel" action="Canlı paneli aç" />}</div></PanelSection><PanelSection title="Geçmiş görevler" eyebrow="GÖREV DEFTERİ"><div className="card divide-y divide-line">{past.length ? past.map((t) => <Link key={t.a.id} href={`/talep/${t.r.id}`} className="flex flex-wrap items-center gap-3 px-4 py-3 text-xs transition hover:bg-paper"><span className={`flex h-8 w-8 items-center justify-center rounded-xl ${t.a.state === "COMPLETED" ? "bg-mint/10 text-[#0d8759]" : "bg-rose/10 text-rose"}`}><CheckCircle2 size={16} /></span><span className="min-w-0 flex-1"><b className="font-mono">{t.r.code}</b><span className="mt-0.5 block text-ink/50">{areaName(t.r.pickupArea)} → {areaName(t.r.dropoffArea)} · {dateTime(t.a.completedAt ?? t.a.cancelledAt ?? t.a.acceptedAt)}</span></span><span className="font-bold">{money(t.r.finalPriceMinor)}</span><span className={t.a.state === "COMPLETED" ? "font-bold text-[#0d8759]" : "font-bold text-rose"}>{t.a.state === "COMPLETED" ? "Tamamlandı" : "İptal"}</span></Link>) : <p className="p-6 text-center text-sm text-ink/50">Henüz tamamlanan veya iptal edilen görev yok.</p>}</div></PanelSection></div><aside className="space-y-4"><div className="card p-5"><CalendarDays size={18} className="text-signal" /><h3 className="mt-3 font-extrabold">Randevulu görevler</h3><p className="mt-1 text-xs text-ink/55">Onaylanan randevular görev listende planlanan saatle birlikte görünür.</p><Link href="/dashboard/kurye/filom" className="mt-3 inline-flex items-center gap-1 text-xs font-bold text-signal hover:underline">Filo vardiya planım <ArrowRight size={13} /></Link></div><div className="card p-5"><h3 className="font-extrabold">Teslim kodu</h3><p className="mt-2 text-xs leading-relaxed text-ink/55">Görevi başlat, teslim anında müşterideki 4 haneli kodu al ve doğrula. Kod doğru olmadan görev tamamlanmaz.</p></div></aside></div>
  </>;
}
