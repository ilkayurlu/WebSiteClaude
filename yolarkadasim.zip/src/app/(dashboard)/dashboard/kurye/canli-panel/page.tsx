import Link from "next/link";
import { Activity, ArrowRight, BellRing, Radio, ShieldCheck, Wifi } from "lucide-react";
import { ProviderStatusToggle } from "@/components/dashboard/ProviderStatusToggle";
import { serverStatusToUi } from "@/lib/provider-status-ui";
import { DashboardHeading, InlineEmpty, MetricCard, PanelSection } from "@/components/dashboard/Elements";
import { ProviderOfferCard } from "@/components/dashboard/ProviderCards";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { providerOverview } from "@/lib/dashboard-data";
import { sweepExpired } from "@/lib/engine";
import { areaName } from "@/lib/geo";

export const metadata = { title: "Canlı Panel" };
export default async function LiveCourierPanel() {
  const s = await requireDashboardRole("PROVIDER");
  await sweepExpired();
  const d = await providerOverview(s);
  if (!d.provider) return null;
  const p = d.provider;
  return <><DashboardHeading eyebrow="VARDİYA & TEKLİFLER" title="Canlı panel" desc="Durumunu yönet; yeni teklifler canlı sayaçla düşer. Süresi dolan veya reddedilen teklif otomatik olarak sıradaki uygun sağlayıcıya geçer." action={<Link href="/dashboard/kurye/gorevler" className="btn-ghost"><ArrowRight size={14} /> Görevlerim</Link>} />
    <div className="dash-hero road-pattern-dark flex flex-wrap items-center justify-between gap-5 rounded-[24px] p-6 text-white"><div><div className="flex items-center gap-2 text-xs font-bold text-white/50"><Radio size={15} className="text-signal" /> ANLIK MÜSAİTLİK</div><h2 className="mt-2 text-xl font-black">Vardiyan hazır mı?</h2><p className="mt-1 max-w-md text-xs leading-relaxed text-white/60">Çevrimiçi olduğunda tarayıcı konum izniyle eşleşme doğruluğu artar; konumun müşterilerle paylaşılmaz, yalnızca yaklaşık varış bandı gösterilir.</p></div><ProviderStatusToggle initialStatus={serverStatusToUi(p.status)} serverStatus={p.status} /></div>
    <div className="mt-5 grid gap-3 sm:grid-cols-3"><MetricCard icon={BellRing} item={{ title: "Bekleyen teklif", value: String(d.offers.length), detail: "60 saniye yanıt süresi" }} /><MetricCard icon={Activity} accent="sky" item={{ title: "Aktif görev", value: String(d.activeTasks.length), detail: "Onaylanmış görevler" }} /><MetricCard icon={Wifi} accent="mint" item={{ title: "Çalışma bölgesi", value: String(p.serviceAreas.length), detail: p.serviceAreas.slice(0, 3).map(areaName).join(" · ") }} /></div>
    <div className="mt-8 grid gap-7 xl:grid-cols-[minmax(0,1fr)_320px]"><PanelSection title="Teklif havuzu" eyebrow="ANLIK EŞLEŞTİRME"><div className="grid gap-4 lg:grid-cols-2">{d.offers.length ? d.offers.map((o) => <ProviderOfferCard key={o.c.id} offer={o} />) : <div className="lg:col-span-2"><InlineEmpty icon={BellRing} title={p.status === "AVAILABLE" ? "Henüz yeni teklif yok" : "Teklif almak için çevrimiçi ol"} desc={p.status === "AVAILABLE" ? "Yeni bir müşteri seni seçtiğinde ya da sistem eşleştirdiğinde burada anında belirecek." : "Vardiyanı açıp hizmet bölgelerini kontrol et; yeni teklifler müsait sağlayıcılara gönderilir."} href="/dashboard/kurye/profil-yonetimi" action="Hizmet bölgelerini yönet" /></div>}</div>{d.pendingFleet.length > 0 && <div className="card mt-4 p-4 text-xs text-ink/60">🏢 {d.pendingFleet.length} teklif önce filo yöneticinin onayını bekliyor; onaylanırsa göreve atanırsın.</div>}</PanelSection><aside className="space-y-4"><div className="card p-5"><div className="flex items-center gap-2 text-sm font-extrabold"><ShieldCheck size={16} className="text-signal" /> Eşleştirme nasıl çalışır?</div><ol className="mt-3 space-y-2 text-xs leading-relaxed text-ink/60"><li><b>1.</b> Bölge, araç ve müsaitlik koşulları doğrulanır.</li><li><b>2.</b> Mesafe bandı, iş yükü ve gerçek puan değerlendirir.</li><li><b>3.</b> Teklifi 60 saniyede kabul veya reddedebilirsin.</li><li><b>4.</b> Kabul edildiğinde müşteriye “Onaylandı” bildirimi gider.</li></ol></div><div className="card p-5 text-xs text-ink/60">📍 Ham konumun müşteriye gösterilmez. Yalnızca yaklaşık varış süresi ve mesafe bandı paylaşılır.</div></aside></div>
  </>;
}
