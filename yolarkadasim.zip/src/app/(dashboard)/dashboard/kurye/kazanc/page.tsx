import Link from "next/link";
import { ArrowRight, Banknote, ChartNoAxesCombined, Info, ReceiptText, TrendingUp } from "lucide-react";
import { DashboardHeading, InlineEmpty, MetricCard, PanelSection } from "@/components/dashboard/Elements";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { providerOverview, startOfTodayIstanbul } from "@/lib/dashboard-data";
import { areaName } from "@/lib/geo";
import { dateTime, money } from "@/lib/labels";
import { PayoutAccountForm } from "@/components/dashboard/PayoutAccountForm";
import { getOwnPayoutAccount } from "@/lib/payouts";
import { db } from "@/db";
import { providerEarnings, providers } from "@/db/schema";
import { and, eq, isNull, sql } from "drizzle-orm";

export const metadata = { title: "Kazanç Dökümü" };
export default async function CourierEarnings() {
  const s = await requireDashboardRole("PROVIDER");
  const d = await providerOverview(s);
  const today = startOfTodayIstanbul();
  const days = Array.from({ length: 7 }, (_, idx) => {
    const start = new Date(today.getTime() - (6 - idx) * 86400000);
    const end = new Date(start.getTime() + 86400000);
    return { date: start, total: d.completed.filter((t) => t.a.completedAt && t.a.completedAt >= start && t.a.completedAt < end).reduce((n, t) => n + (t.r.finalPriceMinor ?? 0), 0) };
  });
  const peak = Math.max(...days.map((x) => x.total), 1);
  const [me] = await db.select({ fleetId: providers.fleetId }).from(providers).where(eq(providers.id, s.providerId!)).limit(1);
  const independent = !me?.fleetId;
  const [ledger] = await db.select({
    net: sql<number>`coalesce(sum(${providerEarnings.netMinor}),0)::bigint`,
    paid: sql<number>`coalesce(sum(${providerEarnings.netMinor}) filter (where ${providerEarnings.status}='PAID'),0)::bigint`,
    commission: sql<number>`coalesce(sum(${providerEarnings.commissionMinor}),0)::bigint`,
  }).from(providerEarnings).where(and(eq(providerEarnings.providerId, s.providerId!), isNull(providerEarnings.fleetId)));
  const account = independent ? await getOwnPayoutAccount("COURIER", s.providerId!) : null;
  return <><DashboardHeading eyebrow="ŞEFFAF DÖKÜM" title="Kazanç görünümü" desc="Bunlar tamamlanan görevlerin brüt tutarlarıdır. Finans entegrasyonu bağlı olmadığı için gerçek hakediş, komisyon veya ödeme alındı iddiasında bulunmuyoruz." action={<Link href="/dashboard/kurye/gorevler" className="btn-ghost btn-sm">Görevlere dön <ArrowRight size={14} /></Link>} />
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4"><MetricCard icon={Banknote} item={{ title: "Bugün", value: money(d.todayMinor), detail: "Tamamlanan görev" }} /><MetricCard icon={TrendingUp} accent="mint" item={{ title: "Bu hafta", value: money(d.weekMinor), detail: "İstanbul saatiyle" }} /><MetricCard icon={ChartNoAxesCombined} accent="sky" item={{ title: "Toplam brüt tutar", value: money(d.lifetimeMinor), detail: "Tüm tamamlanan görevler" }} /><MetricCard icon={ReceiptText} accent="ink" item={{ title: "İşlem", value: String(d.completed.length), detail: "Teslim koduyla doğrulanan" }} /></div>
    <div className="mt-7 grid gap-6 xl:grid-cols-[minmax(0,1fr)_310px]"><div className="space-y-7"><PanelSection title="Son 7 gün" eyebrow="GÖREV TUTARLARI"><div className="card p-5"><div className="dash-chart flex h-44 items-end justify-between gap-2 border-b border-line pb-1">{days.map((x) => <div key={x.date.toISOString()} className="flex h-full flex-1 flex-col items-center justify-end gap-2"><div className="w-full max-w-12 rounded-t-lg bg-signal/75 transition hover:bg-signal" style={{ height: x.total ? `${Math.max(8, x.total / peak * 135)}px` : "3px" }} title={money(x.total)} /><span className="text-[10px] font-bold text-ink/45">{new Intl.DateTimeFormat("tr-TR", { weekday: "short", timeZone: "Europe/Istanbul" }).format(x.date)}</span></div>)}</div><p className="mt-4 text-xs text-ink/50">En yüksek günlük tutar: <b className="text-ink">{money(peak === 1 ? 0 : peak)}</b></p></div></PanelSection><PanelSection title="Tamamlanan görev dökümü" eyebrow="BRÜT TUTAR"><div className="card divide-y divide-line">{d.completed.length ? d.completed.slice(0, 40).map((t) => <Link href={`/talep/${t.r.id}`} key={t.a.id} className="flex items-center gap-3 px-4 py-3 text-xs transition hover:bg-paper"><span className="flex h-8 w-8 items-center justify-center rounded-xl bg-signal/10 text-signal"><ReceiptText size={15} /></span><span className="min-w-0 flex-1"><b className="font-mono">{t.r.code}</b><span className="mt-0.5 block truncate text-ink/50">{areaName(t.r.pickupArea)} → {areaName(t.r.dropoffArea)} · {dateTime(t.a.completedAt)}</span></span><b className="text-sm">{money(t.r.finalPriceMinor)}</b></Link>) : <div className="p-4"><InlineEmpty icon={ReceiptText} title="Henüz tamamlanan görev yok" desc="Görev teslim koduyla tamamlandığında tutar burada görünür." href="/dashboard/kurye/canli-panel" action="Canlı panele git" /></div>}</div></PanelSection></div><aside className="space-y-4">{independent ? <><PayoutAccountForm beneficiaryType="COURIER" beneficiaryId={s.providerId!} current={account} /><div className="card p-5"><h3 className="text-sm font-extrabold">Hakediş defteri</h3><div className="mt-3 space-y-1.5 text-sm"><div className="flex justify-between"><span className="text-ink/55">Net hakediş</span><b>{money(Number(ledger?.net ?? 0))}</b></div><div className="flex justify-between"><span className="text-ink/55">Platform komisyonu</span><b className="text-signal">−{money(Number(ledger?.commission ?? 0))}</b></div><div className="flex justify-between"><span className="text-ink/55">Ödeme emri verilen</span><b className="text-[#0c8a5a]">{money(Number(ledger?.paid ?? 0))}</b></div></div><p className="mt-2 text-[11px] text-ink/45">Ödeme emri = muhasebeye iletilen kayıt; banka transferi referansla ayrıca yürütülür.</p></div></> : <div className="card p-5 text-xs text-ink/60"><b className="text-ink">Filo üyesisiniz.</b> Hakedişleriniz filonuzun ödeme hesabına toplu olarak aktarılır; IBAN tanımını filo yöneticiniz yapar.</div>}<div className="card-ink road-pattern-dark p-5"><Info size={19} className="text-signal" /><h3 className="mt-3 font-extrabold">Hakediş hakkında</h3><p className="mt-2 text-xs leading-relaxed text-white/65">Bu ekran fiyat geçmişini gösterir; banka ödemesi, kesinti, vergi ve komisyon hesaplaması aktif değildir. “Ödendi” şeklinde sahte durum gösterilmez.</p><Link href="/destek" className="mt-4 inline-block text-xs font-bold text-signal hover:underline">Finans sorusu için destek →</Link></div><div className="card p-5"><h3 className="text-sm font-extrabold">Nasıl hesaplanır?</h3><p className="mt-2 text-xs leading-relaxed text-ink/55">Sunucuda hesaplanan açılış ve mesafe ücreti, talep kabulünde kesinleşir. Yalnızca <b>COMPLETED</b> atamalar burada yer alır.</p></div></aside></div>
  </>;
}
