import Link from "next/link";
import { desc, eq } from "drizzle-orm";
import { BadgeCheck, CalendarClock, Camera, ExternalLink, MapPin } from "lucide-react";
import { db } from "@/db";
import { mediaPosts, providerDocuments, providers } from "@/db/schema";
import { ProviderProfileForm } from "@/components/ProfileForm";
import { DocumentUploadPanel } from "@/components/dashboard/DocumentUploadPanel";
import { ServiceZoneWizard } from "@/components/provider/ServiceZoneWizard";
import { MediaStudio } from "@/components/media-client";
import { DashboardHeading, InlineEmpty, PanelSection } from "@/components/dashboard/Elements";
import { requireDashboardRole } from "@/lib/dashboard-auth";
import { providerFleetData } from "@/lib/dashboard-data";
import { dateTime, VEHICLES } from "@/lib/labels";

export const metadata = { title: "Profil Yönetimi" };
export default async function CourierProfileManagement() {
  const s = await requireDashboardRole("PROVIDER");
  const [p] = await db.select().from(providers).where(eq(providers.id, s.providerId!)).limit(1);
  if (!p) return <InlineEmpty icon={BadgeCheck} title="Profil bulunamadı" desc="Hizmet sağlayıcı profiliniz henüz açılmamış. Destek ekibine başvurun." href="/destek" action="Destek al" />;
  const docRows = await db.select().from(providerDocuments).where(eq(providerDocuments.providerId, p.id));
  const docs = (["LICENSE", "REGISTRATION", "CRIMINAL_RECORD"] as const).map((t) => { const d = docRows.find((x) => x.docType === t); return { docType: t, status: (d?.status ?? null) as "SUBMITTED" | "APPROVED" | "REJECTED" | null, note: d?.reviewNote ?? null }; });
  const [posts, fleet] = await Promise.all([
    db.select().from(mediaPosts).where(eq(mediaPosts.ownerId, p.id)).orderBy(desc(mediaPosts.createdAt)).limit(30),
    providerFleetData(s),
  ]);
  const safeProfile = { displayName: p.displayName, headline: p.headline, bio: p.bio, vehicleLabel: p.vehicleLabel, vehicleType: p.vehicleType, serviceTypes: p.serviceTypes, serviceAreas: p.serviceAreas, highlights: p.highlights, acceptsInstant: p.acceptsInstant, acceptsScheduled: p.acceptsScheduled, acceptsRental: p.acceptsRental, rentalHourlyMinor: p.rentalHourlyMinor, baseFareMinor: p.baseFareMinor, perKmMinor: p.perKmMinor, hue: p.hue };
  const safePosts = posts.map((m) => ({ id: m.id, caption: m.caption, publicUrl: m.publicUrl, status: m.status, viewCount: m.viewCount, favoriteCount: m.favoriteCount, createdAt: m.createdAt, moderationReason: m.moderationReason }));
  const upcoming = fleet.shifts.filter((x) => x.status === "PLANNED" && x.endsAt > new Date());
  return <><DashboardHeading eyebrow="VİTRİNİNİ OLUŞTUR" title="Profil yönetimi" desc="Hizmet bölgelerini, araç tanımını, ücretlerini ve tanıtım medyanı güncelle. Telefon, kimlik ve ham konum vitrinde hiçbir zaman gösterilmez." action={<Link href={`/kuryeler/${p.slug}`} className="btn-ghost btn-sm"><ExternalLink size={14} /> Herkese açık görünüm</Link>} />
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_310px]"><div className="space-y-7"><ServiceZoneWizard zones={p.serviceAreas} persist /><DocumentUploadPanel docs={docs} verified={p.isVerified} /><ProviderProfileForm provider={safeProfile} /><PanelSection title="Portföy & medya" eyebrow="MODERASYONLU VİTRİN"><MediaStudio items={safePosts} /></PanelSection></div><aside className="space-y-4"><div className="card p-5"><BadgeCheck size={19} className={p.isVerified ? "text-mint" : "text-sun"} /><h3 className="mt-2 font-extrabold">{p.isVerified ? "Doğrulanmış profil" : "Doğrulama bekliyor"}</h3><p className="mt-2 text-xs text-ink/55">Doğrulama rozeti yalnızca operasyon onayından sonra görünür. Belgeler herkese açık profilde bulunmaz.</p></div><div className="card p-5"><MapPin size={19} className="text-signal" /><h3 className="mt-2 font-extrabold">Araç & bölgeler</h3><p className="mt-2 text-xs text-ink/60">{VEHICLES[p.vehicleType]?.label ?? p.vehicleType} · {p.serviceAreas.length} genel bölge. Araç türü değişikliği doğrulama gerektirir; şimdilik yalnızca araç etiketini güncelleyebilirsin.</p></div><div className="card p-5"><CalendarClock size={18} className="text-signal" /><h3 className="mt-2 font-extrabold">Planlanan vardiyalar</h3>{upcoming.length ? <div className="mt-3 space-y-2">{upcoming.slice(0, 3).map((sh) => <p key={sh.id} className="rounded-lg bg-paper p-2 text-xs">{dateTime(sh.startsAt)} → {dateTime(sh.endsAt)}</p>)}</div> : <p className="mt-2 text-xs text-ink/55">Yaklaşan filo vardiyası yok. Kendi müsaitlik anahtarın canlı panelde.</p>}<Link href="/dashboard/kurye/filom" className="mt-3 inline-block text-xs font-bold text-signal hover:underline">Filom ve takvim →</Link></div></aside></div>
  </>;
}
