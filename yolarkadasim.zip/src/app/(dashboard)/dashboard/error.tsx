"use client";
import Link from "next/link";
import { AlertTriangle, RotateCcw } from "lucide-react";
export default function DashboardError({ reset }: { error: Error; reset: () => void }) {
  return <div className="mx-auto max-w-lg px-5 py-20 text-center"><div className="card road-pattern p-8"><AlertTriangle size={28} className="mx-auto text-signal" /><h2 className="mt-4 text-2xl font-black">Panel yüklenemedi</h2><p className="mt-2 text-sm text-ink/60">Bir şeyler ters gitti. Verileriniz güvende; lütfen tekrar deneyin.</p><div className="mt-6 flex justify-center gap-2"><button onClick={reset} className="btn-primary"><RotateCcw size={15} /> Tekrar dene</button><Link href="/destek" className="btn-ghost">Destek al</Link></div></div></div>;
}
