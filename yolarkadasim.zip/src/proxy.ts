import { createHash } from "node:crypto";
import { NextResponse, type NextRequest } from "next/server";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { authSessions, users } from "@/db/schema";
import { dashboardHome, pathRole, roleAllowed } from "@/lib/dashboard-routes";
import { SESSION_COOKIE } from "@/lib/session-constants";

/** Next.js 16: middleware.ts yerine proxy.ts. Token ve rol DB'den doğrulanır; sayfalar ayrıca kontrol eder. */
export async function proxy(request: NextRequest) {
  const token = request.cookies.get(SESSION_COOKIE)?.value;
  const signIn = () => {
    const target = new URL("/giris", request.url);
    target.searchParams.set("next", request.nextUrl.pathname);
    return NextResponse.redirect(target);
  };
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return signIn();

  try {
    const hash = createHash("sha256").update(token).digest("hex");
    const [row] = await db
      .select({ role: users.role, suspended: users.isSuspended })
      .from(authSessions)
      .innerJoin(users, eq(users.id, authSessions.userId))
      .where(and(eq(authSessions.tokenHash, hash), gt(authSessions.expiresAt, new Date())))
      .limit(1);

    if (!row || row.suspended) {
      const response = signIn();
      response.cookies.delete(SESSION_COOKIE);
      return response;
    }
    if (request.nextUrl.pathname === "/dashboard") return NextResponse.redirect(new URL(dashboardHome(row.role), request.url));
    // /admin: yalnızca operasyon rolleri; çekirdek sayfalarda SUPER_ADMIN sayfa düzeyinde ayrıca zorunlu.
    if (request.nextUrl.pathname === "/admin" || request.nextUrl.pathname.startsWith("/admin/")) {
      if (row.role !== "ADMIN" && row.role !== "SUPER_ADMIN") return NextResponse.redirect(new URL(dashboardHome(row.role), request.url));
      const moderationOnly = ["/admin/degerlendirmeler", "/admin/medya-moderasyon", "/admin/raporlanan-icerikler", "/admin/basvurular", "/admin/audit"];
      if (row.role === "ADMIN" && !moderationOnly.some((p) => request.nextUrl.pathname.startsWith(p))) return NextResponse.redirect(new URL("/dashboard/admin", request.url));
    }
    const expected = pathRole(request.nextUrl.pathname);
    if (expected && !roleAllowed(row.role, expected)) return NextResponse.redirect(new URL(dashboardHome(row.role), request.url));
    return NextResponse.next();
  } catch {
    return new NextResponse("Kimlik doğrulama şu anda kullanılamıyor. Lütfen tekrar deneyin.", {
      status: 503,
      headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" },
    });
  }
}

export const config = {
  matcher: [
    "/dashboard/:path*", "/taleplerim", "/siparislerim", "/sepet", "/panel/:path*", "/filo", "/isletme/:path*",
    "/admin", "/admin/:path*", "/mesajlar", "/talep/:path*", "/siparis/:path*",
  ],
};
