import Link from "next/link";
import type { ReactNode } from "react";
import { PROVIDER_STATUS, REQUEST_STATUS, VEHICLES } from "@/lib/labels";

const STATUS_BADGE_LABEL: Record<string, string> = {
  AVAILABLE: "Çevrimiçi",
  BUSY: "Meşgul",
  ON_TASK: "Görevde",
  PAUSED: "Mola",
  OFFLINE: "Çevrimdışı",
  SUSPENDED: "Hizmet dışı",
};

/** Durum rozeti doğrudan avatarın sağ üst köşesinde: çevrimiçi = yanıp sönen mint, meşgul = sabit turuncu, çevrimdışı = mat gri. */
export function Avatar({ name, hue = 20, size = 48, status }: { name: string; hue?: number; size?: number; status?: string }) {
  const initials = name
    .split(" ")
    .map((x) => x[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  const online = status === "AVAILABLE";
  const busy = status === "BUSY" || status === "ON_TASK" || status === "PAUSED";
  const badge = online
    ? "pulse-dot bg-mint shadow-[0_0_8px_#10B981]"
    : busy
      ? "bg-signal"
      : "bg-white/30";
  const dot = Math.max(10, Math.round(size * 0.24));
  return (
    <div className="relative inline-block" style={{ width: size, height: size }}>
      <div
        className="flex h-full w-full items-center justify-center rounded-full font-black text-white ring-4 ring-white"
        style={{
          background: `linear-gradient(135deg, hsl(${hue} 85% 58%), hsl(${(hue + 40) % 360} 75% 40%))`,
          fontSize: size * 0.36,
        }}
      >
        {initials}
      </div>
      {status && (
        <span
          role="img"
          aria-label={STATUS_BADGE_LABEL[status] ?? status}
          title={STATUS_BADGE_LABEL[status] ?? status}
          className={`absolute -top-1 -right-1 z-10 block rounded-full ring-2 ring-white ${badge}`}
          style={{ width: dot, height: dot }}
        />
      )}
    </div>
  );
}

export function Stars({ value, count, size = "sm" }: { value: number; count?: number; size?: "sm" | "lg" }) {
  if (!count) return <span className="chip !border-dashed !text-ink/60">✦ Yeni sağlayıcı</span>;
  return (
    <span className={`inline-flex items-center gap-1 font-bold ${size === "lg" ? "text-lg" : "text-sm"}`}>
      <span className="text-sun">★</span>
      {value.toFixed(1).replace(".", ",")}
      <span className="font-medium text-ink/45">({count})</span>
    </span>
  );
}

export function StarRow({ value }: { value: number }) {
  return (
    <span className="tracking-tight text-sun" aria-label={`${value} yıldız`}>
      {"★".repeat(value)}
      <span className="text-ink/15">{"★".repeat(5 - value)}</span>
    </span>
  );
}

export function Pill({ tone, children, className = "" }: { tone: string; children: ReactNode; className?: string }) {
  return <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold tone-${tone} ${className}`}>{children}</span>;
}

export function ProviderStatusPill({ status }: { status: string }) {
  const s = PROVIDER_STATUS[status] ?? { label: status, tone: "slate" };
  return (
    <Pill tone={s.tone}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" />
      {s.label}
    </Pill>
  );
}

export function RequestStatusPill({ status }: { status: string }) {
  const s = REQUEST_STATUS[status] ?? { label: status, tone: "slate" };
  return <Pill tone={s.tone}>{s.label}</Pill>;
}

export function VehicleChip({ type, label }: { type: string; label?: string | null }) {
  const v = VEHICLES[type];
  return (
    <span className="chip">
      <span>{v?.icon}</span>
      {label ?? v?.label ?? type}
    </span>
  );
}

export function EmptyState({
  icon = "🧭",
  title,
  description,
  actions,
}: {
  icon?: string;
  title: string;
  description?: string;
  actions?: { label: string; href: string; primary?: boolean }[];
}) {
  return (
    <div className="card road-pattern flex flex-col items-center px-6 py-14 text-center">
      <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-white text-2xl shadow-sm ring-1 ring-line" aria-hidden="true">{icon}</div>
      <h3 className="text-lg font-extrabold">{title}</h3>
      {description && <p className="mt-1.5 max-w-md text-sm text-ink/60">{description}</p>}
      {actions && (
        <div className="mt-5 flex flex-wrap justify-center gap-2">
          {actions.map((a) => (
            <Link key={a.href + a.label} href={a.href} className={a.primary ? "btn-primary" : "btn-ghost"}>
              {a.label}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

export function SectionHead({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: ReactNode }) {
  return (
    <div className="mb-5 flex items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="eyebrow mb-1">{eyebrow}</div>}
        <h2 className="text-2xl font-black tracking-tight sm:text-3xl">{title}</h2>
      </div>
      {action}
    </div>
  );
}

export function Stat({ label, value, sub }: { label: string; value: ReactNode; sub?: string }) {
  return (
    <div className="card p-4">
      <div className="text-[11px] font-bold uppercase tracking-wider text-ink/50">{label}</div>
      <div className="mt-1 text-2xl font-black tracking-tight">{value}</div>
      {sub && <div className="mt-0.5 text-xs text-ink/50">{sub}</div>}
    </div>
  );
}
