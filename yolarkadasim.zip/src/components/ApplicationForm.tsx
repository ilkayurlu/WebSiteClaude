"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { ServiceZoneWizard } from "@/components/provider/ServiceZoneWizard";
import { api } from "./client";

export function ApplicationForm({ kind }: { kind: "RESTAURANT" | "FLEET" }) {
  const router = useRouter();
  const [f, setF] = useState({ name: "", contactName: "", email: "", phone: "", city: "İstanbul", description: "", taxNo: "", areas: [] as string[] });
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [busy, start] = useTransition();
  const set = (k: keyof typeof f, v: unknown) => setF((p) => ({ ...p, [k]: v }));

  function submit() {
    start(async () => {
      try {
        setErr(null);
        const r = await api<{ message: string; status: string }>("/api/applications", "POST", { kind, ...f, phone: f.phone || undefined, taxNo: f.taxNo || undefined, description: f.description || undefined });
        setDone(r.message);
        router.refresh();
      } catch (e) {
        setErr((e as Error).message);
      }
    });
  }

  if (done) {
    return (
      <div className="card road-pattern p-10 text-center">
        <div className="text-3xl">✅</div>
        <h2 className="mt-2 text-2xl font-black">Başvurunuz alındı</h2>
        <p className="mt-2 text-ink/65">{done}</p>
        <div className="mt-5 flex justify-center gap-2">
          <button type="button" className="btn-ghost" onClick={() => { setDone(null); setF({ name: "", contactName: "", email: "", phone: "", city: "İstanbul", description: "", taxNo: "", areas: [] }); }}>Yeni başvuru</button>
          <a href="/yemek" className="btn-primary">Yemek sayfasına dön</a>
        </div>
      </div>
    );
  }

  return (
    <div className="card p-6">
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label className="label" htmlFor="an">{kind === "FLEET" ? "Filo adı" : "İşletme adı"}</label><input id="an" className="input" maxLength={80} value={f.name} onChange={(e) => set("name", e.target.value)} /></div>
        <div><label className="label" htmlFor="ac">Yetkili adı soyadı</label><input id="ac" className="input" maxLength={80} value={f.contactName} onChange={(e) => set("contactName", e.target.value)} /></div>
        <div><label className="label" htmlFor="ae">Kurumsal e-posta</label><input id="ae" type="email" className="input" maxLength={160} value={f.email} onChange={(e) => set("email", e.target.value)} /></div>
        <div><label className="label" htmlFor="ap">Telefon (opsiyonel)</label><input id="ap" className="input" maxLength={32} value={f.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+90 …" /></div>
        <div><label className="label" htmlFor="aci">Şehir</label><input id="aci" className="input" maxLength={60} value={f.city} onChange={(e) => set("city", e.target.value)} /></div>
        <div><label className="label" htmlFor="at">Vergi no (opsiyonel)</label><input id="at" className="input" maxLength={20} value={f.taxNo} onChange={(e) => set("taxNo", e.target.value)} /></div>
      </div>
      <div className="mt-4">
        <ServiceZoneWizard
          zones={f.areas}
          onChange={(zones) => set("areas", zones)}
          title="Hizmet vereceğiniz bölgeler"
          description="İl seçin, ilçeleri işaretleyin; seçimler başvurunuzla birlikte gönderilir."
        />
      </div>
      <div className="mt-4">
        <label className="label" htmlFor="ad">{kind === "FLEET" ? "Filo hakkında" : "İşletme hakkında"}</label>
        <textarea id="ad" className="input min-h-28" maxLength={2000} value={f.description} onChange={(e) => set("description", e.target.value)} placeholder={kind === "FLEET" ? "Araç sayısı, hizmet türleri, çalışma saatleri…" : "Mutfak türü, kapasite, paketleme standardı…"} />
      </div>
      {err && <div className="mt-3 rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
      <button type="button" className="btn-primary mt-5" disabled={busy || !f.name || !f.contactName || !f.email || f.areas.length === 0} onClick={submit}>
        {busy ? "Gönderiliyor…" : "Başvuruyu gönder"}
      </button>
      <p className="mt-2 text-[11px] text-ink/45">Başvurunuz denetim kaydına alınır. Telefon ve vergi bilgisi herkese açık profilde gösterilmez.</p>
    </div>
  );
}
