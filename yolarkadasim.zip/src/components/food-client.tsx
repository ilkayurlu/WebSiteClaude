"use client";

import Image from "next/image";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState, useTransition } from "react";
import { ALLERGENS, money } from "@/lib/labels";
import { CascadingAddressSelect, EMPTY_ADDRESS, type FullAddress } from "./order/CascadingAddressSelect";
import type { MenuProduct } from "@/lib/food";
import { api } from "./client";

/* ---------- Ürün seçenekleri + sepete ekleme ---------- */
export function AddToCart({ restaurantId, product, closed, restaurantName }: { restaurantId: string; product: MenuProduct; closed: boolean; restaurantName: string }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [qty, setQty] = useState(1);
  const [note, setNote] = useState("");
  const [sel, setSel] = useState<Record<string, string[]>>({});
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [busy, start] = useTransition();
  const soldOut = product.stock < 1;

  const unit = useMemo(() => {
    const base = product.discountPriceMinor ?? product.priceMinor;
    const delta = product.groups.reduce((s, g) => s + g.options.filter((o) => (sel[g.id] ?? []).includes(o.id)).reduce((x, o) => x + o.priceDeltaMinor, 0), 0);
    return base + delta;
  }, [product, sel]);

  useEffect(() => {
    const missing: Record<string, string[]> = {};
    for (const g of product.groups) {
      const dflt = g.options.find((o) => o.isDefault);
      missing[g.id] = dflt ? [dflt.id] : [];
    }
    setSel(missing);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [product.id, open]);

  const toggle = (gid: string, oid: string, max: number) => {
    setSel((prev) => {
      const cur = prev[gid] ?? [];
      const has = cur.includes(oid);
      const next = has ? cur.filter((x) => x !== oid) : max > 1 ? [...cur, oid] : [oid];
      return { ...prev, [gid]: next.slice(0, max) };
    });
  };

  const missingRequired = product.groups.filter((g) => g.required && (sel[g.id] ?? []).length < Math.max(1, g.minSelect));

  function submit() {
    setErr(null);
    setOk(null);
    start(async () => {
      try {
        const opts = Object.values(sel).flat();
        await api("/api/cart/items", "POST", { restaurantId, productId: product.id, qty, optionIds: opts, note: note || undefined });
        setOk("Sepete eklendi ✓");
        setOpen(false);
        setQty(1);
        setNote("");
        router.refresh();
        setTimeout(() => setOk(null), 2500);
      } catch (e) {
        setErr((e as Error).message);
      }
    });
  }

  return (
    <>
      <button type="button" disabled={soldOut || closed} onClick={() => setOpen(true)} className={`btn-sm ${soldOut || closed ? "btn border border-dashed border-line text-ink/35" : "btn-add"}`}>
        {soldOut ? "Tükendi" : closed ? "Kapalı" : "＋ Sepete"}
      </button>
      {ok && <div className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2 rounded-full bg-mint px-4 py-2 text-sm font-bold text-white shadow-xl">{ok}</div>}
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 p-0 backdrop-blur-sm sm:items-center sm:p-6" role="dialog" aria-modal="true" onClick={() => setOpen(false)}>
          <div className="fade-up max-h-[92vh] w-full max-w-lg overflow-auto rounded-t-3xl bg-white sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            {product.imageUrl && (
              <div className="relative h-40 w-full">
                <Image src={product.imageUrl} alt={product.name} fill className="object-cover" sizes="(max-width:640px) 100vw, 512px" />
              </div>
            )}
            <div className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h3 className="text-xl font-black tracking-tight">{product.name}</h3>
                  <p className="mt-1 text-sm text-ink/60">{product.description}</p>
                </div>
                <button type="button" aria-label="Kapat" onClick={() => setOpen(false)} className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-paper text-lg hover:bg-paper-2">✕</button>
              </div>

              {product.groups.map((g) => (
                <fieldset key={g.id} className="mt-4">
                  <legend className="mb-2 flex items-center gap-2 text-sm font-bold">
                    {g.name}
                    {g.required ? <span className="rounded-full bg-rose/10 px-2 py-0.5 text-[10px] font-bold text-rose">Zorunlu</span> : <span className="text-[10px] font-medium text-ink/45">opsiyonel · en fazla {g.maxSelect}</span>}
                  </legend>
                  <div className="grid gap-1.5">
                    {g.options.map((o) => {
                      const checked = (sel[g.id] ?? []).includes(o.id);
                      return (
                        <label key={o.id} className={`flex cursor-pointer items-center justify-between rounded-xl border px-3 py-2 text-sm transition ${checked ? "border-signal bg-signal/[0.05]" : "border-line hover:border-ink/25"}`}>
                          <span className="flex items-center gap-2">
                            <input type={g.maxSelect > 1 ? "checkbox" : "radio"} name={g.id} checked={checked} onChange={() => toggle(g.id, o.id, g.maxSelect)} className="accent-[#ff5b23]" />
                            {o.name}
                          </span>
                          {o.priceDeltaMinor > 0 && <span className="font-bold text-signal">+{money(o.priceDeltaMinor)}</span>}
                        </label>
                      );
                    })}
                  </div>
                </fieldset>
              ))}

              <div className="mt-4">
                <label className="label" htmlFor={`note-${product.id}`}>Ürün notu</label>
                <input id={`note-${product.id}`} className="input" maxLength={200} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Ör. soğansız olsun" />
              </div>

              {missingRequired.length > 0 && <div className="mt-3 rounded-xl bg-sun/15 px-3 py-2 text-xs font-semibold text-[#7a5500]">Zorunlu seçim eksik: {missingRequired.map((g) => g.name).join(", ")}</div>}
              {err && <div className="mt-3 rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}

              <div className="mt-5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-1 rounded-full border border-line p-1">
                  <button type="button" aria-label="Azalt" onClick={() => setQty(Math.max(1, qty - 1))} className="h-9 w-9 rounded-full text-lg font-black hover:bg-paper">−</button>
                  <span className="w-8 text-center font-black">{qty}</span>
                  <button type="button" aria-label="Artır" onClick={() => setQty(Math.min(20, qty + 1))} className="h-9 w-9 rounded-full text-lg font-black hover:bg-paper">＋</button>
                </div>
                <button type="button" disabled={busy || missingRequired.length > 0} onClick={submit} className="btn-primary !px-6">
                  {busy ? "Ekleniyor…" : `${money(unit * qty)} · Ekle`}
                </button>
              </div>
              {product.stock <= 5 && <div className="mt-2 text-right text-[11px] font-semibold text-ink/45">Stokta {product.stock} adet kaldı</div>}
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------- Sepet & ödeme ---------- */
type CartData = {
  cart: { id: string; restaurant: { name: string; slug: string; openNow: boolean; minBasketMinor: number; deliveryFeeMinor: number; smallBasketFeeMinor: number; smallBasketThresholdMinor: number; prepMinutes: number; deliveryAreas: string[] } };
  items: { id: string; productId: string; name: string; options: string; qty: number; note: string | null; unitPriceMinor: number; lineTotalMinor: number; stock: number; available: boolean }[];
  subtotalMinor: number;
};

export function Checkout({ initialCart, favoriteProviderId }: { initialCart: CartData | null; favoriteProviderId?: string | null }) {
  const router = useRouter();
  const r = initialCart?.cart.restaurant;
  const [area, setArea] = useState(r?.deliveryAreas[0] ?? "kadikoy");
  const [delivery, setDelivery] = useState<FullAddress>(EMPTY_ADDRESS);
  const [note, setNote] = useState("");
  const [tip, setTip] = useState(0);
  const [payment, setPayment] = useState<"SANDBOX_CARD" | "CASH_ON_DELIVERY">("SANDBOX_CARD");
  const [courierPref, setCourierPref] = useState<"AUTO" | "FAVORITE" | "MANUAL_PROVIDER">("AUTO");
  const [quote, setQuote] = useState<{ subtotalMinor: number; deliveryFeeMinor: number; smallBasketFeeMinor: number; tipMinor: number; totalMinor: number; etaLabel: string } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, start] = useTransition();
  const [idemKey] = useState(() => crypto.randomUUID());

  const requote = (patch: Partial<{ area: string; tip: number }> = {}) => {
    const a = patch.area ?? area;
    const t = patch.tip ?? tip;
    start(async () => {
      try {
        setErr(null);
        const q = await api<typeof quote>("/api/checkout/quote", "POST", { deliveryArea: a, tipMinor: t });
        setQuote(q as never);
      } catch (e) {
        setQuote(null);
        setErr((e as Error).message);
      }
    });
  };

  useEffect(() => {
    if (initialCart) requote();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialCart?.subtotalMinor, initialCart?.items.length]);

  function place() {
    start(async () => {
      try {
        setErr(null);
        const res = await api<{ id: string; code: string }>("/api/orders", "POST", {
          deliveryArea: area,
          addressDetail: [delivery.fullAddressText, delivery.description].filter(Boolean).join(" · ") || undefined,
          note: note || undefined,
          tipMinor: tip,
          paymentMethod: payment,
          courierPreference: courierPref,
          preferredProviderId: courierPref === "FAVORITE" ? favoriteProviderId ?? undefined : undefined,
        }, { "Idempotency-Key": idemKey });
        router.push(`/siparis/${res.id}`);
      } catch (e) {
        setErr((e as Error).message);
      }
    });
  }

  if (!initialCart || !initialCart.items.length) return null;
  const belowMin = initialCart.subtotalMinor < r!.minBasketMinor;

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <CascadingAddressSelect
          label="Teslimat adresi"
          tone="dropoff"
          value={delivery}
          allowedSlugs={r!.deliveryAreas}
          onChange={(next) => {
            setDelivery(next);
            if (next.areaSlug && next.areaSlug !== area) { setArea(next.areaSlug); requote({ area: next.areaSlug }); }
          }}
          hint="Yalnızca işletmenin teslimat verdiği ilçeler listelenir"
        />
        {delivery.areaSlug && !r!.deliveryAreas.includes(delivery.areaSlug) && (
          <div className="mt-2 rounded-xl bg-rose/10 px-3 py-2 text-xs font-semibold text-rose">Bu adrese şu anda teslimat yapılamıyor.</div>
        )}
        <label className="label mt-3" htmlFor="onote">Sipariş notu</label>
        <input id="onote" className="input" maxLength={300} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Opsiyonel — kapı zili çalmasın gibi" />
      </div>

      <div className="card p-5">
        <div className="label">Bahşiş (opsiyonel, varsayılan kapalı)</div>
        <div className="flex gap-2">
          {[0, 1000, 2000, 5000].map((t) => (
            <button type="button" key={t} onClick={() => { setTip(t); requote({ tip: t }); }} className={`flex-1 rounded-xl border px-3 py-2 text-sm font-bold transition ${tip === t ? "border-signal bg-signal/10 text-signal" : "border-line hover:border-ink/25"}`}>
              {t === 0 ? "Yok" : money(t)}
            </button>
          ))}
        </div>
        <div className="label mt-4">Ödeme yöntemi</div>
        <div className="grid gap-2 sm:grid-cols-2">
          {([["SANDBOX_CARD", "💳 Kart (sandbox)", "Gerçek ödeme alınmaz"], ["CASH_ON_DELIVERY", "💵 Kapıda nakit", "Kuryeye ödeyin"]] as const).map(([k, l, d]) => (
            <button type="button" key={k} onClick={() => setPayment(k)} className={`rounded-xl border px-3 py-2.5 text-left transition ${payment === k ? "border-signal bg-signal/[0.05]" : "border-line hover:border-ink/25"}`}>
              <div className="text-sm font-bold">{l}</div>
              <div className="text-[11px] text-ink/50">{d}</div>
            </button>
          ))}
        </div>
        <div className="label mt-4">Kurye tercihi</div>
        <div className="grid gap-2">
          {([["AUTO", "🎯 Sistem en uygun kuryeyi seçsin"], ["FAVORITE", favoriteProviderId ? "♥ Favori kuryem (müsaitse)" : "♥ Favori kuryem — favoriniz yok"]] as const).map(([k, l]) => (
            <label key={k} className={`flex cursor-pointer items-center gap-2 rounded-xl border px-3 py-2.5 text-sm font-bold transition ${courierPref === k ? "border-signal bg-signal/[0.05]" : "border-line"} ${k === "FAVORITE" && !favoriteProviderId ? "opacity-50" : ""}`}>
              <input type="radio" className="accent-[#ff5b23]" checked={courierPref === k} disabled={k === "FAVORITE" && !favoriteProviderId} onChange={() => setCourierPref(k as never)} />
              {l}
            </label>
          ))}
        </div>
        <p className="mt-2 text-[11px] text-ink/45">Favoriniz müsait değilse sistem otomatik olarak en uygun alternatife geçer. Kesin atama garantisi yoktur.</p>
      </div>

      <div className="card-ink road-pattern-dark p-5">
        <div className="text-sm font-extrabold">Ödeme özeti</div>
        <div className="mt-3 space-y-1.5 text-sm">
          <Row k="Ara toplam" v={money(initialCart.subtotalMinor)} />
          <Row k={`Teslimat ücreti · ${r!.name}`} v={quote ? money(quote.deliveryFeeMinor) : "…"} />
          {quote && quote.smallBasketFeeMinor > 0 && <Row k={`Küçük sepet bedeli (${money(r!.smallBasketThresholdMinor)} altı)`} v={money(quote.smallBasketFeeMinor)} />}
          {quote && quote.tipMinor > 0 && <Row k="Bahşiş" v={money(quote.tipMinor)} />}
          <div className="mt-2 flex justify-between border-t border-white/15 pt-2 text-lg font-black">
            <span>Toplam</span>
            <span>{quote ? money(quote.totalMinor) : "—"}</span>
          </div>
          <div className="text-xs text-white/55">Tahmini teslim: {quote?.etaLabel ?? `~${r!.prepMinutes + 20} dk`} · {delivery.districtName ? `${delivery.cityName} / ${delivery.districtName}` : "Adres seçilmedi"}</div>
        </div>
        {belowMin && <div className="mt-3 rounded-xl bg-sun/20 px-3 py-2 text-xs font-bold text-white">Minimum sepet tutarı {money(r!.minBasketMinor)} — {money(r!.minBasketMinor - initialCart.subtotalMinor)} daha ekleyin.</div>}
        {err && <div className="mt-3 rounded-xl bg-rose/20 px-3 py-2 text-xs font-bold text-white">{err}</div>}
        <button type="button" disabled={busy || belowMin || !quote || !delivery.isComplete || !r!.deliveryAreas.includes(area)} onClick={place} className="btn-primary mt-4 w-full !py-3 !text-base">
          {busy ? "İşleniyor…" : "Siparişi onayla"}
        </button>
        <p className="mt-2 text-center text-[11px] text-white/45">Tutarlar sunucuda yeniden hesaplanır. Ödeme sandbox modundadır; gerçek tahsilat yapılmaz.</p>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between text-white/75">
      <span>{k}</span>
      <span className="font-bold text-white">{v}</span>
    </div>
  );
}

export function CartQty({ itemId, qty, stock }: { itemId: string; qty: number; stock: number }) {
  const router = useRouter();
  const [busy, start] = useTransition();
  const act = (fn: () => Promise<unknown>) => start(async () => { try { await fn(); router.refresh(); } catch { router.refresh(); } });
  return (
    <div className="flex items-center gap-1 rounded-full border border-line p-0.5">
      <button type="button" aria-label="Azalt" disabled={busy} onClick={() => act(() => (qty <= 1 ? api(`/api/cart/items/${itemId}`, "DELETE") : api(`/api/cart/items/${itemId}`, "PATCH", { qty: qty - 1 })))} className="h-8 w-8 rounded-full font-black hover:bg-paper">−</button>
      <span className="w-7 text-center text-sm font-bold">{qty}</span>
      <button type="button" aria-label="Artır" disabled={busy || qty >= stock} onClick={() => act(() => api(`/api/cart/items/${itemId}`, "PATCH", { qty: qty + 1 }))} className="h-8 w-8 rounded-full font-black hover:bg-paper disabled:opacity-40">＋</button>
    </div>
  );
}

/* ---------- Sipariş değerlendirme ---------- */
export function OrderRating({ orderId, restaurantName }: { orderId: string; restaurantName: string }) {
  const router = useRouter();
  const [rating, setRating] = useState(0);
  const [cats, setCats] = useState<Record<string, number>>({});
  const [body, setBody] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, start] = useTransition();
  const CATS: [string, string][] = [["catCare", "Ürün kalitesi"], ["catCommunication", "Paketleme"], ["catProfessionalism", "Sipariş doğruluğu"], ["catTime", "Hazırlık süresi"]];
  return (
    <div className="card p-5">
      <h3 className="font-extrabold">{restaurantName} deneyiminiz</h3>
      <div className="mt-3 flex gap-1">
        {[1, 2, 3, 4, 5].map((n) => (
          <button key={n} type="button" aria-label={`${n} yıldız`} onClick={() => setRating(n)} className={`text-2xl transition hover:scale-110 ${n <= rating ? "text-sun" : "text-ink/15"}`}>★</button>
        ))}
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        {CATS.map(([k, l]) => (
          <div key={k} className="flex items-center justify-between rounded-xl bg-paper px-3 py-2">
            <span className="text-xs font-bold">{l}</span>
            <span className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((n) => (
                <button key={n} type="button" aria-label={`${l} ${n}`} onClick={() => setCats({ ...cats, [k]: n })} className={`text-sm transition hover:scale-110 ${n <= (cats[k] ?? 0) ? "text-sun" : "text-ink/15"}`}>★</button>
              ))}
            </span>
          </div>
        ))}
      </div>
      <textarea className="input mt-3 min-h-20" maxLength={1000} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Yorumunuz (opsiyonel)" />
      {err && <div className="mt-2 rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
      <button type="button" disabled={busy || !rating} className="btn-primary mt-3" onClick={() => start(async () => { try { setErr(null); await api(`/api/orders/${orderId}/rate`, "POST", { rating, ...Object.fromEntries(Object.entries(cats).filter(([, v]) => v > 0)), body: body || undefined }); router.refresh(); } catch (e) { setErr((e as Error).message); } })}>
        {busy ? "Gönderiliyor…" : "Değerlendirmeyi gönder"}
      </button>
    </div>
  );
}

/* ---------- İşletme ürün düzenleme ---------- */
export type ProductDraft = {
  id?: string;
  categoryId: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  priceMinor: number;
  discountPriceMinor: number | null;
  stock: number;
  allergens: string[];
  calories: number | null;
  prepMinutes: number | null;
  isVegan: boolean;
  isVegetarian: boolean;
  isSpicy: boolean;
  status: string;
};

export function ProductForm({ categories, product, onDone }: { categories: { id: string; name: string }[]; product?: ProductDraft | null; onDone: () => void }) {
  const router = useRouter();
  const [f, setF] = useState({
    categoryId: product?.categoryId ?? categories[0]?.id ?? "",
    name: product?.name ?? "",
    description: product?.description ?? "",
    price: ((product?.priceMinor ?? 0) / 100).toFixed(2),
    discount: product?.discountPriceMinor ? (product.discountPriceMinor / 100).toFixed(2) : "",
    stock: String(product?.stock ?? 50),
    imageUrl: product?.imageUrl ?? "",
    allergens: product?.allergens ?? [],
    calories: product?.calories ? String(product.calories) : "",
    prepMinutes: product?.prepMinutes ? String(product.prepMinutes) : "",
    isVegan: product?.isVegan ?? false,
    isVegetarian: product?.isVegetarian ?? false,
    isSpicy: product?.isSpicy ?? false,
    status: product?.status ?? "PUBLISHED",
  });
  const [err, setErr] = useState<string | null>(null);
  const [busy, start] = useTransition();
  const set = (k: string, v: unknown) => setF((p) => ({ ...p, [k]: v }));

  function save() {
    start(async () => {
      try {
        setErr(null);
        const payload = {
          categoryId: f.categoryId,
          name: f.name,
          description: f.description || undefined,
          imageUrl: f.imageUrl || undefined,
          priceMinor: Math.round(Number(f.price.replace(",", ".")) * 100) || 0,
          discountPriceMinor: f.discount ? Math.round(Number(f.discount.replace(",", ".")) * 100) : null,
          stock: Number(f.stock) || 0,
          allergens: f.allergens,
          calories: f.calories ? Number(f.calories) : null,
          prepMinutes: f.prepMinutes ? Number(f.prepMinutes) : null,
          isVegan: f.isVegan,
          isVegetarian: f.isVegetarian,
          isSpicy: f.isSpicy,
          status: f.status,
        };
        if (product?.id) await api(`/api/merchant/products/${product.id}`, "PATCH", payload);
        else await api("/api/merchant/products", "POST", payload);
        onDone();
        router.refresh();
      } catch (e) {
        setErr((e as Error).message);
      }
    });
  }

  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div><label className="label">Ürün adı</label><input className="input" value={f.name} maxLength={80} onChange={(e) => set("name", e.target.value)} /></div>
        <div>
          <label className="label">Kategori</label>
          <select className="input" value={f.categoryId} onChange={(e) => set("categoryId", e.target.value)}>
            {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>
      </div>
      <div><label className="label">Açıklama</label><textarea className="input min-h-20" maxLength={600} value={f.description} onChange={(e) => set("description", e.target.value)} /></div>
      <div className="grid gap-3 sm:grid-cols-4">
        <div><label className="label">Fiyat (₺)</label><input className="input" value={f.price} onChange={(e) => set("price", e.target.value)} /></div>
        <div><label className="label">İndirimli (₺)</label><input className="input" value={f.discount} onChange={(e) => set("discount", e.target.value)} placeholder="—" /></div>
        <div><label className="label">Stok</label><input className="input" value={f.stock} onChange={(e) => set("stock", e.target.value)} /></div>
        <div>
          <label className="label">Durum</label>
          <select className="input" value={f.status} onChange={(e) => set("status", e.target.value)}>
            <option value="PUBLISHED">Yayında</option>
            <option value="DRAFT">Taslak</option>
            <option value="OFF">Pasif</option>
            <option value="ARCHIVED">Arşiv</option>
          </select>
        </div>
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <div><label className="label">Kalori</label><input className="input" value={f.calories} onChange={(e) => set("calories", e.target.value)} placeholder="opsiyonel" /></div>
        <div><label className="label">Hazırlık (dk)</label><input className="input" value={f.prepMinutes} onChange={(e) => set("prepMinutes", e.target.value)} placeholder="opsiyonel" /></div>
        <div><label className="label">Görsel adresi</label><input className="input" value={f.imageUrl} onChange={(e) => set("imageUrl", e.target.value)} placeholder="https://…" /></div>
      </div>
      <div>
        <div className="label">Alerjenler</div>
        <div className="flex flex-wrap gap-1.5">
          {ALLERGENS.map((a) => {
            const on = f.allergens.includes(a);
            return (
              <button type="button" key={a} onClick={() => set("allergens", on ? f.allergens.filter((x) => x !== a) : [...f.allergens, a])} className={`chip !cursor-pointer ${on ? "!border-signal !bg-signal/10 !text-signal" : ""}`}>{a}</button>
            );
          })}
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        {[["isVegan", "🌱 Vegan"], ["isVegetarian", "🥬 Vejetaryen"], ["isSpicy", "🌶️ Acı"]] .map(([k, l]) => (
          <label key={k} className="chip !cursor-pointer">
            <input type="checkbox" className="accent-[#ff5b23]" checked={f[k as "isVegan"]} onChange={(e) => set(k, e.target.checked)} />
            {l}
          </label>
        ))}
      </div>
      {err && <div className="rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
      <div className="flex gap-2">
        <button type="button" className="btn-primary" disabled={busy} onClick={save}>{busy ? "Kaydediliyor…" : product ? "Değişiklikleri kaydet" : "Ürünü oluştur"}</button>
        <button type="button" className="btn-ghost" onClick={onDone}>Vazgeç</button>
      </div>
    </div>
  );
}

export function StockToggle({ productId, stock, status }: { productId: string; stock: number; status: string }) {
  const router = useRouter();
  const [busy, start] = useTransition();
  const go = (action: string) => start(async () => { try { await api(`/api/merchant/products/${productId}/action`, "POST", { action }); router.refresh(); } catch { router.refresh(); } });
  return (
    <div className="flex gap-1.5">
      <button type="button" disabled={busy} onClick={() => go("soldout")} className={`btn-sm ${stock === 0 ? "btn border border-line bg-paper text-ink/40" : "btn-ghost"}`}>Tükendi işaretle</button>
      <button type="button" disabled={busy} onClick={() => go("instock")} className="btn-ghost btn-sm">Stok ver</button>
      <button type="button" disabled={busy} onClick={() => go(status === "PUBLISHED" ? "off" : "publish")} className="btn-ghost btn-sm">{status === "PUBLISHED" ? "Pasife al" : "Yayınla"}</button>
    </div>
  );
}

export function OpenToggle({ isOpen }: { isOpen: boolean }) {
  const router = useRouter();
  const [busy, start] = useTransition();
  const [err, setErr] = useState<string | null>(null);
  return (
    <div>
      <button
        type="button"
        disabled={busy}
        onClick={() => start(async () => { try { setErr(null); await api("/api/merchant/open", "POST", { isOpen: !isOpen }); router.refresh(); } catch (e) { setErr((e as Error).message); } })}
        className={`btn ${isOpen ? "bg-mint text-white hover:brightness-95" : "bg-ink text-white hover:bg-ink-2"}`}
      >
        <span className={`h-2 w-2 rounded-full ${isOpen ? "bg-white" : "bg-sun"}`} />
        {isOpen ? "Siparişe açık — kapat" : "Siparişe kapalı — aç"}
      </button>
      {err && <div className="mt-1 text-xs font-semibold text-rose">{err}</div>}
    </div>
  );
}

export function CategoryForm({ onDone }: { onDone: () => void }) {
  const router = useRouter();
  const [f, setF] = useState({ name: "", description: "", timeFrom: "", timeTo: "" });
  const [err, setErr] = useState<string | null>(null);
  const [busy, start] = useTransition();
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      <div><label className="label">Kategori adı</label><input className="input" maxLength={60} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="Ör. Tatlılar" /></div>
      <div><label className="label">Açıklama</label><input className="input" maxLength={200} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
      <div><label className="label">Başlangıç saati (opsiyonel)</label><input className="input" type="time" value={f.timeFrom} onChange={(e) => setF({ ...f, timeFrom: e.target.value })} /></div>
      <div><label className="label">Bitiş saati (opsiyonel)</label><input className="input" type="time" value={f.timeTo} onChange={(e) => setF({ ...f, timeTo: e.target.value })} /></div>
      {err && <div className="rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose sm:col-span-2">{err}</div>}
      <div className="flex gap-2 sm:col-span-2">
        <button type="button" className="btn-primary" disabled={busy || !f.name.trim()} onClick={() => start(async () => { try { setErr(null); await api("/api/merchant/categories", "POST", { name: f.name, description: f.description || undefined, timeFrom: f.timeFrom || undefined, timeTo: f.timeTo || undefined }); onDone(); router.refresh(); } catch (e) { setErr((e as Error).message); } })}>
          {busy ? "Ekleniyor…" : "Kategori ekle"}
        </button>
        <button type="button" className="btn-ghost" onClick={onDone}>Vazgeç</button>
      </div>
    </div>
  );
}

export function OptionGroupForm({ productId, onDone }: { productId: string; onDone: () => void }) {
  const router = useRouter();
  const [name, setName] = useState("");
  const [required, setRequired] = useState(true);
  const [maxSelect, setMaxSelect] = useState(1);
  const [opts, setOpts] = useState<{ name: string; priceDeltaMinor: number }[]>([{ name: "", priceDeltaMinor: 0 }, { name: "", priceDeltaMinor: 0 }]);
  const [err, setErr] = useState<string | null>(null);
  const [busy, start] = useTransition();
  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-3">
        <div><label className="label">Seçim adı</label><input className="input" maxLength={60} value={name} onChange={(e) => setName(e.target.value)} placeholder="Ör. Acı seviyesi" /></div>
        <div><label className="label">Zorunlu mu?</label><label className="chip !cursor-pointer"><input type="checkbox" className="accent-[#ff5b23]" checked={required} onChange={(e) => setRequired(e.target.checked)} /> Zorunlu</label></div>
        <div><label className="label">En fazla seçim</label><input type="number" min={1} max={8} className="input" value={maxSelect} onChange={(e) => setMaxSelect(Number(e.target.value))} /></div>
      </div>
      <div className="space-y-2">
        {opts.map((o, i) => (
          <div key={i} className="grid grid-cols-[1fr_120px_auto] gap-2">
            <input className="input" maxLength={60} placeholder={`Seçenek ${i + 1}`} value={o.name} onChange={(e) => setOpts(opts.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))} />
            <input className="input" type="number" min={0} placeholder="Fark ₺" value={o.priceDeltaMinor / 100 || ""} onChange={(e) => setOpts(opts.map((x, j) => (j === i ? { ...x, priceDeltaMinor: Math.round(Number(e.target.value || 0) * 100) } : x)))} />
            <button type="button" className="btn-ghost btn-sm" onClick={() => setOpts(opts.filter((_, j) => j !== i))}>Sil</button>
          </div>
        ))}
        <button type="button" className="btn-ghost btn-sm" onClick={() => setOpts([...opts, { name: "", priceDeltaMinor: 0 }])}>＋ Seçenek ekle</button>
      </div>
      {err && <div className="rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
      <div className="flex gap-2">
        <button type="button" className="btn-primary" disabled={busy || !name.trim()} onClick={() => start(async () => { try { setErr(null); await api("/api/merchant/option-groups", "POST", { productId, name, required, maxSelect, options: opts.filter((o) => o.name.trim()) }); onDone(); router.refresh(); } catch (e) { setErr((e as Error).message); } })}>{busy ? "Ekleniyor…" : "Seçenek grubunu kaydet"}</button>
        <button type="button" className="btn-ghost" onClick={onDone}>Vazgeç</button>
      </div>
    </div>
  );
}

export function CartBadge({ count }: { count: number }) {
  if (!count) return null;
  return (
    <Link href="/sepet" className="relative flex h-9 items-center gap-1.5 rounded-full bg-signal px-3 text-sm font-bold text-white hover:brightness-110">
      🧺 Sepet
      <span className="rounded-full bg-white/25 px-1.5 text-xs">{count}</span>
    </Link>
  );
}
