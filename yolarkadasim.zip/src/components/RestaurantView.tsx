"use client";

import { useState, type ReactNode } from "react";
import { Tabs } from "./media-client";

export function RestaurantTabs({ tabs, panels, initial = "menu" }: { tabs: { key: string; label: string; count?: number }[]; panels: Record<string, ReactNode>; initial?: string }) {
  const [active, setActive] = useState(initial);
  return (
    <div>
      <div className="sticky top-16 z-30 -mx-4 bg-paper/95 px-4 backdrop-blur sm:mx-0 sm:px-0">
        <Tabs tabs={tabs} active={active} onChange={setActive} />
      </div>
      <div role="tabpanel" className="fade-up pt-6">{panels[active] ?? null}</div>
    </div>
  );
}


export { RestaurantTabs as PanelTabs };
