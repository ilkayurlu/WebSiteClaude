import Link from "next/link";
import { areaName } from "@/lib/geo";
import { KINDS, SERVICES, money } from "@/lib/labels";
import type { PublicProvider } from "@/lib/queries";
import { Avatar, Stars, VehicleChip } from "./ui";
import { FavoriteButton } from "./client";

export function ProviderCard({ p, isFavorite, canFavorite }: { p: PublicProvider; isFavorite?: boolean; canFavorite?: boolean }) {
  return (
    <div className="card card-hover group relative flex flex-col overflow-hidden">
      <div
        className="road-pattern-dark relative h-20"
        style={{ background: `linear-gradient(120deg, hsl(${p.hue} 70% 22%), hsl(${(p.hue + 50) % 360} 60% 14%))` }}
      >
        <div className="absolute right-3 top-3 flex items-center gap-2">
          {p.eta && p.status === "AVAILABLE" && <span className="chip-dark">⏱ {p.eta}</span>}
          {canFavorite && <FavoriteButton targetType="PROVIDER" targetId={p.id} initial={!!isFavorite} compact />}
        </div>
      </div>
      <div className="-mt-8 flex flex-1 flex-col px-5 pb-5">
        <div className="flex items-end justify-between">
          <Avatar name={p.displayName} hue={p.hue} size={64} status={p.status} />
        </div>
        <Link href={`/kuryeler/${p.slug}`} className="mt-3 block">
          <div className="flex items-center gap-1.5">
            <h3 className="text-lg font-extrabold tracking-tight group-hover:text-signal">{p.displayName}</h3>
            {p.isVerified && <span title="Doğrulanmış" className="flex h-4 w-4 items-center justify-center rounded-full bg-sky text-[9px] text-white">✓</span>}
          </div>
          <p className="text-sm text-ink/60">{p.headline}</p>
        </Link>
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <Stars value={p.ratingAvg} count={p.ratingCount} />
          <span className="text-ink/20">•</span>
          <span className="text-xs font-semibold text-ink/55">{KINDS[p.kind]}</span>
          {p.fleet && (
            <>
              <span className="text-ink/20">•</span>
              <span className="text-xs font-semibold text-ink/55">🏢 {p.fleet.name}</span>
            </>
          )}
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <VehicleChip type={p.vehicleType} />
          {p.serviceTypes.slice(0, 3).map((s) => (
            <span key={s} className="chip">
              {SERVICES[s]?.icon} {SERVICES[s]?.label}
            </span>
          ))}
        </div>
        <div className="mt-3 text-xs text-ink/50">📍 {p.serviceAreas.slice(0, 3).map(areaName).join(", ")}{p.serviceAreas.length > 3 ? ` +${p.serviceAreas.length - 3}` : ""}</div>
        <div className="mt-auto flex items-center justify-between gap-2 pt-4">
          <div className="text-xs text-ink/55">
            {p.acceptsRental && p.rentalHourlyMinor ? (
              <>
                <span className="font-black text-ink">{money(p.rentalHourlyMinor)}</span>/saat
              </>
            ) : (
              <>
                açılış <span className="font-black text-ink">{money(p.baseFareMinor)}</span>
              </>
            )}
          </div>
          <div className="flex gap-1.5">
            {p.fleet?.policy === "FLEET_ONLY" ? (
              <Link href={`/filolar/${p.fleet.slug}`} className="btn-ghost btn-sm">Filo üzerinden</Link>
            ) : (
              <Link href={`/talep/yeni?mode=INSTANT_CALL&provider=${p.slug}`} className="btn-primary btn-sm">⚡ Çağır</Link>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
