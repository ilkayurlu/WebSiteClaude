"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import {
  ArrowRight, Bike, Building2, Eye, EyeOff, KeyRound, Loader2, Lock, Mail, ShieldCheck, ShoppingBag, Sparkles, UtensilsCrossed,
  type LucideIcon,
} from "lucide-react";
import { loginWithCredentialsAction, loginWithDemoAction } from "@/actions/auth-mode-actions";
import type { AccessMode, DemoAccount } from "@/lib/auth-mode-types";
import { AuthError, useShake } from "./LoginShake";
import { PinLogin } from "./PinLogin";

const ROLE_UI: Record<string, { label: string; caption: string; icon: LucideIcon; home: string }> = {
  CUSTOMER: { label: "Müşteri", caption: "Sipariş, talep ve cüzdan", icon: ShoppingBag, home: "/dashboard/musteri" },
  PROVIDER: { label: "Kurye / Sürücü", caption: "Görev, vardiya ve kazanç", icon: Bike, home: "/dashboard/kurye" },
  FLEET_OWNER: { label: "Filo yöneticisi", caption: "Ekip ve operasyon", icon: Building2, home: "/dashboard/filo" },
  RESTAURANT_OWNER: { label: "İşletme", caption: "Menü ve siparişler", icon: UtensilsCrossed, home: "/dashboard/isletme" },
};

function CredentialsLogin({ next }: { next?: string }) {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const { shaking, shake } = useShake();

  function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (pending) return;
    setError(null);
    const formData = new FormData(event.currentTarget);
    start(async () => {
      try {
        const res = await loginWithCredentialsAction(formData);
        if (!res.success) {
          setError(res.error);
          shake();
          return;
        }
        router.push(res.redirectTo);
        router.refresh();
      } catch {
        setError("Giriş sırasında bir hata oluştu.");
        shake();
      }
    });
  }

  return (
    <div className={shaking ? "auth-shake" : undefined}>
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-signal/15 ring-1 ring-signal/30">
          <KeyRound size={20} className="text-signal" aria-hidden="true" />
        </span>
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-signal">Seviye 1 · Standart</div>
          <h2 className="text-xl font-black tracking-tight text-white">Hesabınıza giriş yapın</h2>
          <p className="text-xs text-white/50">Rolünüz otomatik algılanır; doğru panele yönlendirilirsiniz.</p>
        </div>
      </div>

      <form onSubmit={onSubmit} className="space-y-4">
        {next && <input type="hidden" name="next" value={next} />}
        <div>
          <label htmlFor="email" className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
            <Mail size={12} className="text-signal" aria-hidden="true" /> E-posta adresi
          </label>
          <input id="email" name="email" type="email" required autoComplete="username" spellCheck={false} placeholder="ornek@yolarkadasi.app" className="w-full rounded-xl border border-white/10 bg-ink px-3.5 py-2.5 text-sm text-white placeholder-white/25 outline-none transition focus:border-signal focus:ring-4 focus:ring-signal/15" />
        </div>
        <div>
          <label htmlFor="password" className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
            <Lock size={12} className="text-signal" aria-hidden="true" /> Parola
          </label>
          <div className="relative">
            <input id="password" name="password" type={showPassword ? "text" : "password"} required autoComplete="current-password" placeholder="••••••••••••" className="w-full rounded-xl border border-white/10 bg-ink py-2.5 pl-3.5 pr-11 text-sm text-white placeholder-white/25 outline-none transition focus:border-signal focus:ring-4 focus:ring-signal/15" />
            <button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Parolayı gizle" : "Parolayı göster"} aria-pressed={showPassword} className="absolute right-2 top-1/2 flex h-8 w-8 -translate-y-1/2 items-center justify-center rounded-lg text-signal transition hover:bg-white/10">
              {showPassword ? <EyeOff size={16} className="text-signal" aria-hidden="true" /> : <Eye size={16} className="text-signal" aria-hidden="true" />}
            </button>
          </div>
        </div>
        {error && <AuthError message={error} />}
        <button type="submit" disabled={pending} className="flex w-full items-center justify-center gap-2 rounded-xl bg-signal py-3 text-sm font-black text-white shadow-[0_10px_24px_-8px_rgba(255,91,35,0.75)] transition hover:brightness-110 disabled:opacity-50">
          {pending ? <Loader2 size={16} className="animate-spin text-white" aria-hidden="true" /> : <ArrowRight size={16} className="text-white" aria-hidden="true" />}
          {pending ? "Doğrulanıyor…" : "Giriş Yap"}
        </button>
      </form>
    </div>
  );
}

function DemoLogin({ accounts }: { accounts: DemoAccount[] }) {
  const router = useRouter();
  const [pendingRole, setPendingRole] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { shaking, shake } = useShake();

  const groups = Object.keys(ROLE_UI)
    .map((role) => ({ role, ...ROLE_UI[role], accounts: accounts.filter((a) => a.role === role) }))
    .filter((g) => g.accounts.length > 0);

  function submit(role: string) {
    if (pendingRole) return;
    setPendingRole(role);
    setError(null);
    void loginWithDemoAction(role)
      .then((res) => {
        if (!res.success) {
          setError(res.error);
          shake();
          setPendingRole(null);
          return;
        }
        router.push(res.redirectTo);
        router.refresh();
      })
      .catch(() => {
        setError("Demo giriş yapılamadı.");
        shake();
        setPendingRole(null);
      });
  }

  return (
    <div className={shaking ? "auth-shake" : undefined}>
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-signal/15 ring-1 ring-signal/30">
          <Sparkles size={20} className="text-signal" aria-hidden="true" />
        </span>
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-signal">Seviye 0 · Demo</div>
          <h2 className="text-xl font-black tracking-tight text-white">Demo rolünü seçin</h2>
          <p className="text-xs text-white/50">Tek tıkla ilgili role bürünüp oturum açın.</p>
        </div>
      </div>

      <div className="max-h-[360px] space-y-3 overflow-y-auto pr-1">
        {groups.map(({ role, label, caption, icon: Icon, accounts: list }) => (
          <div key={role}>
            <div className="mb-1.5 flex items-center gap-2 text-[11px] font-bold text-white/55">
              <Icon size={13} className="text-signal" aria-hidden="true" />{label}
              <span className="font-normal text-white/30">· {caption}</span>
            </div>
            <div className="grid gap-1.5 sm:grid-cols-2">
              {list.map((account) => (
                <button key={account.id} type="button" disabled={pendingRole !== null} onClick={() => submit(role)} className="flex min-h-11 items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2 text-left text-sm font-semibold text-white/85 transition hover:border-signal/50 hover:bg-white/[0.06] disabled:opacity-50">
                  <span className="truncate">{account.name}</span>
                  {pendingRole === role ? <Loader2 size={14} className="shrink-0 animate-spin text-signal" aria-hidden="true" /> : <ArrowRight size={14} className="shrink-0 text-signal" aria-hidden="true" />}
                </button>
              ))}
            </div>
          </div>
        ))}
        {groups.length === 0 && (
          <p className="rounded-xl border border-white/10 bg-white/[0.02] p-4 text-xs text-white/55">
            Demo hesabı bulunamadı. Veritabanı tohumlaması için demo modunun açık olması gerekir.
          </p>
        )}
      </div>
      <p className="mt-3 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2 text-[11px] leading-relaxed text-white/45">
        Demo modda yönetici rolleri tek tıkla açılmaz; yönetim erişimi Seviye 1 (e-posta &amp; parola) veya Seviye 2 (PIN) ile yapılır.
      </p>
      {error && <div className="mt-3"><AuthError message={error} /></div>}
    </div>
  );
}

export function AuthGate({ mode, demoAccounts, pinReady, pinReason, next }: { mode: AccessMode; demoAccounts: DemoAccount[]; pinReady: boolean; pinReason: string | null; next?: string }) {
  const modeInfo: Record<AccessMode, { label: string; icon: LucideIcon }> = {
    "0": { label: "Demo", icon: Sparkles },
    "1": { label: "E-posta & Parola", icon: KeyRound },
    "2": { label: "Yönetici PIN", icon: ShieldCheck },
  };
  const ModeIcon = modeInfo[mode].icon;

  return (
    <div className="rounded-3xl border border-white/10 bg-white/[0.02] p-6 text-white shadow-2xl ring-1 ring-white/10 backdrop-blur-xl sm:p-8">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div className="inline-flex items-center gap-1.5 rounded-full bg-white/[0.06] px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-white/60 ring-1 ring-white/10">
          <ModeIcon size={12} className="text-signal" aria-hidden="true" /> Erişim seviyesi {mode} · {modeInfo[mode].label}
        </div>
        <Link href="/" className="text-[11px] font-bold text-white/50 transition hover:text-signal">← Ana site</Link>
      </div>

      {mode === "0" && <DemoLogin accounts={demoAccounts} />}
      {mode === "1" && <CredentialsLogin next={next} />}
      {mode === "2" && (pinReady ? <PinLogin mode={mode} /> : (
        <div className="flex items-start gap-3 rounded-2xl border border-white/10 bg-white/[0.03] p-4 text-xs leading-relaxed text-white/60">
          <ShieldCheck size={16} className="mt-0.5 shrink-0 text-signal" aria-hidden="true" />
          <span><b className="text-white/85">PIN girişi yapılandırılmadı.</b> {pinReason ?? "ADMIN_ROOT_PIN 4 haneli olarak tanımlanmalı."}</span>
        </div>
      ))}

      <div className="mt-6 grid gap-2 border-t border-white/10 pt-5 sm:grid-cols-2">
        <Link href="/basvuru?kind=FLEET" className="group flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2.5 text-xs font-bold text-white/80 transition hover:border-signal/40 hover:bg-white/[0.05]">
          <Bike size={15} className="shrink-0 text-signal" aria-hidden="true" />
          <span className="min-w-0 flex-1 truncate">Kurye / filo başvurusu</span>
          <ArrowRight size={13} className="shrink-0 text-signal transition group-hover:translate-x-0.5" aria-hidden="true" />
        </Link>
        <Link href="/basvuru?kind=RESTAURANT" className="group flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.02] px-3 py-2.5 text-xs font-bold text-white/80 transition hover:border-signal/40 hover:bg-white/[0.05]">
          <UtensilsCrossed size={15} className="shrink-0 text-signal" aria-hidden="true" />
          <span className="min-w-0 flex-1 truncate">İşletme / restoran kaydı</span>
          <ArrowRight size={13} className="shrink-0 text-signal transition group-hover:translate-x-0.5" aria-hidden="true" />
        </Link>
      </div>
    </div>
  );
}
