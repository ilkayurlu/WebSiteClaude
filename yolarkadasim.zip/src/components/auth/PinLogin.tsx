"use client";

import { useEffect, useRef, useState, type ClipboardEvent, type KeyboardEvent } from "react";
import { ArrowRight, Delete, Loader2, Lock } from "lucide-react";
import { getPinCooldownAction, loginWithPinAction } from "@/actions/admin-pin-auth";
import type { AccessMode } from "@/lib/auth-mode-types";
import { AuthError, useShake } from "./LoginShake";

const LENGTH = 4;
const EMPTY = ["", "", "", ""];

function formatCooldown(ms: number): string {
  if (ms > 60_000) {
    const minutes = Math.ceil(ms / 60_000);
    return `${minutes} dk`;
  }
  return `${Math.max(0.1, ms / 1000).toFixed(1)} sn`;
}

export function PinLogin({ mode }: { mode: AccessMode }) {
  const [digits, setDigits] = useState<string[]>(EMPTY);
  const digitsRef = useRef<string[]>(EMPTY);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [cooldownUntil, setCooldownUntil] = useState(0);
  const cooldownRef = useRef(0);
  const [now, setNow] = useState(() => Date.now());
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const submitting = useRef(false);
  const { shaking, shake } = useShake();
  const cooldownMs = Math.max(0, cooldownUntil - now);
  const cooling = cooldownMs > 0;
  const disabled = loading || cooling;
  const code = digits.join("");

  useEffect(() => {
    refs.current[0]?.focus();
    let active = true;
    void getPinCooldownAction()
      .then(({ cooldownMs: remaining }) => {
        if (!active || remaining <= 0) return;
        const until = Date.now() + remaining;
        cooldownRef.current = until;
        setCooldownUntil(until);
      })
      .catch(() => {});
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!cooling) return;
    const timer = setInterval(() => setNow(Date.now()), 150);
    return () => clearInterval(timer);
  }, [cooling]);

  useEffect(() => {
    if (error && !disabled) refs.current[0]?.focus();
  }, [error, disabled]);

  function focus(index: number) {
    refs.current[Math.max(0, Math.min(LENGTH - 1, index))]?.focus();
  }

  function resetDigits() {
    digitsRef.current = EMPTY;
    setDigits(EMPTY);
    requestAnimationFrame(() => refs.current[0]?.focus());
  }

  async function submit(pin: string) {
    if (mode !== "2" || submitting.current || Date.now() < cooldownRef.current || !/^\d{4}$/.test(pin)) return;
    submitting.current = true;
    setLoading(true);
    setError(null);
    try {
      const result = await loginWithPinAction(pin);
      if (result.success) {
        // Server Action'ın Set-Cookie yanıtı tamamlandıktan sonra tam gezinme;
        // RSC cache ve yumuşak route geçişi nedeniyle /giris'e geri atılmayı önler.
        window.location.href = result.redirectTo === "/admin" ? result.redirectTo : "/admin";
        return;
      }
      setError(result.error);
      if (result.cooldownMs && result.cooldownMs > 0) {
        const until = Date.now() + result.cooldownMs;
        cooldownRef.current = until;
        setCooldownUntil(until);
        setNow(Date.now());
      }
      resetDigits();
      shake();
    } catch {
      setError("PIN doğrulanırken bir hata oluştu. Lütfen tekrar deneyin.");
      resetDigits();
      shake();
    } finally {
      submitting.current = false;
      setLoading(false);
    }
  }

  function applyDigits(index: number, raw: string) {
    const clean = raw.replace(/[^0-9]/g, "");
    if (!clean) {
      const next = [...digitsRef.current];
      next[index] = "";
      digitsRef.current = next;
      setDigits(next);
      return;
    }
    const next = [...digitsRef.current];
    for (let i = 0; i < clean.length && index + i < LENGTH; i++) next[index + i] = clean[i];
    digitsRef.current = next;
    setDigits(next);
    setError(null);
    focus(index + clean.length);
    // ref güncellemesi state commit'inden önce yapıldığı için 4. rakam asla eksik gönderilmez.
    if (next.every((digit) => digit.length === 1)) void submit(next.join(""));
  }

  function onKeyDown(index: number, event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Backspace") {
      event.preventDefault();
      const next = [...digitsRef.current];
      if (next[index]) next[index] = "";
      else if (index > 0) { next[index - 1] = ""; focus(index - 1); }
      digitsRef.current = next;
      setDigits(next);
      setError(null);
    } else if (event.key === "ArrowLeft") focus(index - 1);
    else if (event.key === "ArrowRight") focus(index + 1);
    else if (event.key === "Enter") { event.preventDefault(); void submit(digitsRef.current.join("")); }
  }

  function onPaste(event: ClipboardEvent<HTMLInputElement>) {
    const pasted = event.clipboardData.getData("text").replace(/[^0-9]/g, "").slice(0, LENGTH);
    if (!pasted) return;
    event.preventDefault();
    const next = Array.from({ length: LENGTH }, (_, i) => pasted[i] ?? "");
    digitsRef.current = next;
    setDigits(next);
    setError(null);
    focus(pasted.length);
    if (next.every(Boolean)) void submit(next.join(""));
  }

  return (
    <div className={shaking ? "auth-shake" : undefined}>
      <div className="mb-5 flex items-center gap-3">
        <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-signal/15 ring-1 ring-signal/30"><Lock size={20} className="text-signal" aria-hidden="true" /></span>
        <div><div className="text-[11px] font-bold uppercase tracking-[0.16em] text-signal">Seviye 2 · PIN</div><h2 className="text-xl font-black tracking-tight text-white">Yönetici girişi</h2><p className="text-xs text-white/50">4 haneli güvenlik PIN kodunuzu girin.</p></div>
      </div>
      <div className="flex justify-between gap-3" role="group" aria-label="4 haneli yönetici PIN kodu">
        {digits.map((digit, index) => (
          <input
            key={index}
            ref={(el) => { refs.current[index] = el; }}
            value={digit}
            onChange={(event) => applyDigits(index, event.target.value)}
            onKeyDown={(event) => onKeyDown(index, event)}
            onPaste={onPaste}
            onFocus={(event) => event.currentTarget.select()}
            type="password"
            inputMode="numeric"
            autoComplete={index === 0 ? "one-time-code" : "off"}
            maxLength={LENGTH}
            disabled={disabled}
            aria-label={`PIN hanesi ${index + 1}`}
            className={`h-16 w-full rounded-2xl border-2 bg-ink text-center font-mono text-2xl font-black text-white outline-none transition focus:border-signal focus:ring-4 focus:ring-signal/15 disabled:opacity-50 ${error ? "border-rose/60" : digit ? "border-signal/50" : "border-white/10"}`}
          />
        ))}
      </div>
      <div className="mt-2 flex items-center justify-between text-[11px]"><span className="text-white/40">Yalnızca yönetici erişimi</span><span aria-live="polite" className={cooldownMs > 0 ? "font-bold text-signal" : "text-white/40"}>{cooldownMs > 0 ? `Bekleyin… ${formatCooldown(cooldownMs)}` : loading ? "Doğrulanıyor…" : "Hatalı girişte 3 sn bekleme"}</span></div>
      {error && <div className="mt-3"><AuthError message={error} /></div>}
      <button type="button" onClick={() => void submit(code)} disabled={disabled || code.length !== LENGTH} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-signal py-3 text-sm font-black text-white shadow-[0_10px_24px_-8px_rgba(255,91,35,0.75)] transition hover:brightness-110 disabled:opacity-50">{loading ? <Loader2 size={16} className="animate-spin text-white" aria-hidden="true" /> : <ArrowRight size={16} className="text-white" aria-hidden="true" />}{loading ? "Doğrulanıyor…" : "Admin Girişi Yap"}</button>
      <p className="mt-3 flex items-center justify-center gap-1.5 text-[10px] text-white/35"><Delete size={11} className="text-signal" aria-hidden="true" /> Backspace ile geri silin · yapıştırma desteklenir · denemeler kayda alınır</p>
    </div>
  );
}
