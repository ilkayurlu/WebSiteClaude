"use client";

import { useCallback, useRef, useState } from "react";
import { ShieldAlert } from "lucide-react";

/** Hatalı girişte kartı kısa süre titretir (hareket azaltma tercihine saygılı). */
export function useShake(duration = 500) {
  const [shaking, setShaking] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const shake = useCallback(() => {
    setShaking(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setShaking(false), duration);
  }, [duration]);
  return { shaking, shake };
}

export function AuthError({ message }: { message: string }) {
  return (
    <div role="alert" className="fade-up flex items-start gap-2 rounded-xl bg-signal/15 px-3.5 py-2.5 text-xs font-bold text-signal ring-1 ring-signal/30">
      <ShieldAlert size={15} className="mt-0.5 shrink-0 text-signal" aria-hidden="true" />
      <span>{message}</span>
    </div>
  );
}
