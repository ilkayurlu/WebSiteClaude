"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState, useTransition, type ReactNode } from "react";

export async function api<T = Record<string, unknown>>(url: string, method: string, body?: unknown, headers?: Record<string, string>): Promise<T> {
  const res = await fetch(url, {
    method,
    headers: { "Content-Type": "application/json", ...(headers ?? {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error((data as { error?: string }).error ?? "Bir şeyler ters gitti.");
  return data as T;
}

export function AutoRefresh({ ms = 4000 }: { ms?: number }) {
  const router = useRouter();
  useEffect(() => {
    const t = setInterval(() => {
      if (document.visibilityState === "visible") router.refresh();
    }, ms);
    return () => clearInterval(t);
  }, [ms, router]);
  return null;
}

export function Countdown({ until, total = 60 }: { until: string | Date; total?: number }) {
  const end = new Date(until).getTime();
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);
  const left = Math.max(0, Math.round((end - now) / 1000));
  const pct = Math.min(100, (left / total) * 100);
  return (
    <div className="flex items-center gap-2">
      <div className="h-1.5 w-24 overflow-hidden rounded-full bg-ink/10">
        <div className={`h-full rounded-full transition-all ${left < 15 ? "bg-rose" : "bg-signal"}`} style={{ width: `${pct}%` }} />
      </div>
      <span className={`font-mono text-xs font-bold tabular-nums ${left < 15 ? "text-rose" : "text-ink/70"}`}>{left} sn</span>
    </div>
  );
}

export function ApiButton({
  url,
  method = "POST",
  body,
  className = "btn-ghost",
  children,
  confirm,
  redirect,
  prompt,
}: {
  url: string;
  method?: string;
  body?: Record<string, unknown>;
  className?: string;
  children: ReactNode;
  confirm?: string;
  redirect?: string;
  prompt?: { label: string; field: string };
}) {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [err, setErr] = useState<string | null>(null);
  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button
        type="button"
        disabled={pending}
        className={className}
        onClick={() => {
          if (confirm && !window.confirm(confirm)) return;
          let extra: Record<string, unknown> = {};
          if (prompt) {
            const v = window.prompt(prompt.label);
            if (v === null) return;
            extra = { [prompt.field]: v };
          }
          setErr(null);
          start(async () => {
            try {
              await api(url, method, { ...(body ?? {}), ...extra });
              if (redirect) router.push(redirect);
              router.refresh();
            } catch (e) {
              setErr((e as Error).message);
            }
          });
        }}
      >
        {pending ? "…" : children}
      </button>
      {err && <span className="text-xs font-semibold text-rose">{err}</span>}
    </span>
  );
}

export function FavoriteButton({ targetType, targetId, initial, compact }: { targetType: "PROVIDER" | "FLEET" | "RESTAURANT"; targetId: string; initial: boolean; compact?: boolean }) {
  const [fav, setFav] = useState(initial);
  const [pending, start] = useTransition();
  const [err, setErr] = useState<string | null>(null);
  const router = useRouter();
  return (
    <span className="inline-flex flex-col">
      <button
        type="button"
        disabled={pending}
        aria-pressed={fav}
        onClick={() =>
          start(async () => {
            try {
              setErr(null);
              const r = await api<{ favorite: boolean }>("/api/favorites", "POST", { targetType, targetId });
              setFav(r.favorite);
              router.refresh();
            } catch (e) {
              setErr((e as Error).message);
            }
          })
        }
        className={compact ? `flex h-9 w-9 items-center justify-center rounded-full border bg-white text-lg transition ${fav ? "border-signal text-signal" : "border-line text-ink/40 hover:text-signal"}` : `btn ${fav ? "border border-signal bg-signal/10 text-signal" : "border border-line bg-white text-ink hover:border-signal/50"}`}
      >
        {fav ? "♥" : "♡"}
        {!compact && (fav ? " Favorimde" : " Favori")}
      </button>
      {err && !compact && <span className="mt-1 text-xs text-rose">{err}</span>}
    </span>
  );
}

type DemoUser = { id: string; name: string; role: string; roleLabel: string };

export function RoleSwitcher({ users, currentId }: { users: DemoUser[]; currentId: string }) {
  const [open, setOpen] = useState(false);
  const router = useRouter();
  const ref = useRef<HTMLDivElement>(null);
  const current = users.find((u) => u.id === currentId);
  useEffect(() => {
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);
  const groups = ["CUSTOMER", "PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER", "ADMIN", "SUPER_ADMIN"];
  return (
    <div className="relative" ref={ref}>
      <button type="button" onClick={() => setOpen(!open)} className="flex items-center gap-2 rounded-full border border-white/15 bg-white/5 py-1 pl-1 pr-3 text-left text-white transition hover:bg-white/10">
        <span className="flex h-7 w-7 items-center justify-center rounded-full bg-signal text-xs font-black">{current?.name[0]}</span>
        <span className="hidden leading-tight sm:block">
          <span className="block text-xs font-bold">{current?.name}</span>
          <span className="block text-[10px] text-white/55">{current?.roleLabel}</span>
        </span>
        <span className="text-xs text-white/50">▾</span>
      </button>
      {open && (
        <div className="fade-up absolute right-0 z-50 mt-2 max-h-[70vh] w-72 overflow-auto rounded-2xl border border-line bg-white p-2 text-ink shadow-2xl">
          <div className="px-2 pb-2 pt-1 text-[11px] font-bold uppercase tracking-wider text-ink/45">Demo hesap değiştir</div>
          {groups.map((g) => (
            <div key={g} className="mb-1">
              <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-signal">{users.find((u) => u.role === g)?.roleLabel}</div>
              {users
                .filter((u) => u.role === g)
                .map((u) => (
                  <button
                    key={u.id}
                    type="button"
                    onClick={async () => {
                      const r = await api<{ home: string }>("/api/session", "POST", { userId: u.id });
                      setOpen(false);
                      router.push(r.home);
                      router.refresh();
                    }}
                    className={`flex w-full items-center justify-between rounded-lg px-2 py-1.5 text-left text-sm hover:bg-paper ${u.id === currentId ? "bg-paper font-bold" : ""}`}
                  >
                    {u.name}
                    {u.id === currentId && <span className="text-signal">●</span>}
                  </button>
                ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

type Notif = { id: string; title: string; body: string | null; link: string | null; readAt: string | null; createdAt: string };

export function NotificationBell() {
  const [data, setData] = useState<{ items: Notif[]; unread: number }>({ items: [], unread: 0 });
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let alive = true;
    const load = () =>
      fetch("/api/notifications")
        .then((r) => (r.ok ? r.json() : null))
        .then((d) => alive && d && setData(d))
        .catch(() => {});
    load();
    const t = setInterval(load, 6000);
    const h = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("mousedown", h);
    return () => {
      alive = false;
      clearInterval(t);
      document.removeEventListener("mousedown", h);
    };
  }, []);
  return (
    <div className="relative" ref={ref}>
      <button
        type="button"
        aria-label="Bildirimler"
        onClick={() => {
          setOpen(!open);
          if (!open && data.unread) {
            fetch("/api/notifications", { method: "POST" }).catch(() => {});
            setTimeout(() => setData((d) => ({ ...d, unread: 0 })), 1500);
          }
        }}
        className="relative flex h-9 w-9 items-center justify-center rounded-full border border-white/15 bg-white/5 text-white hover:bg-white/10"
      >
        🔔
        {data.unread > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-signal px-1 text-[10px] font-black">{data.unread}</span>}
      </button>
      {open && (
        <div className="fade-up absolute right-0 z-50 mt-2 w-80 overflow-hidden rounded-2xl border border-line bg-white text-ink shadow-2xl">
          <div className="border-b border-line px-4 py-3 text-sm font-extrabold">Bildirimler</div>
          <div className="max-h-96 overflow-auto">
            {data.items.length === 0 && <div className="px-4 py-8 text-center text-sm text-ink/50">Henüz bildirim yok.</div>}
            {data.items.map((n) => (
              <Link key={n.id} href={n.link ?? "#"} onClick={() => setOpen(false)} className={`block border-b border-line/60 px-4 py-3 hover:bg-paper ${n.readAt ? "" : "bg-signal/[0.04]"}`}>
                <div className="flex items-center gap-2 text-sm font-bold">
                  {!n.readAt && <span className="h-1.5 w-1.5 rounded-full bg-signal" />}
                  {n.title}
                </div>
                {n.body && <div className="mt-0.5 text-xs text-ink/60">{n.body}</div>}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
