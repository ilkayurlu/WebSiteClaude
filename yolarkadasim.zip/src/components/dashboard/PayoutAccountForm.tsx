"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Landmark, Loader2, ShieldCheck } from "lucide-react";
import { savePayoutAccountAction } from "@/actions/admin-finance-actions";

export function PayoutAccountForm({ beneficiaryType, beneficiaryId, current }: { beneficiaryType: "COURIER" | "FLEET"; beneficiaryId: string; current: { ibanMasked: string; holderName: string } | null }) {
  const router = useRouter();
  const [editing, setEditing] = useState(!current);
  const [iban, setIban] = useState("");
  const [holder, setHolder] = useState(current?.holderName ?? "");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 font-extrabold"><Landmark size={17} className="text-signal" /> Ödeme hesabı (IBAN)</h3>
        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-ink/50"><ShieldCheck size={12} className="text-signal" /> Özel saklanır</span>
      </div>
      <p className="mt-1 text-xs text-ink/55">Hakediş ödemeleri bu hesaba yapılır. IBAN hiçbir yerde açık gösterilmez; yalnızca maskeli hali görünür.</p>
      {current && !editing ? (
        <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-paper px-3 py-2.5 text-sm">
          <span><b className="font-mono">{current.ibanMasked}</b><span className="ml-2 text-xs text-ink/55">{current.holderName}</span></span>
          <button type="button" onClick={() => setEditing(true)} className="btn-ghost btn-sm">Güncelle</button>
        </div>
      ) : (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <div><label className="label" htmlFor="iban">IBAN</label><input id="iban" className="input font-mono" value={iban} onChange={(e) => setIban(e.target.value.toUpperCase())} placeholder="TR00 0000 0000 0000 0000 0000 00" maxLength={40} autoComplete="off" /></div>
          <div><label className="label" htmlFor="holder">Hesap sahibi</label><input id="holder" className="input" value={holder} onChange={(e) => setHolder(e.target.value)} maxLength={120} /></div>
          <div className="flex gap-2 sm:col-span-2">
            <button type="button" disabled={pending || iban.replace(/\s/g, "").length < 26 || holder.trim().length < 3} onClick={() => start(async () => { setMsg(null); const r = await savePayoutAccountAction({ beneficiaryType, beneficiaryId, iban, holderName: holder }); if (r.success) { setMsg({ ok: true, text: `Kaydedildi: ${r.ibanMasked}` }); setIban(""); setEditing(false); router.refresh(); } else setMsg({ ok: false, text: r.error ?? "Kaydedilemedi." }); })} className="btn-primary btn-sm">{pending ? <Loader2 size={13} className="animate-spin" /> : null} IBAN&apos;ı kaydet</button>
            {current && <button type="button" onClick={() => setEditing(false)} className="btn-ghost btn-sm">Vazgeç</button>}
          </div>
        </div>
      )}
      {msg && <p role={msg.ok ? "status" : "alert"} className={`mt-2 text-xs font-semibold ${msg.ok ? "text-[#0c8a5a]" : "text-rose"}`}>{msg.text}</p>}
    </div>
  );
}
