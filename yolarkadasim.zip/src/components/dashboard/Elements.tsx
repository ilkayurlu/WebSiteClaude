import Link from "next/link";
import type { ReactNode } from "react";
import { ArrowDownRight, ArrowRight, ArrowUpRight, CalendarClock, CheckCircle2, Clock3, LockKeyhole, MapPin, Navigation2, Package, Sparkles, Star, type LucideIcon } from "lucide-react";
import { Avatar, RequestStatusPill } from "@/components/ui";
import { dateTime, money, ORDER_STATUS } from "@/lib/labels";
import type { MetricItem, TaskSummary } from "@/lib/dashboard-data";

export function DashboardHeading({ eyebrow, title, desc, action }: { eyebrow: string; title: string; desc?: string; action?: ReactNode }) {
  return <div className="mb-7 flex flex-wrap items-end justify-between gap-4"><div><div className="eyebrow">{eyebrow}</div><h1 className="mt-2 text-3xl font-black tracking-[-0.035em] sm:text-[38px]">{title}</h1>{desc && <p className="mt-1 max-w-2xl text-sm leading-relaxed text-ink/55">{desc}</p>}</div>{action}</div>;
}

export function MetricCard({ item, icon: Icon, accent = "signal" }: { item: MetricItem; icon: LucideIcon; accent?: "signal" | "mint" | "sky" | "ink" }) {
  // Marka kuralı: tüm ikonlar turuncu; accent yalnızca geriye dönük uyumluluk için kabul edilir.
  void accent;
  const tone = "bg-signal/10 text-signal";
  return <div className="card group p-5 transition hover:-translate-y-0.5 hover:border-signal/35 hover:shadow-[0_12px_32px_-20px_rgba(14,19,36,.35)]"><div className="flex items-start justify-between"><div className="text-xs font-bold text-ink/50">{item.title}</div><span className={`flex h-9 w-9 items-center justify-center rounded-xl ${tone}`}><Icon size={18} strokeWidth={1.8} /></span></div><div className="mt-2 text-[29px] font-black leading-none tracking-tight">{item.value}</div><div className="mt-2 text-[11px] text-ink/45">{item.detail}</div>{item.change && <span className="mt-2 inline-flex rounded-full bg-mint/10 px-2 py-0.5 text-[10px] font-bold text-[#0d8b5f]">{item.change}</span>}</div>;
}

export function PanelSection({ title, eyebrow, action, children, className = "" }: { title: string; eyebrow?: string; action?: { label: string; href: string }; children: ReactNode; className?: string }) {
  return <section className={className}><div className="mb-4 flex flex-wrap items-end justify-between gap-2"><div>{eyebrow && <div className="eyebrow mb-1">{eyebrow}</div>}<h2 className="text-lg font-extrabold tracking-tight sm:text-xl">{title}</h2></div>{action && <Link href={action.href} className="inline-flex items-center gap-1 text-xs font-bold text-signal transition hover:gap-2 hover:underline">{action.label}<ArrowRight size={14} /></Link>}</div>{children}</section>;
}

export function InlineEmpty({ icon: Icon = Package, title, desc, href, action }: { icon?: LucideIcon; title: string; desc: string; href?: string; action?: string }) {
  return <div className="card road-pattern flex flex-col items-center justify-center px-6 py-10 text-center"><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-signal shadow-sm ring-1 ring-line"><Icon size={21} /></span><h3 className="mt-3 text-sm font-extrabold">{title}</h3><p className="mt-1 max-w-sm text-xs leading-relaxed text-ink/55">{desc}</p>{href && action && <Link href={href} className="btn-primary btn-sm mt-4">{action}<ArrowRight size={13} /></Link>}</div>;
}

export function DeliveryCode({ code, small = false }: { code: string; small?: boolean }) {
  return <div className={`rounded-2xl border border-signal/20 bg-signal/[.07] ${small ? "px-3 py-2" : "px-5 py-4"}`}><div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[.13em] text-signal"><LockKeyhole size={12} /> 4 haneli teslim kodu</div><div className={`${small ? "mt-1 text-2xl" : "mt-2 text-[34px]"} font-mono font-black leading-none tracking-[.23em] text-ink`}>{code}</div><div className="mt-1.5 text-[10px] text-ink/50">Yalnızca teslim anında paylaşın</div></div>;
}

export function TaskTile({ task, showOtp = false }: { task: TaskSummary; showOtp?: boolean }) {
  return <div className="card flex flex-col gap-4 p-4 sm:flex-row sm:items-center sm:p-5"><div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-signal/10 text-signal"><Navigation2 size={18} /></div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><Link href={`/talep/${task.id}`} className="font-mono text-sm font-black hover:text-signal">{task.code}</Link><RequestStatusPill status={task.status} /></div><div className="mt-1 flex items-center gap-1.5 text-xs text-ink/55"><MapPin size={12} className="shrink-0 text-signal" />{task.pickup} <ArrowRight size={12} /> {task.dropoff}</div><div className="mt-1.5 flex flex-wrap items-center gap-2 text-[11px] text-ink/50">{task.providerName && <span className="flex items-center gap-1"><span className="h-4 w-4 rounded-full bg-signal/20 text-center text-[9px] font-bold text-signal">{task.providerName.charAt(0)}</span>{task.providerName}</span>}{task.eta && <span className="font-bold text-ink/75">~ ETA {task.eta}</span>}<span>{dateTime(task.createdAt)}</span></div></div>{showOtp && task.deliveryOtp && <DeliveryCode code={task.deliveryOtp} small />}<div className="flex items-center justify-between gap-3 sm:block sm:text-right"><div className="text-sm font-black">{money(task.priceMinor)}</div><Link href={`/talep/${task.id}`} className="mt-1 inline-flex items-center gap-1 text-[11px] font-bold text-signal hover:underline">Detay <ArrowUpRight size={12} /></Link></div></div>;
}

export function FoodOrderTile({ order }: { order: { id: string; code: string; status: string; restaurantName: string; totalMinor: number; placedAt: Date } }) {
  const state = ORDER_STATUS[order.status];
  return <Link href={`/siparis/${order.id}`} className="card card-hover flex items-center gap-3 p-4"><span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-paper text-lg">🍽️</span><span className="min-w-0 flex-1"><span className="flex flex-wrap items-center gap-2"><b className="font-mono text-sm">{order.code}</b><span className={`rounded-full px-2 py-0.5 text-[10px] font-bold tone-${state?.tone ?? "slate"}`}>{state?.label ?? order.status}</span></span><span className="mt-1 block truncate text-xs text-ink/50">{order.restaurantName} · {dateTime(order.placedAt)}</span></span><span className="text-right"><b className="block text-sm">{money(order.totalMinor)}</b><span className="text-[11px] font-semibold text-signal">Ayrıntı →</span></span></Link>;
}

export function MiniProgress({ label, value, max, tint = "signal" }: { label: string; value: number; max: number; tint?: "signal" | "mint" | "sky" }) {
  return <div><div className="flex justify-between text-xs"><span className="font-semibold text-ink/60">{label}</span><b>{value}</b></div><div className="mt-1 h-2 overflow-hidden rounded-full bg-paper-2"><div className={`h-full rounded-full ${tint === "mint" ? "bg-mint" : tint === "sky" ? "bg-sky" : "bg-signal"}`} style={{ width: `${Math.min(100, Math.max(0, (value / Math.max(max, 1)) * 100))}%` }} /></div></div>;
}

export { ArrowDownRight, CalendarClock, CheckCircle2, Clock3, Sparkles, Star };
