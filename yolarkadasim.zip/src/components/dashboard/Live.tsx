"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import type { DashboardPulse } from "@/lib/dashboard-data";
import type { DashboardRole } from "@/lib/dashboard-config";
import { ChatDock } from "@/components/chat/ChatSheet";
import { DashboardSidebar } from "./Sidebar";
import { DashboardHeader } from "./Header";

/** SSE + sınırlı polling yedeği. Tüm güncellemeler rol kapsamında ve PII'siz sunulur. */
export function useTaskUpdates(initial: DashboardPulse) {
  const router = useRouter();
  const [pulse, setPulse] = useState(initial);
  const [connected, setConnected] = useState<"live" | "connecting" | "fallback">("connecting");
  const last = useRef(initial.signature);
  const [notice, setNotice] = useState("");
  const noticeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const apply = useCallback((next: DashboardPulse) => {
    setPulse((previous) => {
      if (next.offers > previous.offers) setNotice("Yeni kurye teklifi geldi.");
      else if (next.pending > previous.pending) setNotice("Yeni onay bekleyen talep var.");
      if (next.offers > previous.offers || next.pending > previous.pending) {
        if (noticeTimer.current) clearTimeout(noticeTimer.current);
        noticeTimer.current = setTimeout(() => setNotice(""), 5000);
      }
      return next;
    });
    if (last.current !== next.signature) { last.current = next.signature; router.refresh(); }
  }, [router]);

  useEffect(() => {
    const source = new EventSource("/api/dashboard/stream");
    let poll: ReturnType<typeof setInterval> | null = null;
    source.addEventListener("dashboard", (event: MessageEvent<string>) => {
      try { apply(JSON.parse(event.data) as DashboardPulse); setConnected("live"); if (poll) { clearInterval(poll); poll = null; } }
      catch { /* geçersiz veri atlanır */ }
    });
    source.onopen = () => setConnected("live");
    source.onerror = () => {
      setConnected("fallback");
      if (!poll) poll = setInterval(async () => {
        try { const res = await fetch("/api/dashboard/pulse", { cache: "no-store" }); if (res.ok) apply(await res.json() as DashboardPulse); }
        catch { /* bir sonraki turda dene */ }
      }, 8000);
    };
    return () => { source.close(); if (poll) clearInterval(poll); if (noticeTimer.current) clearTimeout(noticeTimer.current); };
  }, [apply]);
  return { pulse, connected, notice };
}

export function DashboardShell({ role, userId, name, status, initialPulse, children }: { role: DashboardRole; userId: string; name: string; status?: string; initialPulse: DashboardPulse; children: ReactNode }) {
  const [menu, setMenu] = useState(false);
  const { pulse, connected, notice } = useTaskUpdates(initialPulse);
  return <div className="min-h-screen bg-paper lg:pl-[260px]">
    <DashboardSidebar role={role} name={name} pulse={pulse} open={menu} close={() => setMenu(false)} />
    <div className="min-h-screen">
      <DashboardHeader role={role} name={name} pulse={pulse} status={status} connected={connected} openMenu={() => setMenu(true)} />
      <main className="mx-auto max-w-[1500px] px-4 pb-16 pt-6 sm:px-7 sm:pt-8">{children}</main>
      <footer className="border-t border-line px-5 py-4 text-center text-[11px] text-ink/40">YolArkadaşı · Güvenli çalışma alanı · Gerçek tahsilat ve SMS bu demo ortamında bağlı değildir.</footer>
    </div>
    {!["ADMIN", "SUPER_ADMIN"].includes(role) && <ChatDock meId={userId} meRole={role} />}
    {notice && <div role="status" className="fixed bottom-5 right-5 z-[60] rounded-2xl bg-ink px-4 py-3 text-sm font-bold text-white shadow-2xl"><span className="mr-2 text-signal">●</span>{notice}</div>}
  </div>;
}
