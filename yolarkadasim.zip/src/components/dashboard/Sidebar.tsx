"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ArrowUpRight, Compass, LockKeyhole, X } from "lucide-react";
import type { DashboardPulse } from "@/lib/dashboard-data";
import { dashboardNav, roleTitles, sharedNav, type DashboardRole, type NavItem } from "@/lib/dashboard-config";

function NavRows({ role, pulse, onNavigate }: { role: DashboardRole; pulse: DashboardPulse; onNavigate: () => void }) {
  const pathname = usePathname();
  const numberFor = (item: NavItem) => item.badgeKey === "unread" ? pulse.messages : item.badgeKey ? pulse[item.badgeKey] : 0;
  const render = (item: NavItem) => {
    const active = pathname === item.href;
    const Icon = item.icon;
    const badge = numberFor(item);
    return <Link key={item.href} href={item.href} onClick={onNavigate} aria-current={active ? "page" : undefined} className={`group flex min-h-11 items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-semibold transition-all duration-200 focus-visible:outline focus-visible:outline-2 focus-visible:outline-signal ${active ? "bg-signal/15 text-white ring-1 ring-signal/45 shadow-[0_8px_20px_-12px_rgba(255,91,35,.9)]" : "text-white/60 hover:bg-white/[0.08] hover:pl-4 hover:text-white"}`}>
      <Icon size={17} strokeWidth={active ? 2.4 : 1.9} className={`text-signal transition ${active ? "drop-shadow-[0_0_6px_rgba(255,91,35,.7)]" : "opacity-80 group-hover:opacity-100"}`} />
      <span className="min-w-0 flex-1 truncate">{item.label}</span>
      {badge > 0 && <span className="flex min-w-5 items-center justify-center rounded-md bg-signal px-1.5 py-0.5 text-[10px] font-black text-white">{badge > 99 ? "99+" : badge}</span>}
      {!badge && (item.href === "/" || item.href === "/mesajlar") && <ArrowUpRight size={12} className="text-signal opacity-0 transition group-hover:opacity-90" />}
    </Link>;
  };
  return <nav className="flex-1 overflow-y-auto px-3 pb-5" aria-label="Dashboard menüsü">
    <div className="mb-3 px-3 pt-2 text-[10px] font-bold uppercase tracking-[.2em] text-white/30">Çalışma alanım</div>
    <div className="space-y-1">{dashboardNav[role].map(render)}</div>
    <div className="mx-3 my-5 h-px bg-white/10" />
    <div className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.2em] text-white/30">Bağlantılar</div>
    <div className="space-y-1">{sharedNav.filter((item) => !["ADMIN", "SUPER_ADMIN"].includes(role) || item.href !== "/mesajlar").map(render)}</div>
  </nav>;
}

function AsideContent({ role, name, pulse, onNavigate }: { role: DashboardRole; name: string; pulse: DashboardPulse; onNavigate: () => void }) {
  const info = roleTitles[role];
  const Symbol = info.symbol;
  return <div className="flex h-full flex-col overflow-hidden bg-ink text-white">
    <div className="border-b border-white/10 px-6 py-6">
      <Link href="/" onClick={onNavigate} className="flex items-center gap-2.5">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-signal text-signal shadow-[0_8px_20px_-10px_rgba(255,91,35,.9)]"><Compass size={20} strokeWidth={2.3} /></span>
        <span className="text-[17px] font-black tracking-tight">Yol<span className="text-signal">Arkadaşı</span></span>
      </Link>
      <div className="mt-7 flex items-center gap-3 rounded-2xl bg-white/[.055] px-3 py-3 ring-1 ring-white/10">
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-signal/15 text-signal"><Symbol size={18} /></span>
        <span className="min-w-0"><span className="block truncate text-sm font-extrabold">{info.title}</span><span className="block truncate text-[11px] text-white/40">{info.caption}</span></span>
      </div>
    </div>
    <NavRows role={role} pulse={pulse} onNavigate={onNavigate} />
    <div className="mx-4 mb-5 rounded-2xl bg-white/[.045] px-4 py-3 ring-1 ring-white/[.07]">
      <div className="flex items-center gap-2 text-[11px] font-bold text-mint"><span className="h-1.5 w-1.5 rounded-full bg-mint" /> Güvenli çalışma alanı</div>
      <p className="mt-1 text-[11px] leading-relaxed text-white/40">Merhaba {name.split(" ")[0]}. Burada yalnızca kendi rolünün verilerini görürsün.</p>
      <p className="mt-2 flex items-center gap-1.5 text-[10px] text-white/35"><LockKeyhole size={11} className="text-signal" /> Konum ve özel bilgiler gizli</p>
    </div>
  </div>;
}

export function DashboardSidebar({ role, name, pulse, open, close }: { role: DashboardRole; name: string; pulse: DashboardPulse; open: boolean; close: () => void }) {
  return <>
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-[260px] lg:block"><AsideContent role={role} name={name} pulse={pulse} onNavigate={close} /></aside>
    {open && <div className="fixed inset-0 z-[75] bg-ink/65 backdrop-blur-sm lg:hidden" onClick={close} role="presentation">
      <aside className="h-full w-[min(85vw,300px)] shadow-2xl" onClick={(event) => event.stopPropagation()}>
        <div className="relative h-full"><AsideContent role={role} name={name} pulse={pulse} onNavigate={close} /><button onClick={close} aria-label="Menüyü kapat" className="absolute right-3 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"><X size={18} className="text-signal" /></button></div>
      </aside>
    </div>}
  </>;
}
