"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Bell, ChevronDown, ExternalLink, LogOut, Menu, MessageCircle, Radio, ShieldCheck } from "lucide-react";
import type { DashboardPulse } from "@/lib/dashboard-data";
import { dashboardNav, roleTitles, type DashboardRole } from "@/lib/dashboard-config";
import { serverStatusToUi } from "@/lib/provider-status-ui";
import { ProviderStatusToggle } from "@/components/dashboard/ProviderStatusToggle";
import { api } from "@/components/client";

interface NotificationItem { id: string; title: string; body: string | null; link: string | null; readAt: string | Date | null; createdAt: string | Date }

function NotificationDropdown({ pulse }: { pulse: DashboardPulse }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [error, setError] = useState("");
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    function outside(e: MouseEvent) { if (root.current && !root.current.contains(e.target as Node)) setOpen(false); }
    document.addEventListener("mousedown", outside);
    return () => document.removeEventListener("mousedown", outside);
  }, []);
  async function toggle() {
    setOpen(!open);
    if (open) return;
    try {
      const result = await api<{ items: NotificationItem[] }>("/api/notifications", "GET");
      setItems(result.items); setError("");
      if (pulse.unread) await api("/api/notifications", "POST");
    } catch (e) { setError(e instanceof Error ? e.message : "Bildirimler yüklenemedi."); }
  }
  return <div ref={root} className="relative">
    <button onClick={toggle} aria-label={`Bildirimler${pulse.unread ? `, ${pulse.unread} okunmamış` : ""}`} aria-expanded={open} className="relative flex h-9 w-9 items-center justify-center rounded-full border border-line text-signal transition hover:border-signal hover:bg-signal/10"><Bell size={17} />{pulse.unread > 0 && <span className="absolute -right-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-signal px-1 text-[10px] font-black text-white">{pulse.unread}</span>}</button>
    {open && <div className="absolute right-0 top-11 z-50 w-[min(86vw,340px)] overflow-hidden rounded-2xl border border-line bg-white shadow-2xl"><div className="border-b border-line px-4 py-3 text-sm font-extrabold">Bildirimler</div><div className="max-h-[320px] overflow-y-auto">{error && <p role="alert" className="p-4 text-xs text-rose">{error}</p>}{!error && !items.length && <p className="p-6 text-center text-sm text-ink/50">Henüz bildirim yok.</p>}{items.map((n) => <Link key={n.id} href={n.link && n.link.startsWith("/") ? n.link : "/dashboard"} onClick={() => setOpen(false)} className="block border-b border-line/60 px-4 py-3 transition hover:bg-paper"><span className="block text-xs font-extrabold">{n.title}</span>{n.body && <span className="mt-1 line-clamp-2 block text-[11px] leading-relaxed text-ink/55">{n.body}</span>}</Link>)}</div></div>}
  </div>;
}

export function DashboardHeader({ role, name, pulse, status, openMenu, connected }: { role: DashboardRole; name: string; pulse: DashboardPulse; status?: string; openMenu: () => void; connected: "live" | "connecting" | "fallback" }) {
  const pathname = usePathname();
  const router = useRouter();
  const [profileOpen, setProfileOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const active = dashboardNav[role].find((item) => item.href === pathname);
  const title = active?.label ?? roleTitles[role].title;
  const month = new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "long", year: "numeric", timeZone: "Europe/Istanbul" }).format(new Date());
  async function logout() {
    setSigningOut(true);
    try { await api("/api/session", "DELETE"); router.replace("/giris"); router.refresh(); }
    catch { setSigningOut(false); }
  }
  return <header className="sticky top-0 z-30 flex h-[68px] items-center justify-between gap-3 border-b border-line/75 bg-white/90 px-4 backdrop-blur-xl sm:px-7">
    <div className="flex min-w-0 items-center gap-3">
      <button type="button" onClick={openMenu} aria-label="Menüyü aç" className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-line text-signal lg:hidden"><Menu size={19} /></button>
      <div className="min-w-0"><div className="truncate text-sm font-extrabold tracking-tight sm:text-base">{title}</div><div className="hidden text-[11px] text-ink/45 sm:block">{month} · {roleTitles[role].title}</div></div>
      <span className={`hidden items-center gap-1.5 rounded-full px-2.5 py-1 text-[10px] font-bold md:inline-flex ${connected === "live" ? "bg-mint/10 text-[#08734c]" : connected === "fallback" ? "bg-sun/10 text-[#866100]" : "bg-paper-2 text-ink/45"}`}><Radio size={12} className="text-signal" /> {connected === "live" ? "Canlı" : connected === "fallback" ? "Yedek bağlantı" : "Bağlanıyor"}</span>
    </div>
    <div className="flex shrink-0 items-center gap-2 sm:gap-3">
      {role === "PROVIDER" && status && <ProviderStatusToggle initialStatus={serverStatusToUi(status)} serverStatus={status} variant="compact" />}
      {!["ADMIN", "SUPER_ADMIN"].includes(role) && <Link href="/mesajlar" aria-label={`Mesajlar${pulse.messages ? `, ${pulse.messages} okunmamış` : ""}`} className="relative flex h-9 w-9 items-center justify-center rounded-full border border-line text-signal transition hover:border-signal hover:bg-signal/10"><MessageCircle size={17} />{pulse.messages > 0 && <span className="absolute -right-1 -top-1 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-signal px-1 text-[10px] font-black text-white">{pulse.messages}</span>}</Link>}
      <NotificationDropdown pulse={pulse} />
      <div className="relative">
        <button type="button" onClick={() => setProfileOpen(!profileOpen)} aria-expanded={profileOpen} className="flex min-h-10 items-center gap-2 rounded-full border border-line bg-paper/50 py-1 pl-1 pr-2 transition hover:border-signal sm:pr-3"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-ink text-xs font-black text-white">{name.charAt(0)}</span><span className="hidden max-w-32 truncate text-xs font-bold sm:block">{name}</span><ChevronDown size={13} className="text-signal" /></button>
        {profileOpen && <div className="absolute right-0 top-12 z-50 w-52 rounded-xl border border-line bg-white p-1.5 shadow-2xl"><div className="border-b border-line px-3 py-2 text-xs"><b className="block truncate">{name}</b><span className="text-ink/45">{roleTitles[role].title}</span></div><Link href="/" className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold hover:bg-paper"><ExternalLink size={14} className="text-signal" /> Platforma dön</Link><Link href="/giris" className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold hover:bg-paper"><ShieldCheck size={14} className="text-signal" /> Hesap değiştir</Link><button type="button" disabled={signingOut} onClick={logout} className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-xs font-bold text-rose hover:bg-rose/10"><LogOut size={14} className="text-signal" />{signingOut ? "Çıkış yapılıyor…" : "Çıkış yap"}</button></div>}
      </div>
    </div>
  </header>;
}
