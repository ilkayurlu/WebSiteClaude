"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { AlertCircle, CalendarClock, Check, Plus, Send, X } from "lucide-react";
import { api } from "@/components/client";
import { VEHICLES } from "@/lib/labels";

export function SupportCaseForm({ sourceType, sourceId, compact = false }: { sourceType: "REQUEST" | "ORDER"; sourceId: string; compact?: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [category, setCategory] = useState<"DELIVERY" | "OTP" | "CANCELLATION" | "OTHER">("DELIVERY");
  const [detail, setDetail] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [sent, setSent] = useState(false);
  const label = compact ? "Destek talebi" : "Sorun bildir";
  return <div>
    {!open && <button type="button" onClick={() => setOpen(true)} className="btn-ghost btn-sm"><AlertCircle size={14} />{sent ? "Yeni talep aç" : label}</button>}
    {open && <div className="mt-3 rounded-2xl border border-line bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between"><b className="text-sm">Destek kaydı aç</b><button type="button" onClick={() => setOpen(false)} aria-label="Kapat" className="text-ink/40 hover:text-rose"><X size={18} /></button></div>
      <p className="mt-1 text-[11px] text-ink/50">Bu kayıt yalnızca kendi {sourceType === "REQUEST" ? "görevinize" : "siparişinize"} bağlanır. Operasyon ekibi inceler.</p>
      <label className="label mt-3" htmlFor={`case-${sourceId}`}>Konu</label>
      <select id={`case-${sourceId}`} className="input" value={category} onChange={(e) => setCategory(e.target.value as typeof category)}><option value="DELIVERY">Teslimat / gecikme</option><option value="OTP">Teslim kodu</option><option value="CANCELLATION">İptal / iade</option><option value="OTHER">Diğer</option></select>
      <label className="label mt-3" htmlFor={`case-detail-${sourceId}`}>Açıklama (en az 12 karakter)</label>
      <textarea id={`case-detail-${sourceId}`} className="input min-h-24" value={detail} onChange={(e) => setDetail(e.target.value)} maxLength={1000} placeholder="Yaşadığınız durumu kısaca anlatın. Kart/şifre paylaşmayın." />
      {error && <p role="alert" className="mt-2 text-xs font-semibold text-rose">{error}</p>}
      <button type="button" disabled={pending || detail.trim().length < 12} onClick={async () => { setPending(true); setError(""); try { await api("/api/dashboard/support", "POST", { sourceType, sourceId, category, detail }); setSent(true); setOpen(false); setDetail(""); router.refresh(); } catch (e) { setError(e instanceof Error ? e.message : "Kaydedilemedi."); } finally { setPending(false); } }} className="btn-primary btn-sm mt-3"><Send size={13} />{pending ? "Gönderiliyor…" : "Operasyona gönder"}</button>
    </div>}
    {sent && !open && <span role="status" className="ml-2 text-xs font-bold text-[#0d8759]"><Check size={12} className="inline text-signal" /> Kayıt alındı</span>}
  </div>;
}

export function FleetInviteForm() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [pending, setPending] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  return <div className="card p-5"><h3 className="text-sm font-extrabold">Filona üye davet et</h3><p className="mt-1 text-xs text-ink/55">Yalnızca platforma kayıtlı bağımsız sağlayıcılara davet gönderebilirsin. Üyelik, kişi kabul edince başlar; dış servise e-posta gönderilmez.</p><div className="mt-4 flex flex-col gap-2 sm:flex-row"><input type="email" className="input flex-1" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="kayıtlı@demo.yolarkadasi.app" aria-label="Sağlayıcı e-postası" /><button type="button" disabled={pending || !email.includes("@") } onClick={async () => { setPending(true); setError(""); setNotice(""); try { await api("/api/dashboard/fleet/invitations", "POST", { email }); setNotice("Davet sağlayıcının paneline iletildi."); setEmail(""); router.refresh(); } catch (e) { setError(e instanceof Error ? e.message : "Davet oluşturulamadı."); } finally { setPending(false); } }} className="btn-primary shrink-0"><Plus size={15} />{pending ? "İletiliyor…" : "Davet gönder"}</button></div>{error && <p role="alert" className="mt-2 text-xs font-semibold text-rose">{error}</p>}{notice && <p role="status" className="mt-2 text-xs font-semibold text-[#0d8759]">{notice}</p>}</div>;
}

export function FleetDutyForm({ members }: { members: { id: string; name: string; vehicleType: string; vehicleLabel: string | null }[] }) {
  const router = useRouter();
  const [providerId, setProviderId] = useState(members[0]?.id ?? "");
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [vehicleLabel, setVehicleLabel] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const provider = members.find((m) => m.id === providerId);
  return <div className="card p-5"><div className="flex items-center gap-2"><CalendarClock size={16} className="text-signal" /><h3 className="text-sm font-extrabold">Vardiya & araç planla</h3></div><p className="mt-1 text-xs text-ink/55">Bu bir planlamadır; gerçek çevrimiçi süre kurye Online olduğunda başlar. Araç tipi üyenin kayıtlı aracından gelir.</p>{members.length ? <div className="mt-4 grid gap-3 sm:grid-cols-2"><div><label className="label" htmlFor="duty-provider">Üye</label><select id="duty-provider" className="input" value={providerId} onChange={(e) => { setProviderId(e.target.value); setVehicleLabel(""); }}>{members.map((m) => <option key={m.id} value={m.id}>{m.name} · {VEHICLES[m.vehicleType]?.label ?? m.vehicleType}</option>)}</select></div><div><label className="label" htmlFor="duty-vehicle">Araç etiketi (isteğe bağlı)</label><input id="duty-vehicle" className="input" value={vehicleLabel} onChange={(e) => setVehicleLabel(e.target.value)} maxLength={70} placeholder={provider?.vehicleLabel ?? "Araç bilgisi"} /></div><div><label className="label" htmlFor="duty-start">Başlangıç</label><input id="duty-start" type="datetime-local" className="input" value={start} onChange={(e) => setStart(e.target.value)} /></div><div><label className="label" htmlFor="duty-end">Bitiş</label><input id="duty-end" type="datetime-local" className="input" value={end} onChange={(e) => setEnd(e.target.value)} /></div><div className="sm:col-span-2"><button type="button" disabled={pending || !provider || !start || !end} onClick={async () => { setPending(true); setError(""); setNotice(""); try { await api("/api/dashboard/fleet/duties", "POST", { providerId, vehicleType: provider?.vehicleType, vehicleLabel: vehicleLabel || undefined, startsAt: new Date(start).toISOString(), endsAt: new Date(end).toISOString() }); setNotice("Vardiya planlandı ve üyeye bildirildi."); setStart(""); setEnd(""); router.refresh(); } catch (e) { setError(e instanceof Error ? e.message : "Vardiya oluşturulamadı."); } finally { setPending(false); } }} className="btn-ink btn-sm"><CalendarClock size={14} />{pending ? "Kaydediliyor…" : "Vardiya planla"}</button></div></div> : <p className="mt-4 rounded-xl bg-paper p-4 text-xs text-ink/55">Planlama için önce ekibine sağlayıcı davet etmelisin.</p>}{error && <p role="alert" className="mt-2 text-xs font-semibold text-rose">{error}</p>}{notice && <p role="status" className="mt-2 text-xs font-semibold text-[#0d8759]">{notice}</p>}</div>;
}
