import Link from "next/link";
import { ArrowRight, CalendarClock, Check, Clock3, MapPin, MessageCircle, Navigation2, PackageCheck, X } from "lucide-react";
import { ApiButton, Countdown } from "@/components/client";
import { OpenChatButton } from "@/components/chat/ChatSheet";
import { ActiveDeliveryCard } from "./ActiveDeliveryCard";
import { MAX_OTP_ATTEMPTS } from "@/lib/delivery";
import { Pill } from "@/components/ui";
import { areaName, etaBand } from "@/lib/geo";
import { dateTime, money, MODES, SERVICES } from "@/lib/labels";
import { OFFER_TTL_S } from "@/lib/engine";
import type { Assignment, Candidate, ServiceRequest } from "@/db/schema";

export function ProviderTaskCard({ task, meId }: { task: { a: Assignment; r: ServiceRequest; customerMasked: string }; meId: string }) {
  const { a, r, customerMasked } = task;
  if (a.state !== "CONFIRMED" && a.state !== "IN_PROGRESS") return null;
  return (
    <ActiveDeliveryCard
      meId={meId}
      delivery={{
        requestId: r.id,
        assignmentId: a.id,
        code: r.code,
        state: a.state,
        customerMasked,
        pickupArea: areaName(r.pickupArea),
        dropoffArea: areaName(r.dropoffArea ?? r.pickupArea),
        dropoffDetail: r.dropoffDetail ?? r.pickupDetail,
        priceLabel: money(r.finalPriceMinor),
        scheduleLabel: r.scheduledStart ? dateTime(r.scheduledStart) : MODES[r.mode]?.label ?? "Anlık görev",
        attemptsLeft: Math.max(0, MAX_OTP_ATTEMPTS - r.otpAttempts),
        locked: !!r.otpLockedAt,
      }}
    />
  );
}

export function ProviderOfferCard({ offer }: { offer: { c: Candidate; r: ServiceRequest } }) {
  const { c, r } = offer;
  return <article className="card overflow-hidden border-signal/30"><div className="flex flex-wrap items-center justify-between gap-2 bg-signal/[.065] px-4 py-2.5"><span className="flex items-center gap-2 font-mono text-sm font-black"><span className="h-2 w-2 rounded-full bg-signal" />{r.code}</span>{c.offerExpiresAt && <Countdown until={c.offerExpiresAt} total={OFFER_TTL_S} />}</div><div className="p-4"><div className="flex flex-wrap gap-1.5"><Pill tone="slate">{SERVICES[r.serviceType]?.label ?? r.serviceType}</Pill><Pill tone="slate">{MODES[r.mode]?.label ?? r.mode}</Pill></div><div className="mt-3 flex items-center gap-2 text-sm font-bold"><MapPin size={14} className="text-signal" />{areaName(r.pickupArea)}<ArrowRight size={13} className="text-signal" />{r.dropoffArea ? areaName(r.dropoffArea) : `${r.rentalHours} sa kiralama`}</div><div className="mt-3 flex items-center justify-between"><span className="text-xs text-ink/55">Size tahmini <b className="text-ink">{etaBand(c.etaSeconds)}</b></span><b className="text-lg">{money(c.priceMinor)}</b></div><div className="mt-4 flex gap-2"><ApiButton url={`/api/offers/${c.id}`} body={{ action: "accept" }} className="btn-mint btn-sm flex-1"><Check size={14} /> Kabul et</ApiButton><ApiButton url={`/api/offers/${c.id}`} body={{ action: "decline" }} className="btn-ghost btn-sm"><X size={14} /> Reddet</ApiButton></div></div></article>;
}
