"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { FileCheck2, FileUp, Loader2, ShieldCheck } from "lucide-react";

type DocStatus = "SUBMITTED" | "APPROVED" | "REJECTED";
interface DocRow { docType: "LICENSE" | "REGISTRATION" | "CRIMINAL_RECORD"; status: DocStatus | null; note: string | null }

const LABELS: Record<DocRow["docType"], { title: string; hint: string }> = {
  LICENSE: { title: "Ehliyet", hint: "Ön yüz, okunaklı fotoğraf" },
  REGISTRATION: { title: "Araç ruhsatı", hint: "Kayıtlı aracınıza ait ruhsat" },
  CRIMINAL_RECORD: { title: "Adli sicil kaydı", hint: "Son 6 ay içinde alınmış" },
};

export function DocumentUploadPanel({ docs, verified }: { docs: DocRow[]; verified: boolean }) {
  const router = useRouter();
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function upload(docType: DocRow["docType"], file: File) {
    setBusy(docType);
    setMsg(null);
    try {
      const fd = new FormData();
      fd.append("docType", docType);
      fd.append("file", file);
      const res = await fetch("/api/provider/documents", { method: "POST", body: fd });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error ?? "Yükleme başarısız.");
      setMsg({ ok: true, text: `${LABELS[docType].title} yüklendi; operasyon incelemesine alındı.` });
      router.refresh();
    } catch (e) {
      setMsg({ ok: false, text: e instanceof Error ? e.message : "Yükleme başarısız." });
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="card p-5">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 font-extrabold"><ShieldCheck size={17} className="text-signal" /> Doğrulama evrakları</h3>
        <span className={`rounded-full px-2.5 py-1 text-[11px] font-bold ${verified ? "bg-mint/12 text-[#0c8a5a]" : "bg-signal/10 text-signal"}`}>{verified ? "✓ Doğrulanmış profil" : "Doğrulama bekleniyor"}</span>
      </div>
      <p className="mt-1 text-xs text-ink/55">Evraklar yalnızca özel depoda saklanır, EXIF/GPS bilgisi temizlenir ve herkese açık profilde asla gösterilmez. Üçü de onaylanınca rozet otomatik verilir.</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {docs.map((d) => (
          <div key={d.docType} className="rounded-2xl border border-line p-3">
            <div className="flex items-center justify-between"><b className="text-sm">{LABELS[d.docType].title}</b>{d.status === "APPROVED" && <FileCheck2 size={15} className="text-signal" />}</div>
            <div className="mt-0.5 text-[11px] text-ink/50">{LABELS[d.docType].hint}</div>
            <div className={`mt-2 inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${d.status === "APPROVED" ? "bg-mint/12 text-[#0c8a5a]" : d.status === "REJECTED" ? "bg-rose/10 text-rose" : d.status === "SUBMITTED" ? "bg-signal/10 text-signal" : "bg-ink/5 text-ink/50"}`}>{d.status === "APPROVED" ? "Onaylandı" : d.status === "REJECTED" ? "Reddedildi" : d.status === "SUBMITTED" ? "İncelemede" : "Yüklenmedi"}</div>
            {d.status === "REJECTED" && d.note && <p className="mt-1 text-[10px] text-rose">{d.note}</p>}
            {d.status !== "APPROVED" && (
              <label className="btn-ghost btn-sm mt-3 w-full cursor-pointer">
                {busy === d.docType ? <Loader2 size={13} className="animate-spin text-signal" /> : <FileUp size={13} className="text-signal" />}
                {d.status ? "Yeniden yükle" : "Belge yükle"}
                <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" disabled={busy !== null} onChange={(e) => { const f = e.target.files?.[0]; if (f) void upload(d.docType, f); e.target.value = ""; }} />
              </label>
            )}
          </div>
        ))}
      </div>
      {msg && <p role={msg.ok ? "status" : "alert"} className={`mt-3 text-xs font-semibold ${msg.ok ? "text-[#0c8a5a]" : "text-rose"}`}>{msg.text}</p>}
    </div>
  );
}
