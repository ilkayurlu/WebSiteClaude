"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Loader2, TriangleAlert } from "lucide-react";
import {
  updateProviderLocationAction,
  updateProviderStatusAction,
  type ProviderStatus,
} from "@/actions/provider-status";
import { haversineM } from "@/lib/geo-math";
import { isStatusLocked, isValidCoords, lockReason } from "@/lib/provider-status-ui";

interface ProviderStatusToggleProps {
  initialStatus: ProviderStatus;
  /** Sunucudaki ham durum (ON_TASK/BUSY/SUSPENDED kilidi için). Verilmezse kilit sunucu yanıtıyla anlaşılır. */
  serverStatus?: string;
  /** compact: dashboard header için tek satır; full: canlı panel hero için rozetli görünüm. */
  variant?: "full" | "compact";
}

const STATUS_CONFIG: Record<
  ProviderStatus,
  { label: string; dotClass: string; bgClass: string; textClass: string; badge: string }
> = {
  ONLINE: {
    label: "Çevrimiçi & Müsait",
    dotClass: "bg-mint shadow-[0_0_12px_#10B981]",
    bgClass: "bg-mint/10 border-mint/20 text-mint",
    textClass: "text-mint",
    badge: "Çağrılar Açık",
  },
  BUSY: {
    label: "Görevde / Meşgul",
    dotClass: "bg-signal shadow-[0_0_12px_#FF5B23]",
    bgClass: "bg-signal/10 border-signal/20 text-signal",
    textClass: "text-signal",
    badge: "Yeni Çağrı Kapalı",
  },
  OFFLINE: {
    label: "Çevrimdışı",
    dotClass: "bg-white/60",
    bgClass: "bg-white/[0.04] border-white/10 text-white/50",
    textClass: "text-white",
    badge: "Vardiya Dışı",
  },
};

const BUTTONS: { value: ProviderStatus; short: string }[] = [
  { value: "ONLINE", short: "Çevrimiçi" },
  { value: "BUSY", short: "Meşgul" },
  { value: "OFFLINE", short: "Çevrimdışı" },
];

const SELECTED_RING: Record<ProviderStatus, string> = {
  ONLINE: "bg-mint/15 ring-1 ring-mint/30",
  BUSY: "bg-signal/15 ring-1 ring-signal/30",
  OFFLINE: "bg-white/10 ring-1 ring-white/20",
};

export function ProviderStatusToggle({ initialStatus, serverStatus, variant = "full" }: ProviderStatusToggleProps) {
  const router = useRouter();
  const [status, setStatus] = useState<ProviderStatus>(initialStatus);
  const [isPending, startTransition] = useTransition();
  const [locating, setLocating] = useState(false);
  const [gpsError, setGpsError] = useState<string | null>(null);
  const [actionError, setActionError] = useState<string | null>(null);

  const locked = isStatusLocked(serverStatus);
  const lockedMessage = lockReason(serverStatus);
  const busy = isPending || locating;

  useEffect(() => {
    setStatus(initialStatus);
  }, [initialStatus]);

  // Heartbeat: sekme açıkken son görülme tazelenir (konum içermez).
  useEffect(() => {
    const beat = () =>
      fetch("/api/provider/presence", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }).catch(
        () => {},
      );
    beat();
    const timer = setInterval(beat, 30_000);
    return () => clearInterval(timer);
  }, []);

  // Arka plan konum takibi: yalnızca ONLINE iken, 60 sn / 100 m eşikle sessiz gönderim.
  useEffect(() => {
    if (status !== "ONLINE" || locked) return;
    if (typeof navigator === "undefined" || !("geolocation" in navigator)) return;
    let cancelled = false;
    let lastSentAt = 0;
    let lastLat: number | null = null;
    let lastLng: number | null = null;
    const watchId = navigator.geolocation.watchPosition(
      (pos) => {
        if (cancelled) return;
        const lat = pos.coords.latitude;
        const lng = pos.coords.longitude;
        if (!isValidCoords(lat, lng)) return;
        const now = Date.now();
        if (lastLat !== null && lastLng !== null) {
          const moved = haversineM(lastLat, lastLng, lat, lng);
          if (now - lastSentAt < 60_000 && moved < 100) return;
        }
        lastSentAt = now;
        lastLat = lat;
        lastLng = lng;
        void updateProviderLocationAction({ lat, lng }).catch(() => {});
      },
      (error) => {
        if (cancelled) return;
        if (error.code === error.PERMISSION_DENIED) {
          setGpsError("Konum izni kapalı; eşleşme yaklaşık bölgeyle yapılır.");
        }
      },
      { enableHighAccuracy: true, timeout: 12_000, maximumAge: 20_000 },
    );
    return () => {
      cancelled = true;
      navigator.geolocation.clearWatch(watchId);
    };
  }, [status, locked]);

  const getCoordinates = (): Promise<{ lat: number; lng: number } | undefined> => {
    return new Promise((resolve) => {
      if (typeof navigator === "undefined" || !("geolocation" in navigator)) {
        setGpsError("Tarayıcınız konum servisini desteklemiyor.");
        return resolve(undefined);
      }
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          if (!isValidCoords(lat, lng)) {
            setGpsError("Konum alınamadı; eşleşme yaklaşık bölgeyle yapılır.");
            return resolve(undefined);
          }
          setGpsError(null);
          resolve({ lat, lng });
        },
        (error) => {
          if (error.code === error.PERMISSION_DENIED) {
            setGpsError("Konum izni verilmedi; eşleşme doğruluğu düşebilir.");
          } else if (error.code === error.TIMEOUT) {
            setGpsError("Konum zaman aşımına uğradı; eşleşme yaklaşık bölgeyle yapılır.");
          } else {
            setGpsError("Konum alınamadı; eşleşme yaklaşık bölgeyle yapılır.");
          }
          resolve(undefined);
        },
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 30_000 },
      );
    });
  };

  const handleStatusChange = async (nextStatus: ProviderStatus): Promise<void> => {
    if (nextStatus === status || busy || locked) return;
    setActionError(null);
    if (nextStatus === "ONLINE") {
      setLocating(true);
      const coords = await getCoordinates();
      startTransition(async () => {
        try {
          const res = await updateProviderStatusAction({ status: nextStatus, ...(coords ? { coords } : {}) });
          if (res.success) {
            setStatus(res.status);
            router.refresh();
          } else {
            setActionError(res.error);
          }
        } catch {
          setActionError("Durum güncellenirken bir hata oluştu.");
        } finally {
          setLocating(false);
        }
      });
      return;
    }
    startTransition(async () => {
      try {
        const res = await updateProviderStatusAction({ status: nextStatus });
        if (res.success) {
          setStatus(res.status);
          router.refresh();
        } else {
          setActionError(res.error);
        }
      } catch {
        setActionError("Durum güncellenirken bir hata oluştu.");
      }
    });
  };

  const current = STATUS_CONFIG[status];
  const disabled = busy || locked;

  const buttons = (
    <div
      role="group"
      aria-label="Çalışma durumu"
      className={`inline-flex items-center bg-ink shadow-xl ring-1 ring-white/10 ${
        variant === "compact" ? "rounded-full p-1" : "rounded-2xl p-1.5"
      }`}
    >
      {BUTTONS.map((button) => {
        const selected = status === button.value;
        const config = STATUS_CONFIG[button.value];
        return (
          <button
            key={button.value}
            type="button"
            disabled={disabled}
            aria-pressed={selected}
            aria-busy={busy && selected}
            title={config.label}
            onClick={() => void handleStatusChange(button.value)}
            className={`flex items-center gap-2 font-bold transition disabled:cursor-not-allowed disabled:opacity-60 ${
              variant === "compact" ? "rounded-full px-2.5 py-1.5 text-[11px]" : "rounded-xl px-3.5 py-2 text-xs"
            } ${selected ? `${SELECTED_RING[button.value]} ${config.textClass}` : "text-white/60 hover:text-white"}`}
          >
            <span
              aria-hidden="true"
              className={`h-2.5 w-2.5 shrink-0 rounded-full ${
                selected ? (button.value === "ONLINE" ? `pulse-dot ${config.dotClass}` : config.dotClass) : "bg-white/20"
              }`}
            />
            {button.short}
          </button>
        );
      })}
    </div>
  );

  if (variant === "compact") {
    const note = actionError ?? gpsError;
    return (
      <div className="relative">
        {buttons}
        {note && (
          <span
            role="alert"
            className="absolute right-0 top-10 z-50 flex w-60 items-start gap-1.5 rounded-xl bg-ink px-3 py-2 text-[11px] text-white shadow-xl ring-1 ring-white/10"
          >
            <TriangleAlert size={12} className="mt-0.5 shrink-0 text-signal" />
            {note}
          </span>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
      {buttons}
      <div className="flex flex-wrap items-center gap-2 text-xs">
        <span aria-live="polite" className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-1.5 font-bold ${current.bgClass}`}>
          {(isPending || locating) && <Loader2 size={12} className="animate-spin text-signal" aria-hidden="true" />}
          {locating ? "Konum alınıyor..." : isPending ? "Güncelleniyor..." : current.badge}
        </span>
        {gpsError && !locked && (
          <span className="flex items-center gap-1 text-[11px] font-medium text-signal/90">
            <TriangleAlert size={12} aria-hidden="true" />
            {gpsError}
          </span>
        )}
      </div>
      {lockedMessage && <p className="text-[11px] text-white/50">{lockedMessage}</p>}
      {actionError && (
        <p role="alert" className="text-[11px] font-semibold text-rose">
          {actionError}
        </p>
      )}
    </div>
  );
}
