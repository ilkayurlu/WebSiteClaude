"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState, useTransition, type ClipboardEvent, type KeyboardEvent } from "react";
import { ArrowRight, CheckCircle2, Loader2, Lock, MapPin, Navigation, Navigation2, ShieldCheck } from "lucide-react";
import { verifyDeliveryCodeAction } from "@/actions/delivery-actions";
import { api } from "@/components/client";
import { OrderChatDrawer } from "@/components/chat/OrderChatDrawer";

export interface ActiveDeliveryInfo {
  requestId: string;
  assignmentId: string;
  code: string;
  state: "CONFIRMED" | "IN_PROGRESS";
  customerMasked: string;
  pickupArea: string;
  dropoffArea: string;
  /** Yalnızca görevi üstlenen kuryeye gösterilen açık adres detayı. */
  dropoffDetail: string | null;
  priceLabel: string;
  scheduleLabel: string;
  attemptsLeft: number;
  locked: boolean;
}

const LENGTH = 4;

function mapsUrl(detail: string | null, area: string) {
  const query = [detail, area, "İstanbul"].filter(Boolean).join(", ");
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`;
}

export function ActiveDeliveryCard({ delivery, meId }: { delivery: ActiveDeliveryInfo; meId: string }) {
  const router = useRouter();
  const [digits, setDigits] = useState<string[]>(Array.from({ length: LENGTH }, () => ""));
  const [attemptsLeft, setAttemptsLeft] = useState(delivery.attemptsLeft);
  const [locked, setLocked] = useState(delivery.locked);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);
  const [pending, startTransition] = useTransition();
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const code = digits.join("");
  const inProgress = delivery.state === "IN_PROGRESS";

  const focus = (index: number) => refs.current[Math.max(0, Math.min(LENGTH - 1, index))]?.focus();

  function setDigit(index: number, value: string) {
    const clean = value.replace(/\D/g, "");
    if (!clean) {
      setDigits((prev) => prev.map((d, i) => (i === index ? "" : d)));
      return;
    }
    // Hızlı yazım veya otomatik doldurmada birden fazla rakam gelirse sıradaki kutulara dağıt.
    setDigits((prev) => {
      const next = [...prev];
      clean.split("").slice(0, LENGTH - index).forEach((ch, offset) => { next[index + offset] = ch; });
      return next;
    });
    focus(index + clean.length);
  }

  function onKeyDown(index: number, event: KeyboardEvent<HTMLInputElement>) {
    if (event.key === "Backspace" && !digits[index] && index > 0) {
      event.preventDefault();
      setDigits((prev) => prev.map((d, i) => (i === index - 1 ? "" : d)));
      focus(index - 1);
    } else if (event.key === "ArrowLeft") {
      focus(index - 1);
    } else if (event.key === "ArrowRight") {
      focus(index + 1);
    } else if (event.key === "Enter" && code.length === LENGTH) {
      submit();
    }
  }

  function onPaste(event: ClipboardEvent<HTMLInputElement>) {
    const pasted = event.clipboardData.getData("text").replace(/\D/g, "").slice(0, LENGTH);
    if (!pasted) return;
    event.preventDefault();
    setDigits(Array.from({ length: LENGTH }, (_, i) => pasted[i] ?? ""));
    focus(pasted.length);
  }

  async function start() {
    setStarting(true);
    setError(null);
    try {
      await api(`/api/assignments/${delivery.assignmentId}`, "POST", { action: "start" });
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Görev başlatılamadı.");
    } finally {
      setStarting(false);
    }
  }

  function submit() {
    if (code.length !== LENGTH || pending || locked) return;
    setError(null);
    startTransition(async () => {
      try {
        const result = await verifyDeliveryCodeAction({ orderId: delivery.requestId, inputCode: code });
        if (result.success) {
          setDone(result.message);
          router.refresh();
          return;
        }
        setError(result.error);
        setAttemptsLeft(result.attemptsLeft);
        setLocked(result.locked);
        setDigits(Array.from({ length: LENGTH }, () => ""));
        if (!result.locked) focus(0);
      } catch {
        setError("Teslimat doğrulanırken bir hata oluştu.");
      }
    });
  }

  if (done) {
    return (
      <article className="card flex items-center gap-4 border-mint/40 p-5">
        <CheckCircle2 size={28} className="shrink-0 text-signal" aria-hidden="true" />
        <div>
          <b className="block text-sm">{delivery.code} teslim edildi</b>
          <span className="text-xs text-ink/60">{done}</span>
        </div>
      </article>
    );
  }

  return (
    <article className="card overflow-hidden">
      <div className={`flex flex-wrap items-center justify-between gap-2 border-b border-line px-5 py-3 ${inProgress ? "bg-signal/[.06]" : "bg-paper"}`}>
        <div className="flex items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${inProgress ? "pulse-dot bg-signal text-signal" : "bg-signal/50"}`} aria-hidden="true" />
          <Link href={`/talep/${delivery.requestId}`} className="font-mono text-sm font-black hover:text-signal">{delivery.code}</Link>
          <span className="rounded-full bg-signal/10 px-2 py-0.5 text-[10px] font-bold text-signal">{inProgress ? "Teslimatta" : "Onaylandı · başlatılmadı"}</span>
        </div>
        <span className="text-xs font-semibold text-ink/50">{delivery.scheduleLabel}</span>
      </div>

      <div className="grid gap-5 p-5 lg:grid-cols-[1fr_auto]">
        <div className="min-w-0">
          <div className="text-[10px] font-bold uppercase tracking-[.12em] text-ink/45">ALICI · MASKELİ</div>
          <b className="mt-1 block text-lg">{delivery.customerMasked}</b>
          <div className="mt-3 flex items-start gap-2 rounded-xl bg-paper px-3 py-3 text-sm">
            <MapPin size={16} className="mt-0.5 shrink-0 text-signal" aria-hidden="true" />
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-1 text-xs font-semibold text-ink/55">
                {delivery.pickupArea} <ArrowRight size={11} className="text-signal" aria-hidden="true" /> {delivery.dropoffArea}
              </div>
              <div className="mt-0.5 break-words font-bold">{delivery.dropoffDetail ?? "Açık adres paylaşılmadı — müşteriyle uygulama içinden teyitleşin."}</div>
            </div>
          </div>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <a href={mapsUrl(delivery.dropoffDetail, delivery.dropoffArea)} target="_blank" rel="noopener noreferrer" className="btn-ink btn-sm">
              <Navigation size={14} className="text-signal" aria-hidden="true" /> Navigasyonu Aç
            </a>
            <OrderChatDrawer orderId={delivery.requestId} meId={meId} meRole="PROVIDER" />
          </div>
          <p className="mt-2 text-[11px] text-ink/45">Adres yalnızca bu görev süresince size görünür; navigasyon harici harita uygulamasında açılır.</p>
        </div>

        <div className="w-full rounded-2xl border border-line bg-white p-4 lg:w-[290px]">
          <div className="flex items-center justify-between">
            <span className="text-sm font-black">{delivery.priceLabel}</span>
            <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-signal"><ShieldCheck size={12} className="text-signal" aria-hidden="true" /> Teslim kodu</span>
          </div>

          {!inProgress ? (
            <div className="mt-3">
              <p className="text-xs text-ink/55">Paketi aldığınızda görevi başlatın; ardından müşterideki 4 haneli kodu girebilirsiniz.</p>
              <button type="button" disabled={starting} onClick={start} className="btn-primary mt-3 w-full">
                {starting ? <Loader2 size={15} className="animate-spin text-signal" aria-hidden="true" /> : <Navigation2 size={15} aria-hidden="true" />}
                {starting ? "Başlatılıyor…" : "Görevi başlat"}
              </button>
            </div>
          ) : locked ? (
            <div className="mt-3 rounded-xl bg-rose/10 p-3 text-xs font-semibold text-rose">
              <Lock size={14} className="mb-1 text-signal" aria-hidden="true" />
              3 hatalı deneme yapıldı. Teslimat kilitlendi ve operasyon incelemesine alındı. Müşteriyle sohbetten iletişim kurabilirsiniz.
            </div>
          ) : (
            <>
              <div className="mt-3 flex justify-between gap-2" role="group" aria-label="4 haneli teslim kodu">
                {digits.map((digit, index) => (
                  <input
                    key={index}
                    ref={(el) => { refs.current[index] = el; }}
                    value={digit}
                    onChange={(event) => setDigit(index, event.target.value)}
                    onKeyDown={(event) => onKeyDown(index, event)}
                    onPaste={onPaste}
                    onFocus={(event) => event.currentTarget.select()}
                    inputMode="numeric"
                    autoComplete={index === 0 ? "one-time-code" : "off"}
                    maxLength={LENGTH}
                    disabled={pending}
                    aria-label={`Kod hanesi ${index + 1}`}
                    className={`h-14 w-14 rounded-xl border-2 bg-paper text-center font-mono text-2xl font-black outline-none transition focus:border-signal focus:bg-white focus:ring-4 focus:ring-signal/15 ${error ? "border-rose/50" : digit ? "border-signal/40" : "border-line"}`}
                  />
                ))}
              </div>
              <div className="mt-2 flex items-center justify-between text-[11px]">
                <span className={attemptsLeft <= 1 ? "font-bold text-rose" : "text-ink/50"}>Kalan deneme hakkı: {attemptsLeft}/3</span>
              </div>
              {error && <p role="alert" className="mt-2 text-xs font-semibold text-rose">{error}</p>}
              <button type="button" disabled={pending || code.length !== LENGTH} onClick={submit} className="btn-primary mt-3 w-full">
                {pending ? <Loader2 size={15} className="animate-spin text-signal" aria-hidden="true" /> : <CheckCircle2 size={15} aria-hidden="true" />}
                {pending ? "Doğrulanıyor…" : "Teslimatı Onayla ve Tamamla"}
              </button>
            </>
          )}
        </div>
      </div>
    </article>
  );
}
