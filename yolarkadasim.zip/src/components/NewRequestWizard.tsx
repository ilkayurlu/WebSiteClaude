"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { distanceBand, etaBand, etaSeconds, haversineM, roadDistanceM } from "@/lib/geo-math";
import { CascadingAddressSelect, EMPTY_ADDRESS, type FullAddress } from "./order/CascadingAddressSelect";
import { useCoverage } from "./order/use-geo";
import { MODES, SERVICES, VEHICLES, money } from "@/lib/labels";
import { api } from "./client";
import { Avatar } from "./ui";

type Mode = "INSTANT_CALL" | "SCHEDULED" | "INSTANT_RENT";
type Pref = {
  provider?: { id: string; slug: string; displayName: string; hue: number; serviceTypes: string[]; serviceAreas: string[]; vehicleType: string; headline: string | null; rentalHourlyMinor: number | null } | null;
  fleet?: { id: string; slug: string; name: string } | null;
};

const STEPS = ["Mod", "Rota & zaman", "Araç & not", "Özet"];

function localDefault() {
  const d = new Date(Date.now() + 24 * 3600000);
  d.setMinutes(0, 0, 0);
  d.setHours(9);
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

export interface InitialDistrict { cityCode: string; cityName: string; districtId: string; districtName: string; slug: string; lat: number; lng: number; approx: boolean }

export function NewRequestWizard({ initialMode, initialDistrict, pref }: { initialMode: Mode; initialDistrict?: InitialDistrict; pref: Pref }) {
  const router = useRouter();
  const p = pref.provider;
  const [step, setStep] = useState(0);
  const [mode, setMode] = useState<Mode>(initialMode);
  const [serviceType, setServiceType] = useState<string>(p ? (p.serviceTypes.find((s) => s !== "RENTAL") ?? "PACKAGE") : "PACKAGE");
  const [pickup, setPickup] = useState<FullAddress>(() => initialDistrict ? {
    ...EMPTY_ADDRESS, cityCode: initialDistrict.cityCode, cityName: initialDistrict.cityName,
    districtId: initialDistrict.districtId, districtName: initialDistrict.districtName, areaSlug: initialDistrict.slug,
    lat: initialDistrict.lat, lng: initialDistrict.lng, approxCoordinates: initialDistrict.approx,
  } : EMPTY_ADDRESS);
  const [dropoff, setDropoff] = useState<FullAddress>(EMPTY_ADDRESS);
  const [scheduled, setScheduled] = useState(localDefault());
  const [hours, setHours] = useState(3);
  const [vehicle, setVehicle] = useState<string>(p?.vehicleType ?? "");
  const [note, setNote] = useState("");
  const [idemKey] = useState(() => (typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`));
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const services = Object.entries(SERVICES).filter(([k]) => k !== "RENTAL");
  const route = useMemo(() => {
    if (mode === "INSTANT_RENT" || pickup.lat == null || pickup.lng == null || dropoff.lat == null || dropoff.lng == null) return null;
    const m = haversineM(pickup.lat, pickup.lng, dropoff.lat, dropoff.lng);
    return { dist: distanceBand(roadDistanceM(m)), eta: etaBand(etaSeconds(m, vehicle || "CAR")), intercity: pickup.cityCode !== dropoff.cityCode };
  }, [pickup.lat, pickup.lng, pickup.cityCode, dropoff.lat, dropoff.lng, dropoff.cityCode, mode, vehicle]);

  const coverage = useCoverage(pickup.areaSlug || null);
  const outOfZone = !!p && !!pickup.areaSlug && !p.serviceAreas.includes(pickup.areaSlug);
  const addressReady = pickup.isComplete && (mode === "INSTANT_RENT" || dropoff.isComplete);
  const routeText = mode === "INSTANT_RENT"
    ? (pickup.districtName ? `${pickup.cityName} / ${pickup.districtName}` : "—")
    : (pickup.districtName && dropoff.districtName
        ? (pickup.cityCode === dropoff.cityCode ? `${pickup.cityName}: ${pickup.districtName} → ${dropoff.districtName}` : `${pickup.cityName} / ${pickup.districtName} → ${dropoff.cityName} / ${dropoff.districtName}`)
        : "—");

  async function submit() {
    setBusy(true);
    setErr(null);
    try {
      const body = {
        mode,
        serviceType: mode === "INSTANT_RENT" ? "RENTAL" : serviceType,
        vehicleTypeReq: vehicle || null,
        pickupArea: pickup.areaSlug,
        pickupDetail: [pickup.fullAddressText, pickup.description].filter(Boolean).join(" · ") || null,
        dropoffArea: mode === "INSTANT_RENT" ? null : dropoff.areaSlug,
        dropoffDetail: mode === "INSTANT_RENT" ? null : ([dropoff.fullAddressText, dropoff.description].filter(Boolean).join(" · ") || null),
        scheduledStart: mode === "SCHEDULED" ? new Date(scheduled).toISOString() : null,
        rentalHours: mode === "INSTANT_RENT" ? hours : null,
        note: note || null,
      };
      const r = await api<{ id: string }>("/api/requests/quote", "POST", body, { "Idempotency-Key": idemKey });
      const q = p ? `?prefer=${p.id}` : pref.fleet ? `?fleet=${pref.fleet.id}` : "";
      router.push(`/talep/${r.id}${q}`);
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1fr_340px]">
      <div className="card overflow-hidden">
        {/* Adımlar */}
        <div className="flex border-b border-line bg-paper/60">
          {STEPS.map((s, i) => (
            <button key={s} type="button" onClick={() => i < step && setStep(i)} className={`relative flex-1 px-2 py-4 text-center text-xs font-bold sm:text-sm ${i === step ? "text-ink" : i < step ? "text-ink/60" : "text-ink/30"}`}>
              <span className={`mr-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] ${i <= step ? "bg-signal text-white" : "bg-ink/10"}`}>{i < step ? "✓" : i + 1}</span>
              <span className="hidden sm:inline">{s}</span>
              {i === step && <span className="absolute inset-x-0 bottom-0 h-0.5 bg-signal" />}
            </button>
          ))}
        </div>

        <div className="p-6 sm:p-8">
          {step === 0 && (
            <div className="fade-up space-y-6">
              <div>
                <h2 className="text-xl font-extrabold">Nasıl hizmet almak istersin?</h2>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  {(Object.keys(MODES) as Mode[]).map((m) => (
                    <button type="button" key={m} onClick={() => setMode(m)} className={`option flex-col text-left ${mode === m ? "option-active" : ""}`}>
                      <span className="text-2xl">{MODES[m].icon}</span>
                      <span className="font-extrabold">{MODES[m].label}</span>
                      <span className="text-xs text-ink/55">{MODES[m].desc}</span>
                    </button>
                  ))}
                </div>
              </div>
              {mode !== "INSTANT_RENT" && (
                <div>
                  <div className="label">Hizmet tipi</div>
                  <div className="grid gap-3 sm:grid-cols-3">
                    {services.map(([k, v]) => {
                      const disabled = !!p && !p.serviceTypes.includes(k);
                      return (
                        <button type="button" key={k} disabled={disabled} onClick={() => setServiceType(k)} className={`option ${serviceType === k ? "option-active" : ""} disabled:cursor-not-allowed disabled:opacity-40`}>
                          <span className="text-xl">{v.icon}</span>
                          <span>
                            <span className="block font-bold">{v.label}</span>
                            <span className="block text-xs text-ink/55">{disabled ? "Bu sağlayıcı vermiyor" : v.desc}</span>
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  {serviceType === "PASSENGER" && <p className="mt-2 text-xs text-ink/55">⚠️ Yolcu taşıma, sigorta ve yasal gereksinimler nedeniyle yalnızca doğrulanmış sürücülerle eşleşir.</p>}
                </div>
              )}
            </div>
          )}

          {step === 1 && (
            <div className="fade-up space-y-5">
              <h2 className="text-xl font-extrabold">{mode === "INSTANT_RENT" ? "Nerede ve ne kadar süre?" : "Nereden nereye?"}</h2>
              <div className="grid gap-4">
                <CascadingAddressSelect
                  label={mode === "INSTANT_RENT" ? "Buluşma / teslim noktası" : "Paket alış noktası"}
                  tone="pickup"
                  value={pickup}
                  onChange={setPickup}
                  requireDetail={mode !== "INSTANT_RENT"}
                  hint={p ? `${p.displayName} bölge uyumu kontrol edilir` : undefined}
                />
                {mode !== "INSTANT_RENT" && (
                  <CascadingAddressSelect label="Teslimat adresi" tone="dropoff" value={dropoff} onChange={setDropoff} />
                )}
                {pickup.areaSlug && (
                  <div className="flex flex-wrap items-center gap-2 rounded-xl border border-line bg-paper px-3 py-2 text-xs">
                    <span className="font-bold text-ink/70">Seçilen bölge:</span>
                    <span className="chip">{pickup.cityName} / {pickup.districtName}</span>
                    {coverage.loading ? (
                      <span className="text-ink/50">Müsait kurye sayısı sorgulanıyor…</span>
                    ) : coverage.data ? (
                      coverage.data.available > 0 ? (
                        <span className="font-bold text-[#0c8a5a]">● {coverage.data.available} müsait kurye · toplam {coverage.data.total}</span>
                      ) : (
                        <span className="font-semibold text-[#8a6100]">Bu ilçede şu an müsait kurye yok; randevu önerebiliriz.</span>
                      )
                    ) : null}
                    {route && <span className="ml-auto font-bold text-ink/70">{route.dist} · {route.eta}{route.intercity ? " · şehirler arası" : ""}</span>}
                  </div>
                )}
              </div>
              {outOfZone && <div className="rounded-xl bg-sun/15 p-3 text-sm text-[#7a5500]">⚠️ {p?.displayName} bu alış bölgesinde hizmet vermiyor. Yine de devam edebilirsiniz; uygun alternatifler önerilir.</div>}
              {mode === "SCHEDULED" && (
                <div>
                  <label className="label">📅 Randevu zamanı</label>
                  <input type="datetime-local" className="input max-w-xs" value={scheduled} onChange={(e) => setScheduled(e.target.value)} />
                  <p className="mt-1 text-xs text-ink/50">En az 30 dk sonrası, en fazla 30 gün ileri.</p>
                </div>
              )}
              {mode === "INSTANT_RENT" && (
                <div>
                  <label className="label">⏱️ Kiralama süresi: {hours} saat</label>
                  <input type="range" min={1} max={12} value={hours} onChange={(e) => setHours(Number(e.target.value))} className="w-full accent-[#ff5b23]" />
                  <div className="mt-1 flex justify-between text-[11px] text-ink/45"><span>1 sa</span><span>6 sa</span><span>12 sa</span></div>
                  {p?.rentalHourlyMinor && <p className="mt-2 text-sm">Tahmini: <b>{money(p.rentalHourlyMinor * hours)}</b> <span className="text-ink/50">(kesin tutar kabulde)</span></p>}
                </div>
              )}
            </div>
          )}

          {step === 2 && (
            <div className="fade-up space-y-5">
              <h2 className="text-xl font-extrabold">Araç tercihi</h2>
              <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
                <button type="button" onClick={() => setVehicle("")} className={`option !p-3 ${vehicle === "" ? "option-active" : ""}`}>
                  <span className="text-xl">✨</span>
                  <span className="text-sm font-bold">Fark etmez</span>
                </button>
                {Object.entries(VEHICLES).map(([k, v]) => (
                  <button type="button" key={k} onClick={() => setVehicle(k)} className={`option !p-3 ${vehicle === k ? "option-active" : ""}`}>
                    <span className="text-xl">{v.icon}</span>
                    <span className="text-sm font-bold">{v.label}</span>
                  </button>
                ))}
              </div>
              <div>
                <label className="label">Not (opsiyonel)</label>
                <textarea className="input min-h-24" value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} placeholder="Ör. kırılacak eşya, kapı kodu sağlayıcıya görev başında iletilir…" />
                <p className="mt-1 text-[11px] text-ink/45">Telefon numarası veya açık adres yazmayın; iletişim uygulama içinden sağlanır.</p>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="fade-up space-y-4">
              <h2 className="text-xl font-extrabold">Özet</h2>
              <div className="divide-y divide-line rounded-2xl border border-line">
                {[
                  ["Mod", `${MODES[mode].icon} ${MODES[mode].label}`],
                  ["Hizmet", mode === "INSTANT_RENT" ? "⏱️ Kiralık" : `${SERVICES[serviceType].icon} ${SERVICES[serviceType].label}`],
                  ["Rota", routeText],
                  ["Alış adresi", pickup.fullAddressText || "—"],
                  ...(mode === "INSTANT_RENT" ? [] : [["Teslim adresi", dropoff.fullAddressText || "—"]]),
                  ...(mode === "SCHEDULED" ? [["Zaman", new Date(scheduled).toLocaleString("tr-TR", { dateStyle: "medium", timeStyle: "short" })]] : []),
                  ...(mode === "INSTANT_RENT" ? [["Süre", `${hours} saat`]] : []),
                  ["Araç", vehicle ? `${VEHICLES[vehicle].icon} ${VEHICLES[vehicle].label}` : "Fark etmez"],
                  ["Tercih", p ? `♥ ${p.displayName}` : pref.fleet ? `🏢 ${pref.fleet.name}` : "Bir sonraki adımda seçeceksiniz"],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between px-4 py-3 text-sm">
                    <span className="text-ink/55">{k}</span>
                    <span className="font-bold">{v}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-ink/55">“Teklif al” sonrası uygun adaylar ve sunucuda hesaplanan fiyatlar listelenir; ardından <b>kim getirsin</b> seçimini yaparsınız.</p>
            </div>
          )}

          {err && <div className="mt-5 rounded-xl bg-rose/10 p-3 text-sm font-semibold text-rose">{err}</div>}

          <div className="mt-8 flex items-center justify-between">
            <button type="button" className="btn-ghost" disabled={step === 0} onClick={() => setStep(step - 1)}>← Geri</button>
            {step < 3 ? (
              <button type="button" className="btn-ink" disabled={step === 1 && !addressReady} onClick={() => setStep(step + 1)}>Devam →</button>
            ) : (
              <button type="button" className="btn-primary" disabled={busy || !addressReady} onClick={submit}>{busy ? "Adaylar aranıyor…" : "Teklif al →"}</button>
            )}
          </div>
        </div>
      </div>

      <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
        {p && (
          <div className="card p-5">
            <div className="text-[11px] font-bold uppercase tracking-wider text-signal">Seçilen yol arkadaşı</div>
            <div className="mt-3 flex items-center gap-3">
              <Avatar name={p.displayName} hue={p.hue} size={48} />
              <div>
                <div className="font-extrabold">{p.displayName}</div>
                <div className="text-xs text-ink/55">{p.headline}</div>
              </div>
            </div>
            <p className="mt-3 text-xs text-ink/55">Müsait değilse veya reddederse sistem otomatik olarak en uygun alternatife yönlendirir.</p>
          </div>
        )}
        {pref.fleet && (
          <div className="card p-5">
            <div className="text-[11px] font-bold uppercase tracking-wider text-signal">Seçilen filo</div>
            <div className="mt-2 text-lg font-extrabold">🏢 {pref.fleet.name}</div>
          </div>
        )}
        <div className="card-ink road-pattern-dark p-5">
          <div className="text-sm font-extrabold">Rota önizleme</div>
          <div className="mt-4 flex items-center gap-3">
            <div className="flex flex-col items-center">
              <span className="h-3 w-3 rounded-full bg-signal" />
              <span className="my-1 h-10 w-0.5 bg-gradient-to-b from-signal to-white/30" />
              <span className="h-3 w-3 rounded-full border-2 border-white" />
            </div>
            <div className="flex-1 space-y-6 text-sm">
              <div className="font-bold">{pickup.districtName || "Alış noktası"}</div>
              <div className="font-bold text-white/80">{mode === "INSTANT_RENT" ? `${hours} saatlik tahsis` : (dropoff.districtName || "Teslim noktası")}</div>
            </div>
          </div>
          {route && (
            <div className="mt-4 grid grid-cols-2 gap-2 text-center">
              <div className="rounded-xl bg-white/[0.06] p-2"><div className="font-black">{route.dist}</div><div className="text-[10px] uppercase text-white/45">mesafe</div></div>
              <div className="rounded-xl bg-white/[0.06] p-2"><div className="font-black">{route.eta}</div><div className="text-[10px] uppercase text-white/45">yolculuk</div></div>
            </div>
          )}
        </div>
      </aside>
    </div>
  );
}
