"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { money } from "@/lib/labels";
import { CategoryForm, OptionGroupForm, ProductForm, StockToggle } from "./food-client";
import { ApiButton } from "./client";
import { Pill } from "./ui";

type Cat = { id: string; name: string; description: string | null; position: number; isActive: boolean; timeFrom: string | null; timeTo: string | null };
type OptGroup = { id: string; name: string; required: boolean; minSelect: number; maxSelect: number; options: { id: string; name: string; priceDeltaMinor: number; isDefault: boolean }[] };
type Prod = {
  id: string;
  categoryId: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  priceMinor: number;
  discountPriceMinor: number | null;
  allergens: string[];
  calories: number | null;
  prepMinutes: number | null;
  stock: number;
  status: string;
  isVegan: boolean;
  isVegetarian: boolean;
  isSpicy: boolean;
  category: string;
  optionGroups: OptGroup[];
};

export function MerchantMenuClient({ categories, products }: { categories: Cat[]; products: Prod[] }) {
  const router = useRouter();
  const [tab, setTab] = useState<"products" | "categories">("products");
  const [editing, setEditing] = useState<Prod | null | "new">(null);
  const [addingCat, setAddingCat] = useState(false);
  const [addingGroupFor, setAddingGroupFor] = useState<string | null>(null);
  const [filter, setFilter] = useState("");

  const shown = products
    .filter((p) => (filter ? (p.name + p.category).toLowerCase().includes(filter.toLowerCase()) : true))
    .sort((a, b) => (a.category === b.category ? a.name.localeCompare(b.name, "tr") : a.category.localeCompare(b.category, "tr")));

  const statusTone: Record<string, string> = { PUBLISHED: "green", DRAFT: "slate", OFF: "amber", ARCHIVED: "red" };

  return (
    <section className="mt-8">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex gap-1 rounded-full bg-paper-2 p-1">
          {([["products", `Ürünler (${products.length})`], ["categories", `Kategoriler (${categories.length})`]] as const).map(([k, l]) => (
            <button key={k} type="button" onClick={() => setTab(k)} className={`rounded-full px-4 py-1.5 text-sm font-bold transition ${tab === k ? "bg-white shadow-sm" : "text-ink/55 hover:text-ink"}`}>{l}</button>
          ))}
        </div>
        {tab === "products" && (
          <div className="flex gap-2">
            <input className="input !w-48" placeholder="Ürün ara…" value={filter} onChange={(e) => setFilter(e.target.value)} aria-label="Ürün ara" />
            <button type="button" className="btn-primary btn-sm" onClick={() => setEditing("new")}>＋ Yeni ürün</button>
          </div>
        )}
        {tab === "categories" && <button type="button" className="btn-primary btn-sm" onClick={() => setAddingCat(true)}>＋ Yeni kategori</button>}
      </div>

      {editing !== null && categories.length > 0 && (
        <div className="card mb-5 p-5">
          <h3 className="mb-4 font-extrabold">{editing === "new" ? "Yeni ürün" : `${editing.name} düzenleniyor`}</h3>
          <ProductForm categories={categories} product={editing === "new" ? null : editing} onDone={() => setEditing(null)} />
        </div>
      )}
      {editing !== null && categories.length === 0 && (
        <div className="card mb-5 border-sun/40 bg-sun/10 p-5 text-sm font-semibold text-[#7a5500]">Ürün eklemek için önce bir kategori oluşturun.</div>
      )}

      {addingCat && (
        <div className="card mb-5 p-5">
          <h3 className="mb-4 font-extrabold">Yeni kategori</h3>
          <CategoryForm onDone={() => setAddingCat(false)} />
        </div>
      )}

      {tab === "products" ? (
        <div className="card overflow-hidden">
          {/* Masaüstü tablo */}
          <table className="hidden w-full text-sm md:table">
            <thead className="border-b border-line bg-paper/60 text-left text-xs uppercase tracking-wider text-ink/50">
              <tr>
                <th className="px-4 py-3">Ürün</th>
                <th className="px-4 py-3">Kategori</th>
                <th className="px-4 py-3">Fiyat</th>
                <th className="px-4 py-3">Stok</th>
                <th className="px-4 py-3">Seçenekler</th>
                <th className="px-4 py-3">Durum</th>
                <th className="px-4 py-3 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-line">
              {shown.map((p) => (
                <tr key={p.id} className="transition hover:bg-paper/60">
                  <td className="px-4 py-3">
                    <div className="font-bold">{p.name}</div>
                    <div className="max-w-xs truncate text-xs text-ink/50">{p.description}</div>
                  </td>
                  <td className="px-4 py-3 text-ink/70">{p.category}</td>
                  <td className="px-4 py-3">
                    {p.discountPriceMinor ? (
                      <span><b className="text-signal">{money(p.discountPriceMinor)}</b> <span className="text-xs text-ink/40 line-through">{money(p.priceMinor)}</span></span>
                    ) : (
                      <b>{money(p.priceMinor)}</b>
                    )}
                  </td>
                  <td className={`px-4 py-3 font-bold ${p.stock === 0 ? "text-rose" : p.stock <= 5 ? "text-[#9a6b00]" : ""}`}>{p.stock === 0 ? "Tükendi" : p.stock}</td>
                  <td className="px-4 py-3 text-xs text-ink/60">{p.optionGroups.length ? p.optionGroups.map((g) => `${g.name}${g.required ? "*" : ""}`).join(", ") : "—"}</td>
                  <td className="px-4 py-3"><Pill tone={statusTone[p.status] ?? "slate"}>{({ PUBLISHED: "Yayında", DRAFT: "Taslak", OFF: "Pasif", ARCHIVED: "Arşiv" } as Record<string, string>)[p.status] ?? p.status}</Pill></td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1.5">
                      <button type="button" className="btn-ghost btn-sm" onClick={() => setEditing(p)}>Düzenle</button>
                      <button type="button" className="btn-ghost btn-sm" onClick={() => setAddingGroupFor(addingGroupFor === p.id ? null : p.id)}>Seçenek</button>
                    </div>
                  </td>
                </tr>
              ))}
              {shown.length === 0 && (
                <tr><td colSpan={7} className="px-4 py-10 text-center text-sm text-ink/50">Ürün bulunamadı. “Yeni ürün” ile menünüzü oluşturun.</td></tr>
              )}
            </tbody>
          </table>
          {/* Mobil kart görünümü */}
          <div className="divide-y divide-line md:hidden">
            {shown.map((p) => (
              <div key={p.id} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-bold">{p.name}</div>
                    <div className="text-xs text-ink/55">{p.category}</div>
                  </div>
                  <Pill tone={statusTone[p.status] ?? "slate"}>{p.status === "PUBLISHED" ? "Yayında" : p.status === "DRAFT" ? "Taslak" : p.status === "OFF" ? "Pasif" : "Arşiv"}</Pill>
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
                  <b>{money(p.discountPriceMinor ?? p.priceMinor)}</b>
                  <span className={p.stock === 0 ? "font-bold text-rose" : "text-ink/60"}>{p.stock === 0 ? "Tükendi" : `${p.stock} stok`}</span>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <button type="button" className="btn-ghost btn-sm" onClick={() => setEditing(p)}>Düzenle</button>
                  <button type="button" className="btn-ghost btn-sm" onClick={() => setAddingGroupFor(addingGroupFor === p.id ? null : p.id)}>Seçenek ekle</button>
                  <ApiButton url={`/api/merchant/products/${p.id}/action`} body={{ action: "archive" }} className="btn-danger btn-sm" confirm="Ürün arşive taşınsın mı?">Arşivle</ApiButton>
                </div>
                <StockToggle productId={p.id} stock={p.stock} status={p.status} />
                {addingGroupFor === p.id && <div className="mt-3"><OptionGroupForm productId={p.id} onDone={() => { setAddingGroupFor(null); router.refresh(); }} /></div>}
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {categories.map((c) => {
            const count = products.filter((p) => p.categoryId === c.id).length;
            return (
              <div key={c.id} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-extrabold">{c.name}</div>
                    {c.description && <div className="text-xs text-ink/55">{c.description}</div>}
                  </div>
                  <Pill tone={c.isActive ? "green" : "slate"}>{c.isActive ? "Aktif" : "Pasif"}</Pill>
                </div>
                <div className="mt-2 flex flex-wrap gap-1.5 text-xs text-ink/55">
                  <span className="chip">{count} ürün</span>
                  {c.timeFrom && c.timeTo && <span className="chip">⏰ {c.timeFrom}–{c.timeTo}</span>}
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  <button type="button" className="btn-ghost btn-sm" onClick={() => { setTab("products"); setFilter(""); }}>Ürünleri gör</button>
                </div>
              </div>
            );
          })}
          {categories.length === 0 && <div className="card col-span-full p-8 text-center text-sm text-ink/55">Henüz kategori yok. Menünüzü oluşturmak için ilk kategoriyi ekleyin.</div>}
        </div>
      )}
      {addingGroupFor && tab === "products" && (
        <div className="card mt-4 p-5">
          <h3 className="mb-4 font-extrabold">Seçenek grubu ekle</h3>
          <OptionGroupForm productId={addingGroupFor} onDone={() => { setAddingGroupFor(null); router.refresh(); }} />
        </div>
      )}
    </section>
  );
}
