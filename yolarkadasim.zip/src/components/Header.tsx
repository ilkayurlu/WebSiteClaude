import Link from "next/link";
import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, carts, users } from "@/db/schema";
import { ROLES } from "@/lib/labels";
import { demoEnabled, getPublicSession } from "@/lib/session";
import { dashboardHome } from "@/lib/dashboard-config";
import { NotificationBell, RoleSwitcher } from "./client";
import { Bike, BadgeCheck, Building2, Compass, LifeBuoy, MessageCircle, ReceiptText, Route, ShieldCheck, ShoppingBasket, Truck, UtensilsCrossed, Zap, type LucideIcon } from "lucide-react";

export function Logo({ dark = true }: { dark?: boolean }) {
  return (
    <Link href="/" className="flex items-center gap-2.5" aria-label="YolArkadaşı ana sayfa">
      <span className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-signal text-white shadow-[0_6px_16px_-6px_rgba(255,91,35,0.8)] transition group-hover:scale-105">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" aria-hidden="true">
          <path d="M4 18c3-8 6-1 8-6s4-6 8-6" />
          <circle cx="4" cy="18" r="1.6" fill="currentColor" />
          <circle cx="20" cy="6" r="1.6" fill="currentColor" />
        </svg>
      </span>
      <span className={`text-lg font-black tracking-tight ${dark ? "text-white" : "text-ink"}`}>
        Yol<span className="text-signal">Arkadaşı</span>
      </span>
    </Link>
  );
}

export async function Header() {
  const s = await getPublicSession();
  const all = await db.select({ id: users.id, name: users.name, role: users.role }).from(users).orderBy(asc(users.createdAt));
  const demo = all.map((u) => ({ ...u, roleLabel: ROLES[u.role] ?? u.role }));
  const role = s.user.role;

  const nav: { href: string; label: string; icon: LucideIcon }[] = [
    { href: "/kesfet", label: "Keşfet", icon: Compass },
    { href: "/yemek", label: "Yemek", icon: UtensilsCrossed },
    { href: "/filolar", label: "Filolar", icon: Truck },
  ];
  if (role === "CUSTOMER") {
    nav.push({ href: "/taleplerim", label: "Taleplerim", icon: Route }, { href: "/siparislerim", label: "Siparişlerim", icon: ReceiptText });
  }
  if (role === "PROVIDER") nav.push({ href: "/panel", label: "Panelim", icon: Bike }, { href: "/panel/profil", label: "Vitrinim", icon: BadgeCheck });
  if (role === "FLEET_OWNER") nav.push({ href: "/filo", label: "Filo paneli", icon: Building2 });
  if (role === "RESTAURANT_OWNER") nav.push({ href: "/isletme", label: "İşletmem", icon: UtensilsCrossed }, { href: "/isletme/siparisler", label: "Siparişler", icon: ReceiptText });
  if (!["ADMIN", "SUPER_ADMIN"].includes(role)) nav.push({ href: "/mesajlar", label: "Mesajlar", icon: MessageCircle });
  if (["ADMIN", "SUPER_ADMIN"].includes(role)) nav.push({ href: dashboardHome(role), label: role === "SUPER_ADMIN" ? "Yönetim" : "Operasyon", icon: ShieldCheck });

  let cartCount = 0;
  if (role === "CUSTOMER") {
    const [cart] = await db.select({ id: carts.id }).from(carts).where(eq(carts.customerId, s.user.id)).limit(1);
    if (cart) cartCount = (await db.select({ n: sql<number>`coalesce(sum(${cartItems.qty}),0)::int` }).from(cartItems).where(eq(cartItems.cartId, cart.id)))[0]?.n ?? 0;
  }

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/95 backdrop-blur">
      <div className="container-x flex h-16 items-center justify-between gap-4">
        <div className="flex min-w-0 items-center gap-6">
          <div className="group shrink-0"><Logo /></div>
          <nav className="hidden min-w-0 items-center gap-0.5 lg:flex" aria-label="Ana menü">
            {nav.map((n) => (
              <Link key={n.href} href={n.href} className="rounded-full px-3 py-2 text-sm font-semibold text-white/70 transition hover:bg-white/10 hover:text-white focus-visible:ring-2 focus-visible:ring-signal">
                <n.icon size={14} className="mr-1.5 inline-block -translate-y-px text-signal" aria-hidden="true" />
                {n.label}
              </Link>
            ))}
          </nav>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          {role === "CUSTOMER" && (
            <>
              <Link href="/sepet" className={`relative flex h-9 w-9 items-center justify-center rounded-full border transition hover:bg-white/10 ${cartCount ? "border-signal bg-signal text-white" : "border-white/15 bg-white/5 text-white"}`} aria-label={`Sepet, ${cartCount} ürün`}>
                <ShoppingBasket size={16} className={cartCount ? "text-white" : "text-signal"} aria-hidden="true" />
                {cartCount > 0 && <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-ink px-1 text-[10px] font-black text-white ring-2 ring-signal">{cartCount}</span>}
              </Link>
              <Link href="/talep/yeni" className="btn-primary btn-sm hidden sm:inline-flex"><Zap size={14} aria-hidden="true" /> Hemen çağır</Link>
            </>
          )}
          <Link href="/destek" className="hidden h-9 items-center rounded-full border border-white/15 bg-white/5 px-3 text-sm font-semibold text-white/75 transition hover:bg-white/10 hover:text-white sm:flex" aria-label="Destek">
            <LifeBuoy size={14} className="mr-1.5 text-signal" aria-hidden="true" /> Destek
          </Link>
          {s.authenticated && <NotificationBell />}
          {s.authenticated && demoEnabled() ? <RoleSwitcher users={demo} currentId={s.user.id} /> : s.authenticated ? <Link href={dashboardHome(role)} className="btn-primary btn-sm">Panelim</Link> : <Link href="/giris" className="btn-primary btn-sm">Giriş yap</Link>}
        </div>
      </div>
      <nav className="scrollbar-none flex gap-1 overflow-x-auto border-t border-white/10 px-4 py-2 lg:hidden" aria-label="Mobil menü">
        {nav.map((n) => (
          <Link key={n.href} href={n.href} className="whitespace-nowrap rounded-full bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/80">
            <n.icon size={12} className="mr-1 inline-block -translate-y-px text-signal" aria-hidden="true" />{n.label}
          </Link>
        ))}
        {s.authenticated && <Link href={dashboardHome(role)} className="whitespace-nowrap rounded-full bg-signal/20 px-3 py-1.5 text-xs font-semibold text-white">Panelim</Link>}
        <Link href="/destek" className="whitespace-nowrap rounded-full bg-white/5 px-3 py-1.5 text-xs font-semibold text-white/80"><LifeBuoy size={12} className="mr-1 inline-block -translate-y-px text-signal" aria-hidden="true" />Destek</Link>
      </nav>
    </header>
  );
}

export function Footer() {
  const groups: { title: string; links: { href: string; label: string }[] }[] = [
    {
      title: "Platform",
      links: [
        { href: "/kesfet", label: "Sağlayıcıları keşfet" },
        { href: "/talep/yeni", label: "Hemen çağır" },
        { href: "/talep/yeni?mode=SCHEDULED", label: "Randevu oluştur" },
        { href: "/talep/yeni?mode=INSTANT_RENT", label: "Saatlik kirala" },
        { href: "/filolar", label: "Filolar" },
      ],
    },
    {
      title: "Yemek & market",
      links: [
        { href: "/yemek", label: "Restoranları keşfet" },
        { href: "/sepet", label: "Sepetim" },
        { href: "/siparislerim", label: "Siparişlerim" },
        { href: "/basvuru?kind=RESTAURANT", label: "Restoran başvurusu" },
      ],
    },
    {
      title: "İş ortakları",
      links: [
        { href: "/panel", label: "Sağlayıcı paneli" },
        { href: "/panel/profil", label: "Profil vitrini" },
        { href: "/isletme", label: "İşletme paneli" },
        { href: "/basvuru?kind=FLEET", label: "Filo başvurusu" },
      ],
    },
    {
      title: "Destek & güvenlik",
      links: [
        { href: "/destek", label: "Destek merkezi" },
        { href: "/dashboard/admin", label: "Operasyon merkezi" },
        { href: "/admin/degerlendirmeler", label: "Değerlendirme moderasyonu" },
        { href: "/admin/medya-moderasyon", label: "Medya moderasyonu" },
        { href: "/admin/audit", label: "Denetim izi" },
      ],
    },
  ];

  return (
    <footer className="mt-24 bg-ink text-white/60">
      <div className="dash-road h-[3px] opacity-70" aria-hidden="true" />
      <div className="container-x grid gap-8 py-12 sm:grid-cols-2 lg:grid-cols-[1.4fr_repeat(4,1fr)]">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs text-sm">Kurye, sürücü, filo ve işletmeleri tek vitrinde buluşturan yol arkadaşı platformu. Hemen çağır, randevu oluştur, saatlik kirala veya yemek siparişi ver.</p>
          <div className="mt-4 flex flex-wrap gap-1.5">
            <span className="chip-dark">🔒 Konum gizliliği</span>
            <span className="chip-dark">⭐ Gerçek hizmet puanı</span>
          </div>
        </div>
        {groups.map((g) => (
          <div key={g.title} className="text-sm">
            <div className="mb-2.5 font-bold text-white">{g.title}</div>
            <ul className="space-y-1.5">
              {g.links.map((l) => (
                <li key={l.href + l.label}>
                  <Link href={l.href} className="transition hover:text-white">{l.label}</Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10 py-5">
        <div className="container-x flex flex-col items-center justify-between gap-2 text-xs sm:flex-row">
          <span>© {new Date().getFullYear()} YolArkadaşı · Demo ortamı — gerçek ödeme, SMS veya canlı medya sağlayıcısı bağlı değildir.</span>
          <Link href="/destek" className="font-semibold text-white/75 hover:text-white">Yardım ve içerik politikası →</Link>
        </div>
      </div>
    </footer>
  );
}
