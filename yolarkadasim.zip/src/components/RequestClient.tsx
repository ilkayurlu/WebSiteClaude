"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { money } from "@/lib/labels";
import { api } from "./client";
import { Avatar, Stars } from "./ui";

type Cand = {
  id: string;
  rank: number;
  eta: string;
  distance: string;
  priceMinor: number;
  isFavorite: boolean;
  provider: { id: string; slug: string; displayName: string; hue: number; headline: string | null; ratingAvg: number; ratingCount: number; status: string; vehicleType: string; fleet: { slug: string; name: string; policy: string } | null };
};

type Choice = { strategy: "AUTO" | "FAVORITE" | "MANUAL_PROVIDER" | "MANUAL_FLEET"; providerId?: string; fleetId?: string };

export function WhoDelivers({ requestId, candidates, prefer, preferFleet, fleetIdsBySlug }: { requestId: string; candidates: Cand[]; prefer?: string; preferFleet?: string; fleetIdsBySlug: Record<string, string> }) {
  const router = useRouter();
  const favs = candidates.filter((c) => c.isFavorite && c.provider.fleet?.policy !== "FLEET_ONLY");
  const fleets = useMemo(() => {
    const m = new Map<string, { id: string; name: string; slug: string; n: number; best: Cand }>();
    for (const c of candidates) {
      if (!c.provider.fleet) continue;
      const id = fleetIdsBySlug[c.provider.fleet.slug];
      const cur = m.get(id);
      if (cur) cur.n++;
      else m.set(id, { id, name: c.provider.fleet.name, slug: c.provider.fleet.slug, n: 1, best: c });
    }
    return [...m.values()];
  }, [candidates, fleetIdsBySlug]);

  const preferCand = prefer ? candidates.find((c) => c.provider.id === prefer) : undefined;
  const initial: Choice = preferCand && preferCand.provider.fleet?.policy !== "FLEET_ONLY"
    ? { strategy: preferCand.isFavorite ? "FAVORITE" : "MANUAL_PROVIDER", providerId: preferCand.provider.id }
    : preferFleet && fleets.some((f) => f.id === preferFleet)
      ? { strategy: "MANUAL_FLEET", fleetId: preferFleet }
      : { strategy: "AUTO" };
  const [choice, setChoice] = useState<Choice>(initial);
  const [expanded, setExpanded] = useState(initial.strategy === "MANUAL_PROVIDER");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const top = candidates[0];

  const selectedPrice =
    choice.strategy === "AUTO" ? top.priceMinor
      : choice.strategy === "MANUAL_FLEET" ? fleets.find((f) => f.id === choice.fleetId)?.best.priceMinor
        : candidates.find((c) => c.provider.id === choice.providerId)?.priceMinor;

  async function submit() {
    setBusy(true);
    setErr(null);
    try {
      await api(`/api/requests/${requestId}/select`, "POST", choice);
      router.refresh();
    } catch (e) {
      setErr((e as Error).message);
      setBusy(false);
      router.refresh();
    }
  }

  const Row = ({ c, strategy }: { c: Cand; strategy: "FAVORITE" | "MANUAL_PROVIDER" }) => {
    const fleetOnly = c.provider.fleet?.policy === "FLEET_ONLY";
    const active = choice.providerId === c.provider.id && choice.strategy === strategy;
    return (
      <button
        type="button"
        disabled={fleetOnly}
        onClick={() => setChoice({ strategy, providerId: c.provider.id })}
        className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left transition ${active ? "border-signal bg-signal/[0.05]" : "border-line bg-white hover:border-ink/25"} disabled:opacity-50`}
      >
        <Avatar name={c.provider.displayName} hue={c.provider.hue} size={40} status={c.provider.status} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 font-bold">
            {c.provider.displayName} {c.isFavorite && <span className="text-signal">♥</span>}
          </div>
          <div className="flex flex-wrap items-center gap-x-2 text-xs text-ink/55">
            <Stars value={c.provider.ratingAvg} count={c.provider.ratingCount} />
            {c.provider.fleet && <span>🏢 {c.provider.fleet.name}</span>}
            {fleetOnly && <span className="font-bold text-rose">Yalnızca filo üzerinden</span>}
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm font-black">{c.eta}</div>
          <div className="text-xs text-ink/50">{money(c.priceMinor)}</div>
        </div>
      </button>
    );
  };

  return (
    <div className="card overflow-hidden">
      <div className="border-b border-line bg-paper/60 px-6 py-4">
        <h2 className="text-lg font-extrabold">Kim getirsin?</h2>
        <p className="text-xs text-ink/55">{candidates.length} uygun aday · konumlar yalnızca ETA bandı olarak gösterilir</p>
      </div>
      <div className="space-y-3 p-6">
        {prefer && !preferCand && (
          <div className="rounded-xl bg-sun/15 p-3 text-sm text-[#7a5500]">⚠️ Tercih ettiğiniz sağlayıcı bu talep için şu an uygun değil (bölge, araç veya müsaitlik). Aşağıdaki alternatiflerden seçebilirsiniz.</div>
        )}
        {preferCand && preferCand.provider.fleet?.policy === "FLEET_ONLY" && (
          <div className="rounded-xl bg-sun/15 p-3 text-sm text-[#7a5500]">ℹ️ {preferCand.provider.displayName} yalnızca filosu üzerinden çağrılabilir; filo seçeneğini kullanın.</div>
        )}

        {/* AUTO */}
        <label className={`option ${choice.strategy === "AUTO" ? "option-active" : ""}`}>
          <input type="radio" className="mt-1 accent-[#ff5b23]" checked={choice.strategy === "AUTO"} onChange={() => setChoice({ strategy: "AUTO" })} />
          <div className="flex-1">
            <div className="flex items-center justify-between">
              <span className="font-extrabold">🎯 En yakın uygun sağlayıcı (sistem seçsin)</span>
              <span className="rounded-full bg-mint/15 px-2 py-0.5 text-xs font-black text-[#0c8a5a]">{top.eta}</span>
            </div>
            <p className="mt-0.5 text-xs text-ink/55">Reddederse veya {60} sn içinde yanıt vermezse sıradaki adaya otomatik geçilir.</p>
          </div>
        </label>

        {/* FAVORITE */}
        <div className={`option flex-col !items-stretch ${choice.strategy === "FAVORITE" ? "option-active" : ""}`}>
          <div className="flex items-center gap-3">
            <input type="radio" className="accent-[#ff5b23]" disabled={!favs.length} checked={choice.strategy === "FAVORITE"} onChange={() => favs[0] && setChoice({ strategy: "FAVORITE", providerId: favs[0].provider.id })} />
            <span className="font-extrabold">♥ Favorilerimden</span>
            {!favs.length && <span className="text-xs text-ink/45">— uygun favori yok</span>}
          </div>
          {favs.length > 0 && choice.strategy === "FAVORITE" && (
            <div className="mt-3 space-y-2">{favs.map((c) => <Row key={c.id} c={c} strategy="FAVORITE" />)}</div>
          )}
        </div>

        {/* MANUAL */}
        <div className={`option flex-col !items-stretch ${choice.strategy === "MANUAL_PROVIDER" ? "option-active" : ""}`}>
          <button type="button" className="flex items-center gap-3 text-left" onClick={() => { setExpanded(true); const first = candidates.find((c) => c.provider.fleet?.policy !== "FLEET_ONLY"); if (choice.strategy !== "MANUAL_PROVIDER" && first) setChoice({ strategy: "MANUAL_PROVIDER", providerId: first.provider.id }); }}>
            <input type="radio" readOnly className="accent-[#ff5b23]" checked={choice.strategy === "MANUAL_PROVIDER"} />
            <span className="flex-1 font-extrabold">👆 Kendim seçeyim</span>
            <span className="text-xs font-bold text-signal">{candidates.length} seçenek {expanded ? "▴" : "▾"}</span>
          </button>
          {expanded && <div className="mt-3 space-y-2">{candidates.map((c) => <Row key={c.id} c={c} strategy="MANUAL_PROVIDER" />)}</div>}
        </div>

        {/* FLEET */}
        <div className={`option flex-col !items-stretch ${choice.strategy === "MANUAL_FLEET" ? "option-active" : ""}`}>
          <div className="flex items-center gap-3">
            <input type="radio" className="accent-[#ff5b23]" disabled={!fleets.length} checked={choice.strategy === "MANUAL_FLEET"} onChange={() => fleets[0] && setChoice({ strategy: "MANUAL_FLEET", fleetId: fleets[0].id })} />
            <span className="font-extrabold">🏢 Filo seçeyim</span>
            {!fleets.length && <span className="text-xs text-ink/45">— uygun filo yok</span>}
          </div>
          {fleets.length > 0 && (
            <div className="mt-3 grid gap-2 sm:grid-cols-2">
              {fleets.map((f) => (
                <button type="button" key={f.id} onClick={() => setChoice({ strategy: "MANUAL_FLEET", fleetId: f.id })} className={`rounded-xl border p-3 text-left ${choice.fleetId === f.id && choice.strategy === "MANUAL_FLEET" ? "border-signal bg-signal/[0.05]" : "border-line bg-white"}`}>
                  <div className="font-bold">{f.name}</div>
                  <div className="text-xs text-ink/55">{f.n} uygun üye · {f.best.eta} · {money(f.best.priceMinor)}</div>
                </button>
              ))}
            </div>
          )}
        </div>

        {err && <div className="rounded-xl bg-rose/10 p-3 text-sm font-semibold text-rose">{err}</div>}

        <div className="flex flex-col gap-3 border-t border-line pt-4 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <div className="text-xs text-ink/50">Tahmini tutar (sunucu hesabı)</div>
            <div className="text-2xl font-black">{money(selectedPrice ?? null)}</div>
          </div>
          <button type="button" disabled={busy} onClick={submit} className="btn-primary !px-8 !py-3 !text-base">{busy ? "İletiliyor…" : "Talebi gönder →"}</button>
        </div>
      </div>
    </div>
  );
}

const StarPick = ({ v, on, big }: { v: number; on: (n: number) => void; big?: boolean }) => (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((n) => (
        <button type="button" key={n} onClick={() => on(n)} className={`${big ? "text-3xl" : "text-lg"} transition hover:scale-110 ${n <= v ? "text-sun" : "text-ink/15"}`}>★</button>
      ))}
    </div>
  );

export function ReviewForm({ requestId, providerName }: { requestId: string; providerName: string }) {
  const router = useRouter();
  const [rating, setRating] = useState(0);
  const [cats, setCats] = useState<Record<string, number>>({ catTime: 0, catCommunication: 0, catCare: 0, catProfessionalism: 0 });
  const [body, setBody] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <div className="card p-6">
      <h2 className="text-lg font-extrabold">{providerName} ile deneyimin nasıldı?</h2>
      <p className="text-xs text-ink/55">Yalnızca tamamlanan görevler, tek sefer ve 14 gün içinde değerlendirilebilir.</p>
      <div className="mt-4"><StarPick v={rating} on={setRating} big /></div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2">
        {[["catTime", "Zamanında"], ["catCommunication", "İletişim"], ["catCare", "Özen"], ["catProfessionalism", "Profesyonellik"]].map(([k, l]) => (
          <div key={k} className="flex items-center justify-between rounded-xl bg-paper px-3 py-2">
            <span className="text-sm font-semibold">{l}</span>
            <StarPick v={cats[k]} on={(n) => setCats({ ...cats, [k]: n })} />
          </div>
        ))}
      </div>
      <textarea className="input mt-4 min-h-24" maxLength={1000} placeholder="Yorumun (opsiyonel) — kişisel bilgi paylaşma" value={body} onChange={(e) => setBody(e.target.value)} />
      {err && <div className="mt-3 rounded-xl bg-rose/10 p-3 text-sm font-semibold text-rose">{err}</div>}
      <button
        type="button"
        disabled={busy || !rating}
        className="btn-primary mt-4"
        onClick={async () => {
          setBusy(true);
          setErr(null);
          try {
            const extra = Object.fromEntries(Object.entries(cats).filter(([, v]) => v > 0));
            await api(`/api/requests/${requestId}/review`, "POST", { rating, ...extra, body: body || undefined });
            router.refresh();
          } catch (e) {
            setErr((e as Error).message);
            setBusy(false);
          }
        }}
      >
        Değerlendirmeyi gönder
      </button>
    </div>
  );
}

export function OtpComplete({ assignmentId }: { assignmentId: string }) {
  const router = useRouter();
  const [otp, setOtp] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <div className="flex flex-col gap-1">
      <div className="flex gap-2">
        <input value={otp} onChange={(e) => setOtp(e.target.value.replace(/\D/g, "").slice(0, 4))} inputMode="numeric" placeholder="Teslim kodu" className="input !w-36 text-center font-mono text-lg tracking-[0.4em]" />
        <button
          type="button"
          disabled={busy || otp.length !== 4}
          className="btn-mint"
          onClick={async () => {
            setBusy(true);
            setErr(null);
            try {
              await api(`/api/assignments/${assignmentId}`, "POST", { action: "complete", otp });
              router.refresh();
            } catch (e) {
              setErr((e as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          ✓ Teslim et
        </button>
      </div>
      {err && <span className="text-xs font-semibold text-rose">{err}</span>}
    </div>
  );
}

export function LinkBtn({ href, children }: { href: string; children: React.ReactNode }) {
  return <Link href={href} className="btn-ghost btn-sm">{children}</Link>;
}
