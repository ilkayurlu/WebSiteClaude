"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  ArrowLeft, ArrowRight, Building2, Check, CheckCircle2, Layers, Loader2, MapPin, Plus, Search, Trash2, X,
} from "lucide-react";
import { saveServiceZones } from "@/actions/provider-zones";
import { useCities, useDistricts, useNeighborhoods, type CityOption, type DistrictOption } from "@/components/order/use-geo";

export interface SelectedZone { cityCode: string; cityName: string; districtId: string; districtName: string; slug: string }
export interface ZoneCityOption { code: string; name: string; districtCount: number }
export interface ZoneDistrictOption { id: string; name: string; slug: string; cityCode: string }

interface Props {
  /** Kanonik il-ilçe slug listesi (ör. istanbul-kadikoy). */
  zones: string[];
  /** Kayıt sonrası kalıcı yazım; verilmezse yalnızca yerel seçim yapılır (başvuru formu). */
  persist?: boolean;
  onChange?: (zones: string[]) => void;
  title?: string;
  description?: string;
}

const STEP_LABELS = ["Şehir", "İlçe", "Onay"] as const;

export function ServiceZoneWizard({ zones, persist = false, onChange, title = "Hizmet Bölgelerim", description }: Props) {
  const router = useRouter();
  const [saved, setSaved] = useState<string[]>(zones);
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<0 | 1 | 2>(0);
  const [cityCode, setCityCode] = useState("");
  const [picked, setPicked] = useState<string[]>([]);
  const [districtQuery, setDistrictQuery] = useState("");
  const [cityQuery, setCityQuery] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [previewDistrict, setPreviewDistrict] = useState<string | null>(null);
  const dialogRef = useRef<HTMLDivElement>(null);

  const cities = useCities();
  const districts = useDistricts(open && cityCode ? cityCode : null);
  const neighborhoods = useNeighborhoods(previewDistrict);

  useEffect(() => { setSaved(zones); }, [zones]);

  const cityList = useMemo(() => (cities.data ?? []) as CityOption[], [cities.data]);
  const districtList = useMemo(() => (districts.data ?? []) as DistrictOption[], [districts.data]);
  const cityByCode = useMemo(() => new Map(cityList.map((c) => [c.code, c])), [cityList]);

  const selected: SelectedZone[] = useMemo(() => saved.map((slug) => {
    const known = districtList.find((d) => d.slug === slug);
    if (known) return { cityCode: known.cityCode, cityName: known.cityName, districtId: known.id, districtName: known.name, slug };
    const [citySlug, ...rest] = slug.split("-");
    const city = cityList.find((c) => c.slug === citySlug);
    const label = rest.join(" ").replace(/\b\w/g, (m) => m.toLocaleUpperCase("tr"));
    return { cityCode: city?.code ?? "", cityName: city?.name ?? citySlug, districtId: slug, districtName: label || slug, slug };
  }), [saved, districtList, cityList]);

  const grouped = useMemo(() => {
    const map = new Map<string, SelectedZone[]>();
    for (const zone of selected) {
      const list = map.get(zone.cityName) ?? [];
      list.push(zone);
      map.set(zone.cityName, list);
    }
    return [...map.entries()].sort((a, b) => b[1].length - a[1].length || a[0].localeCompare(b[0], "tr"));
  }, [selected]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => { if (event.key === "Escape") setOpen(false); };
    document.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = previous; };
  }, [open]);

  function openWizard() {
    setOpen(true); setStep(0); setCityCode(""); setPicked([]); setDistrictQuery(""); setCityQuery("");
    setError(null); setNotice(null); setPreviewDistrict(null);
    setTimeout(() => dialogRef.current?.focus(), 30);
  }

  async function commit(next: string[]) {
    setError(null);
    if (persist) {
      setSaving(true);
      const result = await saveServiceZones(next);
      setSaving(false);
      if (!result.success) { setError(result.error ?? "Kaydedilemedi."); return false; }
      setSaved(result.zones ?? next);
      setNotice("Hizmet bölgeleriniz güncellendi.");
      router.refresh();
    } else {
      setSaved(next);
    }
    onChange?.(next);
    return true;
  }

  async function confirmZones() {
    const city = cityByCode.get(cityCode);
    if (!city || !picked.length) return;
    const additions = districtList.filter((d) => picked.includes(d.id)).map((d) => d.slug);
    const merged = [...saved];
    for (const slug of additions) if (!merged.includes(slug)) merged.push(slug);
    const ok = await commit(merged);
    if (ok) { setOpen(false); setNotice(`${additions.length} ilçe eklendi · toplam ${merged.length} bölge.`); }
  }

  async function removeZone(slug: string) {
    const next = saved.filter((s) => s !== slug);
    if (!next.length) { setError("Son bölge kaldırılamaz; en az bir ilçede hizmet vermelisiniz."); return; }
    await commit(next);
  }

  const filteredCities = cityList.filter((c) => c.name.toLocaleLowerCase("tr").includes(cityQuery.trim().toLocaleLowerCase("tr")));
  const filteredDistricts = districtList.filter((d) => d.name.toLocaleLowerCase("tr").includes(districtQuery.trim().toLocaleLowerCase("tr")));
  const activeCity = cityByCode.get(cityCode);
  const allPicked = districtList.length > 0 && districtList.every((d) => picked.includes(d.id));

  return (
    <div className="rounded-3xl border border-white/10 bg-ink p-5 text-white shadow-xl sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-2xl bg-signal/15 ring-1 ring-signal/30">
            <MapPin size={18} className="text-signal" aria-hidden="true" />
          </span>
          <div>
            <h3 className="text-base font-black">{title}</h3>
            <p className="mt-0.5 max-w-md text-xs leading-relaxed text-white/50">
              {description ?? "Çağrı ve randevular yalnızca seçtiğiniz ilçelerden gelir. Bölgeleri dilediğiniz an değiştirin."}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="rounded-xl bg-signal/15 px-3 py-1.5 font-mono text-xs font-bold text-signal ring-1 ring-signal/30">
            {saved.length} bölge
          </span>
          <button type="button" onClick={openWizard} className="inline-flex items-center gap-1.5 rounded-xl bg-signal px-3.5 py-2 text-xs font-black text-white shadow-[0_4px_12px_rgba(255,91,35,0.4)] transition hover:brightness-110">
            <Plus size={14} className="text-white" aria-hidden="true" /> Yeni Bölge Ekle
          </button>
        </div>
      </div>

      {notice && <p role="status" className="mt-3 flex items-center gap-1.5 rounded-xl bg-mint/10 px-3 py-2 text-xs font-semibold text-mint"><CheckCircle2 size={13} className="text-signal" aria-hidden="true" />{notice}</p>}
      {error && !open && <p role="alert" className="mt-3 rounded-xl bg-signal/15 px-3 py-2 text-xs font-semibold text-signal ring-1 ring-signal/30">{error}</p>}

      <div className="mt-4">
        {selected.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-white/15 p-6 text-center">
            <Layers size={20} className="mx-auto text-signal" aria-hidden="true" />
            <p className="mt-2 text-xs text-white/50">Henüz hizmet bölgeniz yok. Çağrı alabilmek için en az bir ilçe ekleyin.</p>
            <button type="button" onClick={openWizard} className="mt-3 inline-flex items-center gap-1.5 rounded-xl border border-signal/40 px-3 py-1.5 text-xs font-bold text-signal transition hover:bg-signal hover:text-white">
              <Plus size={13} aria-hidden="true" /> Bölge sihirbazını aç
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            {grouped.map(([cityName, list]) => (
              <div key={cityName}>
                <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/45">
                  <Building2 size={12} className="text-signal" aria-hidden="true" />{cityName}
                  <span className="font-mono text-signal">{list.length}</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {list.map((zone) => (
                    <span key={zone.slug} className="group inline-flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-bold text-white transition hover:border-signal/50">
                      <span className="h-1.5 w-1.5 rounded-full bg-signal" aria-hidden="true" />
                      {zone.districtName}
                      <button type="button" onClick={() => void removeZone(zone.slug)} disabled={saving} aria-label={`${zone.cityName} ${zone.districtName} bölgesini kaldır`}
                        className="rounded-md p-0.5 text-signal/70 transition hover:bg-signal/20 hover:text-signal disabled:opacity-40">
                        <X size={12} aria-hidden="true" />
                      </button>
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {open && (
        <div className="fixed inset-0 z-[85] flex items-end justify-center bg-ink/85 p-0 backdrop-blur-md sm:items-center sm:p-4" role="dialog" aria-modal="true" aria-label="Hizmet bölgesi sihirbazı" onClick={() => setOpen(false)}>
          <div ref={dialogRef} tabIndex={-1} onClick={(event) => event.stopPropagation()}
            className="fade-up max-h-[92vh] w-full max-w-2xl overflow-hidden rounded-t-3xl border border-white/15 bg-ink text-white shadow-2xl outline-none sm:rounded-3xl">
            <div className="flex items-center justify-between gap-3 border-b border-white/10 px-5 py-4">
              <ol className="flex items-center gap-2 text-xs font-bold">
                {STEP_LABELS.map((label, index) => (
                  <li key={label} className="flex items-center gap-2">
                    <span className={`flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-black ${index <= step ? "bg-signal text-white" : "bg-white/10 text-white/40"}`}>
                      {index < step ? <Check size={12} className="text-white" aria-hidden="true" /> : index + 1}
                    </span>
                    <span className={index === step ? "text-white" : "text-white/40"}>{label}</span>
                    {index < 2 && <ArrowRight size={12} className="text-signal" aria-hidden="true" />}
                  </li>
                ))}
              </ol>
              <button type="button" onClick={() => setOpen(false)} aria-label="Sihirbazı kapat" className="rounded-lg p-1.5 text-signal transition hover:bg-white/10">
                <X size={16} aria-hidden="true" />
              </button>
            </div>

            <div className="geo-scroll max-h-[62vh] overflow-y-auto px-5 py-5">
              {step === 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
                    <Search size={14} className="text-signal" aria-hidden="true" />
                    <input autoFocus value={cityQuery} onChange={(event) => setCityQuery(event.target.value)} placeholder="İl ara — 81 il" aria-label="İl ara"
                      className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/30" />
                  </div>
                  {cities.status === "loading" && <p className="flex items-center gap-2 text-xs text-white/50"><Loader2 size={13} className="animate-spin text-signal" aria-hidden="true" /> İller yükleniyor…</p>}
                  {cities.status === "error" && (
                    <div className="rounded-xl bg-signal/10 p-3 text-xs text-signal">
                      {cities.message} <button type="button" onClick={cities.retry} className="ml-1 underline">Tekrar dene</button>
                    </div>
                  )}
                  <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {filteredCities.map((city) => (
                      <button key={city.code} type="button" onClick={() => { setCityCode(city.code); setPicked([]); setDistrictQuery(""); setStep(1); }}
                        className={`flex flex-col items-start rounded-2xl border p-3 text-left transition ${cityCode === city.code ? "border-signal bg-signal/15" : "border-white/10 bg-white/[0.02] hover:border-signal/40 hover:bg-white/[0.05]"}`}>
                        <span className="font-mono text-[10px] text-signal">{city.code}</span>
                        <span className="mt-0.5 text-sm font-extrabold text-white">{city.name}</span>
                        <span className="text-[10px] text-white/40">{city.districtCount} ilçe</span>
                      </button>
                    ))}
                    {!filteredCities.length && cities.status === "ready" && <p className="col-span-full py-6 text-center text-xs text-white/45">Bu aramayla il bulunamadı.</p>}
                  </div>
                </div>
              )}

              {step === 1 && activeCity && (
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs text-white/60"><b className="text-white">{activeCity.name}</b> ilçeleri · seçilen <b className="text-signal">{picked.length}</b></p>
                    <button type="button" onClick={() => setPicked(allPicked ? [] : districtList.map((d) => d.id))} disabled={!districtList.length}
                      className="rounded-lg border border-white/15 px-2.5 py-1 text-[11px] font-bold text-signal transition hover:bg-signal/15 disabled:opacity-40">
                      {allPicked ? "Seçimi kaldır" : "Tüm ilçeleri seç"}
                    </button>
                  </div>
                  <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2">
                    <Search size={14} className="text-signal" aria-hidden="true" />
                    <input value={districtQuery} onChange={(event) => setDistrictQuery(event.target.value)} placeholder="İlçe ara" aria-label="İlçe ara"
                      className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/30" />
                  </div>
                  {districts.status === "loading" && <p className="flex items-center gap-2 text-xs text-white/50"><Loader2 size={13} className="animate-spin text-signal" aria-hidden="true" /> İlçeler yükleniyor…</p>}
                  {districts.status === "error" && <div className="rounded-xl bg-signal/10 p-3 text-xs text-signal">{districts.message} <button type="button" onClick={districts.retry} className="underline">Tekrar dene</button></div>}
                  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                    {filteredDistricts.map((district) => {
                      const isPicked = picked.includes(district.id);
                      const alreadySaved = saved.includes(district.slug);
                      return (
                        <div key={district.id} className={`flex items-center justify-between gap-2 rounded-xl border px-3 py-2 transition ${isPicked ? "border-signal bg-signal/15" : "border-white/10 bg-white/[0.02] hover:border-white/25"}`}>
                          <button type="button" onClick={() => setPicked((prev) => prev.includes(district.id) ? prev.filter((id) => id !== district.id) : [...prev, district.id])}
                            className="flex min-w-0 flex-1 items-center gap-2 text-left" aria-pressed={isPicked}>
                            <span className={`flex h-4 w-4 shrink-0 items-center justify-center rounded border ${isPicked ? "border-signal bg-signal" : "border-white/25"}`}>
                              {isPicked && <Check size={11} className="text-white" aria-hidden="true" />}
                            </span>
                            <span className="min-w-0">
                              <span className="block truncate text-xs font-bold text-white">{district.name}</span>
                              <span className="block text-[10px] text-white/40">{alreadySaved ? "Zaten ekli" : `${district.neighborhoodCount} mahalle`}</span>
                            </span>
                          </button>
                          {district.neighborhoodCount > 0 && (
                            <button type="button" onClick={() => setPreviewDistrict(previewDistrict === district.id ? null : district.id)} aria-label={`${district.name} mahallelerini gör`}
                              className="rounded-lg p-1 text-signal transition hover:bg-white/10">
                              <Layers size={13} aria-hidden="true" />
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                  {previewDistrict && (
                    <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-3">
                      <div className="mb-2 flex items-center justify-between">
                        <span className="text-[11px] font-bold uppercase tracking-wider text-white/55">Mahalle önizleme</span>
                        <button type="button" onClick={() => setPreviewDistrict(null)} aria-label="Önizlemeyi kapat" className="text-signal"><X size={13} aria-hidden="true" /></button>
                      </div>
                      {neighborhoods.status === "loading" ? (
                        <p className="flex items-center gap-2 text-xs text-white/50"><Loader2 size={12} className="animate-spin text-signal" aria-hidden="true" /> Mahalleler yükleniyor…</p>
                      ) : (
                        <div className="geo-scroll flex max-h-28 flex-wrap gap-1.5 overflow-y-auto">
                          {((neighborhoods.data ?? []) as { id: string; name: string }[]).map((n) => (
                            <span key={n.id} className="rounded-lg bg-white/8 px-2 py-0.5 text-[10px] text-white/70">{n.name}</span>
                          ))}
                        </div>
                      )}
                      <p className="mt-2 text-[10px] text-white/40">İlçe seçildiğinde tüm mahalleler kapsama dahildir.</p>
                    </div>
                  )}
                </div>
              )}

              {step === 2 && activeCity && (
                <div className="space-y-3">
                  <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
                    <div className="text-xs font-bold text-white">Eklenecek bölgeler</div>
                    <div className="mt-1 text-sm font-black text-signal">{activeCity.name}</div>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {picked.map((id) => {
                        const district = districtList.find((d) => d.id === id);
                        if (!district) return null;
                        return <span key={id} className="rounded-lg bg-signal/15 px-2 py-0.5 text-[11px] font-bold text-signal ring-1 ring-signal/30">{district.name}</span>;
                      })}
                    </div>
                    <p className="mt-3 text-[11px] text-white/45">Toplam hizmet bölgeniz {new Set([...saved, ...districtList.filter((d) => picked.includes(d.id)).map((d) => d.slug)]).size} ilçe olacak.</p>
                  </div>
                  <div className="flex items-start gap-2 rounded-xl border border-mint/20 bg-mint/10 p-3 text-xs text-mint">
                    <CheckCircle2 size={14} className="mt-px shrink-0 text-signal" aria-hidden="true" />
                    Bu ilçelerdeki anlık çağrılar ve randevular panelinize düşer. Bölgeleri panelden tek tıkla kaldırabilirsiniz.
                  </div>
                  {error && <p role="alert" className="rounded-xl bg-signal/15 p-3 text-xs font-semibold text-signal ring-1 ring-signal/30">{error}</p>}
                </div>
              )}
            </div>

            <div className="flex items-center justify-between gap-3 border-t border-white/10 px-5 py-4">
              <button type="button" onClick={() => setStep((s) => (s === 0 ? 0 : ((s - 1) as 0 | 1)))} disabled={step === 0}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-white/55 transition hover:text-white disabled:opacity-30">
                <ArrowLeft size={13} className="text-signal" aria-hidden="true" /> {step === 1 ? "Şehri değiştir" : "İlçeleri düzenle"}
              </button>
              {step === 1 && (
                <button type="button" disabled={!picked.length} onClick={() => setStep(2)}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-signal px-4 py-2 text-xs font-black text-white transition hover:brightness-110 disabled:opacity-40">
                  Devam et ({picked.length}) <ArrowRight size={13} className="text-white" aria-hidden="true" />
                </button>
              )}
              {step === 2 && (
                <button type="button" disabled={saving || !picked.length} onClick={() => void confirmZones()}
                  className="inline-flex items-center gap-1.5 rounded-xl bg-mint px-5 py-2 text-xs font-black text-ink transition hover:brightness-110 disabled:opacity-50">
                  {saving ? <Loader2 size={13} className="animate-spin text-ink" aria-hidden="true" /> : <Check size={13} className="text-ink" aria-hidden="true" />}
                  {saving ? "Kaydediliyor…" : persist ? "Bölgeleri Kaydet" : "Bölgeleri Ekle"}
                </button>
              )}
              {step === 0 && <span className="text-[11px] text-white/35">Devam etmek için bir il seçin</span>}
            </div>
          </div>
        </div>
      )}

      {saving && !open && (
        <p className="mt-3 flex items-center gap-2 text-xs text-white/50"><Loader2 size={12} className="animate-spin text-signal" aria-hidden="true" /> Bölgeler güncelleniyor…</p>
      )}
      {!persist && saved.length > 0 && (
        <p className="mt-3 flex items-center gap-1.5 text-[11px] text-white/40"><Trash2 size={11} className="text-signal" aria-hidden="true" /> Seçimler başvuru formuyla birlikte gönderilir.</p>
      )}
    </div>
  );
}
