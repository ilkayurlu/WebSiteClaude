"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { SERVICES, VEHICLES, money } from "@/lib/labels";
import { api } from "./client";

type P = {
  displayName: string;
  headline: string | null;
  bio: string | null;
  vehicleLabel: string | null;
  vehicleType: string;
  serviceTypes: string[];
  serviceAreas: string[];
  highlights: string[];
  acceptsInstant: boolean;
  acceptsScheduled: boolean;
  acceptsRental: boolean;
  rentalHourlyMinor: number | null;
  baseFareMinor: number;
  perKmMinor: number;
  hue: number;
};

export function ProviderProfileForm({ provider: p }: { provider: P }) {
  const router = useRouter();
  const [f, setF] = useState({
    displayName: p.displayName,
    headline: p.headline ?? "",
    bio: p.bio ?? "",
    vehicleLabel: p.vehicleLabel ?? "",
    serviceTypes: p.serviceTypes,
    serviceAreas: p.serviceAreas,
    highlights: p.highlights,
    acceptsInstant: p.acceptsInstant,
    acceptsScheduled: p.acceptsScheduled,
    acceptsRental: p.acceptsRental,
    rental: p.rentalHourlyMinor ? (p.rentalHourlyMinor / 100).toFixed(2) : "",
    base: (p.baseFareMinor / 100).toFixed(2),
    perKm: (p.perKmMinor / 100).toFixed(2),
    newHighlight: "",
  });
  const [err, setErr] = useState<string | null>(null);
  const [ok, setOk] = useState<string | null>(null);
  const [busy, start] = useTransition();
  const set = (k: keyof typeof f, v: unknown) => setF((prev) => ({ ...prev, [k]: v }));

  function save() {
    start(async () => {
      try {
        setErr(null);
        setOk(null);
        await api("/api/provider/profile", "PATCH", {
          displayName: f.displayName.trim(),
          headline: f.headline.trim() || undefined,
          bio: f.bio.trim() || undefined,
          vehicleLabel: f.vehicleLabel.trim() || undefined,
          serviceTypes: f.serviceTypes,
          serviceAreas: f.serviceAreas,
          highlights: f.highlights,
          acceptsInstant: f.acceptsInstant,
          acceptsScheduled: f.acceptsScheduled,
          acceptsRental: f.acceptsRental,
          rentalHourlyMinor: f.rental ? Math.round(Number(f.rental.replace(",", ".")) * 100) : null,
          baseFareMinor: Math.round(Number(f.base.replace(",", ".")) * 100) || 0,
          perKmMinor: Math.round(Number(f.perKm.replace(",", ".")) * 100) || 0,
        });
        setOk("Profiliniz güncellendi ✓ Değişiklikler herkese açık vitrinde anında görünür.");
        router.refresh();
        setTimeout(() => setOk(null), 4000);
      } catch (e) {
        setErr((e as Error).message);
      }
    });
  }

  const toggle = (key: "serviceTypes" | "highlights", value: string) =>
    set(key, f[key].includes(value) ? f[key].filter((x) => x !== value) : [...f[key], value]);

  return (
    <div className="card p-6">
      <h2 className="text-lg font-extrabold">Vitrin bilgileri</h2>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="dn">Görünen ad</label>
          <input id="dn" className="input" maxLength={60} value={f.displayName} onChange={(e) => set("displayName", e.target.value)} />
        </div>
        <div>
          <label className="label" htmlFor="hl">Hizmet unvanı</label>
          <input id="hl" className="input" maxLength={90} value={f.headline} onChange={(e) => set("headline", e.target.value)} placeholder="Ör. Moto Kurye · Soğuk Zincir" />
        </div>
      </div>
      <div className="mt-4">
        <label className="label" htmlFor="bio">Tanıtım metni</label>
        <textarea id="bio" className="input min-h-28" maxLength={1200} value={f.bio} onChange={(e) => set("bio", e.target.value)} placeholder="Deneyiminiz, çalışma tarzınız ve öne çıkan hizmetleriniz…" />
        <div className="mt-1 text-right text-[11px] text-ink/40">{f.bio.length}/1200</div>
      </div>
      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div>
          <label className="label" htmlFor="vl">Araç ({VEHICLES[p.vehicleType]?.label})</label>
          <input id="vl" className="input" maxLength={60} value={f.vehicleLabel} onChange={(e) => set("vehicleLabel", e.target.value)} placeholder="Ör. Honda PCX 125" />
        </div>
        <div>
          <label className="label" htmlFor="hue">Vitrin rengi</label>
          <input id="hue" type="range" min={0} max={359} value={p.hue} readOnly className="w-full accent-[#ff5b23]" />
          <div className="mt-1 h-3 rounded-full" style={{ background: `linear-gradient(90deg, hsl(${p.hue} 80% 55%), hsl(${(p.hue + 40) % 360} 70% 40%))` }} />
        </div>
      </div>

      <div className="mt-5">
        <div className="label">Hizmet türleri</div>
        <div className="flex flex-wrap gap-1.5">
          {Object.entries(SERVICES).map(([k, v]) => (
            <button type="button" key={k} onClick={() => toggle("serviceTypes", k)} className={`chip !cursor-pointer transition hover:border-signal ${f.serviceTypes.includes(k) ? "!border-signal !bg-signal !text-white" : ""}`}>
              {v.icon} {v.label}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-5 rounded-xl border border-dashed border-line bg-paper/60 p-3 text-xs text-ink/60">
        <b className="text-ink">Hizmet bölgeleri</b> artık sayfanın üstündeki <b>Bölgelerim</b> kartından yönetilir: il → ilçe sihirbazı ile ekleyin, etiketten tek tıkla kaldırın.
      </div>

      <div className="mt-5 grid gap-3 sm:grid-cols-3">
        {[["acceptsInstant", "⚡ Hemen çağırma kabul et"], ["acceptsScheduled", "📅 Randevu kabul et"], ["acceptsRental", "⏱️ Kiralama kabul et"]].map(([k, l]) => (
          <label key={k} className="chip !cursor-pointer justify-start !py-2">
            <input type="checkbox" className="accent-[#ff5b23]" checked={f[k as "acceptsInstant"]} onChange={(e) => set(k as keyof typeof f, e.target.checked)} />
            <span className="text-xs">{l}</span>
          </label>
        ))}
      </div>

      <div className="mt-5 grid gap-4 sm:grid-cols-3">
        <div><label className="label" htmlFor="base">Açılış ücreti (₺)</label><input id="base" className="input" value={f.base} onChange={(e) => set("base", e.target.value)} /></div>
        <div><label className="label" htmlFor="km">Km başı (₺)</label><input id="km" className="input" value={f.perKm} onChange={(e) => set("perKm", e.target.value)} /></div>
        <div><label className="label" htmlFor="rent">Saatlik kiralama (₺)</label><input id="rent" className="input" value={f.rental} onChange={(e) => set("rental", e.target.value)} disabled={!f.acceptsRental} placeholder={f.acceptsRental ? "zorunlu" : "kiralama kapalı"} /></div>
      </div>
      <p className="mt-2 text-[11px] text-ink/45">Örnek hesap: {money(Math.round(Number(f.base.replace(",", ".")) * 100) || 0)} açılış + 6 km × {money(Math.round(Number(f.perKm.replace(",", ".")) * 100) || 0)} = {money((Math.round(Number(f.base.replace(",", ".")) * 100) || 0) + 6 * (Math.round(Number(f.perKm.replace(",", ".")) * 100) || 0))}</p>

      {err && <div className="mt-4 rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
      {ok && <div className="mt-4 rounded-xl bg-mint/10 px-3 py-2 text-sm font-semibold text-[#0c8a5a]">{ok}</div>}
      <div className="mt-5 flex gap-2">
        <button type="button" className="btn-primary" disabled={busy} onClick={save}>{busy ? "Kaydediliyor…" : "Değişiklikleri kaydet"}</button>
        <button type="button" className="btn-ghost" onClick={() => router.refresh()}>Geri al</button>
      </div>
    </div>
  );
}
