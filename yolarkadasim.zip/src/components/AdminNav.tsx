import Link from "next/link";

const LINKS = [
  { href: "/admin", label: "Genel bakış", icon: "📊" },
  { href: "/admin/degerlendirmeler", label: "Değerlendirmeler", icon: "⭐" },
  { href: "/admin/medya-moderasyon", label: "Medya moderasyonu", icon: "🖼️" },
  { href: "/admin/raporlanan-icerikler", label: "Raporlanan içerikler", icon: "⚑" },
  { href: "/admin/basvurular", label: "İş ortağı başvuruları", icon: "🤝" },
  { href: "/admin/audit", label: "Denetim izi", icon: "🧾" },
];

export function AdminNav({ active }: { active: string }) {
  return (
    <nav aria-label="Operasyon bölümleri" className="scrollbar-none flex gap-1.5 overflow-x-auto pb-1">
      {LINKS.map((l) => (
        <Link
          key={l.href}
          href={l.href}
          className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-sm font-bold transition ${active === l.href ? "bg-ink text-white" : "bg-white text-ink/65 ring-1 ring-line hover:ring-signal hover:text-signal"}`}
        >
          <span className="text-xs">{l.icon}</span>
          {l.label}
        </Link>
      ))}
    </nav>
  );
}

export function AdminHead({ title, desc }: { title: string; desc: string; active?: string }) {
  return (
    <div className="mb-6">
      <div className="eyebrow">Yönetim paneli</div>
      <h1 className="mt-1 text-4xl font-black tracking-tight">{title}</h1>
      <p className="mt-2 max-w-3xl text-ink/60">{desc}</p>
    </div>
  );
}
