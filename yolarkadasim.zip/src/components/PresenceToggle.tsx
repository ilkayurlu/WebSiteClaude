"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { api } from "./client";

const OPTS = [
  { k: "AVAILABLE", label: "Müsait", cls: "bg-mint text-white" },
  { k: "PAUSED", label: "Mola", cls: "bg-sun text-ink" },
  { k: "OFFLINE", label: "Çevrimdışı", cls: "bg-ink text-white" },
] as const;

export function PresenceToggle({ status }: { status: string }) {
  const router = useRouter();
  const [err, setErr] = useState<string | null>(null);
  const locked = status === "ON_TASK" || status === "BUSY" || status === "SUSPENDED";

  // Heartbeat: 30 sn'de bir son görülme güncellenir
  useEffect(() => {
    const beat = () => fetch("/api/provider/presence", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" }).catch(() => {});
    beat();
    const t = setInterval(beat, 30000);
    return () => clearInterval(t);
  }, []);

  return (
    <div>
      <div className="inline-flex rounded-full bg-white/10 p-1 ring-1 ring-white/15">
        {OPTS.map((o) => (
          <button
            key={o.k}
            type="button"
            disabled={locked}
            onClick={async () => {
              setErr(null);
              try {
                await api("/api/provider/presence", "POST", { status: o.k });
                router.refresh();
              } catch (e) {
                setErr((e as Error).message);
              }
            }}
            className={`rounded-full px-4 py-1.5 text-xs font-bold transition disabled:cursor-not-allowed ${status === o.k ? o.cls : "text-white/60 hover:text-white"}`}
          >
            {o.label}
          </button>
        ))}
      </div>
      {locked && <div className="mt-1.5 text-xs text-white/50">{status === "SUSPENDED" ? "Profil askıda." : "Aktif görev varken durum otomatik yönetilir."}</div>}
      {err && <div className="mt-1.5 text-xs text-rose">{err}</div>}
    </div>
  );
}
