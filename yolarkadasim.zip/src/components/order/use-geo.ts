"use client";

import { useCallback, useEffect, useState } from "react";

export interface CityOption { code: string; name: string; slug: string; lat: number; lng: number; region: string | null; districtCount: number }
export interface DistrictOption { id: string; cityCode: string; cityName: string; name: string; slug: string; lat: number; lng: number; approx: boolean; neighborhoodCount: number }
export interface NeighborhoodOption { id: string; name: string; districtId: string }
export interface StreetOption { id: string; name: string; kind: "CADDE" | "SOKAK" }

type Entry<T> = { status: "loading" } | { status: "ready"; data: T } | { status: "error"; message: string };

/** Oturum boyu önbellek: aynı il/ilçe tekrar seçildiğinde ağ isteği yapılmaz. */
const cache = new Map<string, Entry<unknown>>();
const inflight = new Map<string, Promise<unknown>>();
const listeners = new Map<string, Set<() => void>>();

async function load<T>(key: string, url: string, pick: (json: Record<string, unknown>) => T): Promise<T> {
  const hit = cache.get(key);
  if (hit?.status === "ready") return hit.data as T;
  const running = inflight.get(key);
  if (running) return running as Promise<T>;
  cache.set(key, { status: "loading" });
  const promise = fetch(url)
    .then(async (res) => {
      const json = (await res.json().catch(() => ({}))) as Record<string, unknown>;
      if (!res.ok) throw new Error(typeof json.error === "string" ? json.error : "Adres verisi yüklenemedi.");
      const data = pick(json);
      cache.set(key, { status: "ready", data });
      return data;
    })
    .catch((error: unknown) => {
      const message = error instanceof Error ? error.message : "Adres verisi yüklenemedi.";
      cache.set(key, { status: "error", message });
      throw new Error(message);
    })
    .finally(() => {
      inflight.delete(key);
      listeners.get(key)?.forEach((fn) => fn());
    });
  inflight.set(key, promise);
  return promise;
}

function useResource<T>(key: string | null, url: string | null, pick: (json: Record<string, unknown>) => T) {
  const [, force] = useState(0);

  useEffect(() => {
    if (!key || !url) return;
    let alive = true;
    const notify = () => { if (alive) force((n) => n + 1); };
    const set = listeners.get(key) ?? new Set<() => void>();
    set.add(notify);
    listeners.set(key, set);
    void load(key, url, pick).then(notify, notify);
    return () => { alive = false; set.delete(notify); };
  }, [key, url, pick]);

  const retry = useCallback(() => {
    if (!key || !url) return;
    cache.delete(key);
    void load(key, url, pick).catch(() => {});
    force((n) => n + 1);
  }, [key, url, pick]);

  if (!key) return { status: "idle" as const, data: [] as T extends Array<infer _U> ? T : never, retry };
  const entry = cache.get(key);
  if (!entry || entry.status === "loading") return { status: "loading" as const, data: [] as never, retry };
  if (entry.status === "error") return { status: "error" as const, message: entry.message, data: [] as never, retry };
  return { status: "ready" as const, data: entry.data as never, retry };
}

const items = <T,>(json: Record<string, unknown>): T[] => (Array.isArray(json.items) ? (json.items as T[]) : []);

// Kararlı dönüştürücüler: efekt bağımlılıkları her render'da değişmez.
const pickCities = (json: Record<string, unknown>) => items<CityOption>(json);
const pickDistricts = (json: Record<string, unknown>) => items<DistrictOption>(json);
const pickNeighborhoods = (json: Record<string, unknown>) => items<NeighborhoodOption>(json);
const pickStreets = (json: Record<string, unknown>) => items<StreetOption>(json);

export function useCities() {
  return useResource<CityOption[]>("geo:cities", "/api/geo/cities", pickCities);
}
export function useDistricts(cityCode: string | null) {
  return useResource<DistrictOption[]>(cityCode ? `geo:districts:${cityCode}` : null, cityCode ? `/api/geo/districts?cityCode=${cityCode}` : null, pickDistricts);
}
export function useNeighborhoods(districtId: string | null) {
  return useResource<NeighborhoodOption[]>(districtId ? `geo:nb:${districtId}` : null, districtId ? `/api/geo/neighborhoods?districtId=${districtId}` : null, pickNeighborhoods);
}
export function useStreetSuggestions(neighborhoodId: string | null, query: string) {
  const enabled = !!neighborhoodId && query.trim().length >= 2;
  return useResource<StreetOption[]>(
    enabled ? `geo:street:${neighborhoodId}:${query.trim().toLocaleLowerCase("tr")}` : null,
    enabled ? `/api/geo/streets?neighborhoodId=${encodeURIComponent(neighborhoodId!)}&q=${encodeURIComponent(query.trim())}` : null,
    pickStreets,
  );
}

export interface Coverage { area: string | null; available: number; total: number }

export function useCoverage(areaSlug: string | null) {
  const [state, setState] = useState<{ slug: string | null; data: Coverage | null }>({ slug: null, data: null });
  useEffect(() => {
    if (!areaSlug) return;
    let alive = true;
    const timer = setTimeout(() => {
      fetch(`/api/geo/coverage?area=${encodeURIComponent(areaSlug)}`)
        .then((r) => (r.ok ? r.json() : null))
        .then((json: Coverage | null) => { if (alive) setState({ slug: areaSlug, data: json }); })
        .catch(() => { if (alive) setState({ slug: areaSlug, data: null }); });
    }, 220);
    return () => { alive = false; clearTimeout(timer); };
  }, [areaSlug]);
  return { loading: !!areaSlug && state.slug !== areaSlug, data: state.slug === areaSlug ? state.data : null };
}
