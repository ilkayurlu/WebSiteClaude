"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Building2, CheckCircle2, Compass, DoorOpen, Info, Loader2, MapPin, Route, Search } from "lucide-react";
import { GeoCombobox, type ComboOption } from "./GeoCombobox";
import { useCities, useDistricts, useNeighborhoods, useStreetSuggestions, type DistrictOption } from "./use-geo";

export interface FullAddress {
  cityCode: string;
  cityName: string;
  districtId: string;
  districtName: string;
  neighborhoodId: string;
  neighborhoodName: string;
  street: string;
  buildingNo: string;
  doorNo?: string;
  description?: string;
  fullAddressText: string;
  areaSlug: string;
  /** Eşleştirme ve mesafe bandı için ilçe merkezi koordinatı. */
  lat: number | null;
  lng: number | null;
  /** İlçe merkezi koordinatı yaklaşık mı (il merkezine düşüldü). */
  approxCoordinates: boolean;
  /** Zorunlu alanlar doldu mu — üst form gönderimi buna göre kilitlenir. */
  isComplete: boolean;
}

export const EMPTY_ADDRESS: FullAddress = {
  cityCode: "", cityName: "", districtId: "", districtName: "", neighborhoodId: "", neighborhoodName: "",
  street: "", buildingNo: "", doorNo: "", description: "", fullAddressText: "", areaSlug: "",
  lat: null, lng: null, approxCoordinates: false, isComplete: false,
};

interface Props {
  label: string;
  tone?: "pickup" | "dropoff";
  value?: FullAddress;
  onChange: (address: FullAddress) => void;
  /** Yalnızca bu ilçelerde teslimat varsa (restoran akışı) seçenekler daraltılır. */
  allowedSlugs?: string[];
  /** Mahalle ve cadde zorunlu mu (kiralama/buluşma noktasında gevşetilebilir). */
  requireDetail?: boolean;
  hint?: string;
}

export function CascadingAddressSelect({ label, tone = "pickup", value, onChange, allowedSlugs, requireDetail = true, hint }: Props) {
  const [cityCode, setCityCode] = useState(value?.cityCode ?? "");
  const [districtId, setDistrictId] = useState(value?.districtId ?? "");
  const [neighborhoodId, setNeighborhoodId] = useState(value?.neighborhoodId ?? "");
  const [freeNeighborhood, setFreeNeighborhood] = useState(value?.neighborhoodId?.startsWith("free:") ? (value.neighborhoodName ?? "") : "");
  const [street, setStreet] = useState(value?.street ?? "");
  const [buildingNo, setBuildingNo] = useState(value?.buildingNo ?? "");
  const [doorNo, setDoorNo] = useState(value?.doorNo ?? "");
  const [description, setDescription] = useState(value?.description ?? "");
  const [streetOpen, setStreetOpen] = useState(false);
  const streetBoxRef = useRef<HTMLDivElement>(null);
  const emitRef = useRef(onChange);
  useEffect(() => { emitRef.current = onChange; }, [onChange]);

  const cities = useCities();
  const districts = useDistricts(cityCode || null);
  const districtList = useMemo(() => {
    const all = (districts.data ?? []) as DistrictOption[];
    if (!allowedSlugs?.length) return all;
    const allowed = new Set(allowedSlugs);
    return all.filter((d) => allowed.has(d.slug));
  }, [districts.data, allowedSlugs]);
  const district = districtList.find((d) => d.id === districtId) ?? null;
  const neighborhoods = useNeighborhoods(districtId || null);
  const neighborhoodList = (neighborhoods.data ?? []) as { id: string; name: string }[];
  const noNeighborhoodData = neighborhoods.status === "ready" && neighborhoodList.length === 0;
  const neighborhood = neighborhoodList.find((n) => n.id === neighborhoodId) ?? null;
  const neighborhoodName = noNeighborhoodData ? freeNeighborhood.trim() : neighborhood?.name ?? "";
  const streets = useStreetSuggestions(noNeighborhoodData ? null : neighborhoodId || null, street);
  const streetOptions = (streets.data ?? []) as { id: string; name: string }[];

  const cityOptions: ComboOption[] = useMemo(() => {
    const list = (cities.data ?? []) as { code: string; name: string; slug: string; districtCount: number }[];
    if (!allowedSlugs?.length) return list.map((c) => ({ value: c.code, label: c.name, hint: `${c.code}` }));
    const codes = new Set(allowedSlugs.map((s) => s.split("-")[0]));
    return list.filter((c) => codes.has(c.slug)).map((c) => ({ value: c.code, label: c.name, hint: `${c.code}` }));
  }, [cities.data, allowedSlugs]);

  const cityName = cityOptions.find((c) => c.value === cityCode)?.label ?? "";
  const detailReady = !requireDetail || (!!neighborhoodName && !!street.trim() && !!buildingNo.trim());
  const isComplete = !!cityCode && !!district && detailReady;

  // Üst forma her değişimde tek tip adres nesnesi iletilir; ilçe seçilir seçilmez areaSlug hazırdır.
  useEffect(() => {
    const parts = [
      neighborhoodName ? `${neighborhoodName} Mah.` : "",
      street.trim(),
      buildingNo.trim() ? `No: ${buildingNo.trim()}` : "",
      doorNo.trim() ? `Daire: ${doorNo.trim()}` : "",
      district?.name ?? "",
      cityName,
    ].filter(Boolean);
    emitRef.current({
      cityCode,
      cityName,
      districtId: district?.id ?? "",
      districtName: district?.name ?? "",
      neighborhoodId: noNeighborhoodData && freeNeighborhood.trim() ? `free:${districtId}` : neighborhoodId,
      neighborhoodName,
      street: street.trim(),
      buildingNo: buildingNo.trim(),
      doorNo: doorNo.trim(),
      description: description.trim(),
      fullAddressText: parts.join(", "),
      areaSlug: district?.slug ?? "",
      lat: district?.lat ?? null,
      lng: district?.lng ?? null,
      approxCoordinates: district?.approx ?? false,
      isComplete,
    });
  }, [cityCode, cityName, district, neighborhoodId, neighborhoodName, noNeighborhoodData, freeNeighborhood, districtId, street, buildingNo, doorNo, description, isComplete]);

  useEffect(() => {
    if (!streetOpen) return;
    const onDown = (event: MouseEvent) => {
      if (streetBoxRef.current && !streetBoxRef.current.contains(event.target as Node)) setStreetOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [streetOpen]);

  function resetFrom(level: "city" | "district" | "neighborhood") {
    if (level === "city") { setDistrictId(""); }
    if (level === "city" || level === "district") { setNeighborhoodId(""); setFreeNeighborhood(""); }
    setStreet(""); setBuildingNo(""); setDoorNo("");
  }

  const accent = tone === "pickup" ? "text-signal" : "text-signal";
  const badge = tone === "pickup" ? "ALIŞ" : "VARIŞ";

  return (
    <section className="rounded-2xl border border-white/10 bg-ink/60 p-4 ring-1 ring-white/5 sm:p-5">
      <header className="mb-4 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-signal/15 ring-1 ring-signal/30">
            {tone === "pickup" ? <MapPin size={16} className={accent} aria-hidden="true" /> : <Route size={16} className={accent} aria-hidden="true" />}
          </span>
          <div>
            <div className="text-[10px] font-black uppercase tracking-[0.18em] text-signal">{badge}</div>
            <h3 className="text-sm font-extrabold text-white">{label}</h3>
          </div>
        </div>
        {isComplete ? (
          <span className="inline-flex items-center gap-1.5 rounded-full bg-mint/12 px-2.5 py-1 text-[11px] font-bold text-mint ring-1 ring-mint/25">
            <CheckCircle2 size={12} className="text-signal" aria-hidden="true" /> Adres tamam
          </span>
        ) : (
          <span className="rounded-full bg-white/5 px-2.5 py-1 text-[11px] font-semibold text-white/45 ring-1 ring-white/10">
            {cityCode ? (district ? "Mahalle ve kapı no gerekli" : "İlçe seçin") : "İl seçin"}
          </span>
        )}
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        <GeoCombobox
          label="İl"
          placeholder="İl seçin (81 il)"
          options={cityOptions}
          value={cityCode || null}
          loading={cities.status === "loading"}
          error={cities.status === "error" ? cities.message : null}
          onRetry={cities.retry}
          onChange={(next) => { setCityCode(next); resetFrom("city"); }}
        />
        <GeoCombobox
          label="İlçe"
          placeholder={cityCode ? "İlçe seçin" : "Önce il seçin"}
          options={districtList.map((d) => ({ value: d.id, label: d.name, hint: d.neighborhoodCount ? `${d.neighborhoodCount} mahalle` : undefined }))}
          value={districtId || null}
          disabled={!cityCode}
          loading={districts.status === "loading"}
          error={districts.status === "error" ? districts.message : null}
          onRetry={districts.retry}
          emptyText={allowedSlugs?.length ? "Bu ilçede hizmet verilmiyor." : "İlçe bulunamadı."}
          onChange={(next) => { setDistrictId(next); resetFrom("district"); }}
        />
      </div>

      {district && (
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          {noNeighborhoodData ? (
            <div>
              <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
                <Compass size={12} className="text-signal" aria-hidden="true" /> Mahalle / Köy
              </span>
              <input
                value={freeNeighborhood}
                onChange={(event) => { setFreeNeighborhood(event.target.value); setNeighborhoodId(""); }}
                placeholder="Mahalle adını yazın"
                className="w-full rounded-xl border border-white/10 bg-ink px-3.5 py-2.5 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-signal focus:ring-4 focus:ring-signal/15"
              />
              <p className="mt-1 flex items-start gap-1 text-[10px] leading-relaxed text-white/40">
                <Info size={11} className="mt-px shrink-0 text-signal" aria-hidden="true" />
                Bu ilçede kayıtlı mahalle listesi yok; serbest giriş kullanılıyor.
              </p>
            </div>
          ) : (
            <GeoCombobox
              label="Mahalle"
              placeholder={neighborhoods.status === "loading" ? "Mahalleler yükleniyor…" : "Mahalle seçin"}
              options={neighborhoodList.map((n) => ({ value: n.id, label: n.name }))}
              value={neighborhoodId || null}
              loading={neighborhoods.status === "loading"}
              error={neighborhoods.status === "error" ? neighborhoods.message : null}
              onRetry={neighborhoods.retry}
              onChange={(next) => { setNeighborhoodId(next); setStreet(""); }}
              icon="search"
            />
          )}

          <div className="relative" ref={streetBoxRef}>
            <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
              <Search size={12} className="text-signal" aria-hidden="true" /> Cadde / Sokak
            </span>
            <input
              value={street}
              disabled={!neighborhoodName}
              onFocus={() => setStreetOpen(true)}
              onChange={(event) => { setStreet(event.target.value); setStreetOpen(true); }}
              placeholder={neighborhoodName ? "Cadde veya sokak adı" : "Önce mahalle seçin"}
              className="w-full rounded-xl border border-white/10 bg-ink px-3.5 py-2.5 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-signal focus:ring-4 focus:ring-signal/15 disabled:opacity-50"
            />
            {streetOpen && streetOptions.length > 0 && (
              <ul className="geo-scroll absolute z-30 mt-1 max-h-40 w-full overflow-y-auto rounded-xl border border-white/15 bg-ink py-1 shadow-2xl">
                {streetOptions.map((option) => (
                  <li key={option.id}>
                    <button type="button" onClick={() => { setStreet(option.name); setStreetOpen(false); }} className="flex w-full items-center gap-2 px-3 py-1.5 text-left text-xs text-white/75 transition hover:bg-signal/15 hover:text-white">
                      <MapPin size={11} className="text-signal" aria-hidden="true" /> {option.name}
                    </button>
                  </li>
                ))}
                <li className="px-3 pb-1 pt-1.5 text-[10px] text-white/35">Öneri listesidir; kendi cadde adınızı yazabilirsiniz.</li>
              </ul>
            )}
          </div>
        </div>
      )}

      {district && (
        <div className="mt-3 grid gap-3 sm:grid-cols-[1fr_1fr_2fr]">
          <div>
            <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
              <Building2 size={12} className="text-signal" aria-hidden="true" /> Bina No
            </span>
            <input value={buildingNo} onChange={(event) => setBuildingNo(event.target.value)} placeholder="Ör. 42" maxLength={12}
              className="w-full rounded-xl border border-white/10 bg-ink px-3.5 py-2.5 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-signal focus:ring-4 focus:ring-signal/15" />
          </div>
          <div>
            <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
              <DoorOpen size={12} className="text-signal" aria-hidden="true" /> Daire
            </span>
            <input value={doorNo} onChange={(event) => setDoorNo(event.target.value)} placeholder="Ör. 7" maxLength={12}
              className="w-full rounded-xl border border-white/10 bg-ink px-3.5 py-2.5 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-signal focus:ring-4 focus:ring-signal/15" />
          </div>
          <div>
            <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
              <Info size={12} className="text-signal" aria-hidden="true" /> Adres tarifi
            </span>
            <input value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Ör. marketin yanı, zili çalmayın" maxLength={160}
              className="w-full rounded-xl border border-white/10 bg-ink px-3.5 py-2.5 text-sm text-white outline-none transition placeholder:text-white/30 focus:border-signal focus:ring-4 focus:ring-signal/15" />
          </div>
        </div>
      )}

      {district && (
        <p className="mt-3 flex items-start gap-1.5 rounded-xl bg-white/[0.03] px-3 py-2 text-[11px] leading-relaxed text-white/50">
          {neighborhoods.status === "loading"
            ? <><Loader2 size={12} className="mt-px shrink-0 animate-spin text-signal" aria-hidden="true" /> Mahalleler yükleniyor…</>
            : <><MapPin size={12} className="mt-px shrink-0 text-signal" aria-hidden="true" />
                Bölge kodu <b className="font-mono text-signal">{district.slug}</b>
                {district.approx && " · mesafe il merkezine göre yaklaşık hesaplanır"}
                {hint ? ` · ${hint}` : ""}</>}
        </p>
      )}
    </section>
  );
}
