"use client";

import { useRef } from "react";
import { useCities, useDistricts, type CityOption, type DistrictOption } from "./use-geo";

/** İl → ilçe filtre alanları. Seçim değiştiğinde içinde bulunduğu GET formu otomatik gönderilir. */
export function AreaFilter({ cityCode, areaSlug, allowAll = false }: { cityCode: string; areaSlug: string; allowAll?: boolean }) {
  const cities = useCities();
  const districts = useDistricts(cityCode || null);
  const cityRef = useRef<HTMLSelectElement>(null);
  const areaRef = useRef<HTMLSelectElement>(null);

  function submit(resetArea: boolean) {
    const form = cityRef.current?.form;
    if (!form) return;
    if (resetArea && areaRef.current) areaRef.current.value = "";
    form.requestSubmit();
  }

  return (
    <>
      <select ref={cityRef} name="city" defaultValue={cityCode} className="input" aria-label="İl" onChange={() => submit(true)}>
        <option value="">{allowAll ? "Tüm iller" : "İl seçin"}</option>
        {((cities.data ?? []) as CityOption[]).map((c) => <option key={c.code} value={c.code}>{c.name}</option>)}
      </select>
      <select ref={areaRef} name="area" defaultValue={areaSlug} className="input" aria-label="İlçe" onChange={() => submit(false)}>
        <option value="">{districts.status === "loading" ? "İlçeler yükleniyor…" : allowAll ? "Tüm ilçeler" : "İlçe seçin"}</option>
        {((districts.data ?? []) as DistrictOption[]).map((d) => <option key={d.id} value={d.slug}>{d.name}</option>)}
      </select>
    </>
  );
}
