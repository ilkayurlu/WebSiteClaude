"use client";

import { useEffect, useId, useMemo, useRef, useState } from "react";
import { Check, ChevronDown, Loader2, MapPin, RefreshCw, Search, X } from "lucide-react";

export interface ComboOption { value: string; label: string; hint?: string }

interface GeoComboboxProps {
  label: string;
  placeholder: string;
  options: ComboOption[];
  value: string | null;
  onChange: (value: string) => void;
  disabled?: boolean;
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  emptyText?: string;
  searchable?: boolean;
  icon?: "pin" | "search";
}

/** Arama destekli, klavye ile gezilebilir seçim kutusu. Tüm ikonlar marka turuncusu. */
export function GeoCombobox({
  label, placeholder, options, value, onChange, disabled, loading, error, onRetry,
  emptyText = "Kayıt bulunamadı.", searchable = true, icon = "pin",
}: GeoComboboxProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const searchRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);
  const listId = useId();

  const selected = options.find((o) => o.value === value) ?? null;
  const filtered = useMemo(() => {
    const q = query.trim().toLocaleLowerCase("tr");
    if (!q) return options;
    return options.filter((o) => o.label.toLocaleLowerCase("tr").includes(q) || o.value.includes(q));
  }, [options, query]);

  useEffect(() => {
    if (!open) return;
    const onDown = (event: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const timer = setTimeout(() => searchRef.current?.focus(), 20);
    return () => clearTimeout(timer);
  }, [open]);

  useEffect(() => {
    if (!open || !listRef.current) return;
    const node = listRef.current.children[active] as HTMLElement | undefined;
    node?.scrollIntoView({ block: "nearest" });
  }, [active, open]);

  function commit(option: ComboOption) {
    onChange(option.value);
    setOpen(false);
  }

  const Icon = icon === "search" ? Search : MapPin;
  const isDisabled = disabled || loading;

  return (
    <div className="relative" ref={rootRef}>
      <span className="mb-1.5 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wider text-white/55">
        <Icon size={12} className="text-signal" aria-hidden="true" /> {label}
      </span>
      <button
        type="button"
        disabled={isDisabled}
        onClick={() => {
          if (open) { setOpen(false); return; }
          setQuery("");
          setActive(Math.max(0, options.findIndex((o) => o.value === value)));
          setOpen(true);
        }}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? listId : undefined}
        className={`flex w-full items-center justify-between gap-2 rounded-xl border bg-ink px-3.5 py-2.5 text-left text-sm transition disabled:cursor-not-allowed disabled:opacity-50 ${
          open ? "border-signal ring-4 ring-signal/15" : selected ? "border-signal/40" : "border-white/10 hover:border-white/25"
        }`}
      >
        <span className={`truncate ${selected ? "font-semibold text-white" : "text-white/35"}`}>
          {loading ? "Yükleniyor…" : selected ? selected.label : placeholder}
        </span>
        <span className="flex shrink-0 items-center gap-1.5">
          {loading && <Loader2 size={14} className="animate-spin text-signal" aria-hidden="true" />}
          {selected && !loading && (
            <span
              role="button"
              tabIndex={-1}
              aria-label={`${label} seçimini temizle`}
              onClick={(event) => { event.stopPropagation(); onChange(""); setOpen(false); }}
              className="rounded-md p-0.5 text-signal/70 transition hover:bg-white/10 hover:text-signal"
            >
              <X size={13} aria-hidden="true" />
            </span>
          )}
          <ChevronDown size={15} className={`text-signal transition ${open ? "rotate-180" : ""}`} aria-hidden="true" />
        </span>
      </button>

      {open && (
        <div className="absolute z-40 mt-2 w-full overflow-hidden rounded-2xl border border-white/15 bg-ink shadow-2xl ring-1 ring-black/40">
          {searchable && (
            <div className="flex items-center gap-2 border-b border-white/10 px-3 py-2">
              <Search size={14} className="shrink-0 text-signal" aria-hidden="true" />
              <input
                ref={searchRef}
                value={query}
                onChange={(event) => { setQuery(event.target.value); setActive(0); }}
                onKeyDown={(event) => {
                  if (event.key === "ArrowDown") { event.preventDefault(); setActive((i) => Math.min(filtered.length - 1, i + 1)); }
                  else if (event.key === "ArrowUp") { event.preventDefault(); setActive((i) => Math.max(0, i - 1)); }
                  else if (event.key === "Enter") { event.preventDefault(); const option = filtered[active]; if (option) commit(option); }
                  else if (event.key === "Escape") { event.preventDefault(); setOpen(false); }
                }}
                placeholder="Ara…"
                aria-label={`${label} içinde ara`}
                className="w-full bg-transparent text-sm text-white outline-none placeholder:text-white/30"
              />
              <span className="shrink-0 font-mono text-[10px] text-white/35">{filtered.length}</span>
            </div>
          )}

          {error ? (
            <div className="px-3 py-4 text-center">
              <p className="text-xs font-semibold text-signal">{error}</p>
              {onRetry && (
                <button type="button" onClick={onRetry} className="mt-2 inline-flex items-center gap-1.5 rounded-lg border border-white/15 px-2.5 py-1 text-[11px] font-bold text-white/80 transition hover:border-signal hover:text-signal">
                  <RefreshCw size={12} className="text-signal" aria-hidden="true" /> Tekrar dene
                </button>
              )}
            </div>
          ) : filtered.length === 0 ? (
            <p className="px-3 py-4 text-center text-xs text-white/45">{loading ? "Yükleniyor…" : emptyText}</p>
          ) : (
            <ul ref={listRef} id={listId} role="listbox" aria-label={label} className="geo-scroll max-h-60 overflow-y-auto py-1">
              {filtered.map((option, index) => {
                const isSelected = option.value === value;
                return (
                  <li key={option.value} role="option" aria-selected={isSelected}>
                    <button
                      type="button"
                      onMouseEnter={() => setActive(index)}
                      onClick={() => commit(option)}
                      className={`flex w-full items-center justify-between gap-2 px-3 py-2 text-left text-sm transition ${
                        index === active ? "bg-signal/15 text-white" : isSelected ? "text-signal" : "text-white/75 hover:bg-white/5"
                      }`}
                    >
                      <span className="truncate">{option.label}</span>
                      <span className="flex shrink-0 items-center gap-2">
                        {option.hint && <span className="font-mono text-[10px] text-white/35">{option.hint}</span>}
                        {isSelected && <Check size={14} className="text-signal" aria-hidden="true" />}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
