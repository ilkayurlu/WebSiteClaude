"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { FLEET_POLICY } from "@/lib/labels";
import { api } from "./client";

export function ReassignControl({ candidateId, members }: { candidateId: string; members: { id: string; name: string; status: string }[] }) {
  const router = useRouter();
  const [to, setTo] = useState(members[0]?.id ?? "");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  if (!members.length) return <span className="text-xs text-ink/45">Yönlendirilebilecek müsait üye yok</span>;
  return (
    <div className="flex flex-col gap-1">
      <div className="flex gap-2">
        <select className="input !py-1.5 !text-xs" value={to} onChange={(e) => setTo(e.target.value)}>
          {members.map((m) => (
            <option key={m.id} value={m.id}>{m.name} · {m.status === "AVAILABLE" ? "müsait" : m.status.toLowerCase()}</option>
          ))}
        </select>
        <button
          type="button"
          disabled={busy || !to}
          className="btn-ink btn-sm whitespace-nowrap"
          onClick={async () => {
            setBusy(true);
            setErr(null);
            try {
              await api(`/api/fleet/offers/${candidateId}`, "POST", { action: "reassign", providerId: to });
              router.refresh();
            } catch (e) {
              setErr((e as Error).message);
            } finally {
              setBusy(false);
            }
          }}
        >
          ↪ Yönlendir
        </button>
      </div>
      {err && <span className="text-xs font-semibold text-rose">{err}</span>}
    </div>
  );
}

export function PolicyForm({ policy, showMembers }: { policy: string; showMembers: boolean }) {
  const router = useRouter();
  const [p, setP] = useState(policy);
  const [show, setShow] = useState(showMembers);
  const [msg, setMsg] = useState<string | null>(null);
  const save = async (next: { directPolicy?: string; showMembersPublicly?: boolean }) => {
    setMsg(null);
    try {
      await api("/api/fleet/policy", "PATCH", next);
      setMsg("Kaydedildi ✓ — teklif yönlendirmesi anında güncellendi.");
      router.refresh();
    } catch (e) {
      setMsg((e as Error).message);
    }
  };
  return (
    <div className="space-y-2.5">
      {Object.entries(FLEET_POLICY).map(([k, v]) => (
        <label key={k} className={`option !p-3 ${p === k ? "option-active" : ""}`}>
          <input type="radio" className="mt-1 accent-[#ff5b23]" checked={p === k} onChange={() => { setP(k); save({ directPolicy: k }); }} />
          <span>
            <span className="block text-sm font-bold">{v.label}</span>
            <span className="block text-xs text-ink/55">{v.desc}</span>
          </span>
        </label>
      ))}
      <label className="flex items-center justify-between rounded-xl bg-paper px-3 py-2.5 text-sm font-semibold">
        Üyeleri herkese açık göster
        <input type="checkbox" className="h-4 w-4 accent-[#ff5b23]" checked={show} onChange={(e) => { setShow(e.target.checked); save({ showMembersPublicly: e.target.checked }); }} />
      </label>
      {msg && <div className="text-xs font-semibold text-mint">{msg}</div>}
    </div>
  );
}
