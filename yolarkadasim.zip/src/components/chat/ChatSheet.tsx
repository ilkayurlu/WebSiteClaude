"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import type { ConversationSummary } from "@/lib/chat";
import { Avatar } from "@/components/ui";
import { ChatBox } from "./ChatBox";

export const OPEN_CHAT_EVENT = "ya:open-chat";

export function openChat(conversationId: string) {
  window.dispatchEvent(new CustomEvent(OPEN_CHAT_EVENT, { detail: { id: conversationId } }));
}

function previewOf(c: ConversationSummary, meId: string): string {
  if (!c.lastMessage) return "Henüz mesaj yok";
  const prefix = c.lastMessage.senderId === meId ? "Siz: " : "";
  if (c.lastMessage.type === "SYSTEM_NOTICE") return c.lastMessage.body;
  if (c.lastMessage.type === "LOCATION_PIN") return `${prefix}📍 Yaklaşık konum paylaşıldı`;
  return `${prefix}${c.lastMessage.body}`;
}

function timeShort(iso: string | null): string {
  if (!iso) return "";
  const d = new Date(iso);
  const diffMin = Math.round((Date.now() - d.getTime()) / 60000);
  if (diffMin < 1) return "şimdi";
  if (diffMin < 60) return `${diffMin} dk`;
  if (diffMin < 1440) return new Intl.DateTimeFormat("tr-TR", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Istanbul" }).format(d);
  return new Intl.DateTimeFormat("tr-TR", { day: "2-digit", month: "short", timeZone: "Europe/Istanbul" }).format(d);
}

/* ---------------- Gelen kutusu listesi ---------------- */
function ConversationList({
  items,
  meId,
  activeId,
  onPick,
  loading,
  error,
  onRetry,
}: {
  items: ConversationSummary[];
  meId: string;
  activeId: string | null;
  onPick: (id: string) => void;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
}) {
  if (loading) {
    return (
      <div className="space-y-2 p-3" aria-busy="true">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className="flex animate-pulse items-center gap-3 rounded-2xl p-3">
            <div className="h-11 w-11 rounded-full bg-paper-2" />
            <div className="flex-1 space-y-2">
              <div className="h-3.5 w-2/3 rounded bg-paper-2" />
              <div className="h-3 w-full rounded bg-paper-2" />
            </div>
          </div>
        ))}
      </div>
    );
  }
  if (error) {
    return (
      <div className="p-6 text-center">
        <p className="text-sm font-semibold text-rose">{error}</p>
        <button type="button" onClick={onRetry} className="btn-ghost btn-sm mt-3">↻ Tekrar dene</button>
      </div>
    );
  }
  if (!items.length) {
    return (
      <div className="flex h-full flex-col items-center justify-center p-8 text-center">
        <span className="flex h-14 w-14 items-center justify-center rounded-2xl bg-paper text-2xl ring-1 ring-line">💬</span>
        <h3 className="mt-3 text-sm font-extrabold">Henüz sohbet yok</h3>
        <p className="mt-1 max-w-[240px] text-xs leading-relaxed text-ink/55">
          Sohbetler bir görev onaylandığında otomatik açılır. Filo üyeleri ve yöneticileri şirket içi kanalı her zaman kullanabilir.
        </p>
        <div className="mt-4 flex gap-2">
          <Link href="/kesfet" className="btn-primary btn-sm">Sağlayıcı bul</Link>
          <Link href="/taleplerim" className="btn-ghost btn-sm">Taleplerim</Link>
        </div>
      </div>
    );
  }
  return (
    <ul className="chat-scroll h-full overflow-y-auto p-2">
      {items.map((c) => {
        const active = c.id === activeId;
        return (
          <li key={c.id}>
            <button
              type="button"
              onClick={() => onPick(c.id)}
              className={`group flex w-full items-center gap-3 rounded-2xl p-3 text-left transition ${active ? "bg-signal/[0.07] ring-1 ring-signal/40" : "hover:bg-paper"}`}
            >
              {c.other ? <Avatar name={c.other.name} hue={c.other.hue} size={44} /> : <span className="flex h-11 w-11 items-center justify-center rounded-full bg-paper-2">💬</span>}
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className={`truncate text-sm ${c.unread ? "font-black" : "font-bold"}`}>{c.other?.name ?? "Sohbet"}</span>
                  {c.contextType === "FLEET_INTERNAL" && <span className="shrink-0 rounded-full bg-sky/10 px-1.5 py-0.5 text-[9px] font-black text-sky">FİLO</span>}
                  {c.status === "CLOSED" && <span className="shrink-0 rounded-full bg-ink/[0.06] px-1.5 py-0.5 text-[9px] font-black text-ink/45">ARŞİV</span>}
                  {c.muted && <span className="shrink-0 text-[10px] text-ink/35">🔕</span>}
                  <span className="ml-auto shrink-0 text-[10px] text-ink/40">{timeShort(c.lastMessageAt)}</span>
                </span>
                <span className="mt-0.5 block truncate text-[11px] text-ink/45">{c.contextLabel}</span>
                <span className={`mt-0.5 block truncate text-xs ${c.unread ? "font-bold text-ink/85" : "text-ink/55"}`}>{previewOf(c, meId)}</span>
              </span>
              {c.unread > 0 && (
                <span className="flex h-5 min-w-5 shrink-0 items-center justify-center rounded-full bg-signal px-1.5 text-[10px] font-black text-white">{c.unread}</span>
              )}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

/* ---------------- Ortak çalışma alanı (sayfa + sheet) ---------------- */
export function ChatWorkspace({
  meId,
  meRole,
  initialId = null,
  variant,
  onClose,
}: {
  meId: string;
  meRole: string;
  initialId?: string | null;
  variant: "sheet" | "page";
  onClose?: () => void;
}) {
  const [items, setItems] = useState<ConversationSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeId, setActiveId] = useState<string | null>(initialId);
  const activeIdRef = useRef(activeId);
  activeIdRef.current = activeId;

  const refresh = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const res = await fetch("/api/chat/conversations");
      if (!res.ok) throw new Error("Sohbetler yüklenemedi.");
      const data = (await res.json()) as { items: ConversationSummary[] };
      setItems(data.items);
      setError(null);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
    const t = setInterval(() => refresh(true), 12000);
    return () => clearInterval(t);
  }, [refresh]);

  useEffect(() => {
    const handler = (e: Event) => {
      const id = (e as CustomEvent<{ id: string }>).detail?.id;
      if (id) {
        setActiveId(id);
        refresh(true);
      }
    };
    window.addEventListener(OPEN_CHAT_EVENT, handler);
    return () => window.removeEventListener(OPEN_CHAT_EVENT, handler);
  }, [refresh]);

  const back = () => {
    setActiveId(null);
    refresh(true);
  };

  if (variant === "sheet") {
    return (
      <div className="flex h-full min-h-0 flex-col bg-white">
        {activeId ? (
          <ChatBox conversationId={activeId} meId={meId} meRole={meRole} onBack={back} onClose={onClose} compact />
        ) : (
          <>
            <div className="flex items-center justify-between border-b border-line px-4 py-3.5">
              <div>
                <h2 className="text-base font-black tracking-tight">Mesajlar</h2>
                <p className="text-[11px] text-ink/45">Görev ve filo sohbetlerin · uçtan uca maskeli</p>
              </div>
              <div className="flex items-center gap-1">
                <Link href="/mesajlar" className="flex h-9 w-9 items-center justify-center rounded-full text-ink/55 transition hover:bg-paper hover:text-signal" aria-label="Tam ekran aç" onClick={onClose}>
                  ⤢
                </Link>
                {onClose && (
                  <button type="button" onClick={onClose} aria-label="Kapat" className="flex h-9 w-9 items-center justify-center rounded-full text-ink/55 transition hover:bg-paper hover:text-rose">
                    ✕
                  </button>
                )}
              </div>
            </div>
            <div className="min-h-0 flex-1">
              <ConversationList items={items} meId={meId} activeId={activeId} onPick={setActiveId} loading={loading} error={error} onRetry={() => refresh()} />
            </div>
          </>
        )}
      </div>
    );
  }

  return (
    <div className="card grid h-[calc(100vh-15rem)] min-h-[480px] grid-cols-1 overflow-hidden md:grid-cols-[340px_1fr]">
      <div className={`min-h-0 border-line md:border-r ${activeId ? "hidden md:block" : ""}`}>
        <ConversationList items={items} meId={meId} activeId={activeId} onPick={setActiveId} loading={loading} error={error} onRetry={() => refresh()} />
      </div>
      <div className={`min-h-0 ${activeId ? "" : "hidden md:block"}`}>
        {activeId ? (
          <ChatBox conversationId={activeId} meId={meId} meRole={meRole} onBack={back} />
        ) : (
          <div className="road-pattern flex h-full flex-col items-center justify-center bg-paper p-8 text-center">
            <span className="flex h-16 w-16 items-center justify-center rounded-3xl bg-white text-3xl shadow-sm ring-1 ring-line">🛵</span>
            <h3 className="mt-4 text-lg font-black tracking-tight">Bir sohbet seçin</h3>
            <p className="mt-1 max-w-sm text-sm text-ink/55">
              Görev sohbetleri atama onaylandığında açılır ve görev bitince arşivlenir. Filo içi kanallar görevden bağımsızdır.
            </p>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <Link href="/kesfet" className="btn-primary btn-sm">⚡ Hemen çağır</Link>
              <Link href="/siparislerim" className="btn-ghost btn-sm">Siparişlerim</Link>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ---------------- Yüzen dock (sağ alt) ---------------- */
export function ChatDock({ meId, meRole }: { meId: string; meRole: string }) {
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const [pulse, setPulse] = useState(false);
  const openRef = useRef(open);
  useEffect(() => { openRef.current = open; }, [open]);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      try {
        const res = await fetch("/api/chat/conversations?summary=1");
        if (!res.ok) return;
        const data = (await res.json()) as { unread: number };
        if (!alive) return;
        setUnread((prev) => {
          if (data.unread > prev && !openRef.current) {
            setPulse(true);
            setTimeout(() => setPulse(false), 2400);
          }
          return data.unread;
        });
      } catch {
        /* rozet sonraki turda güncellenir */
      }
    };
    load();
    const t = setInterval(load, 10000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, []);

  useEffect(() => {
    const handler = () => setOpen(true);
    window.addEventListener(OPEN_CHAT_EVENT, handler);
    return () => window.removeEventListener(OPEN_CHAT_EVENT, handler);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <>
      {open && (
        <div className="fixed inset-0 z-50 sm:inset-auto sm:bottom-24 sm:right-6 sm:z-50">
          <div className="fade-up h-full w-full overflow-hidden bg-white shadow-2xl sm:h-[min(620px,78vh)] sm:w-[400px] sm:rounded-3xl sm:ring-1 sm:ring-line">
            <ChatWorkspace meId={meId} meRole={meRole} variant="sheet" onClose={() => setOpen(false)} />
          </div>
        </div>
      )}
      <button
        type="button"
        onClick={() => setOpen(!open)}
        aria-label={open ? "Mesajları kapat" : `Mesajları aç${unread ? `, ${unread} okunmamış` : ""}`}
        className={`fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full text-white shadow-[0_16px_36px_-12px_rgba(255,91,35,0.9)] transition hover:scale-105 active:scale-95 ${
          open ? "bg-ink" : "bg-gradient-to-br from-signal to-[#e64512]"
        } ${pulse ? "animate-bounce" : ""}`}
      >
        <span className="text-xl" aria-hidden="true">{open ? "✕" : "💬"}</span>
        {!open && unread > 0 && (
          <span className="absolute -right-1 -top-1 flex h-6 min-w-6 items-center justify-center rounded-full bg-ink px-1.5 text-[11px] font-black text-white ring-2 ring-signal">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>
    </>
  );
}

/* ---------------- Bağlamdan sohbet açma düğmesi ---------------- */
export function OpenChatButton({
  requestId,
  orderId,
  providerUserId,
  label = "💬 Mesaj gönder",
  className = "btn-ink btn-sm",
}: {
  requestId?: string;
  orderId?: string;
  providerUserId?: string;
  label?: string;
  className?: string;
}) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  return (
    <span className="inline-flex flex-col items-start gap-1">
      <button
        type="button"
        disabled={busy}
        className={className}
        onClick={async () => {
          setBusy(true);
          setErr(null);
          try {
            const res = await fetch("/api/chat/conversations", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ requestId, orderId, providerUserId }),
            });
            const data = (await res.json().catch(() => ({}))) as { id?: string; error?: string };
            if (!res.ok || !data.id) throw new Error(data.error ?? "Sohbet açılamadı.");
            openChat(data.id);
            router.refresh();
          } catch (e) {
            setErr((e as Error).message);
          } finally {
            setBusy(false);
          }
        }}
      >
        {busy ? "Açılıyor…" : label}
      </button>
      {err && <span className="max-w-[220px] text-xs font-semibold text-rose">{err}</span>}
    </span>
  );
}
