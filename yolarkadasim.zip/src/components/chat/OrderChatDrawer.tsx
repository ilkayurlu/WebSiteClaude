"use client";

import { useEffect, useState } from "react";
import { Loader2, MessageCircle } from "lucide-react";
import { getOrCreateOrderChat } from "@/actions/chat-actions";
import { ChatBox } from "./ChatBox";

interface OrderChatDrawerProps {
  /** Görev (service request) veya yemek siparişi kimliği. */
  orderId: string;
  meId: string;
  meRole: string;
  label?: string;
  className?: string;
}

/** Sipariş bağlamlı sohbet: mobilde alttan açılan drawer, masaüstünde sağ altta yüzen kutu. */
export function OrderChatDrawer({ orderId, meId, meRole, label = "Müşteri ile Sohbet Başlat", className }: OrderChatDrawerProps) {
  const [open, setOpen] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  async function openChat() {
    setError(null);
    if (conversationId) {
      setOpen(true);
      return;
    }
    setLoading(true);
    try {
      const result = await getOrCreateOrderChat(orderId);
      if (!result.success) {
        setError(result.error);
        return;
      }
      setConversationId(result.conversationId);
      setOpen(true);
    } catch {
      setError("Sohbet açılamadı. Lütfen tekrar deneyin.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <span className="inline-flex flex-col items-start gap-1">
        <button
          type="button"
          onClick={openChat}
          disabled={loading}
          className={className ?? "btn-ghost btn-sm"}
          aria-haspopup="dialog"
          aria-expanded={open}
        >
          {loading ? <Loader2 size={14} className="animate-spin text-signal" aria-hidden="true" /> : <MessageCircle size={14} className="text-signal" aria-hidden="true" />}
          {label}
        </button>
        {error && <span role="alert" className="max-w-[240px] text-xs font-semibold text-rose">{error}</span>}
      </span>
      {open && conversationId && (
        <div className="fixed inset-0 z-[80] flex items-end justify-center bg-ink/50 backdrop-blur-sm sm:inset-auto sm:bottom-6 sm:right-6 sm:block sm:bg-transparent sm:backdrop-blur-0" role="dialog" aria-modal="true" aria-label="Sipariş sohbeti" onClick={() => setOpen(false)}>
          <div className="fade-up relative h-[85vh] w-full overflow-hidden rounded-t-3xl bg-white shadow-2xl sm:h-[min(600px,78vh)] sm:w-[400px] sm:rounded-3xl sm:ring-1 sm:ring-line" onClick={(event) => event.stopPropagation()}>
            <div className="mx-auto mt-2 h-1.5 w-12 rounded-full bg-ink/15 sm:hidden" aria-hidden="true" />
            <div className="h-full sm:h-full">
              <ChatBox conversationId={conversationId} meId={meId} meRole={meRole} onClose={() => setOpen(false)} compact />
            </div>
          </div>
        </div>
      )}
    </>
  );
}
