"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useCities, useDistricts, type CityOption, type DistrictOption } from "@/components/order/use-geo";
import type { ChatPeer, ConversationStatus, MessageWithSender } from "@/lib/chat";
import { Avatar, Pill } from "@/components/ui";

type InitPayload = {
  kind: "init";
  messages: MessageWithSender[];
  hasMore: boolean;
  status: ConversationStatus;
  closedReason: string | null;
  contextLabel: string;
  me: string;
  muted: boolean;
  other: ChatPeer | null;
};
type StreamEvent =
  | InitPayload
  | { kind: "messages"; messages: MessageWithSender[] }
  | { kind: "receipts"; status: ConversationStatus; closedReason: string | null; readUpTo: string | null; readIds: string[] }
  | { kind: "reconnect" }
  | { kind: "error"; message: string };

const QUICK_CUSTOMER = ["Adresteyim 👍", "Kodu hazırlıyorum", "Kapıda bekliyorum", "Acele etmeyin, güvenli sürün"];
const QUICK_PROVIDER = ["Geldik 📍", "Kapıdayım 🛵", "Kodu bekliyorum 🔐", "Yola çıktım", "Adrese yaklaştım"];

function timeOf(iso: string) {
  return new Intl.DateTimeFormat("tr-TR", { hour: "2-digit", minute: "2-digit", timeZone: "Europe/Istanbul" }).format(new Date(iso));
}
function dayOf(iso: string) {
  return new Intl.DateTimeFormat("tr-TR", { day: "numeric", month: "long", timeZone: "Europe/Istanbul" }).format(new Date(iso));
}

function labelFromSlug(slug: string): string {
  if (!slug) return "Bölge";
  const parts = slug.split("-");
  return parts.map((part) => part.charAt(0).toLocaleUpperCase("tr") + part.slice(1)).join(" / ");
}

function PinBody({ raw }: { raw: string }) {
  let area = "";
  let label = "";
  try {
    const p = JSON.parse(raw) as { area?: string; label?: string };
    area = p.area ?? "";
    label = p.label ?? "";
  } catch {
    label = raw;
  }
  const name = labelFromSlug(area);
  return (
    <span className="block">
      <span className="flex items-center gap-2 rounded-xl bg-ink/[0.06] px-3 py-2">
        <span className="relative flex h-8 w-8 items-center justify-center rounded-full bg-signal/15 text-signal">
          <span className="pulse-dot h-2 w-2 rounded-full bg-signal text-signal" />
        </span>
        <span>
          <span className="block text-sm font-extrabold">📍 {name}</span>
          {label && <span className="block text-xs opacity-75">{label}</span>}
          <span className="block text-[10px] opacity-55">Yaklaşık konum — tam koordinat paylaşılmaz</span>
        </span>
      </span>
    </span>
  );
}

export function ChatBox({
  conversationId,
  meId,
  meRole,
  onBack,
  onClose,
  compact = false,
}: {
  conversationId: string;
  meId: string;
  meRole: string;
  onBack?: () => void;
  onClose?: () => void;
  compact?: boolean;
}) {
  const [messages, setMessages] = useState<MessageWithSender[]>([]);
  const [other, setOther] = useState<ChatPeer | null>(null);
  const [status, setStatus] = useState<ConversationStatus>("ACTIVE");
  const [closedReason, setClosedReason] = useState<string | null>(null);
  const [contextLabel, setContextLabel] = useState("");
  const [readUpTo, setReadUpTo] = useState<string | null>(null);
  const [readIds, setReadIds] = useState<Set<string>>(new Set());
  const [hasMore, setHasMore] = useState(false);
  const [page, setPage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [loadErr, setLoadErr] = useState<string | null>(null);
  const [live, setLive] = useState<"connecting" | "online" | "polling">("connecting");
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [sendErr, setSendErr] = useState<string | null>(null);
  const [maskNote, setMaskNote] = useState<string | null>(null);
  const [pinOpen, setPinOpen] = useState(false);
  const [pinCity, setPinCity] = useState("");
  const [pinArea, setPinArea] = useState("");
  const pinCities = useCities();
  const pinDistricts = useDistricts(pinCity || null);
  const [pinLabel, setPinLabel] = useState("");
  const [muted, setMuted] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const stickRef = useRef(true);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const maskTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const scrollToBottom = useCallback((smooth: boolean) => {
    requestAnimationFrame(() => {
      bottomRef.current?.scrollIntoView({ behavior: smooth ? "smooth" : "auto", block: "end" });
    });
  }, []);

  const mergeMessages = useCallback((incoming: MessageWithSender[], mode: "append" | "prepend" | "replace") => {
    setMessages((prev) => {
      const base = mode === "replace" ? [] : mode === "prepend" ? [...incoming, ...prev] : [...prev, ...incoming];
      const seen = new Map<string, MessageWithSender>();
      for (const m of base) seen.set(m.id, m);
      return [...seen.values()].sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    });
  }, []);

  const applyInit = useCallback(
    (d: InitPayload) => {
      mergeMessages(d.messages, "replace");
      setOther(d.other);
      setStatus(d.status);
      setClosedReason(d.closedReason);
      setContextLabel(d.contextLabel);
      setHasMore(d.hasMore);
      setMuted(d.muted);
      setReadUpTo(d.other?.lastReadAt ?? null);
      setReadIds(new Set(d.messages.filter((m) => m.isRead).map((m) => m.id)));
      setLoading(false);
      setLoadErr(null);
      scrollToBottom(false);
      // Görünen sohbeti okundu işaretle
      fetch(`/api/chat/conversations/${conversationId}/read`, { method: "POST" }).catch(() => {});
    },
    [conversationId, mergeMessages, scrollToBottom],
  );

  // SSE aboneliği + polling yedeği
  useEffect(() => {
    let disposed = false;
    let es: EventSource | null = null;
    let poll: ReturnType<typeof setInterval> | null = null;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;
    let failures = 0;

    const markReadIfVisible = () => {
      if (document.visibilityState === "visible") fetch(`/api/chat/conversations/${conversationId}/read`, { method: "POST" }).catch(() => {});
    };

    const startPolling = () => {
      if (poll || disposed) return;
      setLive("polling");
      poll = setInterval(async () => {
        try {
          const res = await fetch(`/api/chat/conversations/${conversationId}/messages?page=0&limit=50`);
          if (!res.ok) return;
          const data = (await res.json()) as InitPayload;
          if (disposed) return;
          mergeMessages(data.messages, "replace");
          setStatus(data.status);
          setClosedReason(data.closedReason);
          setMuted(data.muted);
          setReadUpTo(data.other?.lastReadAt ?? null);
          setReadIds(new Set(data.messages.filter((m) => m.isRead).map((m) => m.id)));
          markReadIfVisible();
        } catch {
          /* bir sonraki turda tekrar denenir */
        }
      }, 4000);
    };

    const connect = () => {
      if (disposed) return;
      setLive((v) => (v === "polling" ? v : "connecting"));
      es = new EventSource(`/api/chat/conversations/${conversationId}/stream`);
      es.onopen = () => {
        if (disposed) return;
        failures = 0;
        setLive("online");
        if (poll) {
          clearInterval(poll);
          poll = null;
        }
      };
      es.onmessage = (ev: MessageEvent<string>) => {
        if (disposed) return;
        let data: StreamEvent;
        try {
          data = JSON.parse(ev.data) as StreamEvent;
        } catch {
          return;
        }
        if (data.kind === "init") {
          applyInit(data);
        } else if (data.kind === "messages") {
          mergeMessages(data.messages, "append");
          const fromOther = data.messages.some((m) => m.senderId && m.senderId !== meId);
          if (fromOther) markReadIfVisible();
          if (stickRef.current || data.messages.some((m) => m.senderId === meId)) scrollToBottom(true);
        } else if (data.kind === "receipts") {
          setStatus(data.status);
          setClosedReason(data.closedReason);
          setReadUpTo(data.readUpTo);
          setReadIds(new Set(data.readIds));
        }
      };
      es.onerror = () => {
        if (disposed) return;
        failures += 1;
        es?.close();
        es = null;
        if (failures >= 2) startPolling();
        retryTimer = setTimeout(connect, failures >= 2 ? 15000 : 2500);
      };
    };

    connect();
    const onVisible = () => markReadIfVisible();
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      disposed = true;
      es?.close();
      if (poll) clearInterval(poll);
      if (retryTimer) clearTimeout(retryTimer);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [conversationId, meId, applyInit, mergeMessages, scrollToBottom]);

  // Konuşma değişince sıfırla
  useEffect(() => {
    setMessages([]);
    setLoading(true);
    setPage(0);
    setDraft("");
    setSendErr(null);
    stickRef.current = true;
  }, [conversationId]);

  useEffect(() => () => { if (maskTimer.current) clearTimeout(maskTimer.current); }, []);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    stickRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 90;
  };

  async function loadOlder() {
    try {
      const next = page + 1;
      const res = await fetch(`/api/chat/conversations/${conversationId}/messages?page=${next}&limit=40`);
      if (!res.ok) throw new Error("Geçmiş mesajlar yüklenemedi.");
      const data = (await res.json()) as InitPayload;
      const firstVisible = messages[0]?.id;
      mergeMessages(data.messages, "prepend");
      setHasMore(data.hasMore);
      setPage(next);
      requestAnimationFrame(() => {
        if (firstVisible) document.getElementById(`msg-${firstVisible}`)?.scrollIntoView({ block: "start" });
      });
    } catch (e) {
      setLoadErr((e as Error).message);
    }
  }

  async function send(content: string, type: "TEXT" | "LOCATION_PIN" = "TEXT") {
    if (sending) return;
    setSending(true);
    setSendErr(null);
    try {
      const res = await fetch(`/api/chat/conversations/${conversationId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ conversationId, senderId: meId, content, type }),
      });
      const data = (await res.json().catch(() => ({}))) as { message?: MessageWithSender; masked?: boolean; warning?: string | null; error?: string };
      if (!res.ok) throw new Error(data.error ?? "Mesaj gönderilemedi.");
      if (data.message) {
        mergeMessages([data.message], "append");
        stickRef.current = true;
        scrollToBottom(true);
      }
      if (data.warning) {
        setMaskNote(data.warning);
        if (maskTimer.current) clearTimeout(maskTimer.current);
        maskTimer.current = setTimeout(() => setMaskNote(null), 5000);
      }
      if (type === "TEXT") setDraft("");
      setPinOpen(false);
      setPinLabel("");
      inputRef.current?.focus();
    } catch (e) {
      setSendErr((e as Error).message);
    } finally {
      setSending(false);
    }
  }

  async function toggleMute() {
    const next = !muted;
    setMuted(next);
    try {
      await fetch(`/api/chat/conversations/${conversationId}/mute`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ muted: next }) });
    } catch {
      setMuted(!next);
    }
  }

  const quick = meRole === "CUSTOMER" ? QUICK_CUSTOMER : QUICK_PROVIDER;
  const readOnly = status === "CLOSED";

  const grouped = useMemo(() => {
    const out: { day: string; items: MessageWithSender[] }[] = [];
    for (const m of messages) {
      const day = dayOf(m.createdAt);
      const last = out[out.length - 1];
      if (last && last.day === day) last.items.push(m);
      else out.push({ day, items: [m] });
    }
    return out;
  }, [messages]);

  function receiptFor(m: MessageWithSender): "read" | "delivered" | "sent" {
    if (m.isRead || readIds.has(m.id)) return "read";
    if (readUpTo && m.createdAt <= readUpTo) return "read";
    if (m.deliveredAt) return "delivered";
    return "sent";
  }

  return (
    <div className="flex h-full min-h-0 flex-col bg-paper">
      {/* Başlık */}
      <div className="flex items-center gap-3 border-b border-line bg-white px-4 py-3">
        {onBack && (
          <button type="button" onClick={onBack} aria-label="Gelen kutusuna dön" className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full text-ink/60 transition hover:bg-paper hover:text-signal">
            ←
          </button>
        )}
        {other ? <Avatar name={other.name} hue={other.hue} size={40} /> : <span className="flex h-10 w-10 items-center justify-center rounded-full bg-paper-2 text-sm">💬</span>}
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="truncate text-sm font-extrabold">{other?.name ?? "Sohbet"}</span>
            <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${live === "online" ? "bg-mint" : live === "polling" ? "bg-sun" : "bg-ink/25"}`} title={live === "online" ? "Canlı bağlantı" : live === "polling" ? "Yedek bağlantı (polling)" : "Bağlanıyor"} />
          </div>
          <div className="truncate text-[11px] text-ink/50">{contextLabel || "…"}</div>
        </div>
        <Pill tone={readOnly ? "slate" : "green"}>{readOnly ? "Arşiv" : "Aktif"}</Pill>
        <button type="button" onClick={toggleMute} aria-label={muted ? "Bildirimleri aç" : "Bildirimleri sessize al"} className={`flex h-9 w-9 items-center justify-center rounded-full transition hover:bg-paper ${muted ? "text-ink/35" : "text-ink/65 hover:text-signal"}`}>
          {muted ? "🔕" : "🔔"}
        </button>
        {onClose && (
          <button type="button" onClick={onClose} aria-label="Sohbeti kapat" className="flex h-9 w-9 items-center justify-center rounded-full text-ink/60 transition hover:bg-paper hover:text-rose">
            ✕
          </button>
        )}
      </div>

      {/* Mesaj akışı */}
      <div ref={scrollRef} onScroll={onScroll} className="chat-scroll road-pattern min-h-0 flex-1 overflow-y-auto px-4 py-4">
        {loading && (
          <div className="space-y-3" aria-busy="true">
            {[64, 40, 80, 52].map((w, i) => (
              <div key={i} className={`flex ${i % 2 ? "justify-end" : ""}`}>
                <div className="h-10 animate-pulse rounded-2xl bg-white/80 ring-1 ring-line" style={{ width: `${w}%` }} />
              </div>
            ))}
          </div>
        )}
        {!loading && hasMore && (
          <div className="mb-3 text-center">
            <button type="button" onClick={loadOlder} className="btn-ghost btn-sm">↑ Önceki mesajları yükle</button>
          </div>
        )}
        {loadErr && <div className="mb-3 rounded-xl bg-rose/10 px-3 py-2 text-center text-xs font-semibold text-rose">{loadErr}</div>}
        {!loading && messages.length === 0 && (
          <div className="flex h-full flex-col items-center justify-center text-center">
            <span className="text-2xl">👋</span>
            <p className="mt-2 max-w-[240px] text-sm text-ink/55">Sohbet başladı. İlk mesajı gönderin; telefon ve IBAN paylaşımları otomatik gizlenir.</p>
          </div>
        )}
        {grouped.map((g) => (
          <div key={g.day}>
            <div className="sticky top-0 z-10 my-3 flex justify-center">
              <span className="rounded-full bg-white/90 px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-ink/45 ring-1 ring-line">{g.day}</span>
            </div>
            <div className="space-y-2">
              {g.items.map((m) => {
                if (m.type === "SYSTEM_NOTICE") {
                  return (
                    <div key={m.id} id={`msg-${m.id}`} className="flex justify-center py-1">
                      <span className="max-w-[92%] rounded-full bg-ink/[0.05] px-3.5 py-1.5 text-center text-[11px] font-semibold text-ink/55 ring-1 ring-ink/10">{m.body}</span>
                    </div>
                  );
                }
                const mine = m.senderId === meId;
                const receipt = mine ? receiptFor(m) : null;
                return (
                  <div key={m.id} id={`msg-${m.id}`} className={`fade-up flex ${mine ? "justify-end" : "justify-start"}`}>
                    <div className={`max-w-[82%] ${compact ? "sm:max-w-[78%]" : "sm:max-w-[70%]"}`}>
                      <div
                        className={`rounded-2xl px-3.5 py-2.5 text-sm leading-relaxed shadow-sm ${
                          mine
                            ? "rounded-br-md bg-gradient-to-br from-signal to-[#f04d15] text-white"
                            : "rounded-bl-md bg-white text-ink ring-1 ring-line"
                        }`}
                      >
                        {m.type === "LOCATION_PIN" ? <PinBody raw={m.body} /> : <span className="whitespace-pre-wrap break-words">{m.body}</span>}
                      </div>
                      <div className={`mt-0.5 flex items-center gap-1.5 px-1 text-[10px] text-ink/40 ${mine ? "justify-end" : ""}`}>
                        {m.masked && <span className="font-bold text-[#9a6b00]" title="Kişisel veri otomatik gizlendi">🛡 maskelendi</span>}
                        <span>{timeOf(m.createdAt)}</span>
                        {receipt && (
                          <span aria-label={receipt === "read" ? "Okundu" : receipt === "delivered" ? "İletildi" : "Gönderildi"} className={`font-black tracking-tighter ${receipt === "read" ? "text-mint" : "text-ink/35"}`}>
                            {receipt === "sent" ? "✓" : "✓✓"}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {/* Maskeleme uyarısı */}
      {maskNote && (
        <div className="border-t border-sun/30 bg-sun/15 px-4 py-2 text-xs font-semibold text-[#7a5500]">🛡 {maskNote}</div>
      )}

      {/* Besteci / salt okunur */}
      {readOnly ? (
        <div className="border-t border-line bg-white px-4 py-3.5">
          <div className="flex items-center gap-2.5 rounded-xl bg-paper px-3.5 py-2.5 text-xs font-semibold text-ink/60">
            <span aria-hidden="true">🔒</span>
            <span className="flex-1">{closedReason ?? "Bu sohbet arşivlendi; artık salt okunur."}</span>
            <Link href="/destek" className="shrink-0 font-bold text-signal hover:underline">Destek</Link>
          </div>
        </div>
      ) : (
        <div className="border-t border-line bg-white px-3 pb-3 pt-2">
          <div className="scrollbar-none -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-2">
            {quick.map((q) => (
              <button key={q} type="button" disabled={sending} onClick={() => send(q)} className="shrink-0 rounded-full border border-line bg-paper px-3 py-1.5 text-[11px] font-bold text-ink/70 transition hover:border-signal hover:bg-signal/10 hover:text-signal disabled:opacity-50">
                {q}
              </button>
            ))}
          </div>
          {pinOpen && (
            <div className="mb-2 rounded-xl border border-line bg-paper p-3">
              <div className="text-[11px] font-bold uppercase tracking-wider text-ink/50">Yaklaşık konum paylaş — tam koordinat gönderilmez</div>
              <div className="mt-2 flex flex-col gap-2 sm:flex-row">
                <select className="input !py-2 !text-xs" value={pinCity} onChange={(e) => { setPinCity(e.target.value); setPinArea(""); }} aria-label="İl">
                  <option value="">{pinCities.status === "loading" ? "İller yükleniyor…" : "İl seçin"}</option>
                  {((pinCities.data ?? []) as CityOption[]).map((c) => (
                    <option key={c.code} value={c.code}>{c.name}</option>
                  ))}
                </select>
                <select className="input !py-2 !text-xs" value={pinArea} disabled={!pinCity} onChange={(e) => setPinArea(e.target.value)} aria-label="İlçe">
                  <option value="">{pinDistricts.status === "loading" ? "İlçeler yükleniyor…" : "İlçe seçin"}</option>
                  {((pinDistricts.data ?? []) as DistrictOption[]).map((d) => (
                    <option key={d.id} value={d.slug}>{d.name}</option>
                  ))}
                </select>
                <input className="input !py-2 !text-xs" maxLength={80} value={pinLabel} onChange={(e) => setPinLabel(e.target.value)} placeholder="Kısa etiket (ör. bina önü)" />
                <button type="button" disabled={sending || !pinArea} onClick={() => send(JSON.stringify({ area: pinArea, label: pinLabel }), "LOCATION_PIN")} className="btn-primary btn-sm shrink-0">
                  📍 Gönder
                </button>
              </div>
            </div>
          )}
          {sendErr && <div className="mb-2 rounded-xl bg-rose/10 px-3 py-2 text-xs font-semibold text-rose">{sendErr}</div>}
          <div className="flex items-end gap-2">
            <button type="button" onClick={() => setPinOpen(!pinOpen)} aria-label="Yaklaşık konum paylaş" className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-full border transition ${pinOpen ? "border-signal bg-signal/10 text-signal" : "border-line text-ink/55 hover:border-signal hover:text-signal"}`}>
              📍
            </button>
            <textarea
              ref={inputRef}
              value={draft}
              onChange={(e) => setDraft(e.target.value.slice(0, 1000))}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  if (draft.trim()) send(draft);
                }
              }}
              rows={Math.min(3, Math.max(1, draft.split("\n").length))}
              placeholder="Mesaj yazın… (Enter gönderir, Shift+Enter satır atlar)"
              aria-label="Mesaj"
              className="input max-h-28 min-h-[44px] flex-1 resize-none !rounded-2xl !py-2.5"
            />
            <button
              type="button"
              disabled={sending || !draft.trim()}
              onClick={() => send(draft)}
              aria-label="Gönder"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-signal text-white shadow-[0_8px_18px_-8px_rgba(255,91,35,0.8)] transition hover:scale-105 hover:bg-[#f04d15] active:scale-95 disabled:opacity-40 disabled:hover:scale-100"
            >
              {sending ? (
                <svg className="h-4 w-4 animate-spin" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" className="opacity-25" />
                  <path d="M4 12a8 8 0 018-8" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
                </svg>
              ) : (
                <svg viewBox="0 0 24 24" className="h-[18px] w-[18px]" fill="currentColor" aria-hidden="true" width="18" height="18">
                  <path d="M3.4 20.4l17.4-7.5c.8-.35.8-1.45 0-1.8L3.4 3.6c-.66-.29-1.39.2-1.39.91L2 9.12c0 .5.37.93.87.99L17 12 2.87 13.88c-.5.07-.87.5-.87 1l.01 4.61c0 .72.73 1.2 1.39.91z" />
                </svg>
              )}
            </button>
          </div>
          <div className="mt-1.5 flex items-center justify-between px-1 text-[10px] text-ink/35">
            <span>🛡 Telefon, IBAN ve e-posta otomatik maskelenir</span>
            <span>{draft.length}/1000</span>
          </div>
        </div>
      )}
    </div>
  );
}
