import { getPublicSession } from "@/lib/session";
import { ChatDock } from "./ChatSheet";

/** Oturum rolüne göre yüzen sohbet dock'ı — admin içerik görmez. */
export async function ChatDockGate() {
  const s = await getPublicSession();
  if (!s.authenticated || ["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) return null;
  return <ChatDock meId={s.user.id} meRole={s.user.role} />;
}
