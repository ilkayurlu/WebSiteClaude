"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState, useTransition } from "react";
import { AlertTriangle, ArrowRight, Clock3, Loader2, Lock, MapPin, Radar, UserPlus, X } from "lucide-react";
import { manualAssignCourierAction } from "@/actions/admin-live-tasks";
import type { LiveTask } from "@/lib/admin-data";

const STATUS: Record<string, string> = { QUOTED: "Seçim bekliyor", MATCHING: "Eşleştiriliyor", OFFERED: "Teklifte", EXPIRED: "Kurye bulunamadı", CONFIRMED: "Onaylandı", IN_PROGRESS: "Yolda" };
const VEH: Record<string, string> = { BICYCLE: "Bisiklet", MOTORCYCLE: "Motosiklet", CAR: "Otomobil", VAN: "Panelvan", TRUCK: "Kamyonet", COLD_CHAIN_VAN: "Soğuk zincir", MINIBUS: "Minibüs" };

export function LiveTaskMonitor({ tasks, areas }: { tasks: LiveTask[]; areas: { key: string; name: string }[] }) {
  const router = useRouter();
  const [filter, setFilter] = useState<"ACTION" | "ALL">("ACTION");
  const [target, setTarget] = useState<LiveTask | null>(null);
  const [providerId, setProviderId] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [pending, start] = useTransition();

  useEffect(() => {
    const t = setInterval(() => { if (document.visibilityState === "visible" && !target) router.refresh(); }, 8000);
    return () => clearInterval(t);
  }, [router, target]);

  const shown = filter === "ACTION" ? tasks.filter((t) => t.priority !== "NORMAL") : tasks;
  const heat = useMemo(() => areas.map((a) => ({ ...a, count: tasks.filter((t) => t.pickupKey === a.key).length, critical: tasks.filter((t) => t.pickupKey === a.key && t.priority === "CRITICAL").length })).filter((a) => a.count > 0), [areas, tasks]);

  function openAssign(task: LiveTask) {
    setTarget(task);
    setProviderId(task.eligibleProviders[0]?.id ?? "");
    setReason(task.status === "EXPIRED" ? "Otomatik eşleştirme kurye bulamadı; operasyon manuel atama yaptı." : "Talep uzun süre kabul edilmedi; operasyon manuel atama yaptı.");
    setError(null);
  }

  function assign() {
    if (!target) return;
    setError(null);
    start(async () => {
      try {
        const res = await manualAssignCourierAction(target.id, providerId, reason);
        if (!res.success) throw new Error(res.error);
        setNotice(`${target.code} için kurye atandı; müşteri ve kurye bilgilendirildi.`);
        setTarget(null);
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "Atama yapılamadı.");
      }
    });
  }

  return (
    <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_320px]">
      <div>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="flex gap-2" role="tablist" aria-label="Görev filtresi">
            {([["ACTION", `Müdahale gereken (${tasks.filter((t) => t.priority !== "NORMAL").length})`], ["ALL", `Tüm canlı görevler (${tasks.length})`]] as const).map(([k, l]) => (
              <button key={k} type="button" role="tab" aria-selected={filter === k} onClick={() => setFilter(k)} className={`rounded-full px-4 py-2 text-xs font-bold transition ${filter === k ? "bg-ink text-white" : "bg-white text-ink/60 ring-1 ring-line hover:text-signal hover:ring-signal"}`}>{l}</button>
            ))}
          </div>
          <span className="flex items-center gap-1.5 text-[11px] text-ink/50"><Clock3 size={12} className="text-signal" /> 8 sn&apos;de bir yenilenir</span>
        </div>
        {notice && <div role="status" className="mb-4 rounded-xl bg-mint/10 px-4 py-3 text-sm font-semibold text-[#0c8a5a]">{notice}</div>}
        <div className="space-y-3">
          {shown.map((t) => (
            <article key={t.id} className={`rounded-[18px] border bg-white p-4 transition hover:shadow-[0_14px_30px_-20px_rgba(14,19,36,.4)] ${t.priority === "CRITICAL" ? "border-rose/40" : t.priority === "DELAYED" ? "border-signal/40" : "border-line"}`}>
              <div className="flex flex-wrap items-center gap-2">
                {t.priority !== "NORMAL" && <span className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-black ${t.priority === "CRITICAL" ? "bg-rose/10 text-rose" : "bg-signal/10 text-signal"}`}>{t.otpLocked ? <Lock size={11} /> : <AlertTriangle size={11} />}{t.priority === "CRITICAL" ? "KRİTİK" : "GECİKME"}</span>}
                <Link href={`/talep/${t.id}`} className="font-mono text-sm font-black hover:text-signal">{t.code}</Link>
                <span className="rounded-full bg-paper px-2 py-0.5 text-[10px] font-bold text-ink/60">{STATUS[t.status] ?? t.status}</span>
                {t.linkedOrderId && <span className="rounded-full bg-paper px-2 py-0.5 text-[10px] font-bold text-ink/60">Yemek siparişi</span>}
                <span className="ml-auto text-[11px] font-semibold text-ink/45">{t.ageMinutes} dk önce</span>
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-1.5 text-xs text-ink/60"><MapPin size={12} className="text-signal" />{t.pickup}<ArrowRight size={11} className="text-signal" />{t.dropoff}{t.vehicleTypeReq && <span>· {VEH[t.vehicleTypeReq]}</span>}{t.providerName && <span>· kurye: <b className="text-ink">{t.providerName}</b></span>}</div>
              <p className={`mt-1.5 text-xs font-semibold ${t.priority === "CRITICAL" ? "text-rose" : t.priority === "DELAYED" ? "text-signal" : "text-ink/45"}`}>{t.reason}</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {["QUOTED", "MATCHING", "OFFERED", "EXPIRED"].includes(t.status) && (
                  <button type="button" onClick={() => openAssign(t)} disabled={!t.eligibleProviders.length} className="btn-primary btn-sm"><UserPlus size={13} /> {t.eligibleProviders.length ? `Manuel kurye ata (${t.eligibleProviders.length} uygun)` : "Uygun müsait kurye yok"}</button>
                )}
                {t.otpLocked && <Link href="/admin/uyusmazliklar" className="btn-ghost btn-sm"><Lock size={13} className="text-signal" /> Kilidi incele</Link>}
                <Link href={`/talep/${t.id}`} className="btn-ghost btn-sm">Detay <ArrowRight size={13} className="text-signal" /></Link>
              </div>
            </article>
          ))}
          {shown.length === 0 && <div className="flex flex-col items-center rounded-[18px] border border-line bg-white px-6 py-12 text-center"><Radar size={26} className="text-signal" /><b className="mt-3 text-sm">{filter === "ACTION" ? "Müdahale gereken görev yok" : "Son 24 saatte canlı görev yok"}</b><p className="mt-1 text-xs text-ink/55">Geciken, kurye bulamayan veya teslim kodu kilitlenen görevler burada otomatik belirir.</p></div>}
        </div>
      </div>

      <aside className="space-y-4">
        <div className="rounded-[20px] bg-ink p-5 text-white">
          <div className="flex items-center gap-2 text-sm font-extrabold"><Radar size={16} className="text-signal" /> Bölge yoğunluğu</div>
          <p className="mt-1 text-[11px] text-white/50">Harita simülasyonu: ilçe bazında görev sayısı. Gerçek GPS veya kurye koordinatı gösterilmez.</p>
          <div className="mt-4 grid grid-cols-2 gap-2">
            {heat.length ? heat.map((a) => (
              <div key={a.key} className={`rounded-xl px-3 py-2 ring-1 ${a.critical ? "bg-rose/20 ring-rose/40" : "bg-white/[.06] ring-white/10"}`} style={{ opacity: 0.55 + Math.min(0.45, a.count / 5) }}>
                <div className="truncate text-[11px] font-bold">{a.name}</div>
                <div className="text-lg font-black text-signal">{a.count}</div>
              </div>
            )) : <p className="col-span-2 text-xs text-white/50">Şu an aktif bölge yok.</p>}
          </div>
        </div>
        <div className="rounded-[20px] border border-line bg-white p-5 text-xs leading-relaxed text-ink/60"><b className="text-ink">Manuel atama kuralları</b><br />Yalnızca bölge, hizmet tipi ve araç uyumu doğrulanmış müsait kuryeler listelenir. Atama gerekçesi denetim izine yazılır; müşteri ve kurye bildirim alır, görev sohbeti otomatik açılır.</div>
      </aside>

      {target && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-ink/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Manuel kurye atama" onClick={() => setTarget(null)}>
          <div className="w-full max-w-lg rounded-3xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3">
              <div><h3 className="flex items-center gap-2 font-extrabold"><UserPlus size={17} className="text-signal" /> {target.code} · manuel atama</h3><p className="mt-1 text-xs text-ink/55">{target.pickup} → {target.dropoff} · {target.reason}</p></div>
              <button type="button" onClick={() => setTarget(null)} aria-label="Kapat" className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-paper"><X size={16} className="text-signal" /></button>
            </div>
            <div className="mt-4 max-h-64 space-y-1.5 overflow-y-auto" role="radiogroup" aria-label="Uygun kuryeler">
              {target.eligibleProviders.map((p) => (
                <label key={p.id} className={`flex cursor-pointer items-center justify-between rounded-xl border px-3 py-2.5 text-sm transition ${providerId === p.id ? "border-signal bg-signal/[.05]" : "border-line hover:border-ink/25"}`}>
                  <span className="flex items-center gap-2"><input type="radio" name="assign-provider" checked={providerId === p.id} onChange={() => setProviderId(p.id)} className="accent-[#ff5b23]" /><b>{p.name}</b><span className="text-xs text-ink/50">{VEH[p.vehicleType]}</span></span>
                  <span className="text-xs font-bold text-ink/60">{p.ratingCount ? `★ ${p.ratingAvg.toFixed(1)}` : "Yeni"}</span>
                </label>
              ))}
            </div>
            <label className="label mt-4" htmlFor="assign-reason">Gerekçe (denetim izine yazılır)</label>
            <textarea id="assign-reason" className="input min-h-20" maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} />
            {error && <p role="alert" className="mt-2 text-xs font-semibold text-rose">{error}</p>}
            <div className="mt-4 flex gap-2">
              <button type="button" disabled={pending || !providerId || reason.trim().length < 10} onClick={assign} className="btn-primary">{pending ? <Loader2 size={14} className="animate-spin" /> : <UserPlus size={14} />} Kuryeyi ata</button>
              <button type="button" onClick={() => setTarget(null)} className="btn-ghost">Vazgeç</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
