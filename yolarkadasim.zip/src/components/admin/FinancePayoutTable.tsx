"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { Banknote, Building2, CalendarRange, CircleAlert, FileText, Loader2, Lock, LockOpen, Percent, ReceiptText, Truck, Wallet, X } from "lucide-react";
import {
  holdPayoutAction, processBulkPayoutAction, processSinglePayoutAction, releasePayoutAction,
  type PayoutRecord,
} from "@/actions/admin-finance-actions";
import type { PeriodGranularity } from "@/lib/payouts";
import { money } from "@/lib/labels";

type TypeFilter = "ALL" | "COURIER" | "FLEET";
type StatusFilter = "ALL" | "PENDING" | "PAID" | "HOLD";
type Dialog =
  | { kind: "single"; record: PayoutRecord }
  | { kind: "bulk"; records: PayoutRecord[] }
  | { kind: "hold"; record: PayoutRecord }
  | { kind: "release"; record: PayoutRecord }
  | null;

const STATUS_UI: Record<PayoutRecord["status"], { label: string; cls: string; dot: string }> = {
  PENDING: { label: "Beklemede", cls: "bg-signal/15 text-signal ring-1 ring-signal/30", dot: "bg-signal" },
  PAID: { label: "Ödendi", cls: "bg-mint/15 text-[#0c8a5a] ring-1 ring-mint/30", dot: "bg-mint" },
  HOLD: { label: "Blokta", cls: "bg-white/10 text-white/80 ring-1 ring-white/20", dot: "bg-white/60" },
};

function Kpi({ title, value, hint, icon: Icon, tone }: { title: string; value: string; hint: string; icon: typeof Wallet; tone: "ink" | "signal" | "mint" }) {
  const box = tone === "ink" ? "border-white/10 bg-ink text-white" : tone === "signal" ? "border-signal/25 bg-signal/[0.04] text-ink" : "border-mint/25 bg-mint/[0.05] text-ink";
  const title2 = tone === "ink" ? "text-white/50" : tone === "signal" ? "text-signal" : "text-[#0c8a5a]";
  return (
    <div className={`rounded-3xl border p-5 shadow-xl ${box}`}>
      <div className="flex items-start justify-between gap-2">
        <div className={`text-[11px] font-bold uppercase tracking-wider ${title2}`}>{title}</div>
        <Icon size={18} className="text-signal" aria-hidden="true" />
      </div>
      <div className="mt-2 text-2xl font-black sm:text-3xl">{value}</div>
      <p className={`mt-1 text-xs ${tone === "ink" ? "text-white/40" : "text-ink/50"}`}>{hint}</p>
    </div>
  );
}

export function FinancePayoutTable({ records, granularity, commissionBps }: { records: PayoutRecord[]; granularity: PeriodGranularity; commissionBps: number }) {
  const router = useRouter();
  const [filterType, setFilterType] = useState<TypeFilter>("ALL");
  const [filterStatus, setFilterStatus] = useState<StatusFilter>("ALL");
  const [period, setPeriod] = useState<string>("ALL");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [dialog, setDialog] = useState<Dialog>(null);
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const periods = useMemo(() => [...new Set(records.map((r) => r.period))], [records]);
  const filtered = useMemo(() => records.filter((r) => (filterType === "ALL" || r.beneficiaryType === filterType) && (filterStatus === "ALL" || r.status === filterStatus) && (period === "ALL" || r.period === period)), [records, filterType, filterStatus, period]);
  const totals = useMemo(() => ({
    gross: filtered.reduce((a, r) => a + r.grossMinor, 0),
    fee: filtered.reduce((a, r) => a + r.platformFeeMinor, 0),
    net: filtered.reduce((a, r) => a + r.netMinor, 0),
    courier: filtered.filter((r) => r.beneficiaryType === "COURIER").reduce((a, r) => a + r.netMinor, 0),
    fleet: filtered.filter((r) => r.beneficiaryType === "FLEET").reduce((a, r) => a + r.netMinor, 0),
    pending: filtered.filter((r) => r.status === "PENDING").reduce((a, r) => a + r.netMinor, 0),
  }), [filtered]);

  const payable = filtered.filter((r) => r.status === "PENDING" && r.ibanMasked);
  const allSelected = payable.length > 0 && payable.every((r) => selected.has(r.id));
  const selectedRecords = records.filter((r) => selected.has(r.id));
  const target = (r: PayoutRecord) => ({ beneficiaryType: r.beneficiaryType, beneficiaryId: r.beneficiaryId, period: r.period, granularity });

  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(payable.map((r) => r.id)));
  const toggleOne = (id: string) => setSelected((prev) => { const next = new Set(prev); if (next.has(id)) next.delete(id); else next.add(id); return next; });
  const close = () => { setDialog(null); setNote(""); setError(null); };

  function run() {
    if (!dialog) return;
    setError(null);
    start(async () => {
      try {
        if (dialog.kind === "single") {
          const res = await processSinglePayoutAction(target(dialog.record), note || undefined);
          if (!res.success) throw new Error(res.error);
          setNotice(`${dialog.record.beneficiaryName} · ${dialog.record.period} ödeme emri kayda alındı (ref. ${res.reference}).`);
        } else if (dialog.kind === "bulk") {
          const res = await processBulkPayoutAction(dialog.records.map(target), note || undefined);
          if (!res.success) throw new Error(res.failures?.length ? `${res.error} (${res.failures.length} kayıt işlenemedi)` : res.error);
          setNotice(`${res.processed} ödeme emri kayda alındı${res.failures?.length ? `; ${res.failures.length} kayıt işlenemedi: ${res.failures.map((f) => f.error).join(" · ")}` : "."}`);
          setSelected(new Set());
        } else if (dialog.kind === "hold") {
          const res = await holdPayoutAction(target(dialog.record), note);
          if (!res.success) throw new Error(res.error);
          setNotice(`${dialog.record.beneficiaryName} · ${dialog.record.period} bloke edildi.`);
        } else {
          const res = await releasePayoutAction(target(dialog.record), note);
          if (!res.success) throw new Error(res.error);
          setNotice(`${dialog.record.beneficiaryName} · ${dialog.record.period} bloğu kaldırıldı.`);
        }
        close();
        router.refresh();
      } catch (e) {
        setError(e instanceof Error ? e.message : "İşlem gerçekleştirilemedi.");
      }
    });
  }

  const Seg = <T extends string>({ value, options, onChange, activeCls }: { value: T; options: [T, string][]; onChange: (v: T) => void; activeCls?: (v: T) => string }) => (
    <div className="inline-flex rounded-xl bg-white/5 p-1 ring-1 ring-white/10" role="tablist">
      {options.map(([k, l]) => (
        <button key={k} type="button" role="tab" aria-selected={value === k} onClick={() => onChange(k)} className={`rounded-lg px-3 py-1.5 text-xs font-bold transition ${value === k ? (activeCls?.(k) ?? "bg-white/15 text-white") : "text-white/50 hover:text-white"}`}>{l}</button>
      ))}
    </div>
  );

  const needsReason = dialog?.kind === "hold" || dialog?.kind === "release";

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-3">
        <Kpi tone="ink" icon={ReceiptText} title="Brüt ciro (GMV)" value={money(totals.gross)} hint={`Seçili filtrede ${filtered.length} hakediş dönemi`} />
        <Kpi tone="signal" icon={Percent} title={`Platform komisyonu (güncel %${(commissionBps / 100).toFixed(1)})`} value={money(totals.fee)} hint="Görev bazında kaydedilen oranla kesilen pay" />
        <Kpi tone="mint" icon={Wallet} title="Net hakediş" value={money(totals.net)} hint={`Kurye ${money(totals.courier)} · Filo ${money(totals.fleet)} · Bekleyen ${money(totals.pending)}`} />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-4 rounded-2xl border border-white/10 bg-ink p-4">
        <div className="flex flex-wrap items-center gap-2">
          <Seg value={filterType} onChange={setFilterType} options={[["ALL", "Tümü"], ["COURIER", "Bağımsız kuryeler"], ["FLEET", "Filolar"]]} />
          <Seg value={filterStatus} onChange={setFilterStatus} options={[["ALL", "Tüm durumlar"], ["PENDING", "Bekleyenler"], ["PAID", "Ödenenler"], ["HOLD", "Blokta"]]} activeCls={(v) => (v === "PENDING" ? "bg-signal text-white" : v === "PAID" ? "bg-mint text-ink" : "bg-white/15 text-white")} />
          <label className="inline-flex items-center gap-2 rounded-xl bg-white/5 px-3 py-1.5 text-xs font-bold text-white/70 ring-1 ring-white/10">
            <CalendarRange size={13} className="text-signal" aria-hidden="true" />
            <select value={period} onChange={(e) => setPeriod(e.target.value)} className="bg-transparent text-xs font-bold text-white outline-none" aria-label="Dönem">
              <option value="ALL" className="text-ink">Tüm dönemler</option>
              {periods.map((p) => <option key={p} value={p} className="text-ink">{p}</option>)}
            </select>
          </label>
          <Link href={`/admin/finans?periyot=${granularity === "week" ? "ay" : "hafta"}`} className="rounded-xl bg-white/5 px-3 py-1.5 text-xs font-bold text-white/70 ring-1 ring-white/10 hover:text-white">{granularity === "week" ? "Aylık görünüme geç" : "Haftalık görünüme geç"}</Link>
        </div>
        {selected.size > 0 && (
          <button type="button" disabled={pending} onClick={() => setDialog({ kind: "bulk", records: selectedRecords })} className="rounded-xl bg-signal px-4 py-2 text-xs font-black text-white shadow-[0_4px_12px_rgba(255,91,35,0.4)] transition hover:brightness-110 disabled:opacity-50">
            Seçili ({selected.size}) ödemeyi tamamla · {money(selectedRecords.reduce((a, r) => a + r.netMinor, 0))}
          </button>
        )}
      </div>

      {notice && <div role="status" className="rounded-xl bg-mint/10 px-4 py-3 text-sm font-semibold text-[#0c8a5a]">{notice}</div>}

      <div className="overflow-hidden rounded-2xl border border-white/10 bg-ink shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[980px] text-left text-sm text-white">
            <thead className="border-b border-white/10 bg-white/[0.02] text-[11px] font-bold uppercase tracking-wider text-white/40">
              <tr>
                <th className="w-10 px-5 py-4"><input type="checkbox" aria-label="Ödenebilir tümünü seç" onChange={toggleAll} checked={allSelected} disabled={!payable.length} className="h-4 w-4 accent-[#ff5b23]" /></th>
                <th className="px-5 py-4">Hak sahibi</th>
                <th className="px-5 py-4">IBAN & dönem</th>
                <th className="px-5 py-4 text-right">Görev</th>
                <th className="px-5 py-4 text-right">Brüt</th>
                <th className="px-5 py-4 text-right">Komisyon</th>
                <th className="px-5 py-4 text-right">Net ödenecek</th>
                <th className="px-5 py-4 text-center">Durum</th>
                <th className="px-5 py-4 text-right">İşlem</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/10">
              {filtered.length === 0 && <tr><td colSpan={9} className="p-8 text-center text-xs text-white/40">Filtre kriterlerine uygun ödeme kaydı bulunamadı.</td></tr>}
              {filtered.map((r) => {
                const ui = STATUS_UI[r.status];
                const canPay = r.status === "PENDING" && !!r.ibanMasked;
                return (
                  <tr key={r.id} className="transition hover:bg-white/[0.02]">
                    <td className="px-5 py-4"><input type="checkbox" aria-label={`${r.beneficiaryName} ${r.period} seç`} disabled={!canPay} checked={selected.has(r.id)} onChange={() => toggleOne(r.id)} className="h-4 w-4 accent-[#ff5b23] disabled:opacity-30" /></td>
                    <td className="px-5 py-4">
                      <div className="font-extrabold">{r.beneficiaryName}</div>
                      <span className={`mt-0.5 inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-bold ${r.beneficiaryType === "FLEET" ? "bg-white/10 text-white/80" : "bg-signal/15 text-signal ring-1 ring-signal/30"}`}>
                        {r.beneficiaryType === "FLEET" ? <Building2 size={11} className="text-signal" /> : <Truck size={11} className="text-signal" />}{r.beneficiaryType === "FLEET" ? "Filo" : "Kurye"}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      {r.ibanMasked ? <div className="font-mono text-xs text-white/70">{r.ibanMasked}</div> : <div className="flex items-center gap-1 text-xs font-bold text-signal"><CircleAlert size={12} /> IBAN tanımlı değil</div>}
                      <div className="text-[11px] text-white/40">Dönem: {r.period}</div>
                    </td>
                    <td className="px-5 py-4 text-right font-mono text-white/80">{r.totalOrders}</td>
                    <td className="px-5 py-4 text-right font-mono text-white/60">{money(r.grossMinor)}</td>
                    <td className="px-5 py-4 text-right font-mono text-signal">−{money(r.platformFeeMinor)}</td>
                    <td className="px-5 py-4 text-right font-mono text-base font-black text-[#7fe3b7]">{money(r.netMinor)}</td>
                    <td className="px-5 py-4 text-center"><span className={`inline-flex items-center gap-1.5 rounded-xl px-2.5 py-1 text-xs font-bold ${ui.cls}`}><span className={`h-1.5 w-1.5 rounded-full ${ui.dot}`} />{ui.label}</span></td>
                    <td className="px-5 py-4">
                      <div className="flex justify-end gap-1.5">
                        {r.status === "PENDING" && <button type="button" disabled={pending || !canPay} title={canPay ? "Ödeme emri oluştur" : "IBAN tanımlı olmadan ödenemez"} onClick={() => setDialog({ kind: "single", record: r })} className="rounded-xl bg-white/5 px-3 py-1.5 text-xs font-bold text-[#7fe3b7] ring-1 ring-mint/30 transition hover:bg-mint hover:text-ink disabled:opacity-40">Öde</button>}
                        {r.status === "PENDING" && <button type="button" disabled={pending} onClick={() => setDialog({ kind: "hold", record: r })} aria-label="Bloke et" className="rounded-xl bg-white/5 p-1.5 ring-1 ring-white/10 hover:bg-white/10"><Lock size={14} className="text-signal" /></button>}
                        {r.status === "HOLD" && <button type="button" disabled={pending} onClick={() => setDialog({ kind: "release", record: r })} className="inline-flex items-center gap-1 rounded-xl bg-white/5 px-3 py-1.5 text-xs font-bold ring-1 ring-white/10 hover:bg-white/10"><LockOpen size={13} className="text-signal" /> Bloğu kaldır</button>}
                        {r.status === "PAID" && !r.id.startsWith("draft:") && <a href={`/api/admin/payouts/${r.id}/receipt`} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 rounded-xl bg-white/5 px-3 py-1.5 text-xs font-bold text-white/70 ring-1 ring-white/10 hover:text-white"><FileText size={13} className="text-signal" /> Dekont</a>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="border-t border-white/10 px-5 py-3 text-[11px] text-white/40">Banka/ödeme API&apos;si bağlı değildir. “Öde” ödeme emrini kayda alır, kalemleri PAID yapar ve dekont referansı üretir; para transferi muhasebe tarafından bu referansla yürütülür. Ham IBAN hiçbir ekranda gösterilmez.</div>
      </div>

      {dialog && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-ink/80 p-4 backdrop-blur-md" role="dialog" aria-modal="true" onClick={close}>
          <div className="w-full max-w-md rounded-3xl border border-white/15 bg-ink p-6 text-white shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-start justify-between border-b border-white/10 pb-4">
              <div>
                <h3 className="flex items-center gap-2 text-base font-black">
                  {dialog.kind === "hold" ? <Lock size={17} className="text-signal" /> : dialog.kind === "release" ? <LockOpen size={17} className="text-signal" /> : <Banknote size={17} className="text-signal" />}
                  {dialog.kind === "single" ? "Ödeme emri" : dialog.kind === "bulk" ? "Toplu ödeme emri" : dialog.kind === "hold" ? "Ödemeyi bloke et" : "Bloğu kaldır"}
                </h3>
                <p className="mt-1 text-xs text-white/50">
                  {dialog.kind === "bulk" ? `${dialog.records.length} kayıt · toplam net ${money(dialog.records.reduce((a, r) => a + r.netMinor, 0))}` : `${dialog.record.beneficiaryName} · ${dialog.record.period} · net ${money(dialog.record.netMinor)}`}
                </p>
              </div>
              <button type="button" onClick={close} aria-label="Kapat" className="rounded-lg p-1 text-white/50 hover:bg-white/10 hover:text-white"><X size={16} className="text-signal" /></button>
            </div>
            {dialog.kind !== "hold" && dialog.kind !== "release" && <p className="mt-3 rounded-xl bg-white/5 p-3 text-xs text-white/60">Kalemler PAID olur ve tekrar ödenemez. Para transferi yapılmaz; dekont referansıyla muhasebe yürütür. IBAN tanımlı olmayan kayıtlar atlanır.</p>}
            <label className="mt-4 block text-xs font-bold uppercase tracking-wider text-white/40" htmlFor="payout-note">{needsReason ? "Gerekçe (zorunlu, en az 10 karakter)" : "Not (isteğe bağlı)"}</label>
            <textarea id="payout-note" value={note} onChange={(e) => setNote(e.target.value)} maxLength={500} className="mt-1 min-h-20 w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-white outline-none focus:border-signal" placeholder={needsReason ? "Ör. Teslim kodu uyuşmazlığı inceleniyor." : "Ör. Kasım 2. hafta ödeme turu"} />
            {error && <p role="alert" className="mt-2 text-xs font-semibold text-rose">{error}</p>}
            <div className="mt-5 flex justify-end gap-2 border-t border-white/10 pt-4">
              <button type="button" onClick={close} className="rounded-xl px-4 py-2 text-xs font-bold text-white/60 hover:text-white">Vazgeç</button>
              <button type="button" disabled={pending || (needsReason && note.trim().length < 10)} onClick={run} className="inline-flex items-center gap-1.5 rounded-xl bg-signal px-5 py-2 text-xs font-black text-white shadow-lg disabled:opacity-50">
                {pending && <Loader2 size={13} className="animate-spin" />}{dialog.kind === "single" ? "Ödeme emrini ver" : dialog.kind === "bulk" ? "Toplu emri ver" : dialog.kind === "hold" ? "Bloke et" : "Bloğu kaldır"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
