"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  BadgeCheck, Building2, ChartNoAxesCombined, CircleHelp, Compass, FileClock, Image as ImageIcon, LayoutDashboard,
  Menu, MessageSquareWarning, Route, Settings, Star, Truck, Wallet, X, type LucideIcon,
} from "lucide-react";

interface AdminNavItem { href: string; label: string; icon: LucideIcon; superOnly?: boolean; badge?: number }
interface AdminNavGroup { title: string; items: AdminNavItem[] }

export function AdminSidebar({ role, name, badges }: { role: string; name: string; badges: { approvals: number; cases: number; tasks: number; media: number } }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const isSuper = role === "SUPER_ADMIN";
  const groups: AdminNavGroup[] = [
    { title: "Genel", items: [{ href: "/admin", label: "Dashboard", icon: LayoutDashboard, superOnly: true }] },
    {
      title: "Operasyon",
      items: [
        { href: "/admin/kuryeler", label: "Kuryeler", icon: Truck, superOnly: true, badge: badges.approvals },
        { href: "/admin/filolar", label: "Filolar", icon: Building2, superOnly: true },
        { href: "/admin/talepler", label: "Siparişler & Görevler", icon: Route, superOnly: true, badge: badges.tasks },
        { href: "/admin/uyusmazliklar", label: "Uyuşmazlıklar", icon: CircleHelp, superOnly: true, badge: badges.cases },
      ],
    },
    {
      title: "Moderasyon",
      items: [
        { href: "/admin/medya-moderasyon", label: "Medya moderasyonu", icon: ImageIcon, badge: badges.media },
        { href: "/admin/degerlendirmeler", label: "Değerlendirmeler", icon: Star },
        { href: "/admin/raporlanan-icerikler", label: "Raporlanan içerikler", icon: MessageSquareWarning },
        { href: "/admin/basvurular", label: "İş ortağı başvuruları", icon: BadgeCheck },
        { href: "/admin/audit", label: "Denetim izi", icon: FileClock },
      ],
    },
    {
      title: "Finans & sistem",
      items: [
        { href: "/admin/finans", label: "Finans & hakediş", icon: Wallet, superOnly: true },
        { href: "/admin/ayarlar", label: "Sistem ayarları", icon: Settings, superOnly: true },
      ],
    },
  ];

  const nav = (
    <nav className="flex-1 overflow-y-auto px-3 pb-6" aria-label="Yönetim menüsü">
      {groups.map((g) => {
        const items = g.items.filter((i) => isSuper || !i.superOnly);
        if (!items.length) return null;
        return (
          <div key={g.title} className="mb-5">
            <div className="mb-2 px-3 text-[10px] font-bold uppercase tracking-[.2em] text-white/30">{g.title}</div>
            <div className="space-y-1">
              {items.map((item) => {
                const active = item.href === "/admin" ? pathname === "/admin" : pathname.startsWith(item.href);
                const Icon = item.icon;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    aria-current={active ? "page" : undefined}
                    className={`group flex min-h-11 items-center gap-3 rounded-xl px-3 py-2 text-[13px] font-semibold transition-all ${active ? "bg-signal/15 text-white ring-1 ring-signal/45" : "text-white/60 hover:bg-white/[.07] hover:pl-4 hover:text-white"}`}
                  >
                    <Icon size={17} strokeWidth={active ? 2.4 : 1.9} className={`text-signal transition ${active ? "drop-shadow-[0_0_6px_rgba(255,91,35,.7)]" : "opacity-80 group-hover:opacity-100"}`} aria-hidden="true" />
                    <span className="min-w-0 flex-1 truncate">{item.label}</span>
                    {item.badge ? <span className="rounded-md bg-signal px-1.5 py-0.5 text-[10px] font-black text-white">{item.badge > 99 ? "99+" : item.badge}</span> : null}
                  </Link>
                );
              })}
            </div>
          </div>
        );
      })}
    </nav>
  );

  const body = (
    <div className="flex h-full flex-col bg-ink text-white">
      <div className="border-b border-white/10 px-6 py-6">
        <Link href="/admin" className="flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-signal"><Compass size={20} className="text-white" aria-hidden="true" /></span>
          <span className="leading-tight"><span className="block text-[15px] font-black">Yol<span className="text-signal">Arkadaşı</span></span><span className="block text-[10px] font-bold uppercase tracking-[.18em] text-white/40">Yönetim paneli</span></span>
        </Link>
        <div className="mt-6 rounded-2xl bg-white/[.05] px-3 py-3 ring-1 ring-white/10">
          <div className="flex items-center gap-2 text-sm font-bold"><ChartNoAxesCombined size={15} className="text-signal" aria-hidden="true" /> {name}</div>
          <div className="mt-0.5 text-[11px] text-white/45">{isSuper ? "Platform yöneticisi · tam yetki" : "Operasyon · moderasyon yetkisi"}</div>
        </div>
      </div>
      {nav}
      <div className="border-t border-white/10 px-6 py-4 text-[11px] text-white/40">
        <Link href="/" className="font-semibold text-white/60 hover:text-white">← Platforma dön</Link>
      </div>
    </div>
  );

  return (
    <>
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-[264px] border-r border-white/10 lg:block">{body}</aside>
      <button type="button" onClick={() => setOpen(true)} aria-label="Yönetim menüsünü aç" className="fixed left-4 top-3 z-50 flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/15 lg:hidden">
        <Menu size={19} className="text-signal" aria-hidden="true" />
      </button>
      {open && (
        <div className="fixed inset-0 z-[80] bg-ink/70 backdrop-blur-sm lg:hidden" onClick={() => setOpen(false)} role="presentation">
          <aside className="relative h-full w-[min(86vw,300px)] shadow-2xl" onClick={(e) => e.stopPropagation()}>
            {body}
            <button type="button" onClick={() => setOpen(false)} aria-label="Menüyü kapat" className="absolute right-3 top-4 flex h-9 w-9 items-center justify-center rounded-full bg-white/10"><X size={18} className="text-signal" aria-hidden="true" /></button>
          </aside>
        </div>
      )}
    </>
  );
}
