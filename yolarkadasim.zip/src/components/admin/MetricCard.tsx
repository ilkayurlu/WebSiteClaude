import type { LucideIcon } from "lucide-react";

export interface AdminMetricCardProps {
  title: string;
  value: string;
  detail: string;
  icon: LucideIcon;
  trend?: { label: string; tone: "up" | "down" | "flat" };
}

/** Yönetim KPI kartı — ikon her zaman marka turuncusu. */
export function MetricCard({ title, value, detail, icon: Icon, trend }: AdminMetricCardProps) {
  return (
    <div className="group rounded-[20px] border border-line bg-white p-5 shadow-[0_1px_0_rgba(14,19,36,.04)] transition hover:-translate-y-0.5 hover:border-signal/40 hover:shadow-[0_16px_36px_-22px_rgba(14,19,36,.4)]">
      <div className="flex items-start justify-between gap-3">
        <span className="text-xs font-bold text-ink/55">{title}</span>
        <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-signal/10 transition group-hover:bg-signal/15">
          <Icon size={19} strokeWidth={1.9} className="text-signal" aria-hidden="true" />
        </span>
      </div>
      <div className="mt-2 text-[30px] font-black leading-none tracking-tight">{value}</div>
      <div className="mt-2 text-[11px] leading-relaxed text-ink/50">{detail}</div>
      {trend && (
        <span className={`mt-2 inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ${trend.tone === "down" ? "bg-rose/10 text-rose" : "bg-signal/10 text-signal"}`}>{trend.label}</span>
      )}
    </div>
  );
}
