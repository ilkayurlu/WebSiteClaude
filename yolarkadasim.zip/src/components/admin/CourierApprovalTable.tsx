"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import { Ban, Car, Check, Eye, FileCheck2, FileWarning, Loader2, RotateCcw, ShieldCheck, X } from "lucide-react";
import { api } from "@/components/client";
import { Avatar } from "@/components/ui";
import type { CourierVerification, DocType } from "@/lib/admin-data";

const DOC_LABELS: Record<DocType, string> = { LICENSE: "Ehliyet", REGISTRATION: "Ruhsat", CRIMINAL_RECORD: "Adli sicil" };
const DOC_ORDER: DocType[] = ["LICENSE", "REGISTRATION", "CRIMINAL_RECORD"];
const VEHICLES: Record<string, string> = { BICYCLE: "Bisiklet", MOTORCYCLE: "Motosiklet", CAR: "Otomobil", VAN: "Panelvan", TRUCK: "Kamyonet", COLD_CHAIN_VAN: "Soğuk zincir", MINIBUS: "Minibüs" };

type Filter = "PENDING" | "VERIFIED" | "SUSPENDED" | "ALL";

function docTone(status: string | undefined) {
  if (status === "APPROVED") return "bg-mint/12 text-[#0c8a5a] ring-mint/25";
  if (status === "REJECTED") return "bg-rose/10 text-rose ring-rose/25";
  if (status === "SUBMITTED") return "bg-signal/10 text-signal ring-signal/25";
  return "bg-ink/5 text-ink/45 ring-ink/10";
}

export function CourierApprovalTable({ couriers }: { couriers: CourierVerification[] }) {
  const router = useRouter();
  const [filter, setFilter] = useState<Filter>("PENDING");
  const [preview, setPreview] = useState<{ id: string; title: string } | null>(null);
  const [vehicleFor, setVehicleFor] = useState<CourierVerification | null>(null);
  const [vehicle, setVehicle] = useState({ type: "MOTORCYCLE", label: "", reason: "" });
  const [msg, setMsg] = useState<{ kind: "ok" | "err"; text: string } | null>(null);
  const [pending, start] = useTransition();
  const [busyKey, setBusyKey] = useState<string | null>(null);

  const list = useMemo(() => couriers.filter((c) => {
    const hasSubmitted = DOC_ORDER.some((t) => c.documents[t]?.status === "SUBMITTED");
    if (filter === "PENDING") return c.status !== "SUSPENDED" && (hasSubmitted || !c.isVerified);
    if (filter === "VERIFIED") return c.isVerified;
    if (filter === "SUSPENDED") return c.status === "SUSPENDED";
    return true;
  }), [couriers, filter]);

  function run(key: string, fn: () => Promise<unknown>, ok: string) {
    setBusyKey(key);
    setMsg(null);
    start(async () => {
      try { await fn(); setMsg({ kind: "ok", text: ok }); router.refresh(); }
      catch (e) { setMsg({ kind: "err", text: e instanceof Error ? e.message : "İşlem başarısız." }); }
      finally { setBusyKey(null); }
    });
  }
  const ask = (label: string) => { const v = window.prompt(label); return v === null ? null : v; };

  const counts = {
    PENDING: couriers.filter((c) => c.status !== "SUSPENDED" && (DOC_ORDER.some((t) => c.documents[t]?.status === "SUBMITTED") || !c.isVerified)).length,
    VERIFIED: couriers.filter((c) => c.isVerified).length,
    SUSPENDED: couriers.filter((c) => c.status === "SUSPENDED").length,
    ALL: couriers.length,
  };

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center gap-2" role="tablist" aria-label="Kurye filtresi">
        {([["PENDING", "Onay bekleyen"], ["VERIFIED", "Doğrulanmış"], ["SUSPENDED", "Engellenen"], ["ALL", "Tümü"]] as [Filter, string][]).map(([k, l]) => (
          <button key={k} type="button" role="tab" aria-selected={filter === k} onClick={() => setFilter(k)} className={`rounded-full px-4 py-2 text-xs font-bold transition ${filter === k ? "bg-ink text-white" : "bg-white text-ink/60 ring-1 ring-line hover:ring-signal hover:text-signal"}`}>
            {l} <span className="ml-1 opacity-60">{counts[k]}</span>
          </button>
        ))}
      </div>
      {msg && <div role={msg.kind === "err" ? "alert" : "status"} className={`mb-4 rounded-xl px-4 py-3 text-sm font-semibold ${msg.kind === "err" ? "bg-rose/10 text-rose" : "bg-mint/10 text-[#0c8a5a]"}`}>{msg.text}</div>}

      <div className="overflow-hidden rounded-[20px] border border-line bg-white">
        <table className="hidden w-full text-sm lg:table">
          <thead className="border-b border-line bg-paper/70 text-left text-[11px] uppercase tracking-wider text-ink/50">
            <tr><th className="px-4 py-3">Kurye</th><th className="px-4 py-3">Araç</th>{DOC_ORDER.map((t) => <th key={t} className="px-3 py-3">{DOC_LABELS[t]}</th>)}<th className="px-4 py-3 text-right">İşlemler</th></tr>
          </thead>
          <tbody className="divide-y divide-line">
            {list.map((c) => (
              <tr key={c.providerId} className="align-top transition hover:bg-paper/50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <Avatar name={c.name} hue={c.hue} size={38} status={c.status} />
                    <div className="min-w-0">
                      <Link href={`/kuryeler/${c.slug}`} className="block truncate font-bold hover:text-signal">{c.name}</Link>
                      <div className="text-[11px] text-ink/50">{c.fleetName ? `🏢 ${c.fleetName}` : "Bağımsız"} · {c.isVerified ? <span className="font-bold text-signal">✓ doğrulanmış</span> : "doğrulanmamış"}{c.status === "SUSPENDED" && <span className="ml-1 font-bold text-rose">· engelli</span>}</div>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 text-xs"><b>{VEHICLES[c.vehicleType] ?? c.vehicleType}</b><div className="text-ink/50">{c.vehicleLabel ?? "—"}</div></td>
                {DOC_ORDER.map((t) => {
                  const d = c.documents[t];
                  return (
                    <td key={t} className="px-3 py-3">
                      {d ? (
                        <div className="space-y-1.5">
                          <span className={`inline-flex rounded-full px-2 py-0.5 text-[10px] font-bold ring-1 ${docTone(d.status)}`}>{d.status === "SUBMITTED" ? "İncelemede" : d.status === "APPROVED" ? "Onaylı" : "Reddedildi"}</span>
                          <div className="flex gap-1">
                            <button type="button" onClick={() => setPreview({ id: d.id, title: `${c.name} · ${DOC_LABELS[t]}` })} aria-label={`${DOC_LABELS[t]} önizle`} className="flex h-8 w-8 items-center justify-center rounded-lg border border-line hover:border-signal"><Eye size={14} className="text-signal" /></button>
                            {d.status !== "APPROVED" && <button type="button" disabled={pending} onClick={() => run(`${d.id}a`, () => api(`/api/admin/documents/${d.id}`, "POST", { action: "APPROVED" }), `${DOC_LABELS[t]} onaylandı.`)} aria-label="Evrakı onayla" className="flex h-8 w-8 items-center justify-center rounded-lg border border-line hover:border-signal">{busyKey === `${d.id}a` ? <Loader2 size={14} className="animate-spin text-signal" /> : <Check size={14} className="text-signal" />}</button>}
                            {d.status !== "REJECTED" && <button type="button" disabled={pending} onClick={() => { const note = ask(`${DOC_LABELS[t]} ret gerekçesi (en az 10 karakter):`); if (note !== null) run(`${d.id}r`, () => api(`/api/admin/documents/${d.id}`, "POST", { action: "REJECTED", note }), `${DOC_LABELS[t]} reddedildi.`); }} aria-label="Evrakı reddet" className="flex h-8 w-8 items-center justify-center rounded-lg border border-line hover:border-rose">{busyKey === `${d.id}r` ? <Loader2 size={14} className="animate-spin text-signal" /> : <X size={14} className="text-signal" />}</button>}
                          </div>
                          {d.note && d.status === "REJECTED" && <div className="max-w-[160px] text-[10px] text-rose">{d.note}</div>}
                        </div>
                      ) : (
                        <span className="inline-flex items-center gap-1 rounded-full bg-ink/5 px-2 py-0.5 text-[10px] font-bold text-ink/45"><FileWarning size={11} className="text-signal" /> Yüklenmedi</span>
                      )}
                    </td>
                  );
                })}
                <td className="px-4 py-3">
                  <div className="flex flex-wrap justify-end gap-1.5">
                    {!c.isVerified && <button type="button" disabled={pending} onClick={() => run(`${c.providerId}all`, () => api(`/api/admin/providers/${c.providerId}/verification`, "POST", { action: "APPROVE_ALL" }), `${c.name} doğrulandı.`)} className="btn-mint btn-sm">{busyKey === `${c.providerId}all` ? <Loader2 size={13} className="animate-spin" /> : <ShieldCheck size={13} />} Onayla</button>}
                    <button type="button" disabled={pending} onClick={() => { const note = ask("Tüm evrakların ret gerekçesi (en az 10 karakter):"); if (note !== null) run(`${c.providerId}rej`, () => api(`/api/admin/providers/${c.providerId}/verification`, "POST", { action: "REJECT_ALL", note }), `${c.name} evrakları reddedildi.`); }} className="btn-ghost btn-sm"><X size={13} className="text-signal" /> Reddet</button>
                    <button type="button" onClick={() => { setVehicleFor(c); setVehicle({ type: c.vehicleType, label: c.vehicleLabel ?? "", reason: "" }); }} className="btn-ghost btn-sm"><Car size={13} className="text-signal" /> Araç</button>
                    {c.status === "SUSPENDED" ? (
                      <button type="button" disabled={pending} onClick={() => { const reason = ask("Engeli kaldırma gerekçesi:"); if (reason !== null) run(`${c.providerId}un`, () => api(`/api/admin/providers/${c.providerId}`, "POST", { action: "reinstate", reason }), "Engel kaldırıldı."); }} className="btn-ghost btn-sm"><RotateCcw size={13} className="text-signal" /> Engeli kaldır</button>
                    ) : (
                      <button type="button" disabled={pending} onClick={() => { const reason = ask("Engelleme gerekçesi (zorunlu):"); if (reason !== null) run(`${c.providerId}sus`, () => api(`/api/admin/providers/${c.providerId}`, "POST", { action: "suspend", reason }), `${c.name} engellendi.`); }} className="btn-danger btn-sm"><Ban size={13} /> Engelle</button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="divide-y divide-line lg:hidden">
          {list.map((c) => (
            <div key={c.providerId} className="p-4">
              <div className="flex items-center gap-3"><Avatar name={c.name} hue={c.hue} size={40} status={c.status} /><div className="min-w-0 flex-1"><b className="block truncate">{c.name}</b><span className="text-xs text-ink/50">{VEHICLES[c.vehicleType]} · {c.isVerified ? "doğrulanmış" : "doğrulanmamış"}</span></div></div>
              <div className="mt-3 flex flex-wrap gap-1.5">{DOC_ORDER.map((t) => { const d = c.documents[t]; return <button key={t} type="button" disabled={!d} onClick={() => d && setPreview({ id: d.id, title: `${c.name} · ${DOC_LABELS[t]}` })} className={`rounded-full px-2.5 py-1 text-[10px] font-bold ring-1 ${docTone(d?.status)}`}>{DOC_LABELS[t]} · {d ? (d.status === "SUBMITTED" ? "incele" : d.status === "APPROVED" ? "onaylı" : "red") : "yok"}</button>; })}</div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                {!c.isVerified && <button type="button" disabled={pending} onClick={() => run(`${c.providerId}all`, () => api(`/api/admin/providers/${c.providerId}/verification`, "POST", { action: "APPROVE_ALL" }), `${c.name} doğrulandı.`)} className="btn-mint btn-sm"><ShieldCheck size={13} /> Onayla</button>}
                <button type="button" onClick={() => { setVehicleFor(c); setVehicle({ type: c.vehicleType, label: c.vehicleLabel ?? "", reason: "" }); }} className="btn-ghost btn-sm"><Car size={13} className="text-signal" /> Araç</button>
                {c.status !== "SUSPENDED" && <button type="button" disabled={pending} onClick={() => { const reason = ask("Engelleme gerekçesi (zorunlu):"); if (reason !== null) run(`${c.providerId}sus`, () => api(`/api/admin/providers/${c.providerId}`, "POST", { action: "suspend", reason }), `${c.name} engellendi.`); }} className="btn-danger btn-sm"><Ban size={13} /> Engelle</button>}
              </div>
            </div>
          ))}
        </div>
        {list.length === 0 && <div className="flex flex-col items-center px-6 py-12 text-center"><FileCheck2 size={26} className="text-signal" /><b className="mt-3 text-sm">Bu filtrede kurye yok</b><p className="mt-1 text-xs text-ink/55">Yeni evrak yüklendiğinde onay bekleyenler listesinde görünür.</p></div>}
      </div>

      {preview && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-ink/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label={preview.title} onClick={() => setPreview(null)}>
          <div className="w-full max-w-2xl overflow-hidden rounded-3xl bg-white" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-line px-5 py-3"><b className="text-sm">{preview.title}</b><button type="button" onClick={() => setPreview(null)} aria-label="Kapat" className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-paper"><X size={16} className="text-signal" /></button></div>
            <div className="bg-paper p-4">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={`/api/admin/documents/${preview.id}/preview`} alt={preview.title} className="mx-auto max-h-[60vh] rounded-xl object-contain" />
            </div>
            <p className="px-5 py-3 text-[11px] text-ink/50">Evrak özel depodadır; önbelleğe alınmaz ve yalnızca platform yöneticisi görüntüleyebilir. Belge numaralarını not alanına yazmayın.</p>
          </div>
        </div>
      )}

      {vehicleFor && (
        <div className="fixed inset-0 z-[90] flex items-center justify-center bg-ink/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" aria-label="Araç değişikliği" onClick={() => setVehicleFor(null)}>
          <div className="w-full max-w-md rounded-3xl bg-white p-5" onClick={(e) => e.stopPropagation()}>
            <h3 className="flex items-center gap-2 font-extrabold"><Car size={17} className="text-signal" /> {vehicleFor.name} · araç değişikliği</h3>
            <p className="mt-1 text-xs text-ink/55">Araç tipi değişirse ruhsat evrakı yeniden incelemeye düşer ve doğrulama rozeti kalkar.</p>
            <label className="label mt-4" htmlFor="v-type">Araç tipi</label>
            <select id="v-type" className="input" value={vehicle.type} onChange={(e) => setVehicle({ ...vehicle, type: e.target.value })}>{Object.entries(VEHICLES).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
            <label className="label mt-3" htmlFor="v-label">Araç etiketi</label>
            <input id="v-label" className="input" maxLength={60} value={vehicle.label} onChange={(e) => setVehicle({ ...vehicle, label: e.target.value })} placeholder="Ör. Honda PCX 125" />
            <label className="label mt-3" htmlFor="v-reason">Gerekçe</label>
            <textarea id="v-reason" className="input min-h-20" maxLength={500} value={vehicle.reason} onChange={(e) => setVehicle({ ...vehicle, reason: e.target.value })} placeholder="Ör. Kurye yeni aracının ruhsatını destek kanalından iletti." />
            <div className="mt-4 flex gap-2">
              <button type="button" disabled={pending || vehicle.reason.trim().length < 10} onClick={() => { const target = vehicleFor; run(`${target.providerId}veh`, async () => { await api(`/api/admin/providers/${target.providerId}/vehicle`, "POST", { vehicleType: vehicle.type, vehicleLabel: vehicle.label, reason: vehicle.reason }); setVehicleFor(null); }, "Araç bilgisi güncellendi."); }} className="btn-primary">{pending ? <Loader2 size={14} className="animate-spin" /> : null} Kaydet</button>
              <button type="button" onClick={() => setVehicleFor(null)} className="btn-ghost">Vazgeç</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
