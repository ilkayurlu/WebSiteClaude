"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { Loader2, Percent } from "lucide-react";
import { api } from "@/components/client";

export function CommissionForm({ currentBps }: { currentBps: number }) {
  const router = useRouter();
  const [percent, setPercent] = useState((currentBps / 100).toString());
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [pending, start] = useTransition();
  const bps = Math.round(Number(percent.replace(",", ".")) * 100);
  const valid = Number.isFinite(bps) && bps >= 0 && bps <= 4000;
  const sample = 30000;
  return (
    <div className="rounded-[22px] border border-line bg-white p-5">
      <h3 className="flex items-center gap-2 font-extrabold"><Percent size={16} className="text-signal" /> Platform komisyon oranı</h3>
      <p className="mt-1 text-xs text-ink/55">Yeni oran yalnızca bundan sonra tamamlanan görevlere uygulanır; geçmiş tahakkuklar değişmez.</p>
      <div className="mt-4 grid gap-3 sm:grid-cols-[140px_1fr]">
        <div><label className="label" htmlFor="commission">Oran (%)</label><input id="commission" inputMode="decimal" className="input" value={percent} onChange={(e) => setPercent(e.target.value)} /></div>
        <div><label className="label" htmlFor="commission-reason">Gerekçe</label><input id="commission-reason" className="input" maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Ör. Q3 fiyatlandırma kararı" /></div>
      </div>
      {valid && <p className="mt-2 text-[11px] text-ink/50">Örnek: 300,00 ₺ görevde komisyon {(Math.floor((sample * bps) / 10000) / 100).toFixed(2)} ₺ · kuryeye net {((sample - Math.floor((sample * bps) / 10000)) / 100).toFixed(2)} ₺</p>}
      {!valid && <p className="mt-2 text-[11px] font-semibold text-rose">Oran %0 ile %40 arasında olmalı.</p>}
      {msg && <p role={msg.ok ? "status" : "alert"} className={`mt-2 text-xs font-semibold ${msg.ok ? "text-[#0c8a5a]" : "text-rose"}`}>{msg.text}</p>}
      <button type="button" disabled={pending || !valid || reason.trim().length < 10 || bps === currentBps} onClick={() => start(async () => { setMsg(null); try { await api("/api/admin/settings", "PATCH", { commissionBps: bps, reason }); setMsg({ ok: true, text: "Komisyon güncellendi ve denetim izine yazıldı." }); setReason(""); router.refresh(); } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : "Kaydedilemedi." }); } })} className="btn-primary mt-4">{pending ? <Loader2 size={14} className="animate-spin" /> : null} Oranı kaydet</button>
    </div>
  );
}
