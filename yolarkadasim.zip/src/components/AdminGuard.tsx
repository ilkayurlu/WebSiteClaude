import { EmptyState } from "@/components/ui";

export function AdminOnly() {
  return (
    <div className="container-x py-20">
      <div className="mx-auto max-w-xl">
        <EmptyState
          icon="🛡️"
          title="Bu alan operasyon ekibine açıktır"
          description="Sayfayı görüntülemek için sağ üstteki hesap menüsünden “Operasyon Ekibi” hesabına geçin. Yetki kontrolü sunucuda yapılır; arayüzde gizlemek yeterli değildir."
          actions={[{ label: "Ana sayfaya dön", href: "/", primary: true }]}
        />
      </div>
    </div>
  );
}
