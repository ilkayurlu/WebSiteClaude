"use client";

import Image from "next/image";
import { useRouter } from "next/navigation";
import { useRef, useState, useTransition } from "react";
import { MEDIA_POLICY, MEDIA_STATUS, REPORT_REASONS, money } from "@/lib/labels";
import { api } from "./client";
import { Pill } from "./ui";

export type MediaItem = { id: string; caption: string | null; publicUrl: string | null; status: string; viewCount: number; favoriteCount: number; createdAt: string | Date; moderationReason?: string | null };

/* ---------- Yükleme + kendi içeriklerim ---------- */
export function MediaStudio({ items, limitMb = 8 }: { items: MediaItem[]; limitMb?: number }) {
  const router = useRouter();
  const ref = useRef<HTMLInputElement>(null);
  const [caption, setCaption] = useState("");
  const [rights, setRights] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, start] = useTransition();

  function upload(file: File) {
    setErr(null);
    setMsg(null);
    start(async () => {
      try {
        const fd = new FormData();
        fd.append("file", file);
        fd.append("caption", caption);
        if (rights) fd.append("rights", "1");
        const res = await fetch("/api/media", { method: "POST", body: fd });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error((data as { error?: string }).error ?? "Yükleme başarısız.");
        const d = data as { status: string; trusted: boolean };
        setMsg(d.trusted ? "Yayına alındı ✓ (güvenilir üretici — 24 saat içinde geriye dönük inceleme yapılır)" : "Yüklendi. Moderasyon incelemesinden sonra yayına alınacak.");
        setCaption("");
        setRights(false);
        if (ref.current) ref.current.value = "";
        router.refresh();
      } catch (e) {
        setErr((e as Error).message);
      }
    });
  }

  return (
    <div className="space-y-4">
      <div className="card p-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-extrabold">Yeni içerik yükle</h3>
          <span className="text-xs text-ink/50">JPEG · PNG · WebP · en fazla {limitMb} MB</span>
        </div>
        <label className="mt-3 flex cursor-pointer flex-col items-center justify-center gap-1 rounded-2xl border-2 border-dashed border-line bg-paper/60 px-4 py-7 text-center transition hover:border-signal hover:bg-signal/[0.03]" htmlFor="media-file">
          <span className="text-base font-bold">Fotoğraf seç veya buraya bırak</span>
          <span className="text-xs text-ink/50">EXIF/GPS bilgileri otomatik temizlenir · dosya önce özel alanda saklanır</span>
          <input id="media-file" ref={ref} type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); }} />
        </label>
        <label className="label mt-3" htmlFor="caption">Açıklama</label>
        <input id="caption" className="input" maxLength={500} value={caption} onChange={(e) => setCaption(e.target.value)} placeholder="Ör. Paketleme standardım: kırılacak ürünlerde çift kat koruma" />
        <label className="mt-3 flex items-start gap-2 text-xs text-ink/65">
          <input type="checkbox" className="mt-0.5 accent-[#ff5b23]" checked={rights} onChange={(e) => setRights(e.target.checked)} />
          Bu içeriğin kullanım haklarına sahibim ve müşteri verisi, teslimat belgesi veya kişisel bilgi içermediğini onaylıyorum.
        </label>
        <div className="mt-3 grid gap-1.5 sm:grid-cols-2">
          {MEDIA_POLICY.map((p) => (
            <div key={p.ref} className="rounded-xl bg-paper px-3 py-2 text-[11px]">
              <b className="text-signal">{p.ref} · {p.label}:</b> <span className="text-ink/65">{p.desc}</span>
            </div>
          ))}
        </div>
        {err && <div className="mt-3 rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
        {msg && <div className="mt-3 rounded-xl bg-mint/10 px-3 py-2 text-sm font-semibold text-[#0c8a5a]">{msg}</div>}
        {busy && <div className="mt-3 text-sm font-semibold text-ink/50">Yükleniyor…</div>}
      </div>

      <div>
        <h3 className="mb-3 font-extrabold">İçeriklerim ({items.length})</h3>
        {items.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-line p-6 text-center text-sm text-ink/50">Henüz içerik yüklemediniz. İlk gönderiniz moderasyondan sonra vitrininizde görünür.</div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((m) => (
              <div key={m.id} className="card overflow-hidden">
                <div className="relative aspect-[4/3] bg-paper">
                  {m.publicUrl ? <Image src={m.publicUrl} alt={m.caption ?? "İçerik"} fill className="object-cover" sizes="(max-width:640px) 100vw, 320px" /> : <div className="flex h-full items-center justify-center text-xs font-semibold text-ink/40">Önizleme yayın sonrası</div>}
                </div>
                <div className="p-3">
                  <div className="flex items-center justify-between gap-2">
                    <Pill tone={MEDIA_STATUS[m.status]?.tone ?? "slate"}>{MEDIA_STATUS[m.status]?.label ?? m.status}</Pill>
                    <span className="text-[11px] text-ink/45">👁 {m.viewCount}</span>
                  </div>
                  {m.caption && <p className="mt-1.5 line-clamp-2 text-xs text-ink/70">{m.caption}</p>}
                  {m.moderationReason && <p className="mt-1 text-[11px] text-rose">Gerekçe: {m.moderationReason}</p>}
                  <div className="mt-2 flex gap-1.5">
                    <ApiSmall url={`/api/media/${m.id}`} method="DELETE" confirm="Bu içeriği arşivlemek istiyor musunuz?">Arşivle</ApiSmall>
                    <ReportButton targetType="MEDIA" targetId={m.id} label="Bildir" small />
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function ApiSmall({ url, method = "POST", body, confirm, children }: { url: string; method?: string; body?: Record<string, unknown>; confirm?: string; children: React.ReactNode }) {
  const router = useRouter();
  const [busy, start] = useTransition();
  return (
    <button type="button" disabled={busy} className="btn-ghost btn-sm" onClick={() => { if (confirm && !window.confirm(confirm)) return; start(async () => { try { await api(url, method, body ?? {}); router.refresh(); } catch { router.refresh(); } }); }}>
      {children}
    </button>
  );
}

/* ---------- Herkese açık galeri ---------- */
export function MediaGrid({ items, canReport }: { items: { id: string; caption: string | null; publicUrl: string | null; viewCount: number; publishedAt: string | Date | null }[]; canReport: boolean }) {
  const [active, setActive] = useState<(typeof items)[number] | null>(null);
  if (!items.length) return <div className="rounded-2xl border border-dashed border-line p-8 text-center text-sm text-ink/50">Bu profilde henüz yayınlanmış medya yok.</div>;
  return (
    <>
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        {items.map((m) => (
          <button key={m.id} type="button" onClick={() => setActive(m)} className="group relative aspect-square overflow-hidden rounded-2xl bg-paper ring-1 ring-line transition hover:ring-signal">
            {m.publicUrl ? (
              <Image src={m.publicUrl} alt={m.caption ?? "Görsel"} fill className="object-cover transition duration-300 group-hover:scale-[1.03]" sizes="(max-width:640px) 50vw, 33vw" />
            ) : (
              <span className="flex h-full items-center justify-center text-xs text-ink/40">Medya</span>
            )}
            <span className="absolute bottom-1.5 left-2 rounded-full bg-ink/70 px-2 py-0.5 text-[10px] font-bold text-white">👁 {m.viewCount}</span>
          </button>
        ))}
      </div>
      {active && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink/70 p-4 backdrop-blur-sm" role="dialog" aria-modal="true" onClick={() => setActive(null)}>
          <div className="fade-up w-full max-w-2xl overflow-hidden rounded-3xl bg-white" onClick={(e) => e.stopPropagation()}>
            <div className="relative aspect-[4/3] bg-paper">
              {active.publicUrl && <Image src={active.publicUrl} alt={active.caption ?? "Görsel"} fill className="object-contain" sizes="(max-width:768px) 100vw, 768px" />}
            </div>
            <div className="flex items-start justify-between gap-3 p-4">
              <div>
                {active.caption && <p className="text-sm text-ink/80">{active.caption}</p>}
                <p className="mt-1 text-[11px] text-ink/45">👁 {active.viewCount} görüntülenme · moderasyondan geçmiş içerik</p>
              </div>
              <div className="flex shrink-0 gap-1.5">
                {canReport && <ReportButton targetType="MEDIA" targetId={active.id} label="Bildir" small />}
                <button type="button" className="btn-ghost btn-sm" onClick={() => setActive(null)}>Kapat</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------- İçerik bildirimi ---------- */
export function ReportButton({ targetType, targetId, label = "Profili bildir", small }: { targetType: "PROVIDER" | "FLEET" | "RESTAURANT" | "MEDIA" | "REVIEW"; targetId: string; label?: string; small?: boolean }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState<string>("PII");
  const [detail, setDetail] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, start] = useTransition();
  const url = targetType === "REVIEW" ? `/api/reviews/${targetId}/report` : targetType === "MEDIA" ? `/api/media/${targetId}/report` : "/api/reports";
  return (
    <>
      <button type="button" onClick={() => setOpen(true)} className={small ? "btn-ghost btn-sm" : "btn-ghost"}>⚑ {label}</button>
      {open && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 p-0 backdrop-blur-sm sm:items-center sm:p-6" role="dialog" aria-modal="true" onClick={() => setOpen(false)}>
          <div className="fade-up w-full max-w-md rounded-t-3xl bg-white p-5 sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            {done ? (
              <div className="py-4 text-center">
                <div className="text-2xl">✓</div>
                <h3 className="mt-2 font-extrabold">Bildirim alındı</h3>
                <p className="mt-1 text-sm text-ink/60">Moderasyon ekibi inceleyecek ve gerekçeli karar verecek. Bildirimleriniz gizlidir.</p>
                <button type="button" className="btn-primary mt-4" onClick={() => { setOpen(false); setDone(false); }}>Kapat</button>
              </div>
            ) : (
              <>
                <h3 className="font-extrabold">İçeriği bildir</h3>
                <p className="mt-1 text-xs text-ink/55">Hangi kuralın ihlal edildiğini seçin. Kişisel veri, güvenlik ihlali ve yanıltıcı iddialar öncelikli incelenir.</p>
                <div className="mt-3 grid gap-1.5 sm:grid-cols-2">
                  {Object.entries(REPORT_REASONS).map(([k, v]) => (
                    <label key={k} className={`flex cursor-pointer items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold transition ${reason === k ? "border-signal bg-signal/[0.05]" : "border-line hover:border-ink/25"}`}>
                      <input type="radio" className="accent-[#ff5b23]" checked={reason === k} onChange={() => setReason(k)} />
                      {v}
                    </label>
                  ))}
                </div>
                <label className="label mt-3" htmlFor="rdet">Açıklama (opsiyonel)</label>
                <textarea id="rdet" className="input min-h-20" maxLength={500} value={detail} onChange={(e) => setDetail(e.target.value)} placeholder="Kısa açıklama — hakaret veya kişisel bilgi içermemeli" />
                {err && <div className="mt-2 rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
                <div className="mt-4 flex gap-2">
                  <button type="button" disabled={busy} className="btn-primary" onClick={() => start(async () => { try { setErr(null); await api(url, "POST", { targetType, targetId, reason, detail: detail || undefined }); setDone(true); router.refresh(); } catch (e) { setErr((e as Error).message); } })}>{busy ? "Gönderiliyor…" : "Bildirimi gönder"}</button>
                  <button type="button" className="btn-ghost" onClick={() => setOpen(false)}>Vazgeç</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </>
  );
}

/* ---------- Yorum etkileşimleri ---------- */
export function ReviewActions({ reviewId, canRespond, canAppeal, isAuthor }: { reviewId: string; canRespond: boolean; canAppeal: boolean; isAuthor: boolean }) {
  const router = useRouter();
  const [mode, setMode] = useState<null | "respond" | "appeal" | "report" | "edit">(null);
  const [text, setText] = useState("");
  const [rating, setRating] = useState(0);
  const [reason, setReason] = useState("PII");
  const [err, setErr] = useState<string | null>(null);
  const [busy, start] = useTransition();

  const titles = { respond: "Yanıt yaz", appeal: "İtiraz et", report: "Yorumu bildir", edit: "Değerlendirmeni düzenle" };
  const send = () =>
    start(async () => {
      try {
        setErr(null);
        if (mode === "respond") await api(`/api/reviews/${reviewId}/respond`, "POST", { body: text });
        else if (mode === "appeal") await api(`/api/reviews/${reviewId}/appeal`, "POST", { reason: text });
        else if (mode === "report") await api(`/api/reviews/${reviewId}/report`, "POST", { reason, detail: text || undefined });
        else if (mode === "edit") await api(`/api/reviews/${reviewId}`, "PATCH", { rating: rating || undefined, body: text });
        setMode(null);
        setText("");
        router.refresh();
      } catch (e) {
        setErr((e as Error).message);
      }
    });

  return (
    <>
      <div className="mt-2 flex flex-wrap gap-1.5">
        {canRespond && <button type="button" className="btn-ghost btn-sm" onClick={() => { setMode("respond"); setErr(null); }}>↩ Yanıt ver</button>}
        {canAppeal && <button type="button" className="btn-ghost btn-sm" onClick={() => { setMode("appeal"); setErr(null); }}>⚖ İtiraz et</button>}
        {isAuthor && <button type="button" className="btn-ghost btn-sm" onClick={() => { setMode("edit"); setErr(null); }}>✎ Düzenle</button>}
        {!isAuthor && <button type="button" className="btn-ghost btn-sm" onClick={() => { setMode("report"); setErr(null); }}>⚑ Bildir</button>}
      </div>
      {mode && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-ink/50 backdrop-blur-sm sm:items-center sm:p-6" role="dialog" aria-modal="true" onClick={() => setMode(null)}>
          <div className="fade-up w-full max-w-md rounded-t-3xl bg-white p-5 sm:rounded-3xl" onClick={(e) => e.stopPropagation()}>
            <h3 className="font-extrabold">{titles[mode]}</h3>
            {mode === "report" && (
              <div className="mt-3 grid gap-1.5 sm:grid-cols-2">
                {Object.entries(REPORT_REASONS).map(([k, v]) => (
                  <label key={k} className={`flex cursor-pointer items-center gap-2 rounded-xl border px-3 py-2 text-xs font-bold ${reason === k ? "border-signal bg-signal/[0.05]" : "border-line"}`}>
                    <input type="radio" className="accent-[#ff5b23]" checked={reason === k} onChange={() => setReason(k)} />{v}
                  </label>
                ))}
              </div>
            )}
            {mode === "edit" && (
              <div className="mt-3 flex gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button key={n} type="button" onClick={() => setRating(n)} className={`text-2xl ${n <= rating ? "text-sun" : "text-ink/15"}`}>★</button>
                ))}
              </div>
            )}
            <textarea className="input mt-3 min-h-24" maxLength={mode === "respond" ? 1500 : 1000} value={text} onChange={(e) => setText(e.target.value)} placeholder={mode === "respond" ? "Profesyonel bir yanıt yazın (en az 10 karakter)" : mode === "appeal" ? "İtiraz gerekçeniz (en az 20 karakter)" : mode === "report" ? "Kısa açıklama (opsiyonel)" : "Yorumunuzu güncelleyin (opsiyonel)"} />
            {mode === "edit" && <p className="mt-1 text-[11px] text-ink/45">Düzenleme yalnızca ilk 48 saat içinde yapılabilir; eski sürüm kayıt altında tutulur.</p>}
            {err && <div className="mt-2 rounded-xl bg-rose/10 px-3 py-2 text-sm font-semibold text-rose">{err}</div>}
            <div className="mt-4 flex gap-2">
              <button type="button" disabled={busy} className="btn-primary" onClick={send}>{busy ? "Gönderiliyor…" : "Gönder"}</button>
              <button type="button" className="btn-ghost" onClick={() => setMode(null)}>Vazgeç</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

/* ---------- Erişilebilir sekmeler ---------- */
export function Tabs({ tabs, active, onChange }: { tabs: { key: string; label: string; count?: number }[]; active: string; onChange: (k: string) => void }) {
  return (
    <div role="tablist" aria-label="Profil sekmeleri" className="scrollbar-none flex gap-1 overflow-x-auto border-b border-line">
      {tabs.map((t) => (
        <button
          key={t.key}
          role="tab"
          aria-selected={active === t.key}
          type="button"
          onClick={() => onChange(t.key)}
          className={`relative shrink-0 px-4 py-3 text-sm font-bold transition ${active === t.key ? "text-ink" : "text-ink/45 hover:text-ink/75"}`}
        >
          {t.label}
          {t.count != null && <span className="ml-1.5 rounded-full bg-paper-2 px-1.5 py-0.5 text-[10px] font-bold text-ink/60">{t.count}</span>}
          {active === t.key && <span className="absolute inset-x-2 bottom-0 h-0.5 rounded-t bg-signal" />}
        </button>
      ))}
    </div>
  );
}

/* ---------- İşletme fiyat özeti (sürpriz ücret yok) ---------- */
export function PriceNote({ fee, smallFee, threshold, min }: { fee: number; smallFee: number; threshold: number; min: number }) {
  return (
    <div className="rounded-xl bg-paper px-3 py-2 text-[11px] text-ink/60">
      Teslimat {money(fee)} · {money(threshold)} altı sepetlerde +{money(smallFee)} · minimum sepet {money(min)}. Ödemede sürpriz ücret eklenmez.
    </div>
  );
}
