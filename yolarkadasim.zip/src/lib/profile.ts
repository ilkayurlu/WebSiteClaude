import { eq } from "drizzle-orm";
import { db } from "@/db";
import { fleets, providers } from "@/db/schema";
import { audit } from "./engine";
import { HttpError } from "./http";
import type { Session } from "./session";

export type ProviderPatch = {
  displayName?: string;
  headline?: string;
  bio?: string;
  vehicleLabel?: string;
  serviceTypes?: string[];
  serviceAreas?: string[];
  highlights?: string[];
  acceptsInstant?: boolean;
  acceptsScheduled?: boolean;
  acceptsRental?: boolean;
  rentalHourlyMinor?: number | null;
  baseFareMinor?: number;
  perKmMinor?: number;
  hue?: number;
};

/** Kendi profili dışında hiçbir profil güncellenemez; roller/tenant kapsamı değiştirilemez. */
export async function updateProviderProfile(s: Session, patch: ProviderPatch) {
  if (!s.providerId) throw new HttpError(403, "Bu işlem hizmet sağlayıcı hesabına özeldir.");
  const [p] = await db.select().from(providers).where(eq(providers.id, s.providerId)).limit(1);
  if (!p) throw new HttpError(404, "Profil bulunamadı.");
  if (p.status === "SUSPENDED") throw new HttpError(403, "Profiliniz askıda. Destek ekibiyle iletişime geçin.");
  const before = { headline: p.headline, bio: p.bio, acceptsRental: p.acceptsRental, rentalHourlyMinor: p.rentalHourlyMinor };
  const clean: ProviderPatch = { ...patch };
  if (clean.rentalHourlyMinor != null && clean.rentalHourlyMinor < 0) throw new HttpError(422, "Saatlik ücret negatif olamaz.");
  if (clean.acceptsRental && !clean.rentalHourlyMinor && !p.rentalHourlyMinor) throw new HttpError(422, "Kiralama için saatlik ücret girin.");
  if (clean.baseFareMinor != null && clean.baseFareMinor < 0) throw new HttpError(422, "Açılış ücreti negatif olamaz.");
  const [updated] = await db.update(providers).set(clean).where(eq(providers.id, p.id)).returning();
  await audit(db, s.user.id, "profile.update_self", "provider", p.id, undefined, { before, after: { headline: updated.headline, acceptsRental: updated.acceptsRental } });
  return { ok: true };
}

export async function updateFleetProfile(s: Session, patch: { name?: string; description?: string; phonePublic?: string; website?: string; servicePackages?: string[]; serviceAreas?: string[]; capacityLabel?: string }) {
  if (!s.fleetId) throw new HttpError(403, "Bu işlem filo hesabına özeldir.");
  const [f] = await db.select().from(fleets).where(eq(fleets.id, s.fleetId)).limit(1);
  if (!f) throw new HttpError(404, "Filo bulunamadı.");
  if (patch.website && !/^https?:\/\/[^\s]+\.[^\s]{2,}$/.test(patch.website)) throw new HttpError(422, "Geçerli bir web adresi girin (https://…).");
  await db.update(fleets).set(patch).where(eq(fleets.id, f.id));
  await audit(db, s.user.id, "fleet_profile.update_own", "fleet", f.id);
  return { ok: true };
}
