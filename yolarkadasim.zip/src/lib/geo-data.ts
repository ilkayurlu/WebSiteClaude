import citiesJson from "@/data/geo-cities.json";
import districtsJson from "@/data/geo-districts.json";
import neighborhoodsJson from "@/data/geo-neighborhoods.json";
import { slugify } from "./geo-math";

/**
 * Türkiye geneli adres veri katmanı (81 il · 973 ilçe · 26.378 mahalle).
 * Kaynak: TurkiyeAPI (idari birimler) + açık ilçe koordinat veri seti.
 * Mahalle verisi YALNIZCA sunucuda tutulur; istemciye ilçe bazında servis edilir.
 */

export interface CityOption { code: string; name: string; slug: string; lat: number; lng: number; region: string | null; districtCount: number }
export interface DistrictOption { id: string; cityCode: string; cityName: string; name: string; slug: string; lat: number; lng: number; approx: boolean; neighborhoodCount: number }
export interface NeighborhoodOption { id: string; name: string; districtId: string }
export interface StreetOption { id: string; name: string; kind: "CADDE" | "SOKAK" }

interface RawCity { code: string; id: number; name: string; slug: string; lat: number; lng: number; region: { tr: string; en: string } | string | null }
interface RawDistrict { id: string; cityCode: string; cityName: string; name: string; slug: string; lat: number; lng: number; approx: boolean }

const rawCities = citiesJson as RawCity[];
const rawDistricts = districtsJson as RawDistrict[];
const neighborhoodNames = neighborhoodsJson as Record<string, string[]>;

const districtsByCity = new Map<string, DistrictOption[]>();
const districtById = new Map<string, DistrictOption>();
const districtBySlug = new Map<string, DistrictOption>();

for (const d of rawDistricts) {
  const option: DistrictOption = { ...d, neighborhoodCount: neighborhoodNames[d.id]?.length ?? 0 };
  districtById.set(option.id, option);
  districtBySlug.set(option.slug, option);
  const list = districtsByCity.get(option.cityCode);
  if (list) list.push(option);
  else districtsByCity.set(option.cityCode, [option]);
}

export const CITIES: CityOption[] = rawCities.map((c) => ({
  code: c.code, name: c.name, slug: c.slug, lat: c.lat, lng: c.lng, region: typeof c.region === "string" ? c.region : c.region?.tr ?? null,
  districtCount: districtsByCity.get(c.code)?.length ?? 0,
}));

const cityByCode = new Map(CITIES.map((c) => [c.code, c]));
const cityBySlug = new Map(CITIES.map((c) => [c.slug, c]));

/** Eski sürümde kullanılan sabit İstanbul anahtarları → kanonik il-ilçe slug'ı. */
const LEGACY_AREA_ALIASES: Record<string, string> = {
  kadikoy: "istanbul-kadikoy", uskudar: "istanbul-uskudar", atasehir: "istanbul-atasehir",
  maltepe: "istanbul-maltepe", kartal: "istanbul-kartal", pendik: "istanbul-pendik",
  besiktas: "istanbul-besiktas", sisli: "istanbul-sisli", beyoglu: "istanbul-beyoglu",
  fatih: "istanbul-fatih", sariyer: "istanbul-sariyer", bakirkoy: "istanbul-bakirkoy",
  basaksehir: "istanbul-basaksehir", esenyurt: "istanbul-esenyurt",
  saw: "istanbul-pendik", ist: "istanbul-arnavutkoy",
};

export const LEGACY_AREA_KEYS = Object.keys(LEGACY_AREA_ALIASES);

/** Herhangi bir bölge anahtarını (eski ya da yeni) kanonik slug'a çevirir. */
export function normalizeAreaSlug(key: string | null | undefined): string | null {
  if (!key) return null;
  const value = key.trim();
  if (districtBySlug.has(value)) return value;
  const alias = LEGACY_AREA_ALIASES[value];
  if (alias && districtBySlug.has(alias)) return alias;
  const slugged = slugify(value);
  if (districtBySlug.has(slugged)) return slugged;
  return null;
}

export function isValidAreaSlug(key: string | null | undefined): boolean {
  return normalizeAreaSlug(key) !== null;
}

export function getCities(): CityOption[] {
  return CITIES;
}

export function getCity(cityCode: string): CityOption | undefined {
  return cityByCode.get(cityCode) ?? cityBySlug.get(cityCode);
}

export function getDistricts(cityCode: string): DistrictOption[] {
  const city = getCity(cityCode);
  if (!city) return [];
  return districtsByCity.get(city.code) ?? [];
}

export function getDistrict(districtId: string): DistrictOption | undefined {
  return districtById.get(districtId) ?? districtBySlug.get(districtId);
}

export function getNeighborhoods(districtId: string, query?: string): NeighborhoodOption[] {
  const district = getDistrict(districtId);
  if (!district) return [];
  const names = neighborhoodNames[district.id] ?? [];
  const q = query?.trim().toLocaleLowerCase("tr");
  const filtered = q ? names.filter((n) => n.toLocaleLowerCase("tr").includes(q)) : names;
  return filtered.map((name) => ({ id: `${district.id}:${slugify(name)}`, name, districtId: district.id }));
}

export function getNeighborhood(districtId: string, neighborhoodId: string): NeighborhoodOption | undefined {
  return getNeighborhoods(districtId).find((n) => n.id === neighborhoodId);
}

/**
 * Cadde/sokak arama. Resmî cadde veri seti bağlı değildir; mahalle adından türetilen
 * yaygın adlandırmalar öneri olarak sunulur, kullanıcı serbest metin girebilir.
 */
export function searchStreets(neighborhoodId: string, query: string): StreetOption[] {
  const [districtId] = neighborhoodId.split(":");
  const neighborhood = getNeighborhoods(districtId).find((n) => n.id === neighborhoodId);
  if (!neighborhood) return [];
  const q = query.trim().toLocaleLowerCase("tr");
  const base = [`${neighborhood.name} Caddesi`, `${neighborhood.name} Sokak`, `${neighborhood.name} Çıkmazı`];
  const suggestions: StreetOption[] = base.map((name, i) => ({
    id: `${neighborhoodId}:s${i}`,
    name,
    kind: i === 0 ? "CADDE" : "SOKAK",
  }));
  return q ? suggestions.filter((s) => s.name.toLocaleLowerCase("tr").includes(q)) : suggestions;
}

export interface ResolvedArea {
  key: string;
  slug: string;
  name: string;
  cityName: string;
  cityCode: string;
  districtId: string;
  lat: number;
  lng: number;
  approx: boolean;
}

export function resolveArea(key: string | null | undefined): ResolvedArea | undefined {
  const slug = normalizeAreaSlug(key);
  if (!slug) return undefined;
  const d = districtBySlug.get(slug);
  if (!d) return undefined;
  return { key: slug, slug, name: d.name, cityName: d.cityName, cityCode: d.cityCode, districtId: d.id, lat: d.lat, lng: d.lng, approx: d.approx };
}

/** "Kadıköy" (şehir içi bağlamda) veya "Edirne / Keşan" (iller arası) etiketi. */
export function areaLabel(key: string | null | undefined, opts?: { withCity?: boolean }): string {
  const area = resolveArea(key);
  if (!area) return "—";
  return opts?.withCity ? `${area.cityName} / ${area.name}` : area.name;
}

export function areaLabelWithCity(key: string | null | undefined): string {
  return areaLabel(key, { withCity: true });
}

/** Aynı şehirdeki iki nokta için şehir adı tekrarı olmadan okunur rota. */
export function routeLabel(pickup: string | null | undefined, dropoff: string | null | undefined): string {
  const a = resolveArea(pickup);
  const b = resolveArea(dropoff);
  if (!a && !b) return "—";
  if (!b) return a ? `${a.cityName} / ${a.name}` : "—";
  if (!a) return `${b.cityName} / ${b.name}`;
  return a.cityCode === b.cityCode ? `${a.cityName}: ${a.name} → ${b.name}` : `${a.cityName} / ${a.name} → ${b.cityName} / ${b.name}`;
}

export function districtsForSlugs(slugs: string[]): DistrictOption[] {
  const out: DistrictOption[] = [];
  for (const s of slugs) {
    const canonical = normalizeAreaSlug(s);
    const d = canonical ? districtBySlug.get(canonical) : undefined;
    if (d && !out.some((x) => x.id === d.id)) out.push(d);
  }
  return out;
}
