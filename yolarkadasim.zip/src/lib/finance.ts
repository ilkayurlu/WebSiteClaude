import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { assignments, platformSettings, providerEarnings, serviceRequests } from "@/db/schema";
import { HttpError } from "./http";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type Exec = Tx | typeof db;

export const COMMISSION_KEY = "commission_bps";
export const DEFAULT_COMMISSION_BPS = 1500; // %15
export const MAX_COMMISSION_BPS = 4000; // %40 üst sınır

export async function getCommissionBps(exec: Exec = db): Promise<number> {
  const [row] = await exec.select().from(platformSettings).where(eq(platformSettings.key, COMMISSION_KEY)).limit(1);
  const parsed = row ? Number.parseInt(row.value, 10) : NaN;
  return Number.isFinite(parsed) && parsed >= 0 && parsed <= MAX_COMMISSION_BPS ? parsed : DEFAULT_COMMISSION_BPS;
}

export async function setCommissionBps(exec: Exec, bps: number, actorId: string) {
  if (!Number.isInteger(bps) || bps < 0 || bps > MAX_COMMISSION_BPS) throw new HttpError(422, "Komisyon %0 ile %40 arasında olmalı.");
  await exec
    .insert(platformSettings)
    .values({ key: COMMISSION_KEY, value: String(bps), updatedBy: actorId })
    .onConflictDoUpdate({ target: platformSettings.key, set: { value: String(bps), updatedBy: actorId, updatedAt: new Date() } });
}

/** Komisyon tamsayı kuruş üzerinden, aşağı yuvarlanarak hesaplanır; net = brüt − komisyon. */
export function splitEarning(grossMinor: number, bps: number) {
  const commissionMinor = Math.floor((grossMinor * bps) / 10_000);
  return { commissionMinor, netMinor: grossMinor - commissionMinor };
}

/** Teslim doğrulandığında aynı transaction içinde tahakkuk eder. requestId UNIQUE → çift tahakkuk imkânsız. */
export async function accrueEarning(tx: Tx, input: { requestId: string; providerId: string; fleetId: string | null; grossMinor: number; earnedAt?: Date }) {
  const bps = await getCommissionBps(tx);
  const { commissionMinor, netMinor } = splitEarning(input.grossMinor, bps);
  await tx
    .insert(providerEarnings)
    .values({
      requestId: input.requestId,
      providerId: input.providerId,
      fleetId: input.fleetId,
      grossMinor: input.grossMinor,
      commissionBps: bps,
      commissionMinor,
      netMinor,
      earnedAt: input.earnedAt ?? new Date(),
    })
    .onConflictDoNothing({ target: providerEarnings.requestId });
}

/** Defter öncesi tamamlanmış görevler için idempotent geri doldurma (yalnızca eksik kayıtlar). */
export async function ensureLedgerBackfill() {
  const missing = await db
    .select({ a: assignments, price: serviceRequests.finalPriceMinor })
    .from(assignments)
    .innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId))
    .where(and(eq(assignments.state, "COMPLETED"), sql`not exists (select 1 from ${providerEarnings} pe where pe.request_id = ${assignments.requestId})`))
    .limit(500);
  if (!missing.length) return 0;
  await db.transaction(async (tx) => {
    for (const row of missing) {
      if (row.price == null) continue;
      await accrueEarning(tx, { requestId: row.a.requestId, providerId: row.a.providerId, fleetId: row.a.fleetId, grossMinor: row.price, earnedAt: row.a.completedAt ?? undefined });
    }
  });
  return missing.length;
}

/** ISO haftası başlangıcı (Pazartesi 00:00, İstanbul). */
export function weekStartIstanbul(d: Date) {
  const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
  const local = new Date(`${day}T00:00:00+03:00`);
  const wd = new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: "Europe/Istanbul" }).format(d);
  const offset = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(wd);
  return new Date(local.getTime() - Math.max(offset, 0) * 86_400_000);
}
