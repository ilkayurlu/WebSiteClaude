import { timingSafeEqual } from "node:crypto";
import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { assignments, notifications, orders, providers, serviceRequests, supportCases, users } from "@/db/schema";
import { assignmentAction, audit } from "./engine";
import { HttpError } from "./http";
import type { Session } from "./session";

export const MAX_OTP_ATTEMPTS = 3;

export type VerifyResult =
  | { ok: true; status: "COMPLETED" }
  | { ok: false; error: string; attemptsLeft: number; locked: boolean };

function codesMatch(expected: string, input: string) {
  const a = Buffer.from(expected.padEnd(8, " "));
  const b = Buffer.from(input.trim().padEnd(8, " ").slice(0, 8));
  return a.length === b.length && timingSafeEqual(a, b) && input.trim().length === expected.length;
}

/** orderId: görev (service_request) id'si veya yemek siparişi id'si olabilir; sipariş ise bağlı kurye görevine çözümlenir. */
export async function resolveRequestId(orderId: string): Promise<string> {
  const [req] = await db.select({ id: serviceRequests.id }).from(serviceRequests).where(eq(serviceRequests.id, orderId)).limit(1);
  if (req) return req.id;
  const [order] = await db.select({ id: orders.id }).from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) throw new HttpError(404, "Teslimat bulunamadı.");
  const [linked] = await db.select({ id: serviceRequests.id }).from(serviceRequests).where(eq(serviceRequests.linkedOrderId, order.id)).limit(1);
  if (!linked) throw new HttpError(422, "Bu sipariş için henüz kurye görevi oluşmadı.");
  return linked.id;
}

/**
 * 4 haneli teslim kodu doğrulama. Kural:
 * - Yalnızca görevi üstlenmiş, görevi başlatmış (IN_PROGRESS) kurye deneyebilir.
 * - Hatalı deneme kalıcı olarak sayılır (ayrı transaction); 3. hatada kilitlenir, otomatik OTP uyuşmazlık kaydı açılır.
 * - Doğru kodda görev tamamlanır; tahakkuk ve sohbet arşivi engine içinde aynı transaction'da yapılır.
 */
export async function verifyDeliveryCode(s: Session, orderId: string, inputCode: string): Promise<VerifyResult> {
  if (!s.providerId) throw new HttpError(403, "Yalnızca görevi üstlenen kurye teslim kodu girebilir.");
  if (!/^\d{4}$/.test(inputCode.trim())) throw new HttpError(422, "Teslim kodu 4 haneli rakamlardan oluşur.");
  const requestId = await resolveRequestId(orderId);

  const check = await db.transaction(async (tx) => {
    const [req] = await tx.select().from(serviceRequests).where(eq(serviceRequests.id, requestId)).for("update").limit(1);
    if (!req) throw new HttpError(404, "Teslimat bulunamadı.");
    const [asg] = await tx.select().from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
    if (!asg || asg.providerId !== s.providerId) throw new HttpError(404, "Teslimat bulunamadı.");
    if (asg.state === "COMPLETED") throw new HttpError(409, "Bu teslimat zaten tamamlandı.");
    if (asg.state !== "IN_PROGRESS") throw new HttpError(409, "Kodu girmeden önce görevi başlatın.");
    if (req.otpLockedAt) {
      return { kind: "locked" as const, attemptsLeft: 0 };
    }
    if (codesMatch(req.deliveryOtp, inputCode)) return { kind: "match" as const, assignmentId: asg.id };

    const attempts = req.otpAttempts + 1;
    const lockNow = attempts >= MAX_OTP_ATTEMPTS;
    await tx
      .update(serviceRequests)
      .set({ otpAttempts: attempts, ...(lockNow ? { otpLockedAt: new Date() } : {}), updatedAt: new Date() })
      .where(eq(serviceRequests.id, req.id));
    await audit(tx, s.user.id, lockNow ? "delivery.otp_locked" : "delivery.otp_failed", "service_request", req.id, lockNow ? "3 hatalı teslim kodu denemesi" : `Hatalı deneme ${attempts}/${MAX_OTP_ATTEMPTS}`);
    if (lockNow) {
      const sourceType = req.linkedOrderId ? "ORDER" : "REQUEST";
      const sourceId = req.linkedOrderId ?? req.id;
      const [existing] = await tx.select({ id: supportCases.id }).from(supportCases).where(and(eq(supportCases.sourceId, sourceId), eq(supportCases.category, "OTP"), eq(supportCases.status, "OPEN"))).limit(1);
      if (!existing) {
        await tx.insert(supportCases).values({ customerId: req.customerId, sourceType, sourceId, category: "OTP", detail: `${req.code}: Kurye 3 kez hatalı teslim kodu girdi. Teslimat otomatik olarak kilitlendi ve operasyon incelemesine alındı.` });
      }
      await tx.insert(notifications).values({ userId: req.customerId, title: "Teslimat incelemeye alındı", body: `${req.code}: Teslim kodu 3 kez hatalı girildi. Operasyon ekibi sizinle iletişime geçecek; kodu yalnızca kuryeyi gördüğünüzde paylaşın.`, link: req.linkedOrderId ? `/siparis/${req.linkedOrderId}` : `/talep/${req.id}` });
      const admins = await tx.select({ id: users.id }).from(users).where(eq(users.role, "SUPER_ADMIN"));
      for (const a of admins) await tx.insert(notifications).values({ userId: a.id, title: "Teslim kodu kilidi", body: `${req.code} 3 hatalı denemeyle kilitlendi.`, link: "/admin/uyusmazliklar" });
    }
    return { kind: "wrong" as const, attemptsLeft: Math.max(0, MAX_OTP_ATTEMPTS - attempts), locked: lockNow };
  });

  if (check.kind === "locked") {
    return { ok: false, error: "Teslimat kilitli: 3 hatalı deneme yapıldı. Operasyon ekibi inceliyor.", attemptsLeft: 0, locked: true };
  }
  if (check.kind === "wrong") {
    return {
      ok: false,
      error: check.locked ? "Teslim kodu 3 kez hatalı girildi. Teslimat kilitlendi ve operasyona iletildi." : `Teslim kodu hatalı. Kalan deneme hakkı: ${check.attemptsLeft}.`,
      attemptsLeft: check.attemptsLeft,
      locked: check.locked,
    };
  }
  await assignmentAction(s, check.assignmentId, "complete", inputCode.trim());
  return { ok: true, status: "COMPLETED" };
}

/** Operasyon: kilitli teslimatın deneme hakkını gerekçeyle sıfırlar. */
export async function unlockDeliveryCode(s: Session, requestId: string, reason: string) {
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) throw new HttpError(403, "Bu işlem operasyon ekibine aittir.");
  if (reason.trim().length < 10) throw new HttpError(422, "Kilit açma gerekçesi en az 10 karakter olmalı.");
  return db.transaction(async (tx) => {
    const [req] = await tx.select().from(serviceRequests).where(eq(serviceRequests.id, requestId)).for("update").limit(1);
    if (!req) throw new HttpError(404, "Teslimat bulunamadı.");
    if (!req.otpLockedAt && req.otpAttempts === 0) throw new HttpError(409, "Bu teslimatta kilit yok.");
    await tx.update(serviceRequests).set({ otpAttempts: 0, otpLockedAt: null, updatedAt: new Date() }).where(eq(serviceRequests.id, req.id));
    await audit(tx, s.user.id, "delivery.otp_unlock", "service_request", req.id, reason.trim());
    const [asg] = await tx.select().from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
    if (asg) {
      const [p] = await tx.select({ userId: providers.userId }).from(providers).where(eq(providers.id, asg.providerId)).limit(1);
      if (p) await tx.insert(notifications).values({ userId: p.userId, title: "Teslim kodu kilidi açıldı", body: `${req.code}: Operasyon deneme hakkınızı yeniledi (3 hak).`, link: "/dashboard/kurye/gorevler" });
    }
    return { ok: true };
  });
}
