/** İstemci + sunucu ortak: durum eşleme ve koordinat doğrulama (DB bağımlılığı yok). */

export type UiProviderStatus = "ONLINE" | "BUSY" | "OFFLINE";
export type DbProviderStatusSetting = "AVAILABLE" | "PAUSED" | "OFFLINE";

export interface ProviderCoords {
  lat: number;
  lng: number;
}

/** DB durumu -> 3'lü arayüz durumu. PAUSED (kullanıcı molası) ve sistem meşguliyeti tek "BUSY" görünümünde birleşir. */
export function serverStatusToUi(status: string): UiProviderStatus {
  if (status === "AVAILABLE") return "ONLINE";
  if (status === "OFFLINE") return "OFFLINE";
  if (status === "SUSPENDED") return "OFFLINE";
  return "BUSY";
}

/** Arayüz seçimi -> DB yazılabilir durumu. Kullanıcının "Meşgul" seçimi PAUSED olarak saklanır; sistem BUSY/ON_TASK değerlerine kullanıcı yazamaz. */
export function uiStatusToDb(status: UiProviderStatus): DbProviderStatusSetting {
  if (status === "ONLINE") return "AVAILABLE";
  if (status === "BUSY") return "PAUSED";
  return "OFFLINE";
}

/** Sistem tarafından kilitli durumlar: kullanıcı manuel değiştiremez. */
export function isStatusLocked(serverStatus: string | null | undefined): boolean {
  return serverStatus === "ON_TASK" || serverStatus === "BUSY" || serverStatus === "SUSPENDED";
}

export function lockReason(serverStatus: string | null | undefined): string | null {
  if (serverStatus === "SUSPENDED") return "Profil askıda; durum değiştirilemez.";
  if (serverStatus === "ON_TASK" || serverStatus === "BUSY") return "Aktif görev varken durum otomatik yönetilir.";
  return null;
}

export function isValidCoords(lat: unknown, lng: unknown): lat is number {
  if (typeof lat !== "number" || typeof lng !== "number") return false;
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return false;
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) return false;
  if (lat === 0 && lng === 0) return false;
  return true;
}
