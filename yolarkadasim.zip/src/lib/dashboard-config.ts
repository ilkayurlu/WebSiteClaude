import type { LucideIcon } from "lucide-react";
import {
  Activity, BadgeCheck, Bike, ChartColumnIncreasing, CircleHelp, FileClock, Heart, House,
  LayoutDashboard, ListChecks, MapPinned, MessageCircle, PackageCheck, ReceiptText,
  ShieldCheck, ShoppingBag, Truck, UsersRound, UtensilsCrossed, WalletCards,
} from "lucide-react";
import type { DashboardRole } from "./dashboard-routes";

export { dashboardHome, pathRole, roleAllowed } from "./dashboard-routes";
export type { UserRole, DashboardRole } from "./dashboard-routes";
export type NavItem = { href: string; label: string; icon: LucideIcon; badgeKey?: "offers" | "pending" | "active" | "unread" | "cases" };

export const roleTitles: Record<DashboardRole, { title: string; caption: string; symbol: LucideIcon }> = {
  CUSTOMER: { title: "Müşteri Alanı", caption: "Siparişlerim ve yol arkadaşlarım", symbol: ShoppingBag },
  PROVIDER: { title: "Kurye Merkezi", caption: "Görev, kazanç ve vardiya", symbol: Bike },
  FLEET_OWNER: { title: "Filo Operasyonu", caption: "Ekip ve teslimatlar", symbol: Truck },
  ADMIN: { title: "Operasyon Merkezi", caption: "Platform yönetimi", symbol: ShieldCheck },
  RESTAURANT_OWNER: { title: "İşletme Merkezi", caption: "Menü ve siparişler", symbol: UtensilsCrossed },
};

export const dashboardNav: Record<DashboardRole, NavItem[]> = {
  CUSTOMER: [
    { href: "/dashboard/musteri", label: "Genel bakış", icon: LayoutDashboard },
    { href: "/dashboard/musteri/taleplerim", label: "Aktif talepler", icon: MapPinned, badgeKey: "active" },
    { href: "/dashboard/musteri/gecmis", label: "Geçmiş & puanlar", icon: FileClock },
    { href: "/dashboard/musteri/favorilerim", label: "Favorilerim", icon: Heart },
    { href: "/dashboard/musteri/cuzdan", label: "Harcama özeti", icon: WalletCards },
  ],
  PROVIDER: [
    { href: "/dashboard/kurye", label: "Genel bakış", icon: LayoutDashboard },
    { href: "/dashboard/kurye/canli-panel", label: "Canlı panel", icon: Activity, badgeKey: "offers" },
    { href: "/dashboard/kurye/gorevler", label: "Görevlerim", icon: PackageCheck, badgeKey: "active" },
    { href: "/dashboard/kurye/kazanc", label: "Kazançlar", icon: ChartColumnIncreasing },
    { href: "/dashboard/kurye/profil-yonetimi", label: "Profil yönetimi", icon: BadgeCheck },
    { href: "/dashboard/kurye/filom", label: "Filom", icon: UsersRound },
  ],
  FLEET_OWNER: [
    { href: "/dashboard/filo", label: "Genel bakış", icon: LayoutDashboard },
    { href: "/dashboard/filo/operasyon", label: "Canlı operasyon", icon: MapPinned, badgeKey: "active" },
    { href: "/dashboard/filo/ekip", label: "Ekip & vardiyalar", icon: UsersRound },
    { href: "/dashboard/filo/direkt-talepler", label: "Doğrudan talepler", icon: ListChecks, badgeKey: "pending" },
    { href: "/dashboard/filo/raporlar", label: "Raporlar", icon: ChartColumnIncreasing },
  ],
  ADMIN: [
    { href: "/dashboard/admin", label: "Genel bakış", icon: LayoutDashboard },
    { href: "/dashboard/admin/onay-kuyrugu", label: "Onay kuyruğu", icon: BadgeCheck, badgeKey: "pending" },
    { href: "/dashboard/admin/uyusmazliklar", label: "Uyuşmazlıklar", icon: CircleHelp, badgeKey: "cases" },
    { href: "/dashboard/admin/metrikler", label: "Sistem metrikleri", icon: ChartColumnIncreasing },
  ],
  RESTAURANT_OWNER: [
    { href: "/dashboard/isletme", label: "Genel bakış", icon: LayoutDashboard },
    { href: "/isletme", label: "Menü yönetimi", icon: UtensilsCrossed },
    { href: "/isletme/siparisler", label: "Sipariş kuyruğu", icon: ReceiptText, badgeKey: "pending" },
  ],
};

export const sharedNav: NavItem[] = [
  { href: "/mesajlar", label: "Mesajlar", icon: MessageCircle, badgeKey: "unread" },
  { href: "/", label: "Platforma dön", icon: House },
];
