import { and, asc, desc, eq, gt, gte, inArray, isNull, ne, notInArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments,
  conversationParticipants,
  conversations,
  fleets,
  messages,
  notifications,
  providers,
  serviceRequests,
  users,
  type Conversation,
  type MessageRow,
} from "@/db/schema";
import { isValidAreaSlug, areaName, normalizeAreaSlug } from "./geo";
import { HttpError } from "./http";
import type { Session } from "./session";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type Exec = Tx | typeof db;

export type ChatContextType = "REQUEST" | "FLEET_INTERNAL";
export type MessageType = "TEXT" | "LOCATION_PIN" | "SYSTEM_NOTICE";
export type ConversationStatus = "ACTIVE" | "CLOSED";

export interface ChatPeer {
  userId: string;
  name: string;
  role: string;
  hue: number;
  lastReadAt: string | null;
  muted: boolean;
}

export interface MessageWithSender {
  id: string;
  conversationId: string;
  senderId: string | null;
  senderName: string;
  senderRole: string;
  type: MessageType;
  body: string;
  masked: boolean;
  isRead: boolean;
  deliveredAt: string | null;
  readAt: string | null;
  createdAt: string;
}

export interface ConversationSummary {
  id: string;
  contextType: ChatContextType;
  contextLabel: string;
  status: ConversationStatus;
  closedReason: string | null;
  muted: boolean;
  unread: number;
  other: ChatPeer | null;
  lastMessage: { body: string; type: MessageType; senderId: string | null; createdAt: string } | null;
  lastMessageAt: string | null;
}

const ACTIVE_REQUEST_STATES = ["CONFIRMED", "IN_PROGRESS"];
const MAX_BODY = 1000;

/* ---------------- PII maskeleme (sunucu otoritesi) ---------------- */
const TR_PHONE = /(?:\+90|0090|0)[\s.-]?5\d{2}[\s.-]?\d{3}[\s.-]?\d{2}[\s.-]?\d{2}/g;
const IBAN = /\bTR\s?\d{2}(?:[\s]?[0-9A-Z]{4}){5}[\s]?[0-9A-Z]{2}\b/gi;
const EMAIL = /\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b/g;

export function maskSensitive(text: string): { body: string; masked: boolean } {
  let masked = false;
  let body = text.replace(TR_PHONE, () => {
    masked = true;
    return "[telefon gizlendi]";
  });
  body = body.replace(IBAN, () => {
    masked = true;
    return "[IBAN gizlendi]";
  });
  body = body.replace(EMAIL, () => {
    masked = true;
    return "[e-posta gizlendi]";
  });
  return { body, masked };
}

function pairKeyOf(a: string, b: string) {
  return [a, b].sort().join(":");
}

function hueFor(name: string) {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return h;
}

function toMessage(m: MessageRow, senderName: string, senderRole: string): MessageWithSender {
  return {
    id: m.id,
    conversationId: m.conversationId,
    senderId: m.senderId,
    senderName,
    senderRole,
    type: m.type as MessageType,
    body: m.body,
    masked: m.masked,
    isRead: m.isRead,
    deliveredAt: m.deliveredAt?.toISOString() ?? null,
    readAt: m.readAt?.toISOString() ?? null,
    createdAt: m.createdAt.toISOString(),
  };
}

/* ---------------- Katılımcı çözümleme ---------------- */
async function assertParticipant(exec: Exec, conversationId: string, userId: string) {
  const [conv] = await exec.select().from(conversations).where(eq(conversations.id, conversationId)).limit(1);
  if (!conv) throw new HttpError(404, "Sohbet bulunamadı.");
  const [part] = await exec
    .select()
    .from(conversationParticipants)
    .where(and(eq(conversationParticipants.conversationId, conversationId), eq(conversationParticipants.userId, userId)))
    .limit(1);
  if (!part) throw new HttpError(403, "Bu sohbete erişim yetkiniz yok.");
  return { conv, part };
}

/** Görev bağlamının hâlâ açık olup olmadığını sunucuda doğrular; kapandıysa sohbeti arşivler. */
async function contextStillOpen(exec: Exec, conv: Conversation): Promise<{ open: boolean; reason: string }> {
  if (conv.contextType === "REQUEST") {
    const [req] = await db.select().from(serviceRequests).where(eq(serviceRequests.id, conv.contextId)).limit(1);
    if (!req) return { open: false, reason: "Talep bulunamadı." };
    if (!ACTIVE_REQUEST_STATES.includes(req.status)) {
      const reason = req.status === "COMPLETED" ? "Görev tamamlandı — sohbet arşivlendi." : req.status.startsWith("CANCELLED") ? "Görev iptal edildi — sohbet arşivlendi." : "Görev artık aktif değil — sohbet arşivlendi.";
      return { open: false, reason };
    }
    return { open: true, reason: "" };
  }
  // FLEET_INTERNAL: üyelik sürüyor mu?
  const parts = await db.select().from(conversationParticipants).where(eq(conversationParticipants.conversationId, conv.id));
  for (const p of parts) {
    const [prov] = await db.select().from(providers).where(eq(providers.userId, p.userId)).limit(1);
    if (prov && prov.fleetId !== conv.contextId) return { open: false, reason: "Filo üyeliği sona erdi — sohbet arşivlendi." };
    if (prov?.status === "SUSPENDED") return { open: false, reason: "Üye askıya alındı — sohbet arşivlendi." };
  }
  return { open: true, reason: "" };
}

async function insertSystemNotice(exec: Exec, conversationId: string, body: string) {
  const [m] = await exec
    .insert(messages)
    .values({ conversationId, senderId: null, type: "SYSTEM_NOTICE", body, isRead: true, deliveredAt: new Date(), readAt: new Date() })
    .returning();
  await exec.update(conversations).set({ lastMessageAt: new Date() }).where(eq(conversations.id, conversationId));
  return m;
}

async function closeConversation(exec: Exec, conversationId: string, reason: string) {
  const [conv] = await exec.select().from(conversations).where(eq(conversations.id, conversationId)).limit(1);
  if (!conv || conv.status === "CLOSED") return;
  await exec.update(conversations).set({ status: "CLOSED", closedReason: reason }).where(eq(conversations.id, conversationId));
  await insertSystemNotice(exec, conversationId, `🔒 ${reason}`);
}

/* ---------------- Motor kancaları (tx içinde çağrılır) ---------------- */
export async function ensureRequestConversation(
  tx: Exec,
  input: { requestId: string; code: string; customerId: string; providerUserId: string; providerName: string },
) {
  const pairKey = pairKeyOf(input.customerId, input.providerUserId);
  const [existing] = await tx
    .select()
    .from(conversations)
    .where(and(eq(conversations.contextType, "REQUEST"), eq(conversations.contextId, input.requestId), eq(conversations.pairKey, pairKey)))
    .limit(1);
  if (existing) return existing.id;
  const [conv] = await tx
    .insert(conversations)
    .values({ contextType: "REQUEST", contextId: input.requestId, pairKey, status: "ACTIVE", lastMessageAt: new Date() })
    .returning();
  await tx.insert(conversationParticipants).values([
    { conversationId: conv.id, userId: input.customerId, role: "CUSTOMER" },
    { conversationId: conv.id, userId: input.providerUserId, role: "PROVIDER" },
  ]);
  await insertSystemNotice(tx, conv.id, `✅ ${input.code} görevi onaylandı. Bu sohbet görev süresince açıktır; telefon, adres ve IBAN paylaşımları otomatik gizlenir.`);
  return conv.id;
}

export async function closeRequestConversations(tx: Exec, requestId: string, reason: string) {
  const rows = await tx
    .select({ id: conversations.id })
    .from(conversations)
    .where(and(eq(conversations.contextType, "REQUEST"), eq(conversations.contextId, requestId), eq(conversations.status, "ACTIVE")));
  for (const r of rows) await closeConversation(tx, r.id, reason);
}

/* ---------------- 1) createOrGetConversation ---------------- */
export type CreateConversationInput = {
  requestId?: string;
  orderId?: string;
  providerUserId?: string;
  participantIds?: string[];
};

export async function createOrGetConversation(session: Session, input: CreateConversationInput): Promise<{ id: string; status: ConversationStatus }> {
  const me = session.user.id;

  // Sipariş bağlamı → bağlı kurye talebine çözümlenir
  let requestId = input.requestId;
  if (!requestId && input.orderId) {
    const [req] = await db.select({ id: serviceRequests.id }).from(serviceRequests).where(eq(serviceRequests.linkedOrderId, input.orderId)).limit(1);
    if (!req) throw new HttpError(422, "Bu sipariş için henüz kurye görevi oluşmadı. Kurye atandığında sohbet açılır.");
    requestId = req.id;
  }

  if (requestId) {
    const [req] = await db.select().from(serviceRequests).where(eq(serviceRequests.id, requestId)).limit(1);
    if (!req) throw new HttpError(404, "Talep bulunamadı.");
    const [asg] = await db.select().from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
    if (!asg) throw new HttpError(422, "Henüz kesin atama yok. Sohbet, görev onaylandığında açılır.");
    const [prov] = await db.select().from(providers).where(eq(providers.id, asg.providerId)).limit(1);
    if (!prov) throw new HttpError(404, "Sağlayıcı bulunamadı.");
    const isCustomer = req.customerId === me;
    const isProvider = prov.userId === me;
    if (!isCustomer && !isProvider) throw new HttpError(403, "Yalnızca görevin tarafları mesajlaşabilir.");
    if (input.participantIds && input.participantIds.some((id) => id !== req.customerId && id !== prov.userId)) {
      throw new HttpError(422, "Katılımcılar görev taraflarıyla sınırlıdır.");
    }
    const pairKey = pairKeyOf(req.customerId, prov.userId);
    const [existing] = await db
      .select()
      .from(conversations)
      .where(and(eq(conversations.contextType, "REQUEST"), eq(conversations.contextId, req.id), eq(conversations.pairKey, pairKey)))
      .limit(1);
    if (existing) {
      const live = await contextStillOpen(db, existing);
      if (!live.open && existing.status === "ACTIVE") await closeConversation(db, existing.id, live.reason);
      return { id: existing.id, status: live.open ? "ACTIVE" : "CLOSED" };
    }
    if (!ACTIVE_REQUEST_STATES.includes(req.status)) throw new HttpError(422, "Görev tamamlandığı veya iptal edildiği için yeni sohbet açılamaz.");
    const id = await ensureRequestConversation(db, { requestId: req.id, code: req.code, customerId: req.customerId, providerUserId: prov.userId, providerName: prov.displayName });
    return { id, status: "ACTIVE" };
  }

  // Filo içi sohbet
  if (session.user.role === "FLEET_OWNER" && session.fleetId) {
    const target = input.providerUserId ?? input.participantIds?.find((id) => id !== me);
    if (!target) throw new HttpError(422, "Sohbet başlatılacak üyeyi seçin.");
    const [prov] = await db.select().from(providers).where(eq(providers.userId, target)).limit(1);
    if (!prov || prov.fleetId !== session.fleetId) throw new HttpError(422, "Bu kullanıcı filonuzun üyesi değil.");
    return upsertFleetConversation(session.fleetId, me, target, "FLEET_OWNER", "PROVIDER");
  }
  if (session.user.role === "PROVIDER" && session.providerId) {
    const [prov] = await db.select().from(providers).where(eq(providers.id, session.providerId)).limit(1);
    if (!prov?.fleetId) throw new HttpError(422, "Filo içi sohbet için bir filoya bağlı olmalısınız.");
    const [fleet] = await db.select().from(fleets).where(eq(fleets.id, prov.fleetId)).limit(1);
    if (!fleet) throw new HttpError(404, "Filo bulunamadı.");
    return upsertFleetConversation(fleet.id, me, fleet.ownerUserId, "PROVIDER", "FLEET_OWNER");
  }
  throw new HttpError(403, "Sohbet başlatmak için aktif bir görev veya filo üyeliği gerekir.");
}

async function upsertFleetConversation(fleetId: string, me: string, other: string, myRole: string, otherRole: string) {
  const pairKey = pairKeyOf(me, other);
  const [existing] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.contextType, "FLEET_INTERNAL"), eq(conversations.contextId, fleetId), eq(conversations.pairKey, pairKey)))
    .limit(1);
  if (existing) return { id: existing.id, status: existing.status as ConversationStatus };
  const [conv] = await db
    .insert(conversations)
    .values({ contextType: "FLEET_INTERNAL", contextId: fleetId, pairKey, status: "ACTIVE", lastMessageAt: new Date() })
    .returning();
  await db.insert(conversationParticipants).values([
    { conversationId: conv.id, userId: me, role: myRole },
    { conversationId: conv.id, userId: other, role: otherRole },
  ]);
  await insertSystemNotice(db, conv.id, "🏢 Filo içi kanal açıldı. Görevden bağımsızdır; kişisel veri paylaşımı otomatik maskelenir.");
  return { id: conv.id, status: "ACTIVE" as const };
}

/* ---------------- 2) sendMessage ---------------- */
export type SendMessageInput = { conversationId: string; senderId: string; content: string; type?: MessageType };

export async function sendMessage(session: Session, input: SendMessageInput): Promise<{ message: MessageWithSender; masked: boolean; warning: string | null }> {
  if (input.senderId !== session.user.id) throw new HttpError(403, "Başkası adına mesaj gönderemezsiniz.");
  const type: MessageType = input.type ?? "TEXT";
  if (type === "SYSTEM_NOTICE") throw new HttpError(422, "Sistem bildirimi kullanıcı tarafından gönderilemez.");

  return db.transaction(async (tx) => {
    const { conv } = await assertParticipant(tx, input.conversationId, session.user.id);
    if (conv.status === "CLOSED") throw new HttpError(409, conv.closedReason ?? "Bu sohbet arşivlendi; artık salt okunur.");
    const live = await contextStillOpen(tx, conv);
    if (!live.open) {
      await closeConversation(tx, conv.id, live.reason);
      throw new HttpError(409, live.reason);
    }

    let body: string;
    let masked = false;
    if (type === "LOCATION_PIN") {
      // Gizlilik: ham koordinat kabul edilmez, yalnızca bölge anahtarı + kısa etiket
      let parsed: { area?: unknown; label?: unknown };
      try {
        parsed = JSON.parse(input.content) as { area?: unknown; label?: unknown };
      } catch {
        throw new HttpError(422, "Konum paylaşımı geçersiz.");
      }
      const area = typeof parsed.area === "string" ? parsed.area : "";
      if (!isValidAreaSlug(area)) throw new HttpError(422, "Geçersiz bölge.");
      const label = typeof parsed.label === "string" ? parsed.label.slice(0, 80) : "";
      const safe = maskSensitive(label);
      masked = safe.masked;
      body = JSON.stringify({ area: normalizeAreaSlug(area) ?? area, label: safe.body });
    } else {
      const content = input.content.trim();
      if (!content) throw new HttpError(422, "Boş mesaj gönderilemez.");
      if (content.length > MAX_BODY) throw new HttpError(422, `Mesaj en fazla ${MAX_BODY} karakter olabilir.`);
      const safe = maskSensitive(content);
      body = safe.body;
      masked = safe.masked;
    }

    const [row] = await tx
      .insert(messages)
      .values({ conversationId: conv.id, senderId: session.user.id, type, body, masked })
      .returning();
    await tx.update(conversations).set({ lastMessageAt: row.createdAt }).where(eq(conversations.id, conv.id));
    await tx
      .update(conversationParticipants)
      .set({ lastReadAt: row.createdAt })
      .where(and(eq(conversationParticipants.conversationId, conv.id), eq(conversationParticipants.userId, session.user.id)));

    // Karşı tarafa bildirim: yalnızca okunmamış mesajı yoksa ve sessize almamışsa
    const others = await tx
      .select()
      .from(conversationParticipants)
      .where(and(eq(conversationParticipants.conversationId, conv.id), ne(conversationParticipants.userId, session.user.id)));
    for (const o of others) {
      const hadUnread = o.lastReadAt != null && conv.lastMessageAt != null && conv.lastMessageAt > o.lastReadAt;
      if (!o.muted && !hadUnread) {
        const preview = type === "LOCATION_PIN" ? "📍 Yaklaşık konum paylaşıldı" : body.slice(0, 80);
        await tx.insert(notifications).values({ userId: o.userId, title: `💬 ${session.user.name}`, body: preview, link: `/mesajlar?c=${conv.id}` });
      }
    }

    return {
      message: toMessage(row, session.user.name, session.user.role),
      masked,
      warning: masked ? "Telefon, IBAN veya e-posta algılandı ve otomatik gizlendi. İletişim uygulama içinde kalmalıdır." : null,
    };
  });
}

/* ---------------- 3) getMessages ---------------- */
export type MessagesPage = {
  messages: MessageWithSender[];
  hasMore: boolean;
  status: ConversationStatus;
  closedReason: string | null;
  contextLabel: string;
  me: string;
  muted: boolean;
  other: ChatPeer | null;
};

export async function getMessages(session: Session, conversationId: string, opts: { page?: number; limit?: number } = {}): Promise<MessagesPage> {
  const page = Math.max(0, opts.page ?? 0);
  const limit = Math.min(100, Math.max(10, opts.limit ?? 40));
  const { conv, part } = await assertParticipant(db, conversationId, session.user.id);

  // Karşı tarafın istemcisine ulaşan mesajlar DELIVERED olur
  await db
    .update(messages)
    .set({ deliveredAt: new Date() })
    .where(and(eq(messages.conversationId, conversationId), ne(messages.senderId, session.user.id), isNull(messages.deliveredAt)));

  const rows = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, conversationId))
    .orderBy(desc(messages.createdAt))
    .limit(limit + 1)
    .offset(page * limit);
  const hasMore = rows.length > limit;
  const slice = rows.slice(0, limit).reverse();

  const senderIds = [...new Set(slice.map((m) => m.senderId).filter((x): x is string => !!x))];
  const senders = senderIds.length ? await db.select({ id: users.id, name: users.name, role: users.role }).from(users).where(inArray(users.id, senderIds)) : [];
  const other = await getOtherPeer(conversationId, session.user.id);
  const label = await contextLabelOf(conv);

  return {
    messages: slice.map((m) => {
      const u = senders.find((x) => x.id === m.senderId);
      return toMessage(m, u?.name ?? "Sistem", u?.role ?? "SYSTEM");
    }),
    hasMore,
    status: conv.status as ConversationStatus,
    closedReason: conv.closedReason,
    contextLabel: label,
    me: session.user.id,
    muted: part.muted,
    other,
  };
}

async function getOtherPeer(conversationId: string, me: string): Promise<ChatPeer | null> {
  const parts = await db.select().from(conversationParticipants).where(eq(conversationParticipants.conversationId, conversationId));
  const other = parts.find((p) => p.userId !== me);
  if (!other) return null;
  const [u] = await db.select({ id: users.id, name: users.name, role: users.role }).from(users).where(eq(users.id, other.userId)).limit(1);
  if (!u) return null;
  const [prov] = await db.select({ hue: providers.hue }).from(providers).where(eq(providers.userId, u.id)).limit(1);
  return { userId: u.id, name: u.name, role: u.role, hue: prov?.hue ?? hueFor(u.name), lastReadAt: other.lastReadAt?.toISOString() ?? null, muted: other.muted };
}

async function contextLabelOf(conv: Conversation): Promise<string> {
  if (conv.contextType === "REQUEST") {
    const [req] = await db.select({ code: serviceRequests.code, pickup: serviceRequests.pickupArea, dropoff: serviceRequests.dropoffArea }).from(serviceRequests).where(eq(serviceRequests.id, conv.contextId)).limit(1);
    if (req) return `${req.code} · ${areaName(req.pickup)}${req.dropoff ? ` → ${areaName(req.dropoff)}` : ""}`;
    return "Görev";
  }
  const [f] = await db.select({ name: fleets.name }).from(fleets).where(eq(fleets.id, conv.contextId)).limit(1);
  return `${f?.name ?? "Filo"} · şirket içi`;
}

/* ---------------- 4) markAsRead ---------------- */
export async function markAsRead(session: Session, conversationId: string): Promise<{ ok: true; readAt: string }> {
  const now = new Date();
  await db.transaction(async (tx) => {
    await assertParticipant(tx, conversationId, session.user.id);
    await tx
      .update(conversationParticipants)
      .set({ lastReadAt: now })
      .where(and(eq(conversationParticipants.conversationId, conversationId), eq(conversationParticipants.userId, session.user.id)));
    await tx
      .update(messages)
      .set({ isRead: true, readAt: now, deliveredAt: sql`COALESCE(${messages.deliveredAt}, ${now})` })
      .where(and(eq(messages.conversationId, conversationId), ne(messages.senderId, session.user.id), eq(messages.isRead, false)));
  });
  return { ok: true, readAt: now.toISOString() };
}

export async function setMuted(session: Session, conversationId: string, muted: boolean) {
  await assertParticipant(db, conversationId, session.user.id);
  await db
    .update(conversationParticipants)
    .set({ muted })
    .where(and(eq(conversationParticipants.conversationId, conversationId), eq(conversationParticipants.userId, session.user.id)));
  return { ok: true, muted };
}

/* ---------------- Gelen kutusu ---------------- */
export async function listConversations(session: Session): Promise<ConversationSummary[]> {
  const mine = await db.select().from(conversationParticipants).where(eq(conversationParticipants.userId, session.user.id));
  if (!mine.length) return [];
  const ids = mine.map((m) => m.conversationId);
  const convs = await db.select().from(conversations).where(inArray(conversations.id, ids));
  const parts = await db.select().from(conversationParticipants).where(inArray(conversationParticipants.conversationId, ids));
  const otherIds = [...new Set(parts.filter((p) => p.userId !== session.user.id).map((p) => p.userId))];
  const otherUsers = otherIds.length ? await db.select({ id: users.id, name: users.name, role: users.role }).from(users).where(inArray(users.id, otherIds)) : [];
  const provs = otherIds.length ? await db.select({ userId: providers.userId, hue: providers.hue }).from(providers).where(inArray(providers.userId, otherIds)) : [];

  const summaries: ConversationSummary[] = [];
  for (const conv of convs) {
    const myPart = mine.find((m) => m.conversationId === conv.id);
    if (!myPart) continue;
    const otherPart = parts.find((p) => p.conversationId === conv.id && p.userId !== session.user.id);
    const ou = otherPart ? otherUsers.find((u) => u.id === otherPart.userId) : undefined;
    const [last] = await db.select().from(messages).where(eq(messages.conversationId, conv.id)).orderBy(desc(messages.createdAt)).limit(1);
    const unreadCond = and(
      eq(messages.conversationId, conv.id),
      ne(messages.senderId, session.user.id),
      ne(messages.type, "SYSTEM_NOTICE"),
      myPart.lastReadAt ? gt(messages.createdAt, myPart.lastReadAt) : sql`TRUE`,
    );
    const [unreadRow] = await db
      .select({ n: sql<number>`count(*) filter (where ${messages.senderId} is not null)::int` })
      .from(messages)
      .where(unreadCond);
    summaries.push({
      id: conv.id,
      contextType: conv.contextType as ChatContextType,
      contextLabel: await contextLabelOf(conv),
      status: conv.status as ConversationStatus,
      closedReason: conv.closedReason,
      muted: myPart.muted,
      unread: unreadRow?.n ?? 0,
      other: ou && otherPart
        ? { userId: ou.id, name: ou.name, role: ou.role, hue: provs.find((p) => p.userId === ou.id)?.hue ?? hueFor(ou.name), lastReadAt: otherPart.lastReadAt?.toISOString() ?? null, muted: otherPart.muted }
        : null,
      lastMessage: last ? { body: last.body, type: last.type as MessageType, senderId: last.senderId, createdAt: last.createdAt.toISOString() } : null,
      lastMessageAt: conv.lastMessageAt?.toISOString() ?? null,
    });
  }
  return summaries.sort((a, b) => (b.lastMessageAt ?? "").localeCompare(a.lastMessageAt ?? ""));
}

export async function unreadTotal(session: Session): Promise<number> {
  const list = await listConversations(session);
  return list.filter((c) => !c.muted).reduce((s, c) => s + c.unread, 0);
}

/* ---------------- SSE yardımcıları ---------------- */
export async function streamSnapshot(session: Session, conversationId: string) {
  const { conv } = await assertParticipant(db, conversationId, session.user.id);
  const live = await contextStillOpen(db, conv);
  if (!live.open && conv.status === "ACTIVE") await closeConversation(db, conv.id, live.reason);
  await db
    .update(messages)
    .set({ deliveredAt: new Date() })
    .where(and(eq(messages.conversationId, conversationId), ne(messages.senderId, session.user.id), isNull(messages.deliveredAt)));
  const page = await getMessages(session, conversationId, { page: 0, limit: 50 });
  return { ...page, status: live.open ? ("ACTIVE" as const) : ("CLOSED" as const) };
}

export async function streamDelta(conversationId: string, afterIso: string, seenIds: ReadonlySet<string>) {
  // timestamptz mikrosaniye ↔ JS milisaniye yuvarlaması nedeniyle >= + görülen-id kümesi kullanılır;
  // böylece aynı mesaj iki kez yayınlanmaz, aynı milisaniyedeki mesajlar da kaçmaz.
  const after = new Date(afterIso);
  const conds = [eq(messages.conversationId, conversationId), gte(messages.createdAt, after)];
  const seen = [...seenIds].slice(-400);
  if (seen.length) conds.push(notInArray(messages.id, seen));
  const rows = await db
    .select()
    .from(messages)
    .where(and(...conds))
    .orderBy(asc(messages.createdAt))
    .limit(50);
  if (!rows.length) return { messages: [] as MessageWithSender[], cursor: afterIso };
  const senderIds = [...new Set(rows.map((m) => m.senderId).filter((x): x is string => !!x))];
  const senders = senderIds.length ? await db.select({ id: users.id, name: users.name, role: users.role }).from(users).where(inArray(users.id, senderIds)) : [];
  const mapped = rows.map((m) => {
    const u = senders.find((x) => x.id === m.senderId);
    return toMessage(m, u?.name ?? "Sistem", u?.role ?? "SYSTEM");
  });
  return { messages: mapped, cursor: rows[rows.length - 1].createdAt.toISOString() };
}

export async function streamReceipts(conversationId: string, me: string) {
  const [conv] = await db.select({ status: conversations.status, closedReason: conversations.closedReason }).from(conversations).where(eq(conversations.id, conversationId)).limit(1);
  const parts = await db.select().from(conversationParticipants).where(eq(conversationParticipants.conversationId, conversationId));
  const other = parts.find((p) => p.userId !== me);
  const readRows = await db
    .select({ id: messages.id })
    .from(messages)
    .where(and(eq(messages.conversationId, conversationId), eq(messages.senderId, me), eq(messages.isRead, true)));
  return {
    status: (conv?.status ?? "CLOSED") as ConversationStatus,
    closedReason: conv?.closedReason ?? null,
    readUpTo: other?.lastReadAt?.toISOString() ?? null,
    readIds: readRows.map((r) => r.id),
  };
}
