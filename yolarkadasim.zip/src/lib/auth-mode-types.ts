import type { UserRole } from "@/lib/dashboard-routes";

/** 0 = Demo, 1 = E-posta & şifre, 2 = 4 haneli yönetici PIN'i */
export type AccessMode = "0" | "1" | "2";

export interface DemoAccount {
  id: string;
  name: string;
  role: UserRole;
}

export type AuthResult =
  | { success: true; redirectTo: string; role: UserRole }
  | { success: false; error: string; cooldownMs?: number };

export type AuthAccessSnapshot =
  | { success: true; mode: AccessMode; pinReady: boolean; pinReason: string | null }
  | { success: false; error: string };
