import { and, asc, desc, eq, gte, inArray, isNotNull, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments, fleets, matchingCandidates, orders, providerDocuments, providerEarnings, providers,
  serviceRequests, supportCases, users, type ProviderDocument,
} from "@/db/schema";
import { areaName } from "./geo";
import { getCommissionBps, ensureLedgerBackfill, weekStartIstanbul } from "./finance";
import { isEligible, type MatchInput } from "./matching";
import { startOfTodayIstanbul } from "./dashboard-data";

export interface AdminMetric {
  key: string;
  title: string;
  value: string;
  detail: string;
}

export const DOC_TYPES = ["LICENSE", "REGISTRATION", "CRIMINAL_RECORD"] as const;
export type DocType = (typeof DOC_TYPES)[number];
export const DOC_LABELS: Record<DocType, string> = { LICENSE: "Ehliyet", REGISTRATION: "Araç ruhsatı", CRIMINAL_RECORD: "Adli sicil kaydı" };

export interface CourierVerification {
  providerId: string;
  slug: string;
  name: string;
  hue: number;
  headline: string | null;
  vehicleType: string;
  vehicleLabel: string | null;
  status: string;
  isVerified: boolean;
  fleetName: string | null;
  createdAt: Date;
  documents: Record<DocType, { id: string; status: string; note: string | null; submittedAt: Date } | null>;
}

export interface LiveTask {
  id: string;
  code: string;
  status: string;
  mode: string;
  serviceType: string;
  vehicleTypeReq: string | null;
  pickup: string;
  pickupKey: string;
  dropoff: string;
  ageMinutes: number;
  priority: "CRITICAL" | "DELAYED" | "NORMAL";
  reason: string;
  providerName: string | null;
  otpLocked: boolean;
  linkedOrderId: string | null;
  eligibleProviders: { id: string; name: string; vehicleType: string; status: string; ratingAvg: number; ratingCount: number }[];
}

/* ---------------- KPI ---------------- */
export async function adminKpis() {
  const today = startOfTodayIstanbul();
  const weekAgo = new Date(Date.now() - 7 * 86_400_000);
  const [[reqToday], [ordToday], [prov], durations, etaRows, [cases]] = await Promise.all([
    db.select({
      gmv: sql<number>`coalesce(sum(${serviceRequests.finalPriceMinor}) filter (where ${serviceRequests.status}='COMPLETED' and ${serviceRequests.linkedOrderId} is null and ${serviceRequests.updatedAt} >= ${today}),0)::bigint`,
      done: sql<number>`count(*) filter (where ${serviceRequests.status}='COMPLETED' and ${serviceRequests.updatedAt} >= ${today})::int`,
      active: sql<number>`count(*) filter (where ${serviceRequests.status} in ('MATCHING','OFFERED','CONFIRMED','IN_PROGRESS'))::int`,
    }).from(serviceRequests),
    db.select({
      gmv: sql<number>`coalesce(sum(${orders.totalMinor}) filter (where ${orders.status}='DELIVERED' and ${orders.updatedAt} >= ${today}),0)::bigint`,
      done: sql<number>`count(*) filter (where ${orders.status}='DELIVERED' and ${orders.updatedAt} >= ${today})::int`,
    }).from(orders),
    db.select({
      active: sql<number>`count(*) filter (where ${providers.status} in ('AVAILABLE','BUSY','ON_TASK'))::int`,
      available: sql<number>`count(*) filter (where ${providers.status}='AVAILABLE')::int`,
      total: sql<number>`count(*)::int`,
    }).from(providers),
    db.select({ acceptedAt: assignments.acceptedAt, completedAt: assignments.completedAt })
      .from(assignments).where(and(eq(assignments.state, "COMPLETED"), gte(assignments.completedAt, weekAgo))),
    db.select({ acceptedAt: assignments.acceptedAt, startedAt: assignments.startedAt, eta: matchingCandidates.etaSeconds })
      .from(assignments)
      .innerJoin(matchingCandidates, and(eq(matchingCandidates.requestId, assignments.requestId), eq(matchingCandidates.providerId, assignments.providerId)))
      .where(and(isNotNull(assignments.startedAt), gte(assignments.acceptedAt, weekAgo))),
    db.select({ n: sql<number>`count(*)::int` }).from(supportCases).where(inArray(supportCases.status, ["OPEN", "IN_REVIEW"])),
  ]);
  const mins = durations.filter((d) => d.completedAt).map((d) => (d.completedAt!.getTime() - d.acceptedAt.getTime()) / 60_000).filter((m) => m >= 0);
  const avgMinutes = mins.length ? Math.round(mins.reduce((a, b) => a + b, 0) / mins.length) : null;
  const etaHits = etaRows.filter((r) => r.startedAt && (r.startedAt.getTime() - r.acceptedAt.getTime()) / 1000 <= r.eta);
  const etaRate = etaRows.length ? Math.round((100 * etaHits.length) / etaRows.length) : null;
  return {
    gmvTodayMinor: Number(reqToday?.gmv ?? 0) + Number(ordToday?.gmv ?? 0),
    completedToday: (reqToday?.done ?? 0) + (ordToday?.done ?? 0),
    activeTasks: reqToday?.active ?? 0,
    activeCouriers: prov?.active ?? 0,
    availableCouriers: prov?.available ?? 0,
    totalCouriers: prov?.total ?? 0,
    avgMinutes,
    avgSample: mins.length,
    etaRate,
    etaSample: etaRows.length,
    openCases: cases?.n ?? 0,
  };
}

/* ---------------- Kurye doğrulama ---------------- */
export async function courierVerifications(): Promise<CourierVerification[]> {
  const [provs, docs, fls] = await Promise.all([
    db.select().from(providers).orderBy(asc(providers.isVerified), desc(providers.createdAt)),
    db.select().from(providerDocuments),
    db.select({ id: fleets.id, name: fleets.name }).from(fleets),
  ]);
  return provs.map((p) => {
    const mine = docs.filter((d) => d.providerId === p.id);
    const pick = (t: DocType) => {
      const d: ProviderDocument | undefined = mine.find((x) => x.docType === t);
      return d ? { id: d.id, status: d.status, note: d.reviewNote, submittedAt: d.createdAt } : null;
    };
    return {
      providerId: p.id,
      slug: p.slug,
      name: p.displayName,
      hue: p.hue,
      headline: p.headline,
      vehicleType: p.vehicleType,
      vehicleLabel: p.vehicleLabel,
      status: p.status,
      isVerified: p.isVerified,
      fleetName: p.fleetId ? fls.find((f) => f.id === p.fleetId)?.name ?? null : null,
      createdAt: p.createdAt,
      documents: { LICENSE: pick("LICENSE"), REGISTRATION: pick("REGISTRATION"), CRIMINAL_RECORD: pick("CRIMINAL_RECORD") },
    };
  });
}

/* ---------------- Canlı görev monitörü ---------------- */
const MONITOR_STATES = ["QUOTED", "MATCHING", "OFFERED", "EXPIRED", "CONFIRMED", "IN_PROGRESS"];

export async function liveTasks(): Promise<LiveTask[]> {
  const dayAgo = new Date(Date.now() - 24 * 3_600_000);
  const rows = await db
    .select({ r: serviceRequests, providerName: providers.displayName })
    .from(serviceRequests)
    .leftJoin(assignments, eq(assignments.requestId, serviceRequests.id))
    .leftJoin(providers, eq(providers.id, assignments.providerId))
    .where(and(inArray(serviceRequests.status, MONITOR_STATES), gte(serviceRequests.updatedAt, dayAgo)))
    .orderBy(desc(serviceRequests.createdAt))
    .limit(60);
  const pool = await db.select().from(providers).where(eq(providers.status, "AVAILABLE"));
  const now = Date.now();
  return rows
    .filter(({ r }) => !(r.status === "QUOTED" && now - r.createdAt.getTime() < 15 * 60_000 && !r.linkedOrderId))
    .map(({ r, providerName }) => {
      const age = Math.round((now - r.createdAt.getTime()) / 60_000);
      let priority: LiveTask["priority"] = "NORMAL";
      let reason = "Akış normal";
      if (r.otpLockedAt) { priority = "CRITICAL"; reason = "Teslim kodu 3 kez hatalı — kilitli"; }
      else if (r.status === "EXPIRED") { priority = "CRITICAL"; reason = "Uygun kurye bulunamadı"; }
      else if (r.status === "QUOTED") { priority = "DELAYED"; reason = "Müşteri seçimi / sipariş eşleştirmesi bekliyor"; }
      else if ((r.status === "MATCHING" || r.status === "OFFERED") && age >= 5) { priority = "DELAYED"; reason = `${age} dk'dır kurye kabul etmedi`; }
      else if (r.status === "CONFIRMED" && age >= 45) { priority = "DELAYED"; reason = "Onaylandı ama görev başlatılmadı"; }
      else if (r.status === "IN_PROGRESS" && age >= 120) { priority = "DELAYED"; reason = "Teslimat 2 saati aştı"; }
      const input: MatchInput = { mode: r.mode as MatchInput["mode"], serviceType: r.serviceType, vehicleTypeReq: r.vehicleTypeReq, pickupArea: r.pickupArea };
      const assignable = ["QUOTED", "MATCHING", "OFFERED", "EXPIRED"].includes(r.status);
      const eligibleProviders = assignable
        ? pool.filter((p) => !isEligible(p, input)).slice(0, 12).map((p) => ({ id: p.id, name: p.displayName, vehicleType: p.vehicleType, status: p.status, ratingAvg: p.ratingAvg, ratingCount: p.ratingCount }))
        : [];
      return {
        id: r.id,
        code: r.code,
        status: r.status,
        mode: r.mode,
        serviceType: r.serviceType,
        vehicleTypeReq: r.vehicleTypeReq,
        pickup: areaName(r.pickupArea),
        pickupKey: r.pickupArea,
        dropoff: areaName(r.dropoffArea),
        ageMinutes: age,
        priority,
        reason,
        providerName,
        otpLocked: !!r.otpLockedAt,
        linkedOrderId: r.linkedOrderId,
        eligibleProviders,
      };
    })
    .sort((a, b) => ({ CRITICAL: 0, DELAYED: 1, NORMAL: 2 })[a.priority] - ({ CRITICAL: 0, DELAYED: 1, NORMAL: 2 })[b.priority] || b.ageMinutes - a.ageMinutes);
}

/* ---------------- Finans ---------------- */
export async function financeOverview() {
  await ensureLedgerBackfill();
  const commissionBps = await getCommissionBps();
  const [rows, provs, fls] = await Promise.all([
    db.select().from(providerEarnings).orderBy(desc(providerEarnings.earnedAt)),
    db.select({ id: providers.id, name: providers.displayName, slug: providers.slug, fleetId: providers.fleetId }).from(providers),
    db.select({ id: fleets.id, name: fleets.name, slug: fleets.slug }).from(fleets),
  ]);
  const sum = (xs: typeof rows, k: "grossMinor" | "commissionMinor" | "netMinor") => xs.reduce((a, r) => a + r[k], 0);
  const accrued = rows.filter((r) => r.status === "ACCRUED");
  const approved = rows.filter((r) => r.status === "APPROVED_FOR_PAYOUT");

  // Haftalık ödeme listesi: (hafta, kurye) gruplaması — yalnızca ACCRUED kayıtlar ödemeye onaylanabilir.
  const weekly = new Map<string, { weekStart: Date; providerId: string; name: string; slug: string; fleetName: string | null; count: number; grossMinor: number; commissionMinor: number; netMinor: number; status: "ACCRUED" | "APPROVED_FOR_PAYOUT" | "MIXED" }>();
  for (const r of rows) {
    const ws = weekStartIstanbul(r.earnedAt);
    const key = `${ws.toISOString()}|${r.providerId}`;
    const p = provs.find((x) => x.id === r.providerId);
    const cur = weekly.get(key) ?? { weekStart: ws, providerId: r.providerId, name: p?.name ?? "Kurye", slug: p?.slug ?? "", fleetName: r.fleetId ? fls.find((f) => f.id === r.fleetId)?.name ?? null : null, count: 0, grossMinor: 0, commissionMinor: 0, netMinor: 0, status: r.status as "ACCRUED" | "APPROVED_FOR_PAYOUT" };
    cur.count += 1; cur.grossMinor += r.grossMinor; cur.commissionMinor += r.commissionMinor; cur.netMinor += r.netMinor;
    if (cur.status !== r.status) cur.status = "MIXED";
    weekly.set(key, cur);
  }
  const fleetTotals = fls.map((f) => {
    const mine = rows.filter((r) => r.fleetId === f.id);
    return { id: f.id, name: f.name, slug: f.slug, count: mine.length, grossMinor: sum(mine, "grossMinor"), netMinor: sum(mine, "netMinor"), accruedNetMinor: sum(mine.filter((r) => r.status === "ACCRUED"), "netMinor") };
  }).filter((f) => f.count > 0);
  return {
    commissionBps,
    totals: {
      grossMinor: sum(rows, "grossMinor"),
      commissionMinor: sum(rows, "commissionMinor"),
      netMinor: sum(rows, "netMinor"),
      accruedNetMinor: sum(accrued, "netMinor"),
      approvedNetMinor: sum(approved, "netMinor"),
      count: rows.length,
    },
    weekly: [...weekly.values()].sort((a, b) => b.weekStart.getTime() - a.weekStart.getTime() || b.netMinor - a.netMinor),
    fleetTotals,
    recent: rows.slice(0, 15).map((r) => ({ ...r, providerName: provs.find((p) => p.id === r.providerId)?.name ?? "Kurye" })),
  };
}

/* ---------------- Filolar ---------------- */
export async function adminFleets() {
  const [fls, provs, owners, earn] = await Promise.all([
    db.select().from(fleets).orderBy(asc(fleets.name)),
    db.select({ fleetId: providers.fleetId, status: providers.status, verified: providers.isVerified }).from(providers),
    db.select({ id: users.id, name: users.name }).from(users),
    db.select({ fleetId: providerEarnings.fleetId, gross: providerEarnings.grossMinor }).from(providerEarnings),
  ]);
  return fls.map((f) => {
    const members = provs.filter((p) => p.fleetId === f.id);
    return {
      ...f,
      ownerName: owners.find((o) => o.id === f.ownerUserId)?.name ?? "—",
      members: members.length,
      available: members.filter((m) => m.status === "AVAILABLE").length,
      onTask: members.filter((m) => m.status === "ON_TASK" || m.status === "BUSY").length,
      unverified: members.filter((m) => !m.verified).length,
      grossMinor: earn.filter((e) => e.fleetId === f.id).reduce((a, e) => a + e.gross, 0),
    };
  });
}

export async function lockedDeliveries() {
  return db
    .select({ id: serviceRequests.id, code: serviceRequests.code, attempts: serviceRequests.otpAttempts, lockedAt: serviceRequests.otpLockedAt, linkedOrderId: serviceRequests.linkedOrderId, providerName: providers.displayName })
    .from(serviceRequests)
    .leftJoin(assignments, eq(assignments.requestId, serviceRequests.id))
    .leftJoin(providers, eq(providers.id, assignments.providerId))
    .where(and(isNotNull(serviceRequests.otpLockedAt), eq(serviceRequests.status, "IN_PROGRESS")))
    .orderBy(desc(serviceRequests.otpLockedAt));
}

export async function failedOtpAttempts() {
  return db
    .select({ id: serviceRequests.id, code: serviceRequests.code, attempts: serviceRequests.otpAttempts })
    .from(serviceRequests)
    .where(and(isNull(serviceRequests.otpLockedAt), sql`${serviceRequests.otpAttempts} > 0`, eq(serviceRequests.status, "IN_PROGRESS")));
}
