import { createHash, randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { and, eq, gt, isNull } from "drizzle-orm";
import { db } from "@/db";
import { authSessions, fleets, providerShifts, providers, restaurants, users, type User } from "@/db/schema";
import { ensureSeed } from "./seed";
import { HttpError } from "./http";

import { SESSION_COOKIE, SESSION_TTL_SECONDS } from "./session-constants";
export { SESSION_COOKIE, SESSION_TTL_SECONDS } from "./session-constants";

export type Session = {
  user: User;
  providerId: string | null;
  fleetId: string | null;
  restaurantId: string | null;
  authenticated: boolean;
};

/** Demo hesaplar: DISABLE_DEMO_ACCOUNTS=true ile kapatılır; gerçek kimlik sağlayıcısı bağlanınca üretimde kapatılmalıdır. */
export { demoEnabled } from "./auth-mode";
export const hashSessionToken = (token: string) => createHash("sha256").update(token).digest("hex");

export async function lookupSessionUser(token: string | undefined): Promise<User | null> {
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const [row] = await db
    .select({ user: users })
    .from(authSessions)
    .innerJoin(users, eq(users.id, authSessions.userId))
    .where(and(eq(authSessions.tokenHash, hashSessionToken(token)), gt(authSessions.expiresAt, new Date())))
    .limit(1);
  if (!row?.user || row.user.isSuspended) return null;
  return row.user;
}

export async function issueSession(userId: string) {
  const token = randomBytes(32).toString("hex");
  await db.insert(authSessions).values({
    tokenHash: hashSessionToken(token),
    userId,
    expiresAt: new Date(Date.now() + SESSION_TTL_SECONDS * 1000),
  });
  return token;
}

export async function revokeSession(token: string | undefined) {
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return;
  await db.delete(authSessions).where(eq(authSessions.tokenHash, hashSessionToken(token)));
}

/** Kurye oturumu terk edince boşta açık kalmaz; devam eden göreve müdahale edilmez. */
export async function closeProviderAvailability(userId: string) {
  await db.transaction(async (tx) => {
    const [provider] = await tx.select().from(providers).where(eq(providers.userId, userId)).for("update").limit(1);
    if (!provider || ["BUSY", "ON_TASK"].includes(provider.status)) return;
    if (["AVAILABLE", "PAUSED"].includes(provider.status)) {
      await tx.update(providers).set({ status: "OFFLINE", lastSeenAt: new Date() }).where(eq(providers.id, provider.id));
    }
    await tx.update(providerShifts).set({ endedAt: new Date() }).where(and(eq(providerShifts.providerId, provider.id), isNull(providerShifts.endedAt)));
  });
}

async function hydrate(user: User, authenticated: boolean): Promise<Session> {
  const [prov, fleet, restaurant] = await Promise.all([
    user.role === "PROVIDER" ? db.select({ id: providers.id }).from(providers).where(eq(providers.userId, user.id)).limit(1) : Promise.resolve([]),
    user.role === "FLEET_OWNER" ? db.select({ id: fleets.id }).from(fleets).where(eq(fleets.ownerUserId, user.id)).limit(1) : Promise.resolve([]),
    user.role === "RESTAURANT_OWNER" ? db.select({ id: restaurants.id }).from(restaurants).where(eq(restaurants.ownerUserId, user.id)).limit(1) : Promise.resolve([]),
  ]);
  return { user, providerId: prov[0]?.id ?? null, fleetId: fleet[0]?.id ?? null, restaurantId: restaurant[0]?.id ?? null, authenticated };
}

/** Özel sayfalar ve API'lerde kullanılır; misafire asla başka hesabın verilerini açmaz. */
export async function getSession(): Promise<Session> {
  await ensureSeed();
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  const user = await lookupSessionUser(token);
  if (!user) throw new HttpError(401, "Devam etmek için giriş yapın.");
  return hydrate(user, true);
}

/** Yalnızca public SSR sayfalarında kullanılabilir. Misafir hesabı DB kullanıcısı değildir. */
export async function getPublicSession(): Promise<Session> {
  await ensureSeed();
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  const user = await lookupSessionUser(token);
  if (user) return hydrate(user, true);
  return {
    user: { id: "guest", name: "Misafir", email: "", role: "GUEST", passwordHash: null, isSuspended: false, suspendedReason: null, createdAt: new Date() },
    providerId: null,
    fleetId: null,
    restaurantId: null,
    authenticated: false,
  };
}

export async function requirePageSession() {
  try {
    return await getSession();
  } catch (error) {
    if (error instanceof HttpError && error.status === 401) redirect("/giris?next=/dashboard");
    throw error;
  }
}

export async function requireRole(...roles: string[]) {
  const s = await getSession();
  const allowed = roles.includes(s.user.role) || (s.user.role === "SUPER_ADMIN" && roles.includes("ADMIN"));
  if (!allowed) throw new HttpError(403, "Bu işlem için yetkiniz yok.");
  return s;
}

/** İzin matrisi — kontrol yalnızca UI'da yapılmaz. */
export const PERMISSIONS: Record<string, string[]> = {
  "review:create": ["CUSTOMER"],
  "review:respond": ["PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER", "ADMIN"],
  "review:report": ["CUSTOMER", "PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER", "ADMIN"],
  "review:appeal": ["PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER"],
  "review:moderate": ["ADMIN"],
  "profile_media:upload": ["PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER"],
  "profile_media:moderate": ["ADMIN"],
  "profile_report:create": ["CUSTOMER", "PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER", "ADMIN"],
  "menu:manage_own": ["RESTAURANT_OWNER", "ADMIN"],
  "order:accept": ["RESTAURANT_OWNER", "ADMIN"],
  "order:read_own": ["CUSTOMER", "RESTAURANT_OWNER", "ADMIN"],
  "cart:manage": ["CUSTOMER"],
  "application:create": ["CUSTOMER", "PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER", "ADMIN"],
  "application:review": ["ADMIN"],
};

export function can(s: Session, permission: string) {
  const roles = PERMISSIONS[permission] ?? [];
  return roles.includes(s.user.role) || (s.user.role === "SUPER_ADMIN" && roles.includes("ADMIN"));
}

export function requirePermission(s: Session, permission: string) {
  if (!can(s, permission)) throw new HttpError(403, "Bu işlem için yetkiniz yok.");
}

export const isSuperAdmin = (s: Session) => s.user.role === "SUPER_ADMIN";
