import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLogs,
  contentReports,
  fleets,
  mediaPosts,
  moderationCases,
  notifications,
  orders,
  providers,
  restaurants,
  reviewAppeals,
  reviewResponses,
  reviewRevisions,
  reviews,
  users,
  type ReviewRow,
} from "@/db/schema";
import { audit, recomputeRating } from "./engine";
import { HttpError } from "./http";
import type { Session } from "./session";

export const EDIT_WINDOW_HOURS = 48;

async function targetLabel(targetType: string, targetId: string) {
  if (targetType === "PROVIDER") return (await db.select({ n: providers.displayName }).from(providers).where(eq(providers.id, targetId)).limit(1))[0]?.n;
  if (targetType === "FLEET") return (await db.select({ n: fleets.name }).from(fleets).where(eq(fleets.id, targetId)).limit(1))[0]?.n;
  if (targetType === "RESTAURANT") return (await db.select({ n: restaurants.name }).from(restaurants).where(eq(restaurants.id, targetId)).limit(1))[0]?.n;
  return undefined;
}

/** Yorum hedefinin sahibi mi? (yanıt hakkı) */
async function ownsTarget(s: Session, r: ReviewRow) {
  if (["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) return true;
  if (r.targetType === "PROVIDER" && s.providerId === r.targetId) return true;
  if (r.targetType === "FLEET" && s.fleetId === r.targetId) return true;
  if (r.targetType === "RESTAURANT" && s.restaurantId === r.targetId) return true;
  return false;
}

export async function respondToReview(s: Session, reviewId: string, body: string) {
  const clean = body.trim();
  if (clean.length < 10) throw new HttpError(422, "Yanıt en az 10 karakter olmalı.");
  if (clean.length > 1500) throw new HttpError(422, "Yanıt en fazla 1500 karakter.");
  return db.transaction(async (tx) => {
    const [r] = await tx.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
    if (!r) throw new HttpError(404, "Değerlendirme bulunamadı.");
    if (!(await ownsTarget(s, r))) throw new HttpError(403, "Yalnızca değerlendirilen taraf yanıt verebilir.");
    if (r.status !== "PUBLISHED") throw new HttpError(409, "Gizli değerlendirmelere yanıt verilemez.");
    const [ex] = await tx.select().from(reviewResponses).where(eq(reviewResponses.reviewId, reviewId)).limit(1);
    if (ex) {
      await tx.update(reviewResponses).set({ body: clean, status: "PUBLISHED", createdAt: new Date() }).where(eq(reviewResponses.id, ex.id));
    } else {
      await tx.insert(reviewResponses).values({ reviewId, responderId: s.user.id, responderRole: s.user.role, body: clean });
    }
    await audit(tx, s.user.id, "review.respond", "review", reviewId, undefined, { chars: clean.length });
    await tx.insert(notifications).values({ userId: r.authorId, title: "Değerlendirmenize yanıt geldi", body: clean.slice(0, 90) + (clean.length > 90 ? "…" : ""), link: r.targetType === "RESTAURANT" ? "/siparislerim" : "/taleplerim" });
    return { ok: true };
  });
}

export async function reportReview(s: Session, reviewId: string, reason: string, detail?: string) {
  const [r] = await db.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
  if (!r) throw new HttpError(404, "Değerlendirme bulunamadı.");
  if (r.authorId === s.user.id) throw new HttpError(422, "Kendi değerlendirmenizi bildiremezsiniz.");
  await db.insert(contentReports).values({ reporterId: s.user.id, targetType: "REVIEW", targetId: reviewId, reason, detail: detail?.trim() || null }).onConflictDoNothing();
  await db.insert(moderationCases).values({ kind: "REVIEW", targetType: "REVIEW", targetId: reviewId, status: "OPEN", reason });
  await audit(db, s.user.id, "review.report", "review", reviewId, reason);
  return { ok: true };
}

export async function appealReview(s: Session, reviewId: string, reason: string) {
  if (reason.trim().length < 20) throw new HttpError(422, "İtiraz gerekçesi en az 20 karakter olmalı.");
  return db.transaction(async (tx) => {
    const [r] = await tx.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
    if (!r) throw new HttpError(404, "Değerlendirme bulunamadı.");
    if (!(await ownsTarget(s, r))) throw new HttpError(403, "İtiraz hakkı yalnızca değerlendirilen tarafa aittir.");
    const [dup] = await tx.select({ id: reviewAppeals.id }).from(reviewAppeals).where(and(eq(reviewAppeals.reviewId, reviewId), eq(reviewAppeals.appellantId, s.user.id))).limit(1);
    if (dup) throw new HttpError(409, "Bu değerlendirme için zaten bir itirazınız var.");
    await tx.insert(reviewAppeals).values({ reviewId, appellantId: s.user.id, appellantRole: s.user.role, reason: reason.trim() });
    await tx.insert(moderationCases).values({ kind: "APPEAL", targetType: "REVIEW", targetId: reviewId, status: "OPEN", reason: reason.trim() });
    await audit(tx, s.user.id, "review.appeal", "review", reviewId, reason.trim());
    return { ok: true };
  });
}

export async function decideAppeal(s: Session, appealId: string, decision: "ACCEPTED" | "REJECTED", note: string) {
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) throw new HttpError(403, "İtiraz kararı yalnızca operasyon ekibine aittir.");
  if (note.trim().length < 5) throw new HttpError(422, "Karar gerekçesi zorunlu (en az 5 karakter).");
  return db.transaction(async (tx) => {
    const [a] = await tx.select().from(reviewAppeals).where(eq(reviewAppeals.id, appealId)).limit(1);
    if (!a) throw new HttpError(404, "İtiraz bulunamadı.");
    if (a.status !== "OPEN") throw new HttpError(409, "Bu itiraz zaten karara bağlanmış.");
    await tx.update(reviewAppeals).set({ status: decision, decisionNote: note.trim(), decidedBy: s.user.id, decidedAt: new Date() }).where(eq(reviewAppeals.id, appealId));
    if (decision === "ACCEPTED") {
      await tx.update(reviews).set({ status: "HIDDEN", moderationReason: `İtiraz kabul edildi: ${note.trim()}` }).where(eq(reviews.id, a.reviewId));
      const [r] = await tx.select().from(reviews).where(eq(reviews.id, a.reviewId)).limit(1);
      if (r) await recomputeRating(tx, r.targetId);
    }
    await tx.update(moderationCases).set({ status: decision === "ACCEPTED" ? "HIDDEN" : "APPROVED", decidedBy: s.user.id, decidedAt: new Date(), reason: note.trim() }).where(and(eq(moderationCases.kind, "APPEAL"), eq(moderationCases.targetId, a.reviewId), eq(moderationCases.status, "OPEN")));
    await audit(tx, s.user.id, `appeal.${decision.toLowerCase()}`, "review_appeal", appealId, note.trim(), { reviewId: a.reviewId });
    await tx.insert(notifications).values({ userId: a.appellantId, title: decision === "ACCEPTED" ? "İtirazınız kabul edildi" : "İtirazınız reddedildi", body: note.trim(), link: "/panel" });
    return { ok: true };
  });
}

/** Kullanıcı kendi yorumunu sınırlı süre içinde düzenleyebilir; eski sürüm saklanır. */
export async function editOwnReview(s: Session, reviewId: string, input: { rating?: number; body?: string }) {
  return db.transaction(async (tx) => {
    const [r] = await tx.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
    if (!r || r.authorId !== s.user.id) throw new HttpError(404, "Değerlendirme bulunamadı.");
    const ageH = (Date.now() - r.createdAt.getTime()) / 3600000;
    if (ageH > EDIT_WINDOW_HOURS) throw new HttpError(422, `Düzenleme süresi (${EDIT_WINDOW_HOURS} saat) doldu.`);
    if (input.rating != null && (input.rating < 1 || input.rating > 5)) throw new HttpError(422, "Puan 1-5 arası olmalı.");
    await tx.insert(reviewRevisions).values({ reviewId, rating: r.rating, body: r.body, editedBy: s.user.id });
    await tx.update(reviews).set({ rating: input.rating ?? r.rating, body: input.body !== undefined ? input.body.trim() || null : r.body }).where(eq(reviews.id, reviewId));
    await recomputeRating(tx, r.targetId);
    await audit(tx, s.user.id, "review.edit_own", "review", reviewId, undefined, { ageHours: Math.round(ageH) });
    return { ok: true };
  });
}

export async function moderateReview(s: Session, reviewId: string, action: "hide" | "publish" | "mask_pii", reason: string, policyRef?: string) {
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) throw new HttpError(403, "Moderasyon yalnızca operasyon ekibine açıktır.");
  if (reason.trim().length < 5) throw new HttpError(422, "Gerekçe zorunlu (en az 5 karakter).");
  return db.transaction(async (tx) => {
    const [r] = await tx.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
    if (!r) throw new HttpError(404, "Değerlendirme bulunamadı.");
    const before = { status: r.status, body: r.body, rating: r.rating };
    let body = r.body;
    if (action === "mask_pii" && body) body = maskPii(body);
    await tx.update(reviews).set({ status: action === "hide" ? "HIDDEN" : "PUBLISHED", body, moderationReason: reason }).where(eq(reviews.id, reviewId));
    await recomputeRating(tx, r.targetId);
    await tx.update(moderationCases).set({ status: action === "hide" ? "HIDDEN" : "APPROVED", reason, policyRef: policyRef ?? null, decidedBy: s.user.id, decidedAt: new Date() }).where(and(eq(moderationCases.targetId, reviewId), eq(moderationCases.status, "OPEN")));
    await tx.update(contentReports).set({ status: action === "hide" ? "RESOLVED" : "DISMISSED" }).where(and(eq(contentReports.targetType, "REVIEW"), eq(contentReports.targetId, reviewId), eq(contentReports.status, "OPEN")));
    await audit(tx, s.user.id, `review.${action}`, "review", reviewId, reason, { before, after: { status: action === "hide" ? "HIDDEN" : "PUBLISHED" }, policyRef });
    await tx.insert(notifications).values({ userId: r.authorId, title: action === "hide" ? "Değerlendirmeniz gizlendi" : "Değerlendirmeniz güncellendi", body: reason, link: "/taleplerim" });
    return { ok: true };
  });
}

/** Telefon, adres benzeri kişisel verileri maskeler. */
export function maskPii(text: string) {
  return text
    .replace(/(\+?90[\s-]?)?(\(?\d{3}\)?[\s-]?){2}\d{2}[\s-]?\d{2}/g, "[telefon-maskelendi]")
    .replace(/\b\d{1,3}\s?(No|NO|no)\.?\s?\d{1,4}\b/g, "[adres-maskelendi]")
    .replace(/\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b/g, "[eposta-maskelendi]");
}

export async function reviewModerationData(tab: "all" | "reported" | "appeals") {
  const base = await db
    .select({ r: reviews, author: users.name, reviewer: users.name })
    .from(reviews)
    .leftJoin(users, eq(users.id, reviews.authorId))
    .orderBy(desc(reviews.createdAt))
    .limit(60);
  const targets = await Promise.all(base.map((b) => targetLabel(b.r.targetType, b.r.targetId)));
  const responses = await db.select().from(reviewResponses);
  const reports = await db
    .select({ c: contentReports, reporter: users.name })
    .from(contentReports)
    .leftJoin(users, eq(users.id, contentReports.reporterId))
    .where(eq(contentReports.targetType, "REVIEW"))
    .orderBy(desc(contentReports.createdAt))
    .limit(60);
  const appeals = await db
    .select({ a: reviewAppeals, appellant: users.name })
    .from(reviewAppeals)
    .leftJoin(users, eq(users.id, reviewAppeals.appellantId))
    .orderBy(desc(reviewAppeals.createdAt))
    .limit(60);
  const logs = await db.select().from(auditLogs).where(sql`${auditLogs.action} LIKE 'review.%'`).orderBy(desc(auditLogs.createdAt)).limit(25);
  const items = base.map((b, i) => ({
    id: b.r.id,
    rating: b.r.rating,
    body: b.r.body,
    status: b.r.status,
    reason: b.r.moderationReason,
    createdAt: b.r.createdAt,
    author: maskName(b.author ?? "Müşteri"),
    targetType: b.r.targetType,
    targetName: targets[i] ?? "—",
    response: responses.find((x) => x.reviewId === b.r.id)?.body ?? null,
    reportCount: reports.filter((x) => x.c.targetId === b.r.id).length,
  }));
  return {
    tab,
    items: tab === "reported" ? items.filter((i) => i.reportCount > 0) : items,
    reports: reports.map((x) => ({ id: x.c.id, targetId: x.c.targetId, reason: x.c.reason, detail: x.c.detail, status: x.c.status, createdAt: x.c.createdAt, reporter: maskName(x.reporter ?? "Kullanıcı") })),
    appeals: appeals.map((x) => ({ id: x.a.id, reviewId: x.a.reviewId, reason: x.a.reason, status: x.a.status, note: x.a.decisionNote, createdAt: x.a.createdAt, appellant: x.appellant ?? "—" })),
    logs,
  };
}

function maskName(n: string) {
  const [first, ...rest] = n.split(" ");
  return [first, ...rest.map((r) => r[0] + ".")].join(" ");
}

export async function profileReports() {
  const rows = await db.select().from(contentReports).where(inArray(contentReports.targetType, ["PROVIDER", "FLEET", "RESTAURANT", "MEDIA"])).orderBy(desc(contentReports.createdAt)).limit(80);
  const names: Record<string, string> = {};
  const [provs, fls, rests, posts] = await Promise.all([
    db.select({ id: providers.id, n: providers.displayName }).from(providers),
    db.select({ id: fleets.id, n: fleets.name }).from(fleets),
    db.select({ id: restaurants.id, n: restaurants.name }).from(restaurants),
    db.select({ id: mediaPosts.id, n: mediaPosts.caption }).from(mediaPosts),
  ]);
  for (const x of [...provs, ...fls, ...rests, ...posts]) names[x.id] = x.n ?? "—";
  return rows.map((r) => ({ ...r, targetName: names[r.targetId] ?? "—" }));
}

export async function resolveReport(s: Session, reportId: string, action: "RESOLVED" | "DISMISSED", note: string) {
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) throw new HttpError(403, "Bu işlem operasyon ekibine açıktır.");
  if (note.trim().length < 5) throw new HttpError(422, "Karar notu zorunlu (en az 5 karakter).");
  const [r] = await db.select().from(contentReports).where(eq(contentReports.id, reportId)).limit(1);
  if (!r) throw new HttpError(404, "Bildirim bulunamadı.");
  await db.update(contentReports).set({ status: action }).where(eq(contentReports.id, reportId));
  await db.update(moderationCases).set({ status: action === "RESOLVED" ? "REJECTED" : "APPROVED", reason: note.trim(), decidedBy: s.user.id, decidedAt: new Date() }).where(and(eq(moderationCases.kind, "REPORT"), eq(moderationCases.targetId, r.targetId), eq(moderationCases.status, "OPEN")));
  await audit(db, s.user.id, `report.${action.toLowerCase()}`, "content_report", reportId, note.trim(), { targetType: r.targetType, targetId: r.targetId });
  return { ok: true };
}

export async function reviewTargetsFor(sessionUserId: string) {
  const mine = await db.select({ id: reviews.id }).from(reviews).where(eq(reviews.authorId, sessionUserId));
  return mine.map((m) => m.id);
}

export async function orderStatsFor(restaurantId: string) {
  const [row] = await db
    .select({ n: sql<number>`count(*)::int`, revenue: sql<number>`coalesce(sum(${orders.totalMinor}) filter (where ${orders.status}='DELIVERED'),0)::bigint` })
    .from(orders)
    .where(eq(orders.restaurantId, restaurantId));
  return { orders: row?.n ?? 0, revenue: Number(row?.revenue ?? 0) };
}
