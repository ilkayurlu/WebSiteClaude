/**
 * Sunucu tarafı coğrafi API. İstemci bileşenleri `@/lib/geo-math` (saf matematik)
 * ve `/api/geo/*` uçlarını kullanır; mahalle veri seti istemciye gönderilmez.
 */
export { haversineM, roadDistanceM, etaSeconds, etaBand, distanceBand, slugify } from "./geo-math";
export {
  CITIES, getCities, getCity, getDistricts, getDistrict, getNeighborhoods, getNeighborhood,
  searchStreets, resolveArea, normalizeAreaSlug, isValidAreaSlug, areaLabel, areaLabelWithCity,
  routeLabel, districtsForSlugs, LEGACY_AREA_KEYS,
} from "./geo-data";
export type { CityOption, DistrictOption, NeighborhoodOption, StreetOption, ResolvedArea } from "./geo-data";

import { resolveArea } from "./geo-data";

export type Area = { key: string; name: string; lat: number; lng: number; cityName: string };

/** Geriye dönük uyumluluk: eski `getArea("kadikoy")` çağrıları kanonik ilçeye çözülür. */
export function getArea(key: string | null | undefined): Area | undefined {
  const area = resolveArea(key);
  if (!area) return undefined;
  return { key: area.slug, name: area.name, lat: area.lat, lng: area.lng, cityName: area.cityName };
}

export function areaName(key: string | null | undefined) {
  return resolveArea(key)?.name ?? "—";
}
