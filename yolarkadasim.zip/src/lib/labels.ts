export const VEHICLES: Record<string, { label: string; icon: string }> = {
  BICYCLE: { label: "Bisiklet", icon: "🚲" },
  MOTORCYCLE: { label: "Motosiklet", icon: "🏍️" },
  CAR: { label: "Otomobil", icon: "🚗" },
  VAN: { label: "Panelvan", icon: "🚐" },
  TRUCK: { label: "Kamyonet", icon: "🚚" },
  COLD_CHAIN_VAN: { label: "Soğuk Zincir", icon: "❄️" },
  MINIBUS: { label: "Minibüs", icon: "🚌" },
};

export const SERVICES: Record<string, { label: string; icon: string; desc: string }> = {
  PACKAGE: { label: "Paket", icon: "📦", desc: "Al-götür, evrak, koli" },
  FOOD: { label: "Yemek", icon: "🍲", desc: "Restoran & market teslimatı" },
  PASSENGER: { label: "Yolcu", icon: "🧳", desc: "Transfer, havalimanı" },
  RENTAL: { label: "Kiralık", icon: "⏱️", desc: "Saatlik araç + sürücü" },
};

export const KINDS: Record<string, string> = {
  COURIER: "Kurye",
  DRIVER: "Sürücü",
  VEHICLE_OPERATOR: "Araçlı Taşıyıcı",
};

export const MODES: Record<string, { label: string; short: string; icon: string; desc: string }> = {
  INSTANT_CALL: { label: "Hemen Çağır", short: "Çağır", icon: "⚡", desc: "Şimdi, tek görev: al-getir veya beni al-bırak" },
  SCHEDULED: { label: "Randevu Oluştur", short: "Randevu", icon: "📅", desc: "İleri tarihli, saat dilimli görev" },
  INSTANT_RENT: { label: "Hemen Kirala", short: "Kirala", icon: "⏱️", desc: "Saatlik araç + kişi tahsisi" },
};

export const STRATEGIES: Record<string, string> = {
  AUTO: "Sistem seçti (en uygun)",
  FAVORITE: "Favorimden",
  MANUAL_PROVIDER: "Kendim seçtim",
  MANUAL_FLEET: "Filo seçtim",
};

export const PROVIDER_STATUS: Record<string, { label: string; tone: string }> = {
  OFFLINE: { label: "Çevrimdışı", tone: "slate" },
  AVAILABLE: { label: "Müsait", tone: "green" },
  BUSY: { label: "Meşgul", tone: "amber" },
  ON_TASK: { label: "Görevde", tone: "blue" },
  PAUSED: { label: "Mola", tone: "amber" },
  SUSPENDED: { label: "Askıda", tone: "red" },
};

export const REQUEST_STATUS: Record<string, { label: string; tone: string; customer: string }> = {
  QUOTED: { label: "Teklif hazır", tone: "slate", customer: "Fiyat ve adaylar hazır. Kimin getireceğini seçin." },
  MATCHING: { label: "Eşleştiriliyor", tone: "amber", customer: "Uygun sağlayıcı aranıyor…" },
  OFFERED: { label: "Talep iletildi", tone: "amber", customer: "Talebiniz iletildi. Onay bekleniyor." },
  CONFIRMED: { label: "Onaylandı", tone: "green", customer: "Talebiniz onaylandı. Sağlayıcınız yola çıkmaya hazırlanıyor." },
  IN_PROGRESS: { label: "Yolda", tone: "blue", customer: "Görev sürüyor. Teslimde kodu paylaşın." },
  COMPLETED: { label: "Tamamlandı", tone: "green", customer: "Görev tamamlandı. Deneyiminizi değerlendirebilirsiniz." },
  EXPIRED: { label: "Uygun sağlayıcı yok", tone: "red", customer: "Şu anda uygun sağlayıcı bulunamadı. Randevu oluşturmayı deneyebilirsiniz." },
  CANCELLED_BY_CUSTOMER: { label: "İptal (müşteri)", tone: "red", customer: "Talebi iptal ettiniz." },
  CANCELLED_BY_PROVIDER: { label: "İptal (sağlayıcı)", tone: "red", customer: "Sağlayıcı talebi iptal etti." },
  CANCELLED_BY_OPS: { label: "İptal (operasyon)", tone: "red", customer: "Talep operasyon ekibi tarafından iptal edildi." },
};

export const FLEET_POLICY: Record<string, { label: string; desc: string }> = {
  DIRECT_ALLOWED: { label: "Doğrudan kabul", desc: "Üyeler talebi kendisi kabul eder, filo sahibine bilgi gider." },
  FLEET_APPROVAL_REQUIRED: { label: "Filo onayı gerekli", desc: "Talep önce filo kuyruğuna düşer; onay veya yönlendirme yapılır." },
  FLEET_ONLY: { label: "Yalnızca filo", desc: "Müşteri sadece filoyu seçebilir; üyeler bireysel çağrılamaz." },
};

export const ROLES: Record<string, string> = {
  CUSTOMER: "Müşteri",
  PROVIDER: "Hizmet Sağlayıcı",
  FLEET_OWNER: "Filo Sahibi",
  RESTAURANT_OWNER: "İşletme Sahibi",
  ADMIN: "Operasyon / Admin",
  SUPER_ADMIN: "Platform Yöneticisi",
};

export const CUISINES = [
  { key: "KEBAB", label: "Kebap & Izgara", icon: "🍢" },
  { key: "PIDE", label: "Pide & Lahmacun", icon: "🫓" },
  { key: "HOME", label: "Ev Yemekleri", icon: "🍲" },
  { key: "CAFE", label: "Kafe & Tatlı", icon: "☕" },
  { key: "BURGER", label: "Burger", icon: "🍔" },
  { key: "SEAFOOD", label: "Deniz Ürünleri", icon: "🐟" },
  { key: "VEGAN", label: "Vegan", icon: "🥗" },
  { key: "MARKET", label: "Market", icon: "🛒" },
] as const;

export function cuisineLabel(k: string) {
  return CUISINES.find((c) => c.key === k)?.label ?? k;
}
export function cuisineIcon(k: string) {
  return CUISINES.find((c) => c.key === k)?.icon ?? "🍽️";
}

export const ORDER_STATUS: Record<string, { label: string; tone: string; step: number; customer: string }> = {
  ORDER_PLACED: { label: "Sipariş alındı", tone: "slate", step: 0, customer: "Siparişiniz işletmeye iletildi. Onay bekleniyor." },
  RESTAURANT_ACCEPTED: { label: "İşletme onayladı", tone: "green", step: 1, customer: "İşletme siparişinizi kabul etti." },
  PREPARING: { label: "Hazırlanıyor", tone: "amber", step: 2, customer: "Siparişiniz mutfakta hazırlanıyor." },
  READY_FOR_PICKUP: { label: "Kurye bekleniyor", tone: "amber", step: 3, customer: "Siparişiniz hazır. Uygun kurye aranıyor." },
  COURIER_ASSIGNED: { label: "Kurye atandı", tone: "blue", step: 4, customer: "Kuryeniz atandı, siparişi almaya geliyor." },
  OUT_FOR_DELIVERY: { label: "Yolda", tone: "blue", step: 5, customer: "Siparişiniz yola çıktı." },
  DELIVERED: { label: "Teslim edildi", tone: "green", step: 6, customer: "Siparişiniz teslim edildi. Afiyet olsun!" },
  RESTAURANT_REJECTED: { label: "İşletme reddetti", tone: "red", step: -1, customer: "İşletme siparişinizi kabul edemedi." },
  CANCELLED: { label: "İptal edildi", tone: "red", step: -1, customer: "Sipariş iptal edildi." },
  REFUND_PENDING: { label: "İade bekliyor", tone: "amber", step: -1, customer: "İade talebiniz inceleniyor." },
  REFUNDED: { label: "İade edildi", tone: "green", step: -1, customer: "Tutarınız iade edildi." },
  UNDER_REVIEW: { label: "İncelemede", tone: "amber", step: -1, customer: "Siparişiniz operasyon incelemesinde." },
};

export const PRODUCT_STATUS: Record<string, string> = {
  DRAFT: "Taslak",
  PUBLISHED: "Yayında",
  OFF: "Pasif",
  ARCHIVED: "Arşiv",
};

export const MEDIA_STATUS: Record<string, { label: string; tone: string }> = {
  DRAFT: { label: "Taslak", tone: "slate" },
  PENDING_REVIEW: { label: "İnceleme bekliyor", tone: "amber" },
  APPROVED: { label: "Onaylandı", tone: "blue" },
  PUBLISHED: { label: "Yayında", tone: "green" },
  REJECTED: { label: "Reddedildi", tone: "red" },
  ARCHIVED: { label: "Arşiv", tone: "slate" },
};

export const REPORT_REASONS: Record<string, string> = {
  SPAM: "Spam / reklam",
  HARASSMENT: "Taciz veya hakaret",
  PII: "Kişisel veri içeriyor",
  MISLEADING: "Yanıltıcı iddia",
  ILLEGAL: "Yasa dışı içerik",
  SAFETY: "Trafik / güvenlik ihlali",
  COPYRIGHT: "Telif ihlali",
  OTHER: "Diğer",
};

export const MEDIA_POLICY = [
  { ref: "M-1", label: "Kişisel veri", desc: "Müşteri adresi, telefon, kapı numarası, teslimat belgesi veya müşteri yüzü görünmemeli." },
  { ref: "M-2", label: "Güvenlik", desc: "Araç kullanırken çekilmiş, dikkat dağıtan veya trafik kuralı ihlali içeren içerik yasak." },
  { ref: "M-3", label: "Aldatıcı iddia", desc: "“Kesin teslimat”, “garantili en hızlı” gibi doğrulanamaz vaatler kullanılamaz." },
  { ref: "M-4", label: "Genel içerik", desc: "Hakaret, nefret, taciz, şiddet, yetişkin içerik veya rakip marka taklidi yasak." },
];

export const ALLERGENS = ["Gluten", "Süt", "Yumurta", "Kuruyemiş", "Susam", "Deniz ürünü", "Soya", "Hardal"];

export const FAQ_PROVIDER = [
  { q: "Talebi kabul etme süreniz ne kadar?", a: "Teklif geldiğinde 60 saniye içinde yanıtlamanız beklenir; süre dolarsa talep sıradaki uygun sağlayıcıya geçer." },
  { q: "Fiyatı ben mi belirliyorum?", a: "Hayır. Tutar açılış ücreti + km başı ücretinizle sunucuda hesaplanır. Kiralamada saatlik ücretiniz esas alınır." },
  { q: "Telefon numaram müşteride görünür mü?", a: "Hayır. Numaranız gizlidir; iletişim yalnızca görev süresince platform üzerinden sağlanır." },
  { q: "Değerlendirmeyi silebilir miyim?", a: "Puanınızı silemezsiniz; ancak yanıt verebilir, kural ihlali varsa itiraz edebilirsiniz. Kararı moderasyon verir." },
];

export function money(minor: number | null | undefined, currency = "TRY") {
  if (minor == null) return "—";
  return new Intl.NumberFormat("tr-TR", { style: "currency", currency, maximumFractionDigits: 2 }).format(
    minor / 100,
  );
}

export function dateTime(d: Date | string | null | undefined) {
  if (!d) return "—";
  return new Intl.DateTimeFormat("tr-TR", {
    day: "2-digit",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Istanbul",
  }).format(new Date(d));
}

export function timeAgo(d: Date | string) {
  const s = Math.round((Date.now() - new Date(d).getTime()) / 1000);
  if (s < 60) return "az önce";
  if (s < 3600) return `${Math.floor(s / 60)} dk önce`;
  if (s < 86400) return `${Math.floor(s / 3600)} sa önce`;
  return `${Math.floor(s / 86400)} gün önce`;
}
