import { createHash } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { and, eq, gte, lt } from "drizzle-orm";
import { db } from "@/db";
import { notifications, providerDocuments, providerEarnings, providers } from "@/db/schema";
import { DOC_LABELS, DOC_TYPES, type DocType } from "./admin-data";
import { audit } from "./engine";
import { setCommissionBps } from "./finance";
import { HttpError } from "./http";
import { sniff, stripMetadata, MAX_IMAGE_BYTES } from "./media";
import type { Session } from "./session";

export const DOCS_DIR = path.join(process.cwd(), "storage", "private", "documents");

function requireSuper(s: Session) {
  if (s.user.role !== "SUPER_ADMIN") throw new HttpError(403, "Bu işlem platform yöneticisi yetkisi gerektirir.");
}
function requireReason(reason: string | undefined, min = 10): string {
  const r = (reason ?? "").trim();
  if (r.length < min) throw new HttpError(422, `Gerekçe zorunlu (en az ${min} karakter).`);
  return r;
}

async function syncVerification(tx: Parameters<Parameters<typeof db.transaction>[0]>[0], providerId: string) {
  const docs = await tx.select().from(providerDocuments).where(eq(providerDocuments.providerId, providerId));
  const allApproved = DOC_TYPES.every((t) => docs.some((d) => d.docType === t && d.status === "APPROVED"));
  await tx.update(providers).set({ isVerified: allApproved }).where(eq(providers.id, providerId));
  return allApproved;
}

/** Tek evrak kararı. Tüm evraklar onaylanınca rozet otomatik verilir; red rozeti kaldırır. */
export async function decideDocument(s: Session, docId: string, action: "APPROVED" | "REJECTED", note?: string) {
  requireSuper(s);
  const reason = action === "REJECTED" ? requireReason(note) : (note ?? "").trim() || "Evrak incelendi ve uygun bulundu.";
  return db.transaction(async (tx) => {
    const [doc] = await tx.select().from(providerDocuments).where(eq(providerDocuments.id, docId)).for("update").limit(1);
    if (!doc) throw new HttpError(404, "Evrak bulunamadı.");
    await tx.update(providerDocuments).set({ status: action, reviewNote: reason, reviewedBy: s.user.id, reviewedAt: new Date() }).where(eq(providerDocuments.id, doc.id));
    const verified = await syncVerification(tx, doc.providerId);
    const [p] = await tx.select({ userId: providers.userId }).from(providers).where(eq(providers.id, doc.providerId)).limit(1);
    const label = DOC_LABELS[doc.docType as DocType] ?? doc.docType;
    if (p) await tx.insert(notifications).values({ userId: p.userId, title: action === "APPROVED" ? `${label} onaylandı` : `${label} reddedildi`, body: action === "APPROVED" ? (verified ? "Tüm evraklarınız onaylandı; doğrulanmış rozetiniz aktif." : "Diğer evraklarınız inceleniyor.") : `Gerekçe: ${reason}. Yeni belge yükleyebilirsiniz.`, link: "/dashboard/kurye/profil-yonetimi" });
    await audit(tx, s.user.id, `document.${action.toLowerCase()}`, "provider_document", doc.id, reason, { providerId: doc.providerId, docType: doc.docType, verified });
    return { ok: true, verified };
  });
}

/** Tek tıkla toplu karar: onay için üç evrakın da yüklenmiş olması gerekir. */
export async function decideProviderVerification(s: Session, providerId: string, action: "APPROVE_ALL" | "REJECT_ALL", note?: string) {
  requireSuper(s);
  const reason = action === "REJECT_ALL" ? requireReason(note) : (note ?? "").trim() || "Ehliyet, ruhsat ve adli sicil evrakları incelendi.";
  return db.transaction(async (tx) => {
    const docs = await tx.select().from(providerDocuments).where(eq(providerDocuments.providerId, providerId)).for("update");
    if (action === "APPROVE_ALL") {
      const missing = DOC_TYPES.filter((t) => !docs.some((d) => d.docType === t));
      if (missing.length) throw new HttpError(422, `Eksik evrak var: ${missing.map((t) => DOC_LABELS[t]).join(", ")}. Eksik evrakla doğrulama yapılamaz.`);
    }
    if (!docs.length) throw new HttpError(422, "Bu kuryenin yüklenmiş evrakı yok.");
    const status = action === "APPROVE_ALL" ? "APPROVED" : "REJECTED";
    for (const d of docs) await tx.update(providerDocuments).set({ status, reviewNote: reason, reviewedBy: s.user.id, reviewedAt: new Date() }).where(eq(providerDocuments.id, d.id));
    const verified = await syncVerification(tx, providerId);
    const [p] = await tx.select({ userId: providers.userId }).from(providers).where(eq(providers.id, providerId)).limit(1);
    if (p) await tx.insert(notifications).values({ userId: p.userId, title: verified ? "Profiliniz doğrulandı ✓" : "Evraklarınız reddedildi", body: verified ? "Tüm evraklarınız onaylandı; doğrulanmış rozetiniz aktif." : `Gerekçe: ${reason}`, link: "/dashboard/kurye/profil-yonetimi" });
    await audit(tx, s.user.id, action === "APPROVE_ALL" ? "provider.verification.approve_all" : "provider.verification.reject_all", "provider", providerId, reason, { verified });
    return { ok: true, verified };
  });
}

const VEHICLE_TYPES = ["BICYCLE", "MOTORCYCLE", "CAR", "VAN", "TRUCK", "COLD_CHAIN_VAN", "MINIBUS"] as const;
export type VehicleType = (typeof VEHICLE_TYPES)[number];

/** Araç değişikliği yeni ruhsat gerektirir: ruhsat evrakı yeniden incelemeye düşer, rozet kalkar. */
export async function changeProviderVehicle(s: Session, providerId: string, vehicleType: VehicleType, vehicleLabel: string, reason: string) {
  requireSuper(s);
  const why = requireReason(reason);
  if (!VEHICLE_TYPES.includes(vehicleType)) throw new HttpError(422, "Geçersiz araç tipi.");
  return db.transaction(async (tx) => {
    const [p] = await tx.select().from(providers).where(eq(providers.id, providerId)).for("update").limit(1);
    if (!p) throw new HttpError(404, "Kurye bulunamadı.");
    if (p.status === "ON_TASK" || p.status === "BUSY") throw new HttpError(409, "Aktif görevdeki kuryenin aracı değiştirilemez.");
    const before = { vehicleType: p.vehicleType, vehicleLabel: p.vehicleLabel };
    await tx.update(providers).set({ vehicleType, vehicleLabel: vehicleLabel.trim().slice(0, 60) || null }).where(eq(providers.id, p.id));
    if (before.vehicleType !== vehicleType) {
      await tx.update(providerDocuments).set({ status: "REJECTED", reviewNote: "Araç değişti: yeni ruhsat gerekiyor.", reviewedBy: s.user.id, reviewedAt: new Date() }).where(and(eq(providerDocuments.providerId, p.id), eq(providerDocuments.docType, "REGISTRATION")));
      await syncVerification(tx, p.id);
    }
    await tx.insert(notifications).values({ userId: p.userId, title: "Araç bilginiz güncellendi", body: before.vehicleType !== vehicleType ? "Yeni araç için ruhsat belgesi yüklemeniz gerekiyor." : "Araç etiketi güncellendi.", link: "/dashboard/kurye/profil-yonetimi" });
    await audit(tx, s.user.id, "provider.vehicle_change", "provider", p.id, why, { before, after: { vehicleType, vehicleLabel } });
    return { ok: true };
  });
}

export async function updateCommission(s: Session, bps: number, reason: string) {
  requireSuper(s);
  const why = requireReason(reason);
  await db.transaction(async (tx) => {
    await setCommissionBps(tx, bps, s.user.id);
    await audit(tx, s.user.id, "settings.commission_update", "platform_settings", "commission_bps", why, { bps });
  });
  return { ok: true, bps };
}

/** Kurye evrak yükleme: magic-byte doğrulaması + EXIF temizliği; dosya yalnızca özel depoya yazılır. */
export async function uploadProviderDocument(s: Session, docType: DocType, file: File) {
  if (!s.providerId) throw new HttpError(403, "Evrakı yalnızca kurye yükleyebilir.");
  if (!DOC_TYPES.includes(docType)) throw new HttpError(422, "Geçersiz evrak türü.");
  const buf = Buffer.from(await file.arrayBuffer());
  if (buf.byteLength < 64) throw new HttpError(422, "Dosya geçersiz veya çok küçük.");
  if (buf.byteLength > MAX_IMAGE_BYTES) throw new HttpError(413, "Evrak en fazla 8 MB olabilir.");
  const sniffed = sniff(buf);
  if (!sniffed || sniffed.kind !== "IMAGE") throw new HttpError(415, "Evrak JPEG, PNG veya WebP görsel olmalı.");
  const { data } = stripMetadata(buf, sniffed.mime);
  await mkdir(DOCS_DIR, { recursive: true });
  const name = `${s.providerId}-${docType}-${createHash("sha256").update(data).digest("hex").slice(0, 16)}.${sniffed.ext}`;
  await writeFile(path.join(DOCS_DIR, name), data);
  const privatePath = path.relative(process.cwd(), path.join(DOCS_DIR, name));
  await db.transaction(async (tx) => {
    await tx
      .insert(providerDocuments)
      .values({ providerId: s.providerId!, docType, privatePath, mime: sniffed.mime, status: "SUBMITTED" })
      .onConflictDoUpdate({ target: [providerDocuments.providerId, providerDocuments.docType], set: { privatePath, mime: sniffed.mime, status: "SUBMITTED", reviewNote: null, reviewedBy: null, reviewedAt: null, createdAt: new Date() } });
    await syncVerification(tx, s.providerId!);
    await audit(tx, s.user.id, "document.upload", "provider", s.providerId!, `${DOC_LABELS[docType]} yüklendi`);
  });
  return { ok: true, status: "SUBMITTED" };
}
