import { and, asc, eq, inArray, isNull, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments,
  auditLogs,
  fleets,
  matchingCandidates,
  notifications,
  providers,
  requestEvents,
  restaurants,
  reviews,
  serviceRequests,
  type Candidate,
  type ServiceRequest,
} from "@/db/schema";
import { HttpError } from "./http";
import { computePrice, findCandidates, isEligible, type MatchInput } from "./matching";
import { syncOrderFromRequest } from "./food";
import { closeRequestConversations, ensureRequestConversation } from "./chat";
import { accrueEarning } from "./finance";
import type { Session } from "./session";
import { areaName, normalizeAreaSlug } from "./geo";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type Exec = Tx | typeof db;

export const OFFER_TTL_S = 60;
export const FLEET_TTL_S = 180;
export const REVIEW_WINDOW_DAYS = 14;

/* ---------------- Durum makinesi ---------------- */
const ALLOWED: Record<string, string[]> = {
  QUOTED: ["MATCHING", "CANCELLED_BY_CUSTOMER", "CANCELLED_BY_OPS"],
  MATCHING: ["OFFERED", "EXPIRED", "CANCELLED_BY_CUSTOMER", "CANCELLED_BY_OPS"],
  OFFERED: ["OFFERED", "MATCHING", "CONFIRMED", "EXPIRED", "CANCELLED_BY_CUSTOMER", "CANCELLED_BY_OPS"],
  CONFIRMED: ["IN_PROGRESS", "CANCELLED_BY_CUSTOMER", "CANCELLED_BY_PROVIDER", "CANCELLED_BY_OPS"],
  IN_PROGRESS: ["COMPLETED", "CANCELLED_BY_OPS"],
  EXPIRED: [],
  COMPLETED: [],
};

type Actor = { id: string | null; role: string };
const SYSTEM: Actor = { id: null, role: "system" };

async function transition(tx: Exec, req: ServiceRequest, to: string, actor: Actor, message?: string) {
  const allowed = ALLOWED[req.status] ?? [];
  if (!allowed.includes(to)) throw new HttpError(409, "Talep bu aşamada bu işleme izin vermiyor.");
  await tx.update(serviceRequests).set({ status: to, updatedAt: new Date() }).where(eq(serviceRequests.id, req.id));
  await tx.insert(requestEvents).values({
    requestId: req.id,
    actorId: actor.id,
    actorRole: actor.role,
    fromState: req.status,
    toState: to,
    message: message ?? null,
  });
  req.status = to;
}

async function notify(tx: Exec, userId: string, title: string, body: string, link: string) {
  await tx.insert(notifications).values({ userId, title, body, link });
}

export async function audit(tx: Exec, actorId: string | null, action: string, entityType: string, entityId: string, reason?: string, meta?: Record<string, unknown>) {
  await tx.insert(auditLogs).values({ actorId, action, entityType, entityId, reason: reason ?? null, meta: meta ?? null });
}

async function lockRequest(tx: Tx, id: string) {
  const [r] = await tx.select().from(serviceRequests).where(eq(serviceRequests.id, id)).for("update").limit(1);
  if (!r) throw new HttpError(404, "Talep bulunamadı.");
  return r;
}

function actorOf(s: Session): Actor {
  return { id: s.user.id, role: s.user.role };
}

function genCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let c = "";
  for (let i = 0; i < 6; i++) c += chars[Math.floor(Math.random() * chars.length)];
  return `YA-${c}`;
}

/* ---------------- 1) Teklif (quote) ---------------- */
export type QuoteInput = MatchInput & {
  pickupDetail?: string | null;
  dropoffDetail?: string | null;
  scheduledStart?: string | null;
  note?: string | null;
  idempotencyKey: string;
};

export async function createQuote(s: Session, input: QuoteInput) {
  if (s.user.role !== "CUSTOMER") throw new HttpError(403, "Talep oluşturmak için müşteri hesabı gerekir.");
  // Eski sabit anahtarlar da kabul edilir; kayıt her zaman kanonik il-ilçe slug'ı ile tutulur.
  input = {
    ...input,
    pickupArea: normalizeAreaSlug(input.pickupArea) ?? input.pickupArea,
    dropoffArea: normalizeAreaSlug(input.dropoffArea) ?? input.dropoffArea,
  };
  const [dupe] = await db
    .select({ id: serviceRequests.id, customerId: serviceRequests.customerId })
    .from(serviceRequests)
    .where(eq(serviceRequests.idempotencyKey, input.idempotencyKey))
    .limit(1);
  if (dupe) {
    if (dupe.customerId !== s.user.id) throw new HttpError(409, "Geçersiz idempotency anahtarı.");
    return { id: dupe.id };
  }

  let scheduledStart: Date | null = null;
  let scheduledEnd: Date | null = null;
  if (input.mode === "SCHEDULED") {
    if (!input.scheduledStart) throw new HttpError(422, "Randevu için tarih ve saat seçin.");
    scheduledStart = new Date(input.scheduledStart);
    if (isNaN(scheduledStart.getTime()) || scheduledStart.getTime() < Date.now() + 30 * 60000)
      throw new HttpError(422, "Randevu en az 30 dakika sonrası için olmalı.");
    if (scheduledStart.getTime() > Date.now() + 30 * 86400000) throw new HttpError(422, "Randevu en fazla 30 gün ileri alınabilir.");
  }
  if (input.mode === "INSTANT_RENT") {
    scheduledStart = new Date();
    scheduledEnd = new Date(Date.now() + (input.rentalHours ?? 1) * 3600000);
  }
  if (input.mode !== "INSTANT_RENT" && !input.dropoffArea) throw new HttpError(422, "Varış bölgesini seçin.");

  const cands = await findCandidates(input, 6);

  return db.transaction(async (tx) => {
    const [req] = await tx
      .insert(serviceRequests)
      .values({
        code: genCode(),
        customerId: s.user.id,
        mode: input.mode,
        status: "QUOTED",
        serviceType: input.mode === "INSTANT_RENT" ? "RENTAL" : input.serviceType,
        vehicleTypeReq: input.vehicleTypeReq ?? null,
        pickupArea: input.pickupArea,
        pickupDetail: input.pickupDetail ?? null,
        dropoffArea: input.mode === "INSTANT_RENT" ? null : input.dropoffArea ?? null,
        dropoffDetail: input.dropoffDetail ?? null,
        scheduledStart,
        scheduledEnd,
        rentalHours: input.mode === "INSTANT_RENT" ? input.rentalHours ?? 1 : null,
        note: input.note ?? null,
        deliveryOtp: String(Math.floor(1000 + Math.random() * 9000)),
        idempotencyKey: input.idempotencyKey,
        quotedPriceMinor: cands[0]?.priceMinor ?? null,
      })
      .returning();
    if (cands.length) {
      await tx.insert(matchingCandidates).values(
        cands.map((c, i) => ({
          requestId: req.id,
          providerId: c.provider.id,
          fleetId: c.provider.fleetId,
          score: c.score,
          breakdown: c.breakdown,
          etaSeconds: c.etaSeconds,
          distanceM: c.distanceM,
          priceMinor: c.priceMinor,
          rank: i + 1,
        })),
      );
    }
    await tx.insert(requestEvents).values({
      requestId: req.id,
      actorId: s.user.id,
      actorRole: s.user.role,
      toState: "QUOTED",
      message: `${cands.length} uygun aday bulundu`,
    });
    return { id: req.id };
  });
}

/* ---------------- 2) Seçim ---------------- */
export type SelectInput = { strategy: "AUTO" | "FAVORITE" | "MANUAL_PROVIDER" | "MANUAL_FLEET"; providerId?: string; fleetId?: string };

export async function selectAndSubmit(s: Session, requestId: string, input: SelectInput) {
  return db.transaction(async (tx) => {
    const req = await lockRequest(tx, requestId);
    if (req.customerId !== s.user.id) throw new HttpError(404, "Talep bulunamadı.");
    if (req.status !== "QUOTED") throw new HttpError(409, "Talep bu aşamada değiştirilemez.");

    const cands = await tx.select().from(matchingCandidates).where(eq(matchingCandidates.requestId, req.id)).orderBy(asc(matchingCandidates.rank));
    if (!cands.length) {
      await transition(tx, req, "MATCHING", actorOf(s));
      await transition(tx, req, "EXPIRED", SYSTEM, "Uygun aday yok");
      return { status: req.status };
    }
    const fleetRows = await tx.select().from(fleets);
    const policyOf = (fid: string | null) => (fid ? fleetRows.find((f) => f.id === fid)?.directPolicy ?? null : null);

    let order: Candidate[] = cands;
    if (input.strategy === "FAVORITE" || input.strategy === "MANUAL_PROVIDER") {
      const chosen = cands.find((c) => c.providerId === input.providerId);
      // İstemciden gelen rastgele ID reddedilir: yalnızca aday listesinde olan seçilebilir
      if (!chosen) throw new HttpError(422, "Bu sağlayıcı bu talep için uygun değil.");
      if (policyOf(chosen.fleetId) === "FLEET_ONLY") throw new HttpError(422, "Bu sağlayıcı yalnızca filosu üzerinden çağrılabilir. Filoyu seçin.");
      const [p] = await tx.select().from(providers).where(eq(providers.id, chosen.providerId)).limit(1);
      const reason = p ? isEligible(p, { mode: req.mode as MatchInput["mode"], serviceType: req.serviceType, vehicleTypeReq: req.vehicleTypeReq, pickupArea: req.pickupArea }) : "Sağlayıcı bulunamadı.";
      if (reason) throw new HttpError(422, `${reason} Alternatifler güncellendi.`);
      order = [chosen, ...cands.filter((c) => c.id !== chosen.id)]; // favori/manuel → AUTO fallback
    } else if (input.strategy === "MANUAL_FLEET") {
      const inFleet = cands.filter((c) => c.fleetId && c.fleetId === input.fleetId);
      if (!inFleet.length) throw new HttpError(422, "Bu filonun bu talep için uygun üyesi yok.");
      order = inFleet;
      const skip = cands.filter((c) => !inFleet.includes(c)).map((c) => c.id);
      if (skip.length) await tx.update(matchingCandidates).set({ response: "SKIPPED" }).where(inArray(matchingCandidates.id, skip));
    }
    for (let i = 0; i < order.length; i++) {
      await tx.update(matchingCandidates).set({ rank: i + 1 }).where(eq(matchingCandidates.id, order[i].id));
    }
    await tx
      .update(serviceRequests)
      .set({
        strategy: input.strategy,
        preferredProviderId: input.strategy === "FAVORITE" || input.strategy === "MANUAL_PROVIDER" ? input.providerId : null,
        preferredFleetId: input.strategy === "MANUAL_FLEET" ? input.fleetId : null,
      })
      .where(eq(serviceRequests.id, req.id));
    await transition(tx, req, "MATCHING", actorOf(s), "Eşleştirme başladı");
    await dispatchNext(tx, req);
    return { status: req.status };
  });
}

/* ---------------- 3) Sıradaki adaya teklif ---------------- */
async function dispatchNext(tx: Tx, req: ServiceRequest) {
  const open = await tx
    .select()
    .from(matchingCandidates)
    .where(and(eq(matchingCandidates.requestId, req.id), isNull(matchingCandidates.response)))
    .orderBy(asc(matchingCandidates.rank));

  for (const c of open) {
    const [p] = await tx.select().from(providers).where(eq(providers.id, c.providerId)).limit(1);
    const reason = p ? isEligible(p, { mode: req.mode as MatchInput["mode"], serviceType: req.serviceType, vehicleTypeReq: req.vehicleTypeReq, pickupArea: req.pickupArea }) : "yok";
    if (reason) {
      await tx.update(matchingCandidates).set({ response: "SKIPPED", respondedAt: new Date() }).where(eq(matchingCandidates.id, c.id));
      continue;
    }
    const [fleet] = p.fleetId ? await tx.select().from(fleets).where(eq(fleets.id, p.fleetId)).limit(1) : [];
    const viaFleet = fleet && fleet.directPolicy !== "DIRECT_ALLOWED";
    const ttl = viaFleet ? FLEET_TTL_S : OFFER_TTL_S;
    await tx
      .update(matchingCandidates)
      .set({ response: viaFleet ? "FLEET_PENDING" : "OFFERED", offeredAt: new Date(), offerExpiresAt: new Date(Date.now() + ttl * 1000) })
      .where(eq(matchingCandidates.id, c.id));
    await tx.update(serviceRequests).set({ quotedPriceMinor: c.priceMinor }).where(eq(serviceRequests.id, req.id));
    await transition(tx, req, "OFFERED", SYSTEM, viaFleet ? `${fleet.name} filo onayına gönderildi` : `${p.displayName} adlı sağlayıcıya teklif iletildi`);
    if (viaFleet) {
      await notify(tx, fleet.ownerUserId, "Filo onayı bekleyen talep", `${req.code} · ${p.displayName} için ${areaName(req.pickupArea)} çıkışlı talep`, "/filo");
    } else {
      await notify(tx, p.userId, "Yeni teklif!", `${req.code} · ${areaName(req.pickupArea)} → ${areaName(req.dropoffArea)} · ${OFFER_TTL_S} sn içinde yanıtlayın`, "/panel");
    }
    return;
  }
  if (req.status === "OFFERED" || req.status === "MATCHING") {
    if (req.status === "OFFERED") await transition(tx, req, "MATCHING", SYSTEM, "Aday kalmadı");
    await transition(tx, req, "EXPIRED", SYSTEM, "Şu anda uygun sağlayıcı bulunamadı");
    await notify(tx, req.customerId, "Uygun sağlayıcı bulunamadı", `${req.code} için şu anda uygun sağlayıcı yok. Randevu oluşturmayı deneyin.`, `/talep/${req.id}`);
  }
}

/* ---------------- 4) Zaman aşımı taraması (worker yerine lazy) ---------------- */
export async function sweepExpired() {
  const expired = await db
    .select({ id: matchingCandidates.id, requestId: matchingCandidates.requestId })
    .from(matchingCandidates)
    .where(and(inArray(matchingCandidates.response, ["OFFERED", "FLEET_PENDING"]), lt(matchingCandidates.offerExpiresAt, new Date())))
    .limit(25);
  for (const e of expired) {
    try {
      await db.transaction(async (tx) => {
        const req = await lockRequest(tx, e.requestId);
        const [c] = await tx.select().from(matchingCandidates).where(eq(matchingCandidates.id, e.id)).for("update").limit(1);
        if (!c || !["OFFERED", "FLEET_PENDING"].includes(c.response ?? "") || !c.offerExpiresAt || c.offerExpiresAt > new Date()) return;
        await tx.update(matchingCandidates).set({ response: "TIMEOUT", respondedAt: new Date() }).where(eq(matchingCandidates.id, c.id));
        await tx.insert(requestEvents).values({ requestId: req.id, actorRole: "system", fromState: req.status, toState: req.status, message: "Teklif zaman aşımına uğradı, sıradaki adaya geçiliyor" });
        if (req.status === "OFFERED") await dispatchNext(tx, req);
      });
    } catch {
      /* başka süreç işledi */
    }
  }
}

/* ---------------- 5) Kabul ---------------- */
async function accept(tx: Tx, req: ServiceRequest, c: Candidate, providerId: string, actor: Actor, viaFleetName?: string) {
  const [p] = await tx.select().from(providers).where(eq(providers.id, providerId)).limit(1);
  if (!p) throw new HttpError(404, "Sağlayıcı bulunamadı.");
  await tx.insert(assignments).values({ requestId: req.id, providerId, fleetId: p.fleetId }); // UNIQUE(requestId)
  await tx.update(matchingCandidates).set({ response: "ACCEPTED", respondedAt: new Date() }).where(eq(matchingCandidates.id, c.id));
  await tx.update(serviceRequests).set({ finalPriceMinor: c.priceMinor }).where(eq(serviceRequests.id, req.id));
  await transition(tx, req, "CONFIRMED", actor, viaFleetName ? `${viaFleetName} onayladı · ${p.displayName} atandı` : `${p.displayName} kabul etti`);
  await syncOrderFromRequest(tx, req.id, "CONFIRMED", actor);
  await ensureRequestConversation(tx, { requestId: req.id, code: req.code, customerId: req.customerId, providerUserId: p.userId, providerName: p.displayName });
  if (req.mode !== "SCHEDULED") await tx.update(providers).set({ status: "BUSY" }).where(eq(providers.id, p.id));
  await notify(tx, req.customerId, "Talebiniz onaylandı ✅", `${req.code} · ${p.displayName} görevi üstlendi.`, `/talep/${req.id}`);
  if (p.fleetId) {
    const [f] = await tx.select().from(fleets).where(eq(fleets.id, p.fleetId)).limit(1);
    if (f && !viaFleetName) await notify(tx, f.ownerUserId, "Bilgilendirme: üyeniz görev aldı", `${p.displayName} · ${req.code} talebini doğrudan kabul etti.`, "/filo");
    if (viaFleetName && p.userId !== actor.id) await notify(tx, p.userId, "Filonuz size görev atadı", `${req.code} · ${areaName(req.pickupArea)} çıkışlı`, "/panel");
  }
}

export async function providerRespond(s: Session, candidateId: string, action: "accept" | "decline") {
  if (!s.providerId) throw new HttpError(403, "Yalnızca hizmet sağlayıcılar teklif yanıtlayabilir.");
  await sweepExpired();
  return db.transaction(async (tx) => {
    const [c0] = await tx.select().from(matchingCandidates).where(eq(matchingCandidates.id, candidateId)).limit(1);
    if (!c0 || c0.providerId !== s.providerId) throw new HttpError(404, "Teklif bulunamadı.");
    const req = await lockRequest(tx, c0.requestId);
    const [c] = await tx.select().from(matchingCandidates).where(eq(matchingCandidates.id, candidateId)).limit(1);
    if (c.response !== "OFFERED") throw new HttpError(409, "Bu teklif artık geçerli değil.");
    if (c.offerExpiresAt && c.offerExpiresAt < new Date()) throw new HttpError(409, "Teklifin süresi doldu.");
    if (action === "decline") {
      await tx.update(matchingCandidates).set({ response: "DECLINED", respondedAt: new Date() }).where(eq(matchingCandidates.id, c.id));
      await tx.insert(requestEvents).values({ requestId: req.id, actorId: s.user.id, actorRole: "PROVIDER", fromState: req.status, toState: req.status, message: "Sağlayıcı reddetti, sıradaki adaya geçiliyor" });
      await dispatchNext(tx, req);
      return { ok: true, status: req.status };
    }
    await accept(tx, req, c, c.providerId, actorOf(s));
    return { ok: true, status: req.status };
  });
}

export async function fleetRespond(s: Session, candidateId: string, action: "approve" | "decline" | "reassign", reassignTo?: string) {
  if (!s.fleetId) throw new HttpError(403, "Yalnızca filo yöneticileri bu işlemi yapabilir.");
  await sweepExpired();
  return db.transaction(async (tx) => {
    const [c0] = await tx.select().from(matchingCandidates).where(eq(matchingCandidates.id, candidateId)).limit(1);
    if (!c0 || c0.fleetId !== s.fleetId) throw new HttpError(404, "Teklif bulunamadı.");
    const req = await lockRequest(tx, c0.requestId);
    const [c] = await tx.select().from(matchingCandidates).where(eq(matchingCandidates.id, candidateId)).limit(1);
    if (c.response !== "FLEET_PENDING") throw new HttpError(409, "Bu talep artık onay beklemiyor.");
    const [fleet] = await tx.select().from(fleets).where(eq(fleets.id, s.fleetId!)).limit(1);
    if (action === "decline") {
      await tx.update(matchingCandidates).set({ response: "DECLINED", respondedAt: new Date() }).where(eq(matchingCandidates.id, c.id));
      await tx.insert(requestEvents).values({ requestId: req.id, actorId: s.user.id, actorRole: "FLEET_OWNER", fromState: req.status, toState: req.status, message: `${fleet.name} talebi reddetti` });
      await dispatchNext(tx, req);
      return { ok: true };
    }
    let target = c.providerId;
    if (action === "reassign") {
      if (!reassignTo) throw new HttpError(422, "Yönlendirilecek üyeyi seçin.");
      const [p] = await tx.select().from(providers).where(eq(providers.id, reassignTo)).limit(1);
      if (!p || p.fleetId !== s.fleetId) throw new HttpError(422, "Seçilen kişi bu filonun üyesi değil.");
      const reason = isEligible(p, { mode: req.mode as MatchInput["mode"], serviceType: req.serviceType, vehicleTypeReq: req.vehicleTypeReq, pickupArea: req.pickupArea });
      if (reason) throw new HttpError(422, reason);
      target = p.id;
    }
    await accept(tx, req, c, target, actorOf(s), fleet.name);
    await audit(tx, s.user.id, action === "reassign" ? "fleet.reassign" : "fleet.approve", "service_request", req.id, undefined, { candidateId: c.id, providerId: target });
    return { ok: true };
  });
}

/* ---------------- 6) Görev yürütme ---------------- */
export async function assignmentAction(s: Session, assignmentId: string, action: "start" | "complete" | "cancel", otp?: string) {
  if (!s.providerId) throw new HttpError(403, "Yetkiniz yok.");
  return db.transaction(async (tx) => {
    const [a0] = await tx.select().from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
    if (!a0 || a0.providerId !== s.providerId) throw new HttpError(404, "Görev bulunamadı.");
    const req = await lockRequest(tx, a0.requestId);
    const [a] = await tx.select().from(assignments).where(eq(assignments.id, assignmentId)).limit(1);
    if (action === "start") {
      if (a.state !== "CONFIRMED") throw new HttpError(409, "Görev başlatılamaz.");
      const [busy] = await tx.select({ id: assignments.id }).from(assignments).where(and(eq(assignments.providerId, a.providerId), eq(assignments.state, "IN_PROGRESS"))).limit(1);
      if (busy) throw new HttpError(409, "Aynı anda yalnızca bir aktif görev yürütülebilir.");
      await tx.update(assignments).set({ state: "IN_PROGRESS", startedAt: new Date() }).where(eq(assignments.id, a.id));
      await tx.update(providers).set({ status: "ON_TASK" }).where(eq(providers.id, a.providerId));
      await transition(tx, req, "IN_PROGRESS", actorOf(s), "Sağlayıcı yola çıktı");
      await syncOrderFromRequest(tx, req.id, "IN_PROGRESS", actorOf(s));
      await notify(tx, req.customerId, "Sağlayıcınız yolda 🛵", `${req.code} · Teslimde kodu paylaşın.`, `/talep/${req.id}`);
    } else if (action === "complete") {
      if (a.state !== "IN_PROGRESS") throw new HttpError(409, "Görev tamamlanamaz.");
      if (req.otpLockedAt) throw new HttpError(423, "Teslimat kilitli: operasyon incelemesi bekleniyor.");
      if (!otp || otp.trim() !== req.deliveryOtp) throw new HttpError(422, "Teslim kodu hatalı.");
      const completedAt = new Date();
      await tx.update(assignments).set({ state: "COMPLETED", completedAt }).where(eq(assignments.id, a.id));
      if (req.finalPriceMinor != null) await accrueEarning(tx, { requestId: req.id, providerId: a.providerId, fleetId: a.fleetId, grossMinor: req.finalPriceMinor, earnedAt: completedAt });
      await tx.update(providers).set({ status: "AVAILABLE", completedCount: sql`${providers.completedCount} + 1` }).where(eq(providers.id, a.providerId));
      await transition(tx, req, "COMPLETED", actorOf(s), "Teslim kodu doğrulandı");
      await syncOrderFromRequest(tx, req.id, "COMPLETED", actorOf(s));
      await closeRequestConversations(tx, req.id, "Görev tamamlandı — sohbet arşivlendi.");
      await notify(tx, req.customerId, "Görev tamamlandı ⭐", `${req.code} · Deneyiminizi değerlendirin (14 gün).`, `/talep/${req.id}`);
    } else {
      if (a.state !== "CONFIRMED") throw new HttpError(409, "Başlamış görev iptal edilemez; operasyonla iletişime geçin.");
      await tx.update(assignments).set({ state: "CANCELLED", cancelledAt: new Date() }).where(eq(assignments.id, a.id));
      await tx.update(providers).set({ status: "AVAILABLE", lateCancelRate: sql`LEAST(1, ${providers.lateCancelRate} + 0.02)` }).where(eq(providers.id, a.providerId));
      await transition(tx, req, "CANCELLED_BY_PROVIDER", actorOf(s));
      await syncOrderFromRequest(tx, req.id, "CANCELLED", actorOf(s));
      await closeRequestConversations(tx, req.id, "Görev iptal edildi — sohbet arşivlendi.");
      await notify(tx, req.customerId, "Talep iptal edildi", `${req.code} sağlayıcı tarafından iptal edildi. Yeni talep oluşturabilirsiniz.`, `/talep/${req.id}`);
    }
    return { ok: true };
  });
}

/* ---------------- 7) İptal ---------------- */
export async function cancelRequest(s: Session, requestId: string, reason?: string) {
  const isOps = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role);
  if (isOps && (!reason || reason.trim().length < 5)) throw new HttpError(422, "Operasyon iptali için gerekçe zorunlu (en az 5 karakter).");
  return db.transaction(async (tx) => {
    const req = await lockRequest(tx, requestId);
    if (!isOps && req.customerId !== s.user.id) throw new HttpError(404, "Talep bulunamadı.");
    await tx
      .update(matchingCandidates)
      .set({ response: "SKIPPED" })
      .where(and(eq(matchingCandidates.requestId, req.id), sql`(${matchingCandidates.response} IS NULL OR ${matchingCandidates.response} IN ('OFFERED','FLEET_PENDING'))`));
    const [a] = await tx.select().from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
    await transition(tx, req, isOps ? "CANCELLED_BY_OPS" : "CANCELLED_BY_CUSTOMER", actorOf(s), reason);
    await syncOrderFromRequest(tx, req.id, "CANCELLED", actorOf(s));
    await closeRequestConversations(tx, req.id, "Görev iptal edildi — sohbet arşivlendi.");
    if (a && (a.state === "CONFIRMED" || a.state === "IN_PROGRESS")) {
      await tx.update(assignments).set({ state: "CANCELLED", cancelledAt: new Date() }).where(eq(assignments.id, a.id));
      const [p] = await tx.select().from(providers).where(eq(providers.id, a.providerId)).limit(1);
      if (p) {
        if (p.status === "BUSY" || p.status === "ON_TASK") await tx.update(providers).set({ status: "AVAILABLE" }).where(eq(providers.id, p.id));
        await notify(tx, p.userId, "Görev iptal edildi", `${req.code} ${isOps ? "operasyon" : "müşteri"} tarafından iptal edildi.`, "/panel");
      }
    }
    if (isOps) {
      await audit(tx, s.user.id, "request.cancel_by_ops", "service_request", req.id, reason);
      await notify(tx, req.customerId, "Talep operasyon tarafından iptal edildi", `${req.code}: ${reason}`, `/talep/${req.id}`);
    }
    return { ok: true };
  });
}

/* ---------------- 8) Değerlendirme ---------------- */
export type ReviewInput = { rating: number; catTime?: number; catCommunication?: number; catCare?: number; catProfessionalism?: number; body?: string };

export async function submitReview(s: Session, requestId: string, input: ReviewInput) {
  return db.transaction(async (tx) => {
    const [req] = await tx.select().from(serviceRequests).where(eq(serviceRequests.id, requestId)).limit(1);
    if (!req || req.customerId !== s.user.id) throw new HttpError(404, "Talep bulunamadı.");
    if (req.status !== "COMPLETED") throw new HttpError(422, "Yalnızca tamamlanan görevler değerlendirilebilir.");
    if (Date.now() - req.updatedAt.getTime() > REVIEW_WINDOW_DAYS * 86400000) throw new HttpError(422, "Değerlendirme süresi (14 gün) doldu.");
    const [a] = await tx.select().from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
    if (!a) throw new HttpError(422, "Atama bulunamadı.");
    const [existing] = await tx.select({ id: reviews.id }).from(reviews).where(and(eq(reviews.authorId, s.user.id), eq(reviews.sourceId, req.id))).limit(1);
    if (existing) throw new HttpError(409, "Bu görevi zaten değerlendirdiniz.");
    await tx.insert(reviews).values({ authorId: s.user.id, targetId: a.providerId, sourceId: req.id, ...input, body: input.body?.trim() || null });
    await recomputeRating(tx, a.providerId);
    const [p] = await tx.select().from(providers).where(eq(providers.id, a.providerId)).limit(1);
    if (p) await notify(tx, p.userId, "Yeni değerlendirme", `${req.code} için ${input.rating}★ aldınız.`, `/kuryeler/${p.slug}`);
    return { ok: true };
  });
}

/** Ortalama her zaman DB'den yeniden hesaplanır; admin puan değiştiremez, yalnızca görünürlük. */
export async function recomputeRating(tx: Exec, targetId: string) {
  const [agg] = await tx
    .select({ avg: sql<number>`coalesce(avg(${reviews.rating}),0)::float`, n: sql<number>`count(*)::int` })
    .from(reviews)
    .where(and(eq(reviews.targetId, targetId), eq(reviews.status, "PUBLISHED")));
  const avg = Math.round(agg.avg * 100) / 100;
  const [sample] = await tx.select({ t: reviews.targetType }).from(reviews).where(eq(reviews.targetId, targetId)).limit(1);
  if (sample?.t === "RESTAURANT") {
    await tx.update(restaurants).set({ ratingAvg: avg, ratingCount: agg.n }).where(eq(restaurants.id, targetId));
  } else {
    await tx.update(providers).set({ ratingAvg: avg, ratingCount: agg.n }).where(eq(providers.id, targetId));
  }
}


/* ---------------- 9) Operasyon: manuel kurye atama ---------------- */
const MANUAL_ASSIGNABLE = ["QUOTED", "MATCHING", "OFFERED", "EXPIRED"];

export async function adminAssignProvider(s: Session, requestId: string, providerId: string, reason: string) {
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) throw new HttpError(403, "Manuel atama operasyon yetkisi gerektirir.");
  if (reason.trim().length < 10) throw new HttpError(422, "Manuel atama gerekçesi en az 10 karakter olmalı.");
  return db.transaction(async (tx) => {
    const req = await lockRequest(tx, requestId);
    if (!MANUAL_ASSIGNABLE.includes(req.status)) throw new HttpError(409, "Bu talep manuel atamaya uygun durumda değil.");
    const [existing] = await tx.select({ id: assignments.id }).from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
    if (existing) throw new HttpError(409, "Bu talebe zaten bir kurye atanmış.");
    const [p] = await tx.select().from(providers).where(eq(providers.id, providerId)).for("update").limit(1);
    if (!p) throw new HttpError(404, "Kurye bulunamadı.");
    const reasonIneligible = isEligible(p, { mode: req.mode as MatchInput["mode"], serviceType: req.serviceType, vehicleTypeReq: req.vehicleTypeReq, pickupArea: req.pickupArea });
    if (reasonIneligible) throw new HttpError(422, reasonIneligible);

    await tx
      .update(matchingCandidates)
      .set({ response: "SKIPPED", respondedAt: new Date() })
      .where(and(eq(matchingCandidates.requestId, req.id), sql`(${matchingCandidates.response} IS NULL OR ${matchingCandidates.response} IN ('OFFERED','FLEET_PENDING'))`));
    const price = computePrice(p, { mode: req.mode as MatchInput["mode"], serviceType: req.serviceType, pickupArea: req.pickupArea, dropoffArea: req.dropoffArea, rentalHours: req.rentalHours });
    await tx
      .insert(matchingCandidates)
      .values({ requestId: req.id, providerId: p.id, fleetId: p.fleetId, score: 0, breakdown: { manual: 1 }, etaSeconds: 900, distanceM: 0, priceMinor: price, rank: 99, response: "ACCEPTED", offeredAt: new Date(), respondedAt: new Date() })
      .onConflictDoUpdate({ target: [matchingCandidates.requestId, matchingCandidates.providerId], set: { response: "ACCEPTED", respondedAt: new Date(), priceMinor: price } });
    await tx.insert(assignments).values({ requestId: req.id, providerId: p.id, fleetId: p.fleetId });
    const from = req.status;
    await tx.update(serviceRequests).set({ status: "CONFIRMED", finalPriceMinor: price, updatedAt: new Date() }).where(eq(serviceRequests.id, req.id));
    await tx.insert(requestEvents).values({ requestId: req.id, actorId: s.user.id, actorRole: s.user.role, fromState: from, toState: "CONFIRMED", message: `Operasyon manuel atama · ${p.displayName}` });
    req.status = "CONFIRMED";
    if (req.mode !== "SCHEDULED") await tx.update(providers).set({ status: "BUSY" }).where(eq(providers.id, p.id));
    await syncOrderFromRequest(tx, req.id, "CONFIRMED", actorOf(s));
    await ensureRequestConversation(tx, { requestId: req.id, code: req.code, customerId: req.customerId, providerUserId: p.userId, providerName: p.displayName });
    await notify(tx, req.customerId, "Talebiniz onaylandı ✅", `${req.code} · Operasyon ${p.displayName} adlı kuryeyi atadı.`, `/talep/${req.id}`);
    await notify(tx, p.userId, "Operasyon size görev atadı", `${req.code} · ${areaName(req.pickupArea)} çıkışlı`, "/dashboard/kurye/gorevler");
    await audit(tx, s.user.id, "request.manual_assign", "service_request", req.id, reason.trim(), { providerId: p.id, from });
    return { ok: true };
  });
}
