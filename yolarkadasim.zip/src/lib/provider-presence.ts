import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { providerShifts, providers } from "@/db/schema";
import { HttpError } from "./http";
import { isValidCoords, type DbProviderStatusSetting, type ProviderCoords } from "./provider-status-ui";

export interface PresenceUpdate {
  status?: DbProviderStatusSetting;
  coords?: ProviderCoords;
}

/**
 * Tek yetkili durum/konum yazımı: API route ve Server Action aynı işlevi kullanır.
 * - SUSPENDED profiller yazamaz.
 * - ON_TASK/BUSY iken manuel durum değişikliği reddedilir; sessiz konum güncellemesine izin verilir.
 * - Konum yalnızca eşleşme/takip için anlamlı durumlarda saklanır; OFFLINE/PAUSED geçişlerinde koordinat yoksayılır.
 * - Ham koordinatlar yalnızca DB'de saklanır; bu işlevin dönüşünde koordinat yer almaz.
 */
export async function applyProviderPresence(providerId: string, input: PresenceUpdate): Promise<{ status: string }> {
  if (input.coords && !isValidCoords(input.coords.lat, input.coords.lng)) {
    throw new HttpError(422, "Geçersiz konum bilgisi.");
  }
  return db.transaction(async (tx) => {
    const [provider] = await tx.select().from(providers).where(eq(providers.id, providerId)).for("update").limit(1);
    if (!provider) throw new HttpError(404, "Profil bulunamadı.");
    if (provider.status === "SUSPENDED") throw new HttpError(403, "Profiliniz askıda.");
    if (input.status && (provider.status === "ON_TASK" || provider.status === "BUSY")) {
      throw new HttpError(409, "Aktif görev varken durum değiştirilemez.");
    }

    const now = new Date();
    const next = input.status ?? provider.status;
    const [openShift] = await tx
      .select()
      .from(providerShifts)
      .where(and(eq(providerShifts.providerId, provider.id), isNull(providerShifts.endedAt)))
      .limit(1);
    if (next === "AVAILABLE" && !openShift) {
      await tx.insert(providerShifts).values({ providerId: provider.id, startedAt: now });
    }
    if ((next === "OFFLINE" || next === "PAUSED") && openShift) {
      await tx.update(providerShifts).set({ endedAt: now }).where(eq(providerShifts.id, openShift.id));
    }

    // Konum saklama kuralı: çevrimiçi geçişlerde ve aktif görevdeki sessiz güncellemelerde yazılır.
    let persistCoords = false;
    if (input.coords) {
      persistCoords = input.status ? next === "AVAILABLE" : ["AVAILABLE", "BUSY", "ON_TASK"].includes(provider.status);
    }

    await tx
      .update(providers)
      .set({
        lastSeenAt: now,
        ...(input.status ? { status: input.status } : {}),
        ...(persistCoords && input.coords ? { lastLat: input.coords.lat, lastLng: input.coords.lng } : {}),
      })
      .where(eq(providers.id, provider.id));
    return { status: next };
  });
}
