import { and, asc, desc, eq, gt, inArray, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments, auditLogs, fleetDutySlots, fleetInvitations, fleets, matchingCandidates, mediaPosts,
  notifications, orderEvents, orders, partnerApplications, providerShifts, providers, requestEvents,
  restaurants, reviews, serviceRequests, supportCases, users,
} from "@/db/schema";
import { etaBand, areaName } from "./geo";
import { getFleetInbox, getProviderPanel, getFavoriteIds } from "./queries";
import { unreadTotal } from "./chat";
import { listCustomerOrders } from "./food";
import type { Session } from "./session";

export interface MetricItem {
  title: string;
  value: string;
  detail: string;
  change?: string;
}
export interface TaskSummary {
  id: string;
  code: string;
  status: string;
  pickup: string;
  dropoff: string;
  priceMinor: number | null;
  linkedOrderId: string | null;
  providerName: string | null;
  providerSlug: string | null;
  providerHue: number | null;
  eta: string | null;
  deliveryOtp: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export const activeRequestStates = ["QUOTED", "MATCHING", "OFFERED", "CONFIRMED", "IN_PROGRESS"];
export const activeOrderStates = ["ORDER_PLACED", "RESTAURANT_ACCEPTED", "PREPARING", "READY_FOR_PICKUP", "COURIER_ASSIGNED", "OUT_FOR_DELIVERY"];

function maskedName(name: string | null) {
  if (!name) return "Müşteri";
  return name.split(/\s+/).filter(Boolean).map((part) => `${part.charAt(0)}.`).join(" ");
}

export function startOfTodayIstanbul(now = new Date()) {
  const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
  return new Date(`${day}T00:00:00+03:00`);
}
export function startOfWeekIstanbul(now = new Date()) {
  const today = startOfTodayIstanbul(now);
  const day = new Intl.DateTimeFormat("en-US", { weekday: "short", timeZone: "Europe/Istanbul" }).format(now);
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].indexOf(day);
  return new Date(today.getTime() - Math.max(days, 0) * 86400000);
}

/** Müşteriye özel görevler; tam adres ve sağlayıcının ham konumu dönmez. */
export async function customerTasks(session: Session): Promise<TaskSummary[]> {
  const rows = await db
    .select({
      request: serviceRequests,
      providerName: providers.displayName,
      providerSlug: providers.slug,
      providerHue: providers.hue,
      etaSeconds: matchingCandidates.etaSeconds,
    })
    .from(serviceRequests)
    .leftJoin(assignments, eq(assignments.requestId, serviceRequests.id))
    .leftJoin(providers, eq(providers.id, assignments.providerId))
    .leftJoin(matchingCandidates, and(eq(matchingCandidates.requestId, serviceRequests.id), eq(matchingCandidates.providerId, assignments.providerId)))
    .where(eq(serviceRequests.customerId, session.user.id))
    .orderBy(desc(serviceRequests.createdAt))
    .limit(75);
  return rows.map(({ request: r, providerName, providerSlug, providerHue, etaSeconds }) => ({
    id: r.id,
    code: r.code,
    status: r.status,
    pickup: areaName(r.pickupArea),
    dropoff: areaName(r.dropoffArea),
    priceMinor: r.finalPriceMinor ?? r.quotedPriceMinor,
    linkedOrderId: r.linkedOrderId,
    providerName,
    providerSlug,
    providerHue,
    eta: etaSeconds ? etaBand(etaSeconds) : null,
    deliveryOtp: ["CONFIRMED", "IN_PROGRESS"].includes(r.status) ? r.deliveryOtp : null,
    createdAt: r.createdAt,
    updatedAt: r.updatedAt,
  }));
}

export async function customerOverview(session: Session) {
  const [tasks, foodOrders, favorites] = await Promise.all([
    customerTasks(session), listCustomerOrders(session.user.id), getFavoriteIds(session.user.id),
  ]);
  const independent = tasks.filter((t) => !t.linkedOrderId);
  return {
    activeTasks: independent.filter((t) => activeRequestStates.includes(t.status)),
    recentTasks: independent.slice(0, 8),
    activeOrders: foodOrders.filter((o) => activeOrderStates.includes(o.status)),
    recentOrders: foodOrders.slice(0, 8),
    favoriteCount: favorites.providers.length + favorites.fleets.length + favorites.restaurants.length,
    completedCount: independent.filter((t) => t.status === "COMPLETED").length + foodOrders.filter((o) => o.status === "DELIVERED").length,
    spentMinor: independent.filter((t) => t.status === "COMPLETED").reduce((a, t) => a + (t.priceMinor ?? 0), 0)
      + foodOrders.filter((o) => o.status === "DELIVERED").reduce((a, o) => a + o.totalMinor, 0),
  };
}

export async function customerSpending(session: Session) {
  const [tasks, foodOrders] = await Promise.all([
    db.select({ id: serviceRequests.id, code: serviceRequests.code, amount: serviceRequests.finalPriceMinor, date: serviceRequests.updatedAt })
      .from(serviceRequests).where(and(eq(serviceRequests.customerId, session.user.id), eq(serviceRequests.status, "COMPLETED"), isNull(serviceRequests.linkedOrderId))),
    db.select({ id: orders.id, code: orders.code, amount: orders.totalMinor, date: orders.updatedAt })
      .from(orders).where(and(eq(orders.customerId, session.user.id), eq(orders.status, "DELIVERED"))),
  ]);
  const lines = [
    ...tasks.map((r) => ({ id: r.id, code: r.code, type: "Görev", amountMinor: r.amount ?? 0, date: r.date, href: `/talep/${r.id}` })),
    ...foodOrders.map((o) => ({ id: o.id, code: o.code, type: "Yemek", amountMinor: o.amount, date: o.date, href: `/siparis/${o.id}` })),
  ].sort((a, b) => b.date.getTime() - a.date.getTime());
  const today = startOfTodayIstanbul();
  const week = startOfWeekIstanbul();
  return {
    lines,
    totalMinor: lines.reduce((sum, x) => sum + x.amountMinor, 0),
    todayMinor: lines.filter((x) => x.date >= today).reduce((sum, x) => sum + x.amountMinor, 0),
    weekMinor: lines.filter((x) => x.date >= week).reduce((sum, x) => sum + x.amountMinor, 0),
  };
}

export async function providerOverview(session: Session) {
  if (!session.providerId) throw new Error("Provider profile is required");
  const panel = await getProviderPanel(session.providerId);
  const today = startOfTodayIstanbul();
  const week = startOfWeekIstanbul();
  const shiftRows = await db.select().from(providerShifts).where(and(eq(providerShifts.providerId, session.providerId), gt(providerShifts.startedAt, new Date(today.getTime() - 14 * 86400000)))).orderBy(desc(providerShifts.startedAt));
  const ids = [...new Set(panel.tasks.map((t) => t.r.customerId))];
  const clients = ids.length ? await db.select({ id: users.id, name: users.name }).from(users).where(inArray(users.id, ids)) : [];
  const completed = await db.select({ a: assignments, r: serviceRequests }).from(assignments)
    .innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId))
    .where(and(eq(assignments.providerId, session.providerId), eq(assignments.state, "COMPLETED")))
    .orderBy(desc(assignments.completedAt));
  const now = Date.now();
  const onlineTodayMs = shiftRows.reduce((sum, sh) => {
    const from = Math.max(today.getTime(), sh.startedAt.getTime());
    // Kaybolan oturum/sekme süreyi sonsuza kadar artırmaz: son heartbeat + 90 sn sınırı.
    const lastHeartbeat = panel.provider?.lastSeenAt?.getTime() ?? sh.startedAt.getTime();
    const until = sh.endedAt?.getTime() ?? Math.min(now, lastHeartbeat + 90_000);
    return sum + Math.max(0, until - from);
  }, 0);
  const maskedTasks = panel.tasks.map((t) => ({ ...t, customerMasked: maskedName(clients.find((u) => u.id === t.r.customerId)?.name ?? null) }));
  return {
    ...panel,
    tasks: maskedTasks,
    offers: panel.offers.filter((o) => !o.c.offerExpiresAt || o.c.offerExpiresAt > new Date()),
    activeTasks: maskedTasks.filter((t) => ["CONFIRMED", "IN_PROGRESS"].includes(t.a.state)),
    todayMinor: completed.filter((t) => t.a.completedAt && t.a.completedAt >= today).reduce((sum, t) => sum + (t.r.finalPriceMinor ?? 0), 0),
    weekMinor: completed.filter((t) => t.a.completedAt && t.a.completedAt >= week).reduce((sum, t) => sum + (t.r.finalPriceMinor ?? 0), 0),
    lifetimeMinor: completed.reduce((sum, t) => sum + (t.r.finalPriceMinor ?? 0), 0),
    todayCount: completed.filter((t) => t.a.completedAt && t.a.completedAt >= today).length,
    completed,
    onlineTodayMinutes: Math.floor(onlineTodayMs / 60000),
    currentShift: shiftRows.find((sh) => !sh.endedAt) ?? null,
  };
}

export async function providerFleetData(session: Session) {
  if (!session.providerId) throw new Error("Provider profile is required");
  const [provider] = await db.select({ fleetId: providers.fleetId, name: providers.displayName, vehicleType: providers.vehicleType }).from(providers).where(eq(providers.id, session.providerId)).limit(1);
  const [fleet] = provider?.fleetId ? await db.select().from(fleets).where(eq(fleets.id, provider.fleetId)).limit(1) : [];
  const [owner] = fleet ? await db.select({ name: users.name }).from(users).where(eq(users.id, fleet.ownerUserId)).limit(1) : [];
  const invitations = await db.select({ invitation: fleetInvitations, fleetName: fleets.name }).from(fleetInvitations).innerJoin(fleets, eq(fleets.id, fleetInvitations.fleetId)).where(eq(fleetInvitations.providerId, session.providerId)).orderBy(desc(fleetInvitations.createdAt)).limit(12);
  const shifts = await db.select().from(fleetDutySlots).where(eq(fleetDutySlots.providerId, session.providerId)).orderBy(desc(fleetDutySlots.startsAt)).limit(20);
  return { provider, fleet: fleet ?? null, ownerName: owner?.name ?? null, invitations, shifts };
}

export async function fleetOverview(session: Session) {
  if (!session.fleetId) throw new Error("Fleet profile is required");
  const panel = await getFleetInbox(session.fleetId);
  const invitations = await db
    .select({ invitation: fleetInvitations, providerName: providers.displayName, providerHue: providers.hue, vehicleType: providers.vehicleType })
    .from(fleetInvitations)
    .innerJoin(providers, eq(providers.id, fleetInvitations.providerId))
    .where(eq(fleetInvitations.fleetId, session.fleetId))
    .orderBy(desc(fleetInvitations.createdAt))
    .limit(35);
  const duties = await db.select().from(fleetDutySlots).where(eq(fleetDutySlots.fleetId, session.fleetId)).orderBy(desc(fleetDutySlots.startsAt)).limit(35);
  const [gross] = await db.select({ value: sql<number>`coalesce(sum(${serviceRequests.finalPriceMinor}),0)::bigint` }).from(assignments).innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId)).where(and(eq(assignments.fleetId, session.fleetId), eq(assignments.state, "COMPLETED")));
  const completed = panel.active.filter((x) => x.a.state === "COMPLETED").length;
  const cancelled = panel.active.filter((x) => x.a.state === "CANCELLED").length;
  return {
    ...panel,
    invitations,
    duties,
    current: panel.active.filter((x) => ["CONFIRMED", "IN_PROGRESS"].includes(x.a.state)),
    completed,
    cancelled,
    successRate: completed + cancelled ? Math.round(100 * completed / (completed + cancelled)) : null,
    grossMinor: Number(gross?.value ?? 0),
  };
}

export async function adminOverview() {
  const [requestRows, orderRows, provRows, fleetRows, restRows, inviteRows, caseRows, reviewRows, pendingMedia, pendingApps] = await Promise.all([
    db.select({ id: serviceRequests.id, status: serviceRequests.status, amount: serviceRequests.finalPriceMinor, linked: serviceRequests.linkedOrderId, createdAt: serviceRequests.createdAt, updatedAt: serviceRequests.updatedAt }).from(serviceRequests),
    db.select({ id: orders.id, status: orders.status, amount: orders.totalMinor, createdAt: orders.placedAt, updatedAt: orders.updatedAt }).from(orders),
    db.select({ status: providers.status, verified: providers.isVerified }).from(providers),
    db.select({ id: fleets.id }).from(fleets),
    db.select({ id: restaurants.id }).from(restaurants),
    db.select({ id: fleetInvitations.id }).from(fleetInvitations).where(eq(fleetInvitations.status, "PENDING")),
    db.select({ id: supportCases.id }).from(supportCases).where(inArray(supportCases.status, ["OPEN", "IN_REVIEW"])),
    db.select({ id: reviews.id }).from(reviews),
    db.select({ id: mediaPosts.id }).from(mediaPosts).where(eq(mediaPosts.status, "PENDING_REVIEW")),
    db.select({ id: partnerApplications.id }).from(partnerApplications).where(eq(partnerApplications.status, "PENDING")),
  ]);
  const gmvtasks = requestRows.filter((r) => r.status === "COMPLETED" && !r.linked).reduce((sum, r) => sum + (r.amount ?? 0), 0);
  const gmvorders = orderRows.filter((o) => o.status === "DELIVERED").reduce((sum, o) => sum + o.amount, 0);
  const sevenDays = Array.from({ length: 7 }, (_, i) => {
    const day = new Date(startOfTodayIstanbul().getTime() - (6 - i) * 86400000);
    const next = new Date(day.getTime() + 86400000);
    const req = requestRows.filter((r) => r.status === "COMPLETED" && r.updatedAt >= day && r.updatedAt < next && !r.linked);
    const ord = orderRows.filter((o) => o.status === "DELIVERED" && o.updatedAt >= day && o.updatedAt < next);
    return { date: day, count: req.length + ord.length, amountMinor: req.reduce((s, x) => s + (x.amount ?? 0), 0) + ord.reduce((s, x) => s + x.amount, 0) };
  });
  return {
    gmvMinor: gmvtasks + gmvorders,
    activeProviders: provRows.filter((p) => p.status === "AVAILABLE" || p.status === "BUSY" || p.status === "ON_TASK").length,
    availableProviders: provRows.filter((p) => p.status === "AVAILABLE").length,
    activeTasks: requestRows.filter((r) => ["MATCHING", "OFFERED", "CONFIRMED", "IN_PROGRESS"].includes(r.status)).length,
    activeOrders: orderRows.filter((o) => activeOrderStates.includes(o.status)).length,
    completedTasks: requestRows.filter((r) => r.status === "COMPLETED").length,
    deliveredOrders: orderRows.filter((o) => o.status === "DELIVERED").length,
    fleets: fleetRows.length,
    restaurants: restRows.length,
    reviews: reviewRows.length,
    pendingApprovals: pendingApps.length + pendingMedia.length + provRows.filter((p) => !p.verified && p.status !== "SUSPENDED").length,
    openCases: caseRows.length,
    pendingInvitations: inviteRows.length,
    sevenDays,
  };
}

export type DashboardPulse = { signature: string; offers: number; active: number; pending: number; unread: number; messages: number; cases: number };

/** PII içermeyen rol kapsamlı değişiklik imzası. SSE ve polling aynı kaynaktan beslenir. */
export async function getDashboardPulse(s: Session): Promise<DashboardPulse> {
  let offers = 0;
  let active = 0;
  let pending = 0;
  let cases = 0;
  let stamp = "";
  if (s.user.role === "CUSTOMER") {
    const [req] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${serviceRequests.updatedAt})::text,'')` }).from(serviceRequests).where(and(eq(serviceRequests.customerId, s.user.id), inArray(serviceRequests.status, activeRequestStates)));
    const [ord] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${orders.updatedAt})::text,'')` }).from(orders).where(and(eq(orders.customerId, s.user.id), inArray(orders.status, activeOrderStates)));
    active = (req?.n ?? 0) + (ord?.n ?? 0); stamp = `${req?.stamp ?? ""}|${ord?.stamp ?? ""}`;
  } else if (s.providerId) {
    const [o] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${matchingCandidates.offeredAt})::text,'')` }).from(matchingCandidates).where(and(eq(matchingCandidates.providerId, s.providerId), eq(matchingCandidates.response, "OFFERED"), gt(matchingCandidates.offerExpiresAt, new Date())));
    const [a] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${serviceRequests.updatedAt})::text,'')` }).from(assignments).innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId)).where(and(eq(assignments.providerId, s.providerId), inArray(assignments.state, ["CONFIRMED", "IN_PROGRESS"])));
    const [p] = await db.select({ status: providers.status }).from(providers).where(eq(providers.id, s.providerId)).limit(1);
    offers = o?.n ?? 0; active = a?.n ?? 0;
    stamp = `${o?.stamp ?? ""}|${a?.stamp ?? ""}|${p?.status ?? ""}|${p?.status === "AVAILABLE" ? Math.floor(Date.now() / 60_000) : ""}`;
  } else if (s.fleetId) {
    const [o] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${matchingCandidates.offeredAt})::text,'')` }).from(matchingCandidates).where(and(eq(matchingCandidates.fleetId, s.fleetId), eq(matchingCandidates.response, "FLEET_PENDING"), gt(matchingCandidates.offerExpiresAt, new Date())));
    const [a] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${serviceRequests.updatedAt})::text,'')` }).from(assignments).innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId)).where(and(eq(assignments.fleetId, s.fleetId), inArray(assignments.state, ["CONFIRMED", "IN_PROGRESS"])));
    pending = o?.n ?? 0; active = a?.n ?? 0; stamp = `${o?.stamp ?? ""}|${a?.stamp ?? ""}`;
  } else if (s.restaurantId) {
    const [o] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${orders.updatedAt})::text,'')` }).from(orders).where(and(eq(orders.restaurantId, s.restaurantId), eq(orders.status, "ORDER_PLACED")));
    pending = o?.n ?? 0; stamp = o?.stamp ?? "";
  } else if (["ADMIN", "SUPER_ADMIN"].includes(s.user.role) || s.user.role === "SUPER_ADMIN") {
    const [[req], [ord], [prov], [med], [apps], [support], [last]] = await Promise.all([
      db.select({ n: sql<number>`count(*) filter (where ${serviceRequests.status} in ('MATCHING','OFFERED','CONFIRMED','IN_PROGRESS'))::int`, stamp: sql<string>`coalesce(max(${serviceRequests.updatedAt})::text,'')` }).from(serviceRequests),
      db.select({ n: sql<number>`count(*) filter (where ${orders.status} in ('ORDER_PLACED','RESTAURANT_ACCEPTED','PREPARING','READY_FOR_PICKUP','COURIER_ASSIGNED','OUT_FOR_DELIVERY'))::int`, stamp: sql<string>`coalesce(max(${orders.updatedAt})::text,'')` }).from(orders),
      db.select({ n: sql<number>`count(*) filter (where ${providers.isVerified} = false and ${providers.status} <> 'SUSPENDED')::int` }).from(providers),
      db.select({ n: sql<number>`count(*)::int` }).from(mediaPosts).where(eq(mediaPosts.status, "PENDING_REVIEW")),
      db.select({ n: sql<number>`count(*)::int` }).from(partnerApplications).where(eq(partnerApplications.status, "PENDING")),
      db.select({ n: sql<number>`count(*)::int` }).from(supportCases).where(inArray(supportCases.status, ["OPEN", "IN_REVIEW"])),
      db.select({ stamp: sql<string>`coalesce(max(${auditLogs.createdAt})::text,'')` }).from(auditLogs),
    ]);
    pending = (prov?.n ?? 0) + (med?.n ?? 0) + (apps?.n ?? 0);
    active = (req?.n ?? 0) + (ord?.n ?? 0);
    cases = support?.n ?? 0;
    stamp = `${req?.stamp ?? ""}|${ord?.stamp ?? ""}|${last?.stamp ?? ""}`;
  }
  const [notif] = await db.select({ n: sql<number>`count(*)::int`, stamp: sql<string>`coalesce(max(${notifications.createdAt})::text,'')` }).from(notifications).where(and(eq(notifications.userId, s.user.id), isNull(notifications.readAt)));
  const unread = notif?.n ?? 0;
  const messageCount = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role) || s.user.role === "SUPER_ADMIN" ? 0 : await unreadTotal(s);
  return { offers, active, pending, unread, messages: messageCount, cases, signature: [offers, active, pending, cases, unread, messageCount, stamp, notif?.stamp ?? ""].join(":") };
}
