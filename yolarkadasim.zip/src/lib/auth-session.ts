import { cookies } from "next/headers";
import { closeProviderAvailability, issueSession, lookupSessionUser, revokeSession, SESSION_COOKIE, SESSION_TTL_SECONDS } from "./session";

/**
 * Oturum açmanın tek yolu: eski token iptal edilir, kurye boşta kalmaz ve
 * DB'de yalnızca SHA-256 özeti tutulan opak token httpOnly çereze yazılır.
 * Çerezde rol/kullanıcı kimliği/JSON taşınmaz.
 */
export async function openSessionForUser(userId: string): Promise<void> {
  const jar = await cookies();
  const previousToken = jar.get(SESSION_COOKIE)?.value;
  const previous = await lookupSessionUser(previousToken);
  if (previous && previous.id !== userId && previous.role === "PROVIDER") await closeProviderAvailability(previous.id);
  await revokeSession(previousToken);

  const token = await issueSession(userId);
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_TTL_SECONDS,
  });
}
