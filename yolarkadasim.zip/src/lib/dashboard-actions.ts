import { and, eq, gt, inArray, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import { fleetDutySlots, fleetInvitations, fleets, notifications, orders, providers, serviceRequests, supportCases, users } from "@/db/schema";
import { audit } from "./engine";
import { HttpError } from "./http";
import type { Session } from "./session";

export async function inviteFleetProvider(s: Session, email: string) {
  if (!s.fleetId || s.user.role !== "FLEET_OWNER") throw new HttpError(403, "Yalnızca kendi filonuza üye davet edebilirsiniz.");
  const [user] = await db.select().from(users).where(eq(users.email, email.trim().toLowerCase())).limit(1);
  if (!user || user.role !== "PROVIDER") throw new HttpError(404, "Bu e-posta ile kayıtlı hizmet sağlayıcı bulunamadı. Davet yalnızca kayıtlı sağlayıcılara gönderilebilir.");
  const [provider] = await db.select().from(providers).where(eq(providers.userId, user.id)).limit(1);
  if (!provider || provider.status === "SUSPENDED") throw new HttpError(422, "Bu sağlayıcı şu anda davet edilemez.");
  if (provider.fleetId === s.fleetId) throw new HttpError(409, "Sağlayıcı zaten filonuzun üyesi.");
  if (provider.fleetId) throw new HttpError(409, "Sağlayıcı başka bir filoya bağlı.");
  const [pending] = await db.select().from(fleetInvitations).where(and(eq(fleetInvitations.fleetId, s.fleetId), eq(fleetInvitations.providerId, provider.id), eq(fleetInvitations.status, "PENDING"))).limit(1);
  if (pending) throw new HttpError(409, "Bu sağlayıcıya gönderilmiş bekleyen bir davet var.");
  const [fleet] = await db.select({ name: fleets.name }).from(fleets).where(eq(fleets.id, s.fleetId)).limit(1);
  return db.transaction(async (tx) => {
    const [invite] = await tx.insert(fleetInvitations).values({ fleetId: s.fleetId!, providerId: provider.id, createdBy: s.user.id }).returning();
    await tx.insert(notifications).values({ userId: provider.userId, title: `${fleet?.name ?? "Filo"} sizi davet etti`, body: "Filo üyeliği davetini panelinizden kabul veya reddedebilirsiniz.", link: "/dashboard/kurye/filom" });
    await audit(tx, s.user.id, "fleet.invite", "fleet_invitation", invite.id, "Kayıtlı sağlayıcıya davet", { fleetId: s.fleetId });
    return { id: invite.id, status: invite.status };
  });
}

export async function answerFleetInvitation(s: Session, invitationId: string, action: "ACCEPTED" | "DECLINED" | "CANCELLED") {
  return db.transaction(async (tx) => {
    const [invite] = await tx.select().from(fleetInvitations).where(eq(fleetInvitations.id, invitationId)).for("update").limit(1);
    if (!invite) throw new HttpError(404, "Davet bulunamadı.");
    if (invite.status !== "PENDING") throw new HttpError(409, "Bu davet artık beklemiyor.");
    if (action === "CANCELLED") {
      if (s.fleetId !== invite.fleetId || s.user.role !== "FLEET_OWNER") throw new HttpError(403, "Bu daveti iptal edemezsiniz.");
    } else {
      if (s.providerId !== invite.providerId || s.user.role !== "PROVIDER") throw new HttpError(403, "Yalnızca davet edilen sağlayıcı yanıtlayabilir.");
    }
    const [provider] = await tx.select().from(providers).where(eq(providers.id, invite.providerId)).for("update").limit(1);
    if (!provider) throw new HttpError(404, "Sağlayıcı bulunamadı.");
    if (action === "ACCEPTED") {
      if (provider.fleetId) throw new HttpError(409, "Sağlayıcı zaten bir filoya bağlı.");
      await tx.update(providers).set({ fleetId: invite.fleetId }).where(eq(providers.id, provider.id));
      await tx.update(fleetInvitations).set({ status: "CANCELLED", respondedAt: new Date() }).where(and(eq(fleetInvitations.providerId, provider.id), eq(fleetInvitations.status, "PENDING"), sql`${fleetInvitations.id} <> ${invite.id}`));
    }
    await tx.update(fleetInvitations).set({ status: action, respondedAt: new Date() }).where(eq(fleetInvitations.id, invite.id));
    const [fleet] = await tx.select().from(fleets).where(eq(fleets.id, invite.fleetId)).limit(1);
    if (fleet) await tx.insert(notifications).values({ userId: action === "CANCELLED" ? provider.userId : fleet.ownerUserId, title: action === "ACCEPTED" ? "Davet kabul edildi" : action === "DECLINED" ? "Davet reddedildi" : "Filo daveti iptal edildi", body: action === "CANCELLED" ? `${fleet.name} daveti geri çekti.` : `${provider.displayName} daveti ${action === "ACCEPTED" ? "kabul etti" : "reddetti"}.`, link: action === "CANCELLED" ? "/dashboard/kurye/filom" : "/dashboard/filo/ekip" });
    await audit(tx, s.user.id, `fleet.invitation.${action.toLowerCase()}`, "fleet_invitation", invite.id, "Üyelik daveti kararı", { fleetId: invite.fleetId });
    return { ok: true, status: action };
  });
}

export async function scheduleFleetDuty(s: Session, input: { providerId: string; startsAt: Date; endsAt: Date; vehicleType: string; vehicleLabel?: string }) {
  if (!s.fleetId || s.user.role !== "FLEET_OWNER") throw new HttpError(403, "Yalnızca filo yöneticisi vardiya planlayabilir.");
  if (input.startsAt.getTime() < Date.now() + 10 * 60000 || input.startsAt.getTime() > Date.now() + 30 * 86400000) throw new HttpError(422, "Vardiya 10 dakika ile 30 gün sonrası arasında başlamalı.");
  const duration = input.endsAt.getTime() - input.startsAt.getTime();
  if (duration < 30 * 60000 || duration > 12 * 3600000) throw new HttpError(422, "Vardiya süresi 30 dakika ile 12 saat arasında olmalı.");
  return db.transaction(async (tx) => {
    // Aynı sağlayıcı için eşzamanlı çakışan planlar advisory lock ile engellenir.
    await tx.execute(sql`select pg_advisory_xact_lock(hashtext(${input.providerId}))`);
    const [provider] = await tx.select().from(providers).where(and(eq(providers.id, input.providerId), eq(providers.fleetId, s.fleetId!))).limit(1);
    if (!provider) throw new HttpError(404, "Bu sağlayıcı filonuzda bulunamadı.");
    if (provider.vehicleType !== input.vehicleType) throw new HttpError(422, "Araç türü sağlayıcının doğrulanmış aracıyla eşleşmeli.");
    const [overlap] = await tx.select({ id: fleetDutySlots.id }).from(fleetDutySlots).where(and(eq(fleetDutySlots.providerId, provider.id), eq(fleetDutySlots.status, "PLANNED"), lt(fleetDutySlots.startsAt, input.endsAt), gt(fleetDutySlots.endsAt, input.startsAt))).limit(1);
    if (overlap) throw new HttpError(409, "Bu üyenin aynı saatlerde başka bir vardiyası var.");
    const [duty] = await tx.insert(fleetDutySlots).values({ fleetId: s.fleetId!, providerId: provider.id, vehicleType: input.vehicleType, vehicleLabel: input.vehicleLabel?.trim() || provider.vehicleLabel, startsAt: input.startsAt, endsAt: input.endsAt, createdBy: s.user.id }).returning();
    await tx.insert(notifications).values({ userId: provider.userId, title: "Yeni vardiya planlandı", body: "Filonuz yeni bir vardiya oluşturdu. Tarih ve araç bilgilerini panelinizden görebilirsiniz.", link: "/dashboard/kurye/filom" });
    await audit(tx, s.user.id, "fleet.duty.schedule", "fleet_duty_slot", duty.id, "Vardiya planı", { fleetId: s.fleetId, providerId: provider.id });
    return { id: duty.id };
  });
}

export async function cancelFleetDuty(s: Session, id: string) {
  if (!s.fleetId || s.user.role !== "FLEET_OWNER") throw new HttpError(403, "Yalnızca filo yöneticisi vardiya iptal edebilir.");
  return db.transaction(async (tx) => {
    const [duty] = await tx.select().from(fleetDutySlots).where(and(eq(fleetDutySlots.id, id), eq(fleetDutySlots.fleetId, s.fleetId!))).for("update").limit(1);
    if (!duty) throw new HttpError(404, "Vardiya bulunamadı.");
    if (duty.status !== "PLANNED" || duty.startsAt < new Date()) throw new HttpError(409, "Başlamış veya kapanmış vardiya iptal edilemez.");
    await tx.update(fleetDutySlots).set({ status: "CANCELLED" }).where(eq(fleetDutySlots.id, duty.id));
    const [provider] = await tx.select({ userId: providers.userId }).from(providers).where(eq(providers.id, duty.providerId)).limit(1);
    if (provider) await tx.insert(notifications).values({ userId: provider.userId, title: "Vardiya iptal edildi", body: "Filonuz planlanan vardiyanızı iptal etti. Güncel programı kontrol edin.", link: "/dashboard/kurye/filom" });
    await audit(tx, s.user.id, "fleet.duty.cancel", "fleet_duty_slot", id, "Vardiya iptali");
    return { ok: true };
  });
}

export async function createSupportCase(s: Session, input: { sourceType: "REQUEST" | "ORDER"; sourceId: string; category: "DELIVERY" | "OTP" | "CANCELLATION" | "OTHER"; detail: string }) {
  if (s.user.role !== "CUSTOMER") throw new HttpError(403, "Destek vakasını yalnızca müşteri açabilir.");
  const owned = input.sourceType === "ORDER"
    ? await db.select({ id: orders.id }).from(orders).where(and(eq(orders.id, input.sourceId), eq(orders.customerId, s.user.id))).limit(1)
    : await db.select({ id: serviceRequests.id }).from(serviceRequests).where(and(eq(serviceRequests.id, input.sourceId), eq(serviceRequests.customerId, s.user.id))).limit(1);
  if (!owned.length) throw new HttpError(404, "İlgili sipariş veya talep bulunamadı.");
  return db.transaction(async (tx) => {
    const [row] = await tx.insert(supportCases).values({ customerId: s.user.id, sourceType: input.sourceType, sourceId: input.sourceId, category: input.category, detail: input.detail.trim() }).returning();
    await audit(tx, s.user.id, "support.case.open", "support_case", row.id, `Kategori: ${input.category}`);
    return { id: row.id, status: row.status };
  });
}

export async function resolveSupportCase(s: Session, caseId: string, input: { status: "IN_REVIEW" | "RESOLVED" | "REJECTED"; resolution: string }) {
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role) && s.user.role !== "SUPER_ADMIN") throw new HttpError(403, "Yalnızca operasyon ekibi karar verebilir.");
  return db.transaction(async (tx) => {
    const [row] = await tx.select().from(supportCases).where(eq(supportCases.id, caseId)).for("update").limit(1);
    if (!row) throw new HttpError(404, "Destek kaydı bulunamadı.");
    if (["RESOLVED", "REJECTED"].includes(row.status)) throw new HttpError(409, "Bu vaka zaten sonuçlandırılmış.");
    const closed = input.status !== "IN_REVIEW";
    await tx.update(supportCases).set({ status: input.status, resolution: input.resolution.trim(), resolvedBy: s.user.id, resolvedAt: closed ? new Date() : null, updatedAt: new Date() }).where(eq(supportCases.id, row.id));
    await tx.insert(notifications).values({ userId: row.customerId, title: closed ? "Destek talebiniz sonuçlandı" : "Destek talebiniz inceleniyor", body: "Karar ve gerekçeyi müşteri panelinizde görebilirsiniz.", link: "/dashboard/musteri/gecmis" });
    await audit(tx, s.user.id, "support.case.decision", "support_case", row.id, `Karar: ${input.status}`, { before: row.status, after: input.status });
    return { ok: true };
  });
}
