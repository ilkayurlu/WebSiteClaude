import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments,
  favorites,
  fleets,
  matchingCandidates,
  notifications,
  providers,
  requestEvents,
  reviews,
  serviceRequests,
  users,
  type Fleet,
  type Provider,
} from "@/db/schema";
import { distanceBand, etaBand, etaSeconds, getArea, getCity, haversineM, roadDistanceM } from "./geo";
import type { Session } from "./session";
import { ratingBayes } from "./matching";

/** Whitelist serializer — telefon, ham konum, userId asla dışarı çıkmaz. */
export function publicProvider(p: Provider, fleet?: Pick<Fleet, "slug" | "name" | "directPolicy" | "isVerified"> | null) {
  return {
    id: p.id,
    slug: p.slug,
    kind: p.kind,
    displayName: p.displayName,
    headline: p.headline,
    bio: p.bio,
    vehicleType: p.vehicleType,
    vehicleLabel: p.vehicleLabel,
    serviceTypes: p.serviceTypes,
    serviceAreas: p.serviceAreas,
    highlights: p.highlights,
    isVerified: p.isVerified,
    status: p.status,
    ratingAvg: p.ratingAvg,
    ratingCount: p.ratingCount,
    completedCount: p.completedCount,
    onTimeRate: p.onTimeRate,
    acceptsInstant: p.acceptsInstant,
    acceptsScheduled: p.acceptsScheduled,
    acceptsRental: p.acceptsRental,
    rentalHourlyMinor: p.rentalHourlyMinor,
    baseFareMinor: p.baseFareMinor,
    perKmMinor: p.perKmMinor,
    hue: p.hue,
    fleet: fleet ? { slug: fleet.slug, name: fleet.name, policy: fleet.directPolicy, isVerified: fleet.isVerified } : null,
  };
}
export type PublicProvider = ReturnType<typeof publicProvider> & { eta?: string; distance?: string; etaS?: number };

async function fleetMap(ids: (string | null)[]) {
  const clean = [...new Set(ids.filter(Boolean))] as string[];
  if (!clean.length) return new Map<string, Fleet>();
  const rows = await db.select().from(fleets).where(inArray(fleets.id, clean));
  return new Map(rows.map((f) => [f.id, f]));
}

export async function listProviders(f: { area?: string; cityCode?: string; vehicle?: string; service?: string; mode?: string; onlyAvailable?: boolean }) {
  const rows = await db.select().from(providers).where(sql`${providers.visibility} = 'PUBLIC' AND ${providers.status} <> 'SUSPENDED'`);
  const fm = await fleetMap(rows.map((r) => r.fleetId));
  const area = getArea(f.area);
  const city = !area && f.cityCode ? getCity(f.cityCode) : undefined;
  const cityPrefix = city ? `${city.slug}-` : null;
  let list: PublicProvider[] = rows
    .filter((p) => (!f.vehicle || p.vehicleType === f.vehicle))
    .filter((p) => (!f.service || p.serviceTypes.includes(f.service)))
    .filter((p) => (f.mode === "INSTANT_RENT" ? p.acceptsRental : f.mode === "SCHEDULED" ? p.acceptsScheduled : true))
    .filter((p) => (!area || p.serviceAreas.includes(area.key)))
    .filter((p) => (!cityPrefix || p.serviceAreas.some((slug) => slug.startsWith(cityPrefix))))
    .filter((p) => (!f.onlyAvailable || p.status === "AVAILABLE"))
    .map((p) => {
      const base: PublicProvider = publicProvider(p, p.fleetId ? fm.get(p.fleetId) : null);
      if (area && p.lastLat != null && p.lastLng != null) {
        const m = haversineM(p.lastLat, p.lastLng, area.lat, area.lng);
        base.etaS = etaSeconds(m, p.vehicleType);
        base.eta = etaBand(base.etaS);
        base.distance = distanceBand(roadDistanceM(m));
      }
      return base;
    });
  list = list.sort((a, b) => {
    const av = a.status === "AVAILABLE" ? 0 : 1;
    const bv = b.status === "AVAILABLE" ? 0 : 1;
    if (av !== bv) return av - bv;
    if (a.etaS != null && b.etaS != null) return a.etaS - b.etaS;
    return ratingBayes(b.ratingAvg, b.ratingCount) - ratingBayes(a.ratingAvg, a.ratingCount);
  });
  return list;
}

export async function getProviderPage(slug: string) {
  const [p] = await db.select().from(providers).where(eq(providers.slug, slug)).limit(1);
  if (!p || p.visibility === "HIDDEN") return null;
  const [fleet] = p.fleetId ? await db.select().from(fleets).where(eq(fleets.id, p.fleetId)).limit(1) : [];
  const revs = await db
    .select({ r: reviews, author: users.name })
    .from(reviews)
    .leftJoin(users, eq(users.id, reviews.authorId))
    .where(and(eq(reviews.targetId, p.id), eq(reviews.status, "PUBLISHED")))
    .orderBy(desc(reviews.createdAt))
    .limit(30);
  const cats = revs.length
    ? {
        time: avg(revs.map((x) => x.r.catTime)),
        communication: avg(revs.map((x) => x.r.catCommunication)),
        care: avg(revs.map((x) => x.r.catCare)),
        professionalism: avg(revs.map((x) => x.r.catProfessionalism)),
      }
    : null;
  const dist = [5, 4, 3, 2, 1].map((s) => ({ star: s, n: revs.filter((x) => x.r.rating === s).length }));
  return {
    provider: publicProvider(p, fleet ?? null),
    reviews: revs.map((x) => ({
      id: x.r.id,
      rating: x.r.rating,
      body: x.r.body,
      createdAt: x.r.createdAt,
      author: maskName(x.author ?? "Müşteri"),
    })),
    categories: cats,
    distribution: dist,
  };
}

function avg(xs: (number | null)[]) {
  const v = xs.filter((x): x is number => x != null);
  return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : 0;
}

export function maskName(n: string) {
  const [first, ...rest] = n.split(" ");
  return [first, ...rest.map((r) => r[0] + ".")].join(" ");
}

export async function listFleets() {
  const rows = await db.select().from(fleets).orderBy(asc(fleets.name));
  const counts = await db
    .select({ fleetId: providers.fleetId, n: sql<number>`count(*)::int`, avail: sql<number>`count(*) filter (where ${providers.status}='AVAILABLE')::int`, rating: sql<number>`coalesce(avg(nullif(${providers.ratingAvg},0)),0)::float` })
    .from(providers)
    .groupBy(providers.fleetId);
  return rows.map((f) => {
    const c = counts.find((x) => x.fleetId === f.id);
    return { ...f, ownerUserId: undefined, members: c?.n ?? 0, available: c?.avail ?? 0, rating: c?.rating ?? 0 };
  });
}

export async function getFleetPage(slug: string) {
  const [f] = await db.select().from(fleets).where(eq(fleets.slug, slug)).limit(1);
  if (!f) return null;
  const members = await db.select().from(providers).where(eq(providers.fleetId, f.id));
  return {
    fleet: {
      id: f.id,
      slug: f.slug,
      name: f.name,
      description: f.description,
      city: f.city,
      policy: f.directPolicy,
      isVerified: f.isVerified,
      accent: f.accent,
      showMembersPublicly: f.showMembersPublicly,
      opensAt: f.opensAt,
      closesAt: f.closesAt,
      phonePublic: f.phonePublic,
      website: f.website,
      capacityLabel: f.capacityLabel,
      servicePackages: f.servicePackages,
      serviceAreas: f.serviceAreas,
    },
    members: f.showMembersPublicly ? members.filter((m) => m.visibility === "PUBLIC").map((m) => publicProvider(m, f)) : [],
    memberCount: members.length,
    availableCount: members.filter((m) => m.status === "AVAILABLE").length,
  };
}

export async function getFavoriteIds(customerId: string) {
  const rows = await db.select().from(favorites).where(eq(favorites.customerId, customerId));
  return {
    providers: rows.filter((r) => r.targetType === "PROVIDER").map((r) => r.targetId),
    fleets: rows.filter((r) => r.targetType === "FLEET").map((r) => r.targetId),
    restaurants: rows.filter((r) => r.targetType === "RESTAURANT").map((r) => r.targetId),
  };
}

export async function getFavoriteProviders(customerId: string) {
  const ids = (await getFavoriteIds(customerId)).providers;
  if (!ids.length) return [];
  const rows = await db.select().from(providers).where(inArray(providers.id, ids));
  const fm = await fleetMap(rows.map((r) => r.fleetId));
  return rows.map((p) => publicProvider(p, p.fleetId ? fm.get(p.fleetId) : null));
}

/** Talep görünümü — sahiplik: müşteri, aday/atanan sağlayıcı, ilgili filo, ops. */
export async function getRequestView(s: Session, id: string) {
  const [req] = await db.select().from(serviceRequests).where(eq(serviceRequests.id, id)).limit(1);
  if (!req) return null;
  const cands = await db.select().from(matchingCandidates).where(eq(matchingCandidates.requestId, id)).orderBy(asc(matchingCandidates.rank));
  const [asg] = await db.select().from(assignments).where(eq(assignments.requestId, id)).limit(1);

  const isCustomer = req.customerId === s.user.id;
  const isAdmin = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role);
  const isProvider = !!s.providerId && (asg?.providerId === s.providerId || cands.some((c) => c.providerId === s.providerId && c.response));
  const isFleet = !!s.fleetId && (asg?.fleetId === s.fleetId || cands.some((c) => c.fleetId === s.fleetId && c.response));
  if (!isCustomer && !isAdmin && !isProvider && !isFleet) return null;

  const provIds = [...new Set([...cands.map((c) => c.providerId), asg?.providerId].filter(Boolean))] as string[];
  const provRows = provIds.length ? await db.select().from(providers).where(inArray(providers.id, provIds)) : [];
  const fm = await fleetMap(provRows.map((p) => p.fleetId));
  const pm = new Map(provRows.map((p) => [p.id, publicProvider(p, p.fleetId ? fm.get(p.fleetId) : null)]));

  const events = await db.select().from(requestEvents).where(eq(requestEvents.requestId, id)).orderBy(asc(requestEvents.createdAt));
  const [review] = await db.select().from(reviews).where(eq(reviews.sourceId, id)).limit(1);
  const favs = isCustomer ? await getFavoriteIds(s.user.id) : { providers: [] as string[], fleets: [] as string[], restaurants: [] as string[] };

  return {
    viewer: { isCustomer, isAdmin, isProvider, isFleet },
    request: { ...req, deliveryOtp: isCustomer ? req.deliveryOtp : null, idempotencyKey: undefined },
    candidates: cands.map((c) => ({
      id: c.id,
      rank: c.rank,
      provider: pm.get(c.providerId)!,
      eta: etaBand(c.etaSeconds),
      distance: distanceBand(c.distanceM),
      priceMinor: c.priceMinor,
      score: c.score,
      breakdown: c.breakdown,
      response: c.response,
      offerExpiresAt: c.offerExpiresAt,
      isFavorite: favs.providers.includes(c.providerId),
    })),
    assignment: asg ? { ...asg, provider: pm.get(asg.providerId)! } : null,
    events,
    review: review ? { rating: review.rating, body: review.body, status: review.status } : null,
  };
}
export type RequestView = NonNullable<Awaited<ReturnType<typeof getRequestView>>>;

export async function listCustomerRequests(customerId: string) {
  const rows = await db.select().from(serviceRequests).where(eq(serviceRequests.customerId, customerId)).orderBy(desc(serviceRequests.createdAt)).limit(50);
  const ids = rows.map((r) => r.id);
  const asg = ids.length ? await db.select({ requestId: assignments.requestId, name: providers.displayName }).from(assignments).innerJoin(providers, eq(providers.id, assignments.providerId)).where(inArray(assignments.requestId, ids)) : [];
  return rows.map((r) => ({ ...r, providerName: asg.find((a) => a.requestId === r.id)?.name ?? null }));
}

export async function getProviderPanel(providerId: string) {
  const [p] = await db.select().from(providers).where(eq(providers.id, providerId)).limit(1);
  const offers = await db
    .select({ c: matchingCandidates, r: serviceRequests })
    .from(matchingCandidates)
    .innerJoin(serviceRequests, eq(serviceRequests.id, matchingCandidates.requestId))
    .where(and(eq(matchingCandidates.providerId, providerId), eq(matchingCandidates.response, "OFFERED")))
    .orderBy(asc(matchingCandidates.offerExpiresAt));
  const pendingFleet = await db
    .select({ c: matchingCandidates, r: serviceRequests })
    .from(matchingCandidates)
    .innerJoin(serviceRequests, eq(serviceRequests.id, matchingCandidates.requestId))
    .where(and(eq(matchingCandidates.providerId, providerId), eq(matchingCandidates.response, "FLEET_PENDING")));
  const tasks = await db
    .select({ a: assignments, r: serviceRequests })
    .from(assignments)
    .innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId))
    .where(eq(assignments.providerId, providerId))
    .orderBy(desc(assignments.acceptedAt))
    .limit(30);
  const [fleet] = p?.fleetId ? await db.select().from(fleets).where(eq(fleets.id, p.fleetId)).limit(1) : [];
  const earnings = tasks.filter((t) => t.a.state === "COMPLETED").reduce((s, t) => s + (t.r.finalPriceMinor ?? 0), 0);
  return { provider: p, fleet: fleet ?? null, offers, pendingFleet, tasks, earnings };
}

export async function getFleetInbox(fleetId: string) {
  const [fleet] = await db.select().from(fleets).where(eq(fleets.id, fleetId)).limit(1);
  const members = await db.select().from(providers).where(eq(providers.fleetId, fleetId)).orderBy(asc(providers.displayName));
  const pending = await db
    .select({ c: matchingCandidates, r: serviceRequests, p: providers })
    .from(matchingCandidates)
    .innerJoin(serviceRequests, eq(serviceRequests.id, matchingCandidates.requestId))
    .innerJoin(providers, eq(providers.id, matchingCandidates.providerId))
    .where(and(eq(matchingCandidates.fleetId, fleetId), eq(matchingCandidates.response, "FLEET_PENDING")))
    .orderBy(asc(matchingCandidates.offerExpiresAt));
  const active = await db
    .select({ a: assignments, r: serviceRequests, p: providers })
    .from(assignments)
    .innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId))
    .innerJoin(providers, eq(providers.id, assignments.providerId))
    .where(eq(assignments.fleetId, fleetId))
    .orderBy(desc(assignments.acceptedAt))
    .limit(30);
  return { fleet, members, pending, active };
}

export async function getNotifications(userId: string) {
  const rows = await db.select().from(notifications).where(eq(notifications.userId, userId)).orderBy(desc(notifications.createdAt)).limit(20);
  const [c] = await db.select({ n: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, userId), sql`${notifications.readAt} IS NULL`));
  return { items: rows, unread: c?.n ?? 0 };
}
