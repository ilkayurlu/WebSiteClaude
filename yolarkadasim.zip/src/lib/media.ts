import { createHash } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, fleets, mediaPosts, moderationCases, notifications, providers, restaurants, type MediaPost } from "@/db/schema";
import { HttpError } from "./http";
import { audit } from "./engine";
import type { Session } from "./session";

const PRIVATE_DIR = path.join(process.cwd(), "storage", "private");
export const MAX_IMAGE_BYTES = 8 * 1024 * 1024;
export const MAX_VIDEO_BYTES = 60 * 1024 * 1024;

/** Gerçek dosya türü kontrolü — yalnızca MIME başlığına güvenilmez. */
export function sniff(buf: Uint8Array): { mime: string; ext: string; kind: "IMAGE" | "VIDEO" } | null {
  const h = Buffer.from(buf.slice(0, 16));
  if (h[0] === 0xff && h[1] === 0xd8 && h[2] === 0xff) return { mime: "image/jpeg", ext: "jpg", kind: "IMAGE" };
  if (h.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: "image/png", ext: "png", kind: "IMAGE" };
  if (h.subarray(0, 4).toString("latin1") === "RIFF" && h.subarray(8, 12).toString("latin1") === "WEBP") return { mime: "image/webp", ext: "webp", kind: "IMAGE" };
  if (h.subarray(4, 8).toString("latin1") === "ftyp") return { mime: "video/mp4", ext: "mp4", kind: "VIDEO" };
  return null;
}

/** JPEG: APP1 (EXIF/GPS) ve diğer uygulama segmentleri atılır; PNG/WebP: EXIF chunk'ları silinir. */
export function stripMetadata(buf: Buffer, mime: string): { data: Buffer; stripped: boolean } {
  if (mime === "image/jpeg") {
    const out: Buffer[] = [];
    let i = 0;
    if (buf[0] !== 0xff || buf[1] !== 0xd8) return { data: buf, stripped: false };
    out.push(buf.subarray(0, 2));
    i = 2;
    let stripped = false;
    while (i < buf.length) {
      if (buf[i] !== 0xff) {
        out.push(buf.subarray(i));
        break;
      }
      const marker = buf[i + 1];
      if (marker === 0xda) {
        out.push(buf.subarray(i)); // SOS + entropy data: olduğu gibi
        break;
      }
      const len = buf.readUInt16BE(i + 2);
      const isApp = marker >= 0xe0 && marker <= 0xef;
      const isComment = marker === 0xfe;
      if (isApp && marker !== 0xe0) {
        stripped = true; // APP1 EXIF/XMP, APP13 IPTC vb. kaldırılır
      } else if (isComment) {
        stripped = true;
      } else {
        out.push(buf.subarray(i, i + 2 + len));
      }
      i += 2 + len;
    }
    return { data: Buffer.concat(out), stripped };
  }
  if (mime === "image/png") {
    const sig = buf.subarray(0, 8);
    const chunks: Buffer[] = [Buffer.from(sig)];
    let i = 8;
    let stripped = false;
    while (i + 8 <= buf.length) {
      const len = buf.readUInt32BE(i);
      const type = buf.subarray(i + 4, i + 8).toString("latin1");
      const total = 12 + len;
      const keep = ["IHDR", "PLTE", "IDAT", "IEND", "tRNS", "gAMA", "sRGB", "pHYs"].includes(type);
      if (!keep) stripped = true;
      else chunks.push(Buffer.from(buf.subarray(i, i + total)));
      i += total;
      if (type === "IEND") break;
    }
    return { data: Buffer.concat(chunks), stripped };
  }
  if (mime === "image/webp") {
    // Basit yaklaşım: EXIF/XMP chunk'larını RIFF içinden çıkar
    const isRiff = buf.subarray(0, 4).toString("latin1") === "RIFF";
    if (!isRiff) return { data: buf, stripped: false };
    const head = Buffer.from(buf.subarray(0, 12));
    const out: Buffer[] = [head];
    let i = 12;
    let stripped = false;
    while (i + 8 <= buf.length) {
      const fourcc = buf.subarray(i, i + 4).toString("latin1");
      const len = buf.readUInt32LE(i + 4);
      const total = 8 + len + (len % 2);
      if (fourcc === "EXIF" || fourcc === "XMP " || fourcc === "ICCP") stripped = true;
      else out.push(Buffer.from(buf.subarray(i, Math.min(i + total, buf.length))));
      i += total;
    }
    const body = Buffer.concat(out);
    body.writeUInt32LE(body.length - 8, 4);
    return { data: body, stripped };
  }
  return { data: buf, stripped: false };
}

async function writePrivate(id: string, ext: string, data: Buffer) {
  await mkdir(PRIVATE_DIR, { recursive: true });
  const p = path.join(PRIVATE_DIR, `${id}.${ext}`);
  await writeFile(p, data);
  return path.relative(process.cwd(), p);
}

export type Owner = { ownerType: "PROVIDER" | "FLEET" | "RESTAURANT"; ownerId: string };

export async function resolveOwner(s: Session): Promise<Owner> {
  if (s.providerId) return { ownerType: "PROVIDER", ownerId: s.providerId };
  if (s.fleetId) return { ownerType: "FLEET", ownerId: s.fleetId };
  if (s.restaurantId) return { ownerType: "RESTAURANT", ownerId: s.restaurantId };
  throw new HttpError(403, "Medya yüklemek için sağlayıcı, filo veya işletme hesabı gerekir.");
}

/** Güvenilir üretici: ≥3 yayında içerik ve hiç ihlali yok → hızlandırılmış yayın + 24 sa post-review. */
export async function isTrustedProducer(owner: Owner) {
  const [pub] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(mediaPosts)
    .where(and(eq(mediaPosts.ownerType, owner.ownerType), eq(mediaPosts.ownerId, owner.ownerId), eq(mediaPosts.status, "PUBLISHED")));
  const [rej] = await db
    .select({ n: sql<number>`count(*)::int` })
    .from(mediaPosts)
    .where(and(eq(mediaPosts.ownerType, owner.ownerType), eq(mediaPosts.ownerId, owner.ownerId), eq(mediaPosts.status, "REJECTED")));
  return (pub?.n ?? 0) >= 3 && (rej?.n ?? 0) === 0;
}

export async function createMediaPost(s: Session, file: File, input: { caption?: string; rightsDeclaration?: boolean; kind?: "POST" | "COVER" }) {
  const owner = await resolveOwner(s);
  if (!input.rightsDeclaration) throw new HttpError(422, "İçeriğin kullanım haklarına sahip olduğunuzu onaylamanız gerekir.");
  const buf = Buffer.from(await file.arrayBuffer());
  const isVideo = file.type.startsWith("video") || file.size > MAX_IMAGE_BYTES;
  const limit = isVideo ? MAX_VIDEO_BYTES : MAX_IMAGE_BYTES;
  if (buf.byteLength < 64) throw new HttpError(422, "Dosya geçersiz veya çok küçük.");
  if (buf.byteLength > limit) throw new HttpError(413, `Dosya boyutu sınırı aşıldı (en fazla ${Math.round(limit / 1024 / 1024)} MB).`);
  const sniffed = sniff(buf);
  if (!sniffed) throw new HttpError(415, "Desteklenmeyen dosya türü. Yalnızca JPEG, PNG, WebP veya MP4 yükleyebilirsiniz.");
  if (sniffed.kind === "VIDEO") throw new HttpError(422, "Video yüklemesi bu demo ortamında kapalı (transcode servisi bağlı değil). Fotoğraf yükleyebilirsiniz.");
  const id = crypto.randomUUID();
  const { data, stripped } = stripMetadata(buf, sniffed.mime);
  const sha256 = createHash("sha256").update(data).digest("hex");
  const [dup] = await db.select({ id: mediaPosts.id, status: mediaPosts.status }).from(mediaPosts).where(eq(mediaPosts.sha256, sha256)).limit(1);
  if (dup && dup.status === "REJECTED") throw new HttpError(422, "Bu içerik daha önce reddedilmişti. Aynı dosya tekrar yüklenemez.");
  const privatePath = await writePrivate(id, sniffed.ext, data);
  const trusted = await isTrustedProducer(owner);
  const [post] = await db
    .insert(mediaPosts)
    .values({
      id,
      ownerType: owner.ownerType,
      ownerId: owner.ownerId,
      userId: s.user.id,
      caption: input.caption?.trim() || null,
      mediaType: sniffed.kind,
      status: trusted ? "PUBLISHED" : "PENDING_REVIEW",
      privatePath,
      mime: sniffed.mime,
      bytes: data.byteLength,
      sha256,
      exifStripped: stripped,
      scanned: true,
      rightsDeclaration: true,
      publishedAt: trusted ? new Date() : null,
    })
    .returning();
  if (trusted) {
    await db.insert(moderationCases).values({ kind: "MEDIA", targetType: "MEDIA", targetId: post.id, status: "OPEN", reason: "Güvenilir üretici — 24 saat içinde geriye dönük inceleme", policyRef: "M-FAST" });
  } else {
    await db.insert(moderationCases).values({ kind: "MEDIA", targetType: "MEDIA", targetId: post.id, status: "OPEN", reason: "Yeni medya gönderisi incelemesi" });
  }
  await audit(db, s.user.id, "media.upload", "media_post", post.id, undefined, { mime: post.mime, bytes: post.bytes, exifStripped: post.exifStripped, trusted });
  return { id: post.id, status: post.status, trusted };
}

/** Yayına alma: public sürüm yetki kontrollü medya uç noktası üzerinden sunulur. */
function publishFile(post: MediaPost) {
  if (!post.privatePath) return null;
  return `/api/media/file/${post.id}`;
}

export async function moderateMedia(s: Session, postId: string, action: "approve" | "reject" | "hide" | "archive", reason: string, policyRef?: string) {
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) throw new HttpError(403, "Medya moderasyonu yalnızca operasyon ekibine açıktır.");
  if (!reason || reason.trim().length < 5) throw new HttpError(422, "Gerekçe zorunlu (en az 5 karakter).");
  return db.transaction(async (tx) => {
    const [post] = await tx.select().from(mediaPosts).where(eq(mediaPosts.id, postId)).limit(1);
    if (!post) throw new HttpError(404, "Medya bulunamadı.");
    const before = post.status;
    let publicUrl = post.publicUrl;
    let status = post.status;
    if (action === "approve") {
      publicUrl = publishFile(post) ?? post.publicUrl;
      status = publicUrl ? "PUBLISHED" : "APPROVED";
    } else if (action === "reject") status = "REJECTED";
    else if (action === "hide") status = "ARCHIVED";
    else status = "ARCHIVED";
    await tx
      .update(mediaPosts)
      .set({ status, publicUrl: status === "PUBLISHED" ? publicUrl : null, moderationReason: reason, publishedAt: status === "PUBLISHED" ? post.publishedAt ?? new Date() : null })
      .where(eq(mediaPosts.id, postId));
    const [c] = await tx.select().from(moderationCases).where(and(eq(moderationCases.targetId, postId), eq(moderationCases.kind, "MEDIA"))).limit(1);
    if (c) await tx.update(moderationCases).set({ status: action === "approve" ? "APPROVED" : action === "reject" ? "REJECTED" : "ARCHIVED", reason, policyRef: policyRef ?? null, decidedBy: s.user.id, decidedAt: new Date() }).where(eq(moderationCases.id, c.id));
    else await tx.insert(moderationCases).values({ kind: "MEDIA", targetType: "MEDIA", targetId: postId, status: action === "approve" ? "APPROVED" : "REJECTED", reason, policyRef: policyRef ?? null, decidedBy: s.user.id, decidedAt: new Date() });
    await audit(tx, s.user.id, `media.${action}`, "media_post", postId, reason, { before, after: status, policyRef });
    const messages: Record<string, string> = {
      approve: "Medyanız onaylandı ve yayına alındı.",
      reject: `Medyanız reddedildi. Gerekçe: ${reason}`,
      hide: `Medyanız geçici olarak gizlendi. Gerekçe: ${reason}`,
      archive: `Medyanız arşivlendi. Gerekçe: ${reason}`,
    };
    await tx.insert(notifications).values({ userId: post.userId, title: "Medya güncellemesi", body: messages[action], link: ownerLink(post) });
    return { ok: true, status };
  });
}

export function ownerLink(post: Pick<MediaPost, "ownerType" | "ownerId">) {
  return post.ownerType === "PROVIDER" ? "/panel/profil" : post.ownerType === "FLEET" ? "/filo" : "/isletme";
}

export async function deleteOwnMedia(s: Session, postId: string) {
  const [post] = await db.select().from(mediaPosts).where(eq(mediaPosts.id, postId)).limit(1);
  if (!post) throw new HttpError(404, "Medya bulunamadı.");
  if (post.userId !== s.user.id && !["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) throw new HttpError(403, "Yalnızca kendi içeriğinizi silebilirsiniz.");
  await db.update(mediaPosts).set({ status: "ARCHIVED", publicUrl: null }).where(eq(mediaPosts.id, postId));
  await audit(db, s.user.id, "media.delete_own", "media_post", postId);
  return { ok: true };
}

export async function reportContent(s: Session, input: { targetType: string; targetId: string; reason: string; detail?: string }) {
  const [dup] = await db
    .select({ id: mediaPosts.id })
    .from(mediaPosts)
    .where(sql`${input.targetType} = ${input.targetType} AND 1=0`)
    .limit(1);
  void dup;
  const { contentReports } = await import("@/db/schema");
  await db
    .insert(contentReports)
    .values({ reporterId: s.user.id, targetType: input.targetType, targetId: input.targetId, reason: input.reason, detail: input.detail?.trim() || null })
    .onConflictDoNothing();
  await db.insert(moderationCases).values({ kind: "REPORT", targetType: input.targetType, targetId: input.targetId, status: "OPEN", reason: input.reason });
  if (input.targetType === "MEDIA") await db.update(mediaPosts).set({ reportCount: sql`${mediaPosts.reportCount} + 1` }).where(eq(mediaPosts.id, input.targetId));
  await audit(db, s.user.id, "content.report", input.targetType, input.targetId, input.reason, { detailProvided: !!input.detail });
  return { ok: true };
}

export async function getPublishedMedia(ownerType: string, ownerId: string) {
  return db
    .select()
    .from(mediaPosts)
    .where(and(eq(mediaPosts.ownerType, ownerType), eq(mediaPosts.ownerId, ownerId), eq(mediaPosts.status, "PUBLISHED")))
    .orderBy(sql`${mediaPosts.publishedAt} DESC NULLS LAST`);
}

export async function getOwnMedia(owner: Owner) {
  return db.select().from(mediaPosts).where(and(eq(mediaPosts.ownerType, owner.ownerType), eq(mediaPosts.ownerId, owner.ownerId))).orderBy(sql`${mediaPosts.createdAt} DESC`);
}

export async function moderationQueue(kind?: string) {
  const posts = await db.select().from(mediaPosts).where(eq(mediaPosts.status, "PENDING_REVIEW")).orderBy(mediaPosts.createdAt);
  const names: Record<string, string> = {};
  const provs = await db.select({ id: providers.id, name: providers.displayName }).from(providers);
  const fls = await db.select({ id: fleets.id, name: fleets.name }).from(fleets);
  const rests = await db.select({ id: restaurants.id, name: restaurants.name }).from(restaurants);
  for (const p of posts) names[p.ownerId] = provs.find((x) => x.id === p.ownerId)?.name ?? fls.find((x) => x.id === p.ownerId)?.name ?? rests.find((x) => x.id === p.ownerId)?.name ?? "Bilinmeyen";
  const cases = await db.select().from(moderationCases).where(eq(moderationCases.status, "OPEN")).orderBy(moderationCases.createdAt).limit(60);
  const logs = await db.select().from(auditLogs).orderBy(sql`${auditLogs.createdAt} DESC`).limit(30);
  return { posts: posts.map((p) => ({ ...p, ownerName: names[p.ownerId] ?? "" })), cases, logs, kind };
}
