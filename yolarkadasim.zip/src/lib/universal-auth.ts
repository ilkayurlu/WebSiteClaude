import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { partnerApplications, providers, users, type User } from "@/db/schema";
import { dashboardHome } from "./dashboard-routes";
import { audit } from "./engine";
import { HttpError } from "./http";
import { authenticateRoot, rootAuthConfigured, rootAuthEmail } from "./root-auth";

const SCRYPT_PARAMS = { N: 16384, r: 8, p: 1 };
const KEYLEN = 64;
const FAIL_LIMIT = 5;
const FAIL_WINDOW_MS = 15 * 60_000;

const attempts = new Map<string, { n: number; firstAt: number }>();

/* ---------------- Parola özetleme (scrypt, tuzlu, zaman-sabit) ---------------- */
export function hashPassword(plain: string): string {
  const salt = randomBytes(16).toString("hex");
  const key = scryptSync(plain, salt, KEYLEN, SCRYPT_PARAMS).toString("hex");
  return `scrypt$${salt}$${key}`;
}

export function verifyPassword(plain: string, stored: string | null | undefined): boolean {
  if (!stored) return false;
  const parts = stored.split("$");
  if (parts.length !== 3 || parts[0] !== "scrypt") return false;
  const [, salt, hex] = parts;
  if (!/^[a-f0-9]{32}$/.test(salt) || !/^[a-f0-9]{128}$/.test(hex)) return false;
  const derived = scryptSync(plain, salt, KEYLEN, SCRYPT_PARAMS);
  const expected = Buffer.from(hex, "hex");
  return derived.length === expected.length && timingSafeEqual(derived, expected);
}

/* ---------------- Kilit ---------------- */
function failCount(key: string): number {
  const e = attempts.get(key);
  if (!e) return 0;
  if (Date.now() - e.firstAt > FAIL_WINDOW_MS) {
    attempts.delete(key);
    return 0;
  }
  return e.n;
}
function recordFail(key: string) {
  const e = attempts.get(key);
  if (!e || Date.now() - e.firstAt > FAIL_WINDOW_MS) attempts.set(key, { n: 1, firstAt: Date.now() });
  else e.n += 1;
}
function clearFail(key: string) {
  attempts.delete(key);
  if (attempts.size > 4000) attempts.clear();
}

/* ---------------- Güvenli göreceli yönlendirme ---------------- */
export function safeNextPath(next: string | null | undefined, fallback: string): string {
  if (!next || typeof next !== "string") return fallback;
  if (!next.startsWith("/") || next.startsWith("//") || next.includes("\\") || next.startsWith("/giris")) return fallback;
  return next;
}

/* ---------------- Demo/tohum parola özetleri ---------------- */
let seeded = false;

/**
 * Parola özeti olmayan mevcut kullanıcılara tek seferlik özet yazar.
 * Kural: şifre kaynak kodda sabitlenmez; DEMO_DEFAULT_PASSWORD ortam değişkeni
 * varsa onun scrypt özeti, yoksa her hesap için rastgele (giriş yapılamayan) özet yazılır.
 */
export async function ensurePasswordHashes(): Promise<void> {
  if (seeded) return;
  const missing = await db.select({ id: users.id }).from(users).where(isNull(users.passwordHash)).limit(100);
  if (!missing.length) {
    seeded = true;
    return;
  }
  const envDefault = process.env.DEMO_DEFAULT_PASSWORD;
  const sharedHash = envDefault && envDefault.length >= 8 ? hashPassword(envDefault) : null;
  for (const u of missing) {
    await db
      .update(users)
      .set({ passwordHash: sharedHash ?? hashPassword(randomBytes(24).toString("hex")) })
      .where(eq(users.id, u.id));
  }
  seeded = true;
}

/* ---------------- Tek kapılı giriş ---------------- */
export interface UniversalAuthResult {
  user: User;
  redirectTo: string;
  via: "root" | "password";
}

export async function authenticateUniversal(input: { email: string; password: string; ip: string; next?: string | null }): Promise<UniversalAuthResult> {
  await ensurePasswordHashes();
  const email = input.email.trim().toLowerCase();
  const key = `${input.ip}|${email}`;

  if (failCount(key) >= FAIL_LIMIT) {
    await audit(db, null, "auth.locked_out", "auth", email, "Çok fazla başarısız giriş denemesi", { ip: input.ip });
    throw new HttpError(429, "Çok fazla başarısız deneme. 15 dakika sonra tekrar deneyin.");
  }

  // 1) Acil durum Süper Admin bypass: kök e-postasıyla eşleşiyorsa ve kapı yapılandırılmışsa önce bu yol denenir.
  if (rootAuthConfigured() && rootAuthEmail() === email) {
    try {
      const rootUser = await authenticateRoot({ email, password: input.password, ip: input.ip });
      if (rootUser.isSuspended) {
        throw new HttpError(403, "Hesabınız askıya alınmıştır. Operasyon yönetimiyle iletişime geçin.");
      }
      clearFail(key);
      return { user: rootUser, redirectTo: "/admin", via: "root" };
    } catch (err) {
      // Kök e-postası için yanlış parola girildiyse normal parolaya düşülmez; tek otorite ortam değişkenidir.
      if (err instanceof HttpError) throw err;
      throw new HttpError(401, "E-posta veya parola hatalı.");
    }
  }

  // 2) Veritabanı kullanıcısı + scrypt parola doğrulaması
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  // Kullanıcı yoksa bile zaman farkı sızmaması için sahte doğrulama yapılır.
  const dummyHash = "scrypt$00000000000000000000000000000000$" + "0".repeat(128);
  const ok = verifyPassword(input.password, user?.passwordHash ?? dummyHash);

  if (!user || !ok) {
    recordFail(key);
    // Başvuru aşamasındaki e-posta mı? Yalnızca bekleyen başvuru varsa bilgilendirici mesaj döner.
    const [pendingApp] = await db.select({ status: partnerApplications.status }).from(partnerApplications).where(eq(partnerApplications.email, email)).limit(1);
    if (!user && pendingApp?.status === "PENDING") {
      throw new HttpError(403, "Başvurunuz evrak inceleme aşamasındadır. Onaylandığında giriş bilgileriniz iletilecektir.");
    }
    await audit(db, null, "auth.failed", "auth", email, "Hatalı e-posta veya parola", { attempts: failCount(key) });
    throw new HttpError(401, "E-posta veya parola hatalı.");
  }

  // 3) Hesap ve sağlayıcı durumu kontrolleri (parola doğrulandıktan sonra)
  if (user.isSuspended) {
    await audit(db, user.id, "auth.suspended_blocked", "user", user.id, "Askıdaki hesap giriş denemesi");
    throw new HttpError(403, user.suspendedReason ? `Hesabınız askıya alınmıştır: ${user.suspendedReason}` : "Hesabınız askıya alınmıştır. Destek ekibiyle iletişime geçin.");
  }

  if (user.role === "PROVIDER") {
    const [prov] = await db.select({ status: providers.status }).from(providers).where(eq(providers.userId, user.id)).limit(1);
    if (!prov || prov.status === "PENDING") {
      throw new HttpError(403, "Başvurunuz evrak inceleme aşamasındadır. Onaylandığında paneliniz açılacaktır.");
    }
    if (prov.status === "SUSPENDED") {
      await audit(db, user.id, "auth.provider_suspended_blocked", "user", user.id, "Engellenmiş kurye giriş denemesi");
      throw new HttpError(403, "Kurye profiliniz engellenmiştir. Operasyon ekibiyle iletişime geçin.");
    }
  }

  clearFail(key);
  const home = dashboardHome(user.role);
  return { user, redirectTo: safeNextPath(input.next, home), via: "password" };
}
