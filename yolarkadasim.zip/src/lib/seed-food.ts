import { sql } from "drizzle-orm";
import { db } from "@/db";
import { fleets, mediaPosts, menuCategories, productOptionGroups, productOptions, products, providers, restaurants, users } from "@/db/schema";

const IMG = {
  kebab: "https://images.pexels.com/photos/37329603/pexels-photo-37329603.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  pide: "https://images.pexels.com/photos/29358859/pexels-photo-29358859.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  lahmacun: "https://images.pexels.com/photos/24427085/pexels-photo-24427085.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bar: "https://images.pexels.com/photos/20607932/pexels-photo-20607932.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  feast: "https://images.pexels.com/photos/36287931/pexels-photo-36287931.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  wrap: "https://images.pexels.com/photos/15202777/pexels-photo-15202777.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  grill: "https://images.pexels.com/photos/37206710/pexels-photo-37206710.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  spread: "https://images.pexels.com/photos/36287930/pexels-photo-36287930.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  cafe: "https://images.pexels.com/photos/18617712/pexels-photo-18617712.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  bakery: "https://images.pexels.com/photos/39583847/pexels-photo-39583847.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  cake: "https://images.pexels.com/photos/1206385/pexels-photo-1206385.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  coffee: "https://images.pexels.com/photos/17671395/pexels-photo-17671395.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  pastry: "https://images.pexels.com/photos/33313216/pexels-photo-33313216.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  rider: "https://images.pexels.com/photos/11161442/pexels-photo-11161442.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  barista: "https://images.pexels.com/photos/8425194/pexels-photo-8425194.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  window: "https://images.pexels.com/photos/8974874/pexels-photo-8974874.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
};

type Opt = { name: string; delta: number; def?: boolean };
type Grp = { name: string; required: boolean; min: number; max: number; opts: Opt[] };
type Prod = {
  n: string;
  d: string;
  img: string;
  price: number;
  disc?: number;
  allergens?: string[];
  cal?: number;
  prep?: number;
  stock?: number;
  veg?: boolean;
  vegan?: boolean;
  spicy?: boolean;
  groups?: Grp[];
  status?: string;
};
type Cat = { n: string; d: string; prods: Prod[]; time?: [string, string] };
type Rest = {
  slug: string;
  name: string;
  tagline: string;
  desc: string;
  cuisines: string[];
  tags: string[];
  cover: string;
  hue: number;
  areas: string[];
  open: boolean;
  hours: [string, string];
  prep: number;
  fee: number;
  min: number;
  verified: boolean;
  phone: string;
  site: string;
  addr: string;
  vegan?: boolean;
  halal?: boolean;
  campaign?: [string, string];
  cats: Cat[];
};

const RESTAURANTS: Rest[] = [
  {
    slug: "ocakbasi-moda",
    name: "Ocakbaşı Moda",
    tagline: "Kadıköy’ün 32 yıllık mangal ustası",
    desc: "Odun ateşinde pişen kebaplar, günlük hazırlanan mezeler ve taş fırın pideleri. Etlerimizi Trakya’daki anlaşmalı çiftlikten alıyoruz.",
    cuisines: ["KEBAB", "PIDE"],
    tags: ["Odun ateşi", "Günlük meze", "Aile işletmesi"],
    cover: IMG.kebab,
    hue: 14,
    areas: ["kadikoy", "uskudar", "atasehir"],
    open: true,
    hours: ["11:30", "23:30"],
    prep: 30,
    fee: 2500,
    min: 20000,
    verified: true,
    phone: "+90 216 555 01 34",
    site: "ocakbasi-moda.example",
    addr: "Moda Cd. No:112, Kadıköy / İstanbul",
    halal: true,
    campaign: ["150 ₺ üzeri siparişte ayran hediye", "Kampanya sepet tutarına otomatik uygulanır, kupon gerekmez."],
    cats: [
      {
        n: "Izgaralar",
        d: "Odun ateşinde, günlük çekim",
        prods: [
          { n: "Adana Kebap", d: "El çekimi kuzu kıyma, közlenmiş domates ve biber, lavaş ile", img: IMG.kebab, price: 32000, cal: 680, prep: 22, allergens: ["Gluten"], spicy: true, groups: [{ name: "Acı seviyesi", required: true, min: 1, max: 1, opts: [{ name: "Acısız", delta: 0, def: true }, { name: "Orta acı", delta: 0 }, { name: "Çok acı", delta: 0 }] }, { name: "Ekstra", required: false, min: 0, max: 3, opts: [{ name: "Ekstra lavaş", delta: 2000 }, { name: "Közlenmiş biber", delta: 3500 }, { name: "Şalgam suyu", delta: 4000 }] }], veg: undefined as never },
          { n: "Karışık Izgara", d: "Adana, tavuk şiş, kuzu şiş, kanat; bulgur pilavı ve meze tabağı", img: IMG.grill, price: 54000, cal: 940, prep: 28, stock: 12 },
          { n: "Tavuk Şiş", d: "Yoğurtlu marine, közlenmiş sebze, pilav üstü", img: IMG.wrap, price: 26500, cal: 520, prep: 18 },
        ],
      },
      {
        n: "Taş Fırın",
        d: "Pide ve lahmacun — 3 dakikada fırından",
        prods: [
          { n: "Kıymalı Pide", d: "Kapalı pide, dana kıyma, maydanoz, tereyağı", img: IMG.pide, price: 24000, cal: 610, prep: 12, allergens: ["Gluten", "Süt"], groups: [{ name: "Hamur", required: true, min: 1, max: 1, opts: [{ name: "İnce hamur", delta: 0, def: true }, { name: "Kalın hamur", delta: 0 }] }] },
          { n: "Lahmacun (2 adet)", d: "İnce hamur, bol maydanoz, limon dilimi", img: IMG.lahmacun, price: 16000, cal: 420, prep: 9, allergens: ["Gluten"] },
          { n: "Kaşarlı Pide", d: "Çift kaşarlı, tereyağlı", img: IMG.pide, price: 22000, cal: 720, prep: 12, veg: true, allergens: ["Gluten", "Süt"] },
        ],
      },
      {
        n: "Başlangıçlar",
        d: "Mezeler ve çorbalar",
        prods: [
          { n: "Humus", d: "Nohut ezmesi, tereyağı, pastırma parçaları", img: IMG.feast, price: 9500, cal: 260, prep: 5, veg: true },
          { n: "Mercimek Çorbası", d: "Günlük, limon ve kruton ile", img: IMG.spread, price: 7500, cal: 190, prep: 5, vegan: true },
          { n: "Mevsim Salata", d: "Nar ekşili, cevizli", img: IMG.spread, price: 8500, cal: 150, prep: 5, vegan: true, allergens: ["Kuruyemiş"] },
        ],
      },
      {
        n: "İçecekler",
        d: "Soğuk ve sıcak",
        prods: [
          { n: "Ayran (300 ml)", d: "Yayık ayranı, köpüklü", img: IMG.cafe, price: 4000, cal: 90, vegan: true },
          { n: "Şalgam Suyu", d: "Acılı / acısız", img: IMG.cafe, price: 4500, vegan: true, groups: [{ name: "Tercih", required: true, min: 1, max: 1, opts: [{ name: "Acısız", delta: 0, def: true }, { name: "Acılı", delta: 0 }] }] },
          { n: "Türk Kahvesi", d: "Orta şekerli, lokum ile", img: IMG.coffee, price: 6500, vegan: true },
        ],
      },
    ],
  },
  {
    slug: "yesil-kase",
    name: "Yeşil Kase",
    tagline: "Tamamen bitkisel mutfak",
    desc: "Ataşehir’de %100 bitkisel tabaklar, soğuk sıkım içecekler ve glutensiz seçenekler. Tüm malzemeler mevsimsel ve yerel üreticiden.",
    cuisines: ["VEGAN", "HOME"],
    tags: ["Glutensiz seçenek", "Soğuk sıkım", "Yerel üretici"],
    cover: IMG.spread,
    hue: 145,
    areas: ["atasehir", "kadikoy", "maltepe"],
    open: true,
    hours: ["09:00", "21:00"],
    prep: 18,
    fee: 1900,
    min: 12000,
    verified: true,
    phone: "+90 216 555 02 88",
    site: "yesilkase.example",
    addr: "Barbaros Mah. Lale Sk. No:4, Ataşehir / İstanbul",
    vegan: true,
    cats: [
      {
        n: "Kaseler",
        d: "Tahıl + yeşillik + protein",
        prods: [
          { n: "Nohutlu Güç Kasesi", d: "Kinoa, fırınlanmış nohut, avokado, tahin sos", img: IMG.spread, price: 23500, cal: 480, prep: 12, vegan: true, allergens: ["Susam"], groups: [{ name: "Sos", required: true, min: 1, max: 1, opts: [{ name: "Tahin", delta: 0, def: true }, { name: "Limonlu zeytinyağı", delta: 0 }, { name: "Acı harissa", delta: 1500 }] }] },
          { n: "Yeşil Detoks Kasesi", d: "Bulgur, brokoli, edamame, nane-limon", img: IMG.feast, price: 21500, cal: 390, prep: 10, vegan: true, allergens: ["Gluten", "Soya"] },
        ],
      },
      {
        n: "Soğuk Sıkım",
        d: "Günlük hazırlanır",
        prods: [
          { n: "Yeşil Enerji (400 ml)", d: "Elma, salatalık, ıspanak, zencefil, limon", img: IMG.coffee, price: 12500, cal: 140, vegan: true },
          { n: "Pancar Kök (400 ml)", d: "Pancar, havuç, portakal", img: IMG.coffee, price: 12500, cal: 160, vegan: true, stock: 0 },
        ],
      },
    ],
  },
  {
    slug: "kadikoy-firin",
    name: "Kadıköy Fırın & Kafe",
    tagline: "Sabah 07:00’den itibaren taze",
    desc: "Ekşi mayalı ekmekler, günlük pastane ürünleri ve nitelikli kahve. Kahvaltı menümüz 11:00’e kadar geçerlidir.",
    cuisines: ["CAFE"],
    tags: ["Ekşi maya", "Nitelikli kahve", "Kahvaltı"],
    cover: IMG.bakery,
    hue: 32,
    areas: ["kadikoy", "uskudar"],
    open: true,
    hours: ["07:00", "20:00"],
    prep: 15,
    fee: 1500,
    min: 8000,
    verified: true,
    phone: "+90 216 555 03 12",
    site: "kadikoyfirin.example",
    addr: "Caferağa Mah. Sakız Sk. No:7, Kadıköy / İstanbul",
    cats: [
      {
        n: "Kahvaltı",
        d: "11:00’e kadar",
        time: ["07:00", "11:00"],
        prods: [
          { n: "Serpme Kahvaltı (2 kişilik)", d: "Peynir çeşitleri, zeytin, reçel, bal-kaymak, menemen, sınırsız çay", img: IMG.feast, price: 62000, cal: 1200, prep: 20, veg: true, allergens: ["Süt", "Yumurta", "Gluten"] },
          { n: "Avokadolu Ekşi Maya Tost", d: "Poşe yumurta, çörek otu, roka", img: IMG.pastry, price: 18500, cal: 420, prep: 10, veg: true },
        ],
      },
      {
        n: "Pastane",
        d: "Günlük üretim",
        prods: [
          { n: "San Sebastian Cheesecake", d: "Dilim, günlük", img: IMG.cake, price: 14500, cal: 380, prep: 3, veg: true, allergens: ["Süt", "Yumurta", "Gluten"] },
          { n: "Kruvasan (sade)", d: "Tereyağlı, 24 kat", img: IMG.pastry, price: 9500, cal: 300, veg: true, allergens: ["Gluten", "Süt"] },
          { n: "Profiterol", d: "Çikolata soslu, 6 adet", img: IMG.cake, price: 12000, cal: 420, veg: true, allergens: ["Süt", "Yumurta", "Gluten"], stock: 4 },
        ],
      },
      {
        n: "Kahveler",
        d: "Tek çekirdek: Etiyopya / Kolombiya",
        prods: [
          { n: "Flat White", d: "Çift shot, mikro köpük", img: IMG.coffee, price: 9000, cal: 120, veg: true, groups: [{ name: "Süt", required: true, min: 1, max: 1, opts: [{ name: "İnek sütü", delta: 0, def: true }, { name: "Yulaf sütü", delta: 2500 }, { name: "Badem sütü", delta: 2500 }] }] },
          { n: "Filtre Kahve", d: "Günün çekirdeği, 250 ml", img: IMG.barista, price: 8000, cal: 5, vegan: true },
        ],
      },
    ],
  },
  {
    slug: "burger-hane",
    name: "Burger Hane Beşiktaş",
    tagline: "Kuru yaşlandırılmış köfte, el yapımı sos",
    desc: "Beşiktaş çarşı içinde 40 günlük kuru yaşlandırılmış dana ile hazırlanan burgerler. Patateslerimizi kendimiz kesiyoruz.",
    cuisines: ["BURGER"],
    tags: ["Kuru yaşlandırma", "El yapımı sos", "Gece 02:00"],
    cover: IMG.wrap,
    hue: 25,
    areas: ["besiktas", "sisli", "beyoglu"],
    open: true,
    hours: ["12:00", "02:00"],
    prep: 22,
    fee: 2900,
    min: 18000,
    verified: false,
    phone: "+90 212 555 04 45",
    site: "burgerhane.example",
    addr: "Çırağan Cd. No:23, Beşiktaş / İstanbul",
    campaign: ["İkinci burger %30 indirimli", "Aynı sepette 2 ve üzeri burgerde geçerlidir."],
    cats: [
      {
        n: "Burgerler",
        d: "180 gr köfte, brioche ekmek",
        prods: [
          { n: "Klasik Hane Burger", d: "Cheddar, karamelize soğan, turşu, hane sos", img: IMG.wrap, price: 27500, cal: 780, prep: 15, allergens: ["Gluten", "Süt", "Yumurta"], groups: [{ name: "Pişirme", required: true, min: 1, max: 1, opts: [{ name: "Orta", delta: 0, def: true }, { name: "İyi pişmiş", delta: 0 }] }, { name: "Ekstra", required: false, min: 0, max: 4, opts: [{ name: "Ekstra köfte", delta: 12000 }, { name: "Cheddar", delta: 3500 }, { name: "Bacon", delta: 6000 }, { name: "Jalapeno", delta: 2000 }] }] },
          { n: "Mantarlı Trüf Burger", d: "Sote mantar, trüf mayonez, İsviçre peyniri", img: IMG.grill, price: 34500, disc: 31000, cal: 860, prep: 16, allergens: ["Gluten", "Süt", "Yumurta"] },
          { n: "Vegan NoHut Burger", d: "Nohut köftesi, avokado, vegan mayo", img: IMG.spread, price: 25500, cal: 560, prep: 14, vegan: true, allergens: ["Gluten", "Susam"] },
        ],
      },
      {
        n: "Yan ürünler",
        d: "El kesim",
        prods: [
          { n: "Trüflü Patates", d: "Parmesan ve maydanoz ile", img: IMG.pastry, price: 11500, cal: 420, veg: true, allergens: ["Süt"] },
          { n: "Soğan Halkası (8 adet)", d: "Bira hamurlu, acı mayonez", img: IMG.wrap, price: 9500, cal: 380, veg: true, allergens: ["Gluten", "Yumurta"] },
        ],
      },
      {
        n: "İçecekler",
        d: "",
        prods: [
          { n: "Ev Yapımı Limonata", d: "Nane ve limon, 400 ml", img: IMG.coffee, price: 7500, vegan: true },
          { n: "Milkshake (Çikolata)", d: "Gerçek dondurma ile", img: IMG.cake, price: 12500, veg: true, allergens: ["Süt"], stock: 3 },
        ],
      },
    ],
  },
  {
    slug: "balikci-uskudar",
    name: "Balıkçı Üsküdar",
    tagline: "Günlük av, mevsim balığı",
    desc: "Her sabah hal’den alınan balıklar. Menü balığın durumuna göre günlük değişir; tükenen ürünler anında pasife alınır.",
    cuisines: ["SEAFOOD", "HOME"],
    tags: ["Günlük av", "Deniz manzarası"],
    cover: IMG.window,
    hue: 200,
    areas: ["uskudar", "kadikoy"],
    open: false,
    hours: ["16:00", "23:00"],
    prep: 35,
    fee: 3900,
    min: 35000,
    verified: true,
    phone: "+90 216 555 05 90",
    site: "balikcioskudar.example",
    addr: "Hakimiyeti Milliye Cd. No:61, Üsküdar / İstanbul",
    cats: [
      {
        n: "Balıklar",
        d: "Günlük, gramaj ile",
        prods: [
          { n: "Izgara Levrek", d: "Roka, limon, zeytinyağı", img: IMG.spread, price: 48000, cal: 420, prep: 25, allergens: ["Deniz ürünü"], stock: 0 },
          { n: "Kalamar Tava", d: "Tartar sos ile", img: IMG.grill, price: 32000, cal: 520, prep: 18, allergens: ["Deniz ürünü", "Gluten"] },
        ],
      },
    ],
  },
  {
    slug: "mahalle-market",
    name: "Mahalle Market",
    tagline: "15 dakikada temel ihtiyaçlar",
    desc: "Kadıköy ve Moda çevresine hızlı market teslimatı. Süt ürünleri, atıştırmalık, temizlik ve bebek ürünleri.",
    cuisines: ["MARKET"],
    tags: ["Hızlı teslimat", "Soğuk zincir"],
    cover: IMG.bar,
    hue: 160,
    areas: ["kadikoy", "maltepe", "atasehir"],
    open: true,
    hours: ["08:00", "23:59"],
    prep: 8,
    fee: 1200,
    min: 6000,
    verified: true,
    phone: "+90 216 555 06 11",
    site: "mahalemarket.example",
    addr: "Rasimpaşa Mah. Uzun Hafız Sk. No:88, Kadıköy / İstanbul",
    cats: [
      {
        n: "Süt & Kahvaltı",
        d: "Soğuk zincir ile taşınır",
        prods: [
          { n: "Günlük Süt (1 L)", d: "Pastörize, tam yağlı", img: IMG.cafe, price: 4200, stock: 40, vegan: true },
          { n: "Beyaz Peynir (400 g)", d: "Ezine tipi, tam yağlı", img: IMG.pastry, price: 12500, stock: 18, veg: true, allergens: ["Süt"] },
        ],
      },
      {
        n: "Atıştırmalık",
        d: "",
        prods: [
          { n: "Karışık Kuruyemiş (250 g)", d: "Badem, fındık, kaju, ceviz", img: IMG.cake, price: 18500, stock: 25, vegan: true, allergens: ["Kuruyemiş"] },
        ],
      },
    ],
  },
];

const PROVIDER_MEDIA: Record<string, { caption: string; url: string; views: number }[]> = {
  "ahmet-moto": [
    { caption: "Termal çantada sıcak yemek teslimatı — ısı kaybı olmadan 18 dk", url: IMG.rider, views: 412 },
    { caption: "Paketleme özeni: kırılacak ürünlerde çift kat balonlu koruma", url: IMG.wrap, views: 268 },
    { caption: "Kadıköy–Üsküdar hattında sabah trafiği için alternatif rota", url: IMG.window, views: 190 },
  ],
  "zeynep-bisiklet": [{ caption: "Kargo bisikletimle sıfır emisyon teslimat — günde ortalama 22 görev", url: IMG.rider, views: 331 }],
  "mehmet-transfer": [
    { caption: "Havalimanı transferinde bagaj düzeni ve çocuk koltuğu kurulumu", url: IMG.window, views: 502 },
    { caption: "Araç içi hijyen kontrolü her görev öncesi yapılır", url: IMG.window, views: 214 },
  ],
  "selin-van": [{ caption: "Mağaza dağıtımında çoklu durak rotası — 9 adres, 3 saat", url: IMG.rider, views: 176 }],
  "ayse-soguk": [{ caption: "Soğuk zincir vanasında +2/+8°C kayıt cihazı her teslimatta raporlanır", url: IMG.window, views: 289 }],
  "elvan-sedan": [{ caption: "Şehir içi yolculukta güvenli sürüş notlarım", url: IMG.window, views: 143 }],
};

const g = globalThis as typeof globalThis & { __yaSeedFood?: Promise<void> };

export function ensureSeedFood() {
  if (!g.__yaSeedFood) {
    g.__yaSeedFood = runFoodSeed().catch((e) => {
      g.__yaSeedFood = undefined;
      throw e;
    });
  }
  return g.__yaSeedFood;
}

async function runFoodSeed() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(424243)`);
    const [chk] = await tx.select({ id: restaurants.id }).from(restaurants).limit(1);
    if (!chk) {
      for (const r of RESTAURANTS) {
        const [owner] = await tx
          .insert(users)
          .values({ name: `${r.name} İşletmesi`, email: `${r.slug}@demo.yolarkadasi.app`, role: "RESTAURANT_OWNER" })
          .returning();
        const [rest] = await tx
          .insert(restaurants)
          .values({
            slug: r.slug,
            ownerUserId: owner.id,
            name: r.name,
            tagline: r.tagline,
            description: r.desc,
            cuisines: r.cuisines,
            tags: r.tags,
            coverUrl: r.cover,
            logoHue: r.hue,
            deliveryAreas: r.areas,
            isOpen: r.open,
            opensAt: r.hours[0],
            closesAt: r.hours[1],
            prepMinutes: r.prep,
            deliveryFeeMinor: r.fee,
            minBasketMinor: r.min,
            isVerified: r.verified,
            phonePublic: r.phone,
            website: r.site,
            addressPublic: r.addr,
            hasVegan: !!r.vegan,
            hasHalal: !!r.halal,
            campaignTitle: r.campaign?.[0] ?? null,
            campaignDetail: r.campaign?.[1] ?? null,
          })
          .returning();
        let pos = 0;
        for (const c of r.cats) {
          const [cat] = await tx
            .insert(menuCategories)
            .values({ restaurantId: rest.id, name: c.n, description: c.d, position: pos++, isActive: true, timeFrom: c.time?.[0] ?? null, timeTo: c.time?.[1] ?? null })
            .returning();
          for (const pr of c.prods) {
            const [p] = await tx
              .insert(products)
              .values({
                restaurantId: rest.id,
                categoryId: cat.id,
                name: pr.n,
                description: pr.d,
                imageUrl: pr.img,
                priceMinor: pr.price,
                discountPriceMinor: pr.disc ?? null,
                allergens: pr.allergens ?? [],
                calories: pr.cal ?? null,
                prepMinutes: pr.prep ?? null,
                stock: pr.stock ?? 50,
                status: pr.status ?? "PUBLISHED",
                isVegetarian: !!pr.veg,
                isVegan: !!pr.vegan,
                isSpicy: !!pr.spicy,
              })
              .returning();
            let gpos = 0;
            for (const grp of pr.groups ?? []) {
              const [gRow] = await tx
                .insert(productOptionGroups)
                .values({ productId: p.id, name: grp.name, required: grp.required, minSelect: grp.min, maxSelect: grp.max, position: gpos++ })
                .returning();
              let opos = 0;
              for (const o of grp.opts) {
                await tx.insert(productOptions).values({ groupId: gRow.id, name: o.name, priceDeltaMinor: o.delta, isDefault: !!o.def, position: opos++ });
              }
            }
          }
        }
        // İşletme vitrin medyası (yayında demo içerik)
        await tx.insert(mediaPosts).values([
          { ownerType: "RESTAURANT", ownerId: rest.id, userId: owner.id, caption: `${r.name} — mutfak ve servis alanımız`, mediaType: "IMAGE", status: "PUBLISHED", publicUrl: r.cover, mime: "image/jpeg", exifStripped: true, scanned: true, rightsDeclaration: true, viewCount: 500 + pos * 37, publishedAt: new Date() },
          { ownerType: "RESTAURANT", ownerId: rest.id, userId: owner.id, caption: "Paketleme standardımız: sızdırmaz kap + ısı koruyucu poşet", mediaType: "IMAGE", status: "PUBLISHED", publicUrl: IMG.pastry, mime: "image/jpeg", exifStripped: true, scanned: true, rightsDeclaration: true, viewCount: 210, publishedAt: new Date() },
        ]);
      }
    }

    // Sağlayıcı & filo medya vitrini (bir kez)
    const [mediaChk] = await tx.select({ id: mediaPosts.id }).from(mediaPosts).where(sql`${mediaPosts.ownerType} = 'PROVIDER'`).limit(1);
    if (!mediaChk) {
      const provs = await tx.select().from(providers);
      const fls = await tx.select().from(fleets);
      for (const p of provs) {
        const items = PROVIDER_MEDIA[p.slug] ?? [
          { caption: "Hizmet bölgemdeki teslimatlardan bir kesit", url: IMG.rider, views: 60 + (p.hue % 90) },
        ];
        for (const m of items) {
          await tx.insert(mediaPosts).values({
            ownerType: "PROVIDER",
            ownerId: p.id,
            userId: p.userId,
            caption: m.caption,
            status: "PUBLISHED",
            publicUrl: m.url,
            mime: "image/jpeg",
            exifStripped: true,
            scanned: true,
            rightsDeclaration: true,
            viewCount: m.views,
            favoriteCount: Math.round(m.views / 9),
            publishedAt: new Date(Date.now() - 86400000 * (1 + (m.views % 7))),
          });
        }
        // İnceleme bekleyen örnek gönderi (moderasyon kuyruğu boş kalmasın)
        if (p.slug === "kerem-yeni" || p.slug === "burak-moto") {
          await tx.insert(mediaPosts).values({
            ownerType: "PROVIDER",
            ownerId: p.id,
            userId: p.userId,
            caption: p.slug === "kerem-yeni" ? "İlk hafta teslimatlarım — hız ortalamam 22 dakika" : "Gece vardiyasında teslimat rotam",
            status: "PENDING_REVIEW",
            publicUrl: IMG.rider,
            mime: "image/jpeg",
            exifStripped: true,
            scanned: true,
            rightsDeclaration: true,
          });
        }
      }
      for (const f of fls) {
        const covers = [IMG.rider, IMG.grill, IMG.window];
        const captions = [
          "Filo araçlarımız — günlük bakım ve kilometre takibi yapılır",
          "Operasyon merkezimiz: vardiya planı ve canlı görev takibi",
          "Paketleme ve yükleme standardımız",
        ];
        for (let i = 0; i < 3; i++) {
          await tx.insert(mediaPosts).values({
            ownerType: "FLEET",
            ownerId: f.id,
            userId: f.ownerUserId,
            caption: captions[i],
            status: "PUBLISHED",
            publicUrl: covers[i % covers.length],
            mime: "image/jpeg",
            exifStripped: true,
            scanned: true,
            rightsDeclaration: true,
            viewCount: 300 + i * 55,
            publishedAt: new Date(Date.now() - 86400000 * (i + 2)),
          });
        }
      }
    }
  });
}
