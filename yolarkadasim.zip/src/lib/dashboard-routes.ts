export type UserRole = "CUSTOMER" | "PROVIDER" | "FLEET_OWNER" | "RESTAURANT_OWNER" | "ADMIN" | "SUPER_ADMIN";
export type DashboardRole = "CUSTOMER" | "PROVIDER" | "FLEET_OWNER" | "RESTAURANT_OWNER" | "ADMIN";

export function dashboardHome(role: string): string {
  switch (role) {
    case "CUSTOMER": return "/dashboard/musteri";
    case "PROVIDER": return "/dashboard/kurye";
    case "FLEET_OWNER": return "/dashboard/filo";
    case "ADMIN": return "/dashboard/admin";
    case "SUPER_ADMIN": return "/admin";
    case "RESTAURANT_OWNER": return "/dashboard/isletme";
    default: return "/giris";
  }
}

export function pathRole(path: string): DashboardRole | null {
  const segment = path.split("/")[2];
  if (segment === "musteri") return "CUSTOMER";
  if (segment === "kurye") return "PROVIDER";
  if (segment === "filo") return "FLEET_OWNER";
  if (segment === "admin") return "ADMIN";
  if (segment === "isletme") return "RESTAURANT_OWNER";
  return null;
}

export function roleAllowed(role: string, expected: DashboardRole) {
  return role === expected || (expected === "ADMIN" && role === "SUPER_ADMIN");
}
