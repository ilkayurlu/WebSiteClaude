import { and, asc, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments,
  cartItems,
  carts,
  matchingCandidates,
  mediaPosts,
  menuCategories,
  notifications,
  orderEvents,
  orderItems,
  orders,
  productOptionGroups,
  productOptions,
  products,
  providers,
  requestEvents,
  restaurants,
  reviewResponses,
  reviews,
  serviceRequests,
  users,
  type Restaurant,
} from "@/db/schema";
import { HttpError } from "./http";
import { findFavorites } from "./favorites";
import { closeRequestConversations } from "./chat";
import { findCandidates, type MatchInput } from "./matching";
import { getArea, areaName, etaBand, getCity } from "./geo";
import type { Session } from "./session";
import { ORDER_STATUS } from "./labels";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
export const REVIEW_WINDOW_DAYS = 14;
const DELIVERY_MINUTES = 20;

/* ---------------- Public serializer ---------------- */
export function publicRestaurant(r: Restaurant) {
  return {
    id: r.id,
    slug: r.slug,
    name: r.name,
    tagline: r.tagline,
    description: r.description,
    cuisines: r.cuisines,
    tags: r.tags,
    coverUrl: r.coverUrl,
    logoHue: r.logoHue,
    deliveryAreas: r.deliveryAreas,
    isOpen: r.isOpen,
    opensAt: r.opensAt,
    closesAt: r.closesAt,
    prepMinutes: r.prepMinutes,
    deliveryFeeMinor: r.deliveryFeeMinor,
    smallBasketFeeMinor: r.smallBasketFeeMinor,
    smallBasketThresholdMinor: r.smallBasketThresholdMinor,
    minBasketMinor: r.minBasketMinor,
    ratingAvg: r.ratingAvg,
    ratingCount: r.ratingCount,
    isVerified: r.isVerified,
    phonePublic: r.phonePublic,
    website: r.website,
    addressPublic: r.addressPublic,
    hasVegan: r.hasVegan,
    hasHalal: r.hasHalal,
    campaignTitle: r.campaignTitle,
    campaignDetail: r.campaignDetail,
  };
}

/** İşletme açık mı: hem manuel bayrak hem saat aralığı (gece yarısını aşan aralıklar dahil). */
export function isOpenNow(r: Restaurant, now = new Date()) {
  if (!r.isOpen || r.status !== "ACTIVE") return false;
  const mins = now.getHours() * 60 + now.getMinutes();
  const [oh, om] = r.opensAt.split(":").map(Number);
  const [ch, cm] = r.closesAt.split(":").map(Number);
  const open = oh * 60 + om;
  const close = ch * 60 + cm;
  return close > open ? mins >= open && mins <= close : mins >= open || mins <= close;
}

export type Filters = {
  area?: string;
  cityCode?: string;
  cuisine?: string;
  openNow?: boolean;
  vegan?: boolean;
  halal?: boolean;
  maxFee?: number;
  maxPrep?: number;
  minRating?: number;
  campaign?: boolean;
  q?: string;
  sort?: "rating" | "fast" | "cheap";
};

export async function listRestaurants(f: Filters) {
  const rows = await db
    .select()
    .from(restaurants)
    .where(sql`${restaurants.visibility} = 'PUBLIC' AND ${restaurants.status} = 'ACTIVE'`);
  const counts = await db
    .select({ restaurantId: products.restaurantId, n: sql<number>`count(*)::int`, vegan: sql<number>`count(*) filter (where ${products.isVegan})::int` })
    .from(products)
    .where(eq(products.status, "PUBLISHED"))
    .groupBy(products.restaurantId);
  return rows
    .map((r) => {
      const c = counts.find((x) => x.restaurantId === r.id);
      return {
        ...publicRestaurant(r),
        openNow: isOpenNow(r),
        itemCount: c?.n ?? 0,
        etaMinutes: r.prepMinutes + DELIVERY_MINUTES,
      };
    })
    .filter((r) => (!f.area || r.deliveryAreas.includes(f.area)))
    .filter((r) => {
      if (f.area || !f.cityCode) return true;
      const city = getCity(f.cityCode);
      return !!city && r.deliveryAreas.some((slug) => slug.startsWith(`${city.slug}-`));
    })
    .filter((r) => (!f.cuisine || r.cuisines.includes(f.cuisine)))
    .filter((r) => (!f.openNow || r.openNow))
    .filter((r) => (!f.vegan || r.hasVegan))
    .filter((r) => (!f.halal || r.hasHalal))
    .filter((r) => (!f.campaign || !!r.campaignTitle))
    .filter((r) => (f.maxFee == null || r.deliveryFeeMinor <= f.maxFee))
    .filter((r) => (f.maxPrep == null || r.prepMinutes <= f.maxPrep))
    .filter((r) => (f.minRating == null || (r.ratingCount && r.ratingAvg >= f.minRating)))
    .filter((r) => (!f.q || (r.name + r.tagline + r.cuisines.join(" ")).toLowerCase().includes(f.q.toLowerCase())))
    .sort((a, b) => {
      if (f.sort === "fast") return a.etaMinutes - b.etaMinutes;
      if (f.sort === "cheap") return a.deliveryFeeMinor - b.deliveryFeeMinor;
      if (a.openNow !== b.openNow) return a.openNow ? -1 : 1;
      return b.ratingAvg * Math.min(1, b.ratingCount / 5) - a.ratingAvg * Math.min(1, a.ratingCount / 5);
    });
}

export type MenuProduct = {
  id: string;
  name: string;
  description: string | null;
  imageUrl: string | null;
  priceMinor: number;
  discountPriceMinor: number | null;
  allergens: string[];
  calories: number | null;
  prepMinutes: number | null;
  stock: number;
  isVegetarian: boolean;
  isVegan: boolean;
  isSpicy: boolean;
  groups: { id: string; name: string; required: boolean; minSelect: number; maxSelect: number; options: { id: string; name: string; priceDeltaMinor: number; isDefault: boolean }[] }[];
};

export type MenuCategory = { id: string; name: string; description: string | null; timeFrom: string | null; timeTo: string | null; timeWindow: string | null; activeNow: boolean; products: MenuProduct[] };

export async function getMenu(restaurantId: string): Promise<MenuCategory[]> {
  const cats = await db.select().from(menuCategories).where(and(eq(menuCategories.restaurantId, restaurantId), eq(menuCategories.isActive, true))).orderBy(asc(menuCategories.position));
  if (!cats.length) return [];
  const prods = await db.select().from(products).where(and(inArray(products.restaurantId, [restaurantId]), eq(products.status, "PUBLISHED")));
  const groups = prods.length ? await db.select().from(productOptionGroups).where(inArray(productOptionGroups.productId, prods.map((p) => p.id))).orderBy(asc(productOptionGroups.position)) : [];
  const opts = groups.length ? await db.select().from(productOptions).where(inArray(productOptions.groupId, groups.map((g) => g.id))).orderBy(asc(productOptions.position)) : [];
  const now = new Date().getHours() * 60 + new Date().getMinutes();
  const toMin = (t: string) => { const [h, m] = t.split(":").map(Number); return h * 60 + m; };
  return cats
    .map((c) => {
      const inWindow = !c.timeFrom || !c.timeTo || (toMin(c.timeTo) > toMin(c.timeFrom) ? now >= toMin(c.timeFrom) && now <= toMin(c.timeTo) : now >= toMin(c.timeFrom) || now <= toMin(c.timeTo));
      return {
        id: c.id,
        name: c.name,
        description: c.description,
        timeFrom: c.timeFrom,
        timeTo: c.timeTo,
        timeWindow: c.timeFrom && c.timeTo ? `${c.timeFrom}–${c.timeTo}` : null,
        activeNow: inWindow,
        products: prods
          .filter((p) => p.categoryId === c.id)
          .map((p) => ({
            id: p.id,
            name: p.name,
            description: p.description,
            imageUrl: p.imageUrl,
            priceMinor: p.priceMinor,
            discountPriceMinor: p.discountPriceMinor,
            allergens: p.allergens,
            calories: p.calories,
            prepMinutes: p.prepMinutes,
            stock: p.stock,
            isVegetarian: p.isVegetarian,
            isVegan: p.isVegan,
            isSpicy: p.isSpicy,
            groups: groups
              .filter((g) => g.productId === p.id)
              .map((g) => ({ id: g.id, name: g.name, required: g.required, minSelect: g.minSelect, maxSelect: g.maxSelect, options: opts.filter((o) => o.groupId === g.id).map((o) => ({ id: o.id, name: o.name, priceDeltaMinor: o.priceDeltaMinor, isDefault: o.isDefault })) })),
          })),
      };
    })
    .filter((c) => c.products.length > 0) as MenuCategory[];
}

export async function getRestaurantPage(slug: string) {
  const [r] = await db.select().from(restaurants).where(eq(restaurants.slug, slug)).limit(1);
  if (!r || r.visibility === "HIDDEN" || r.status !== "ACTIVE") return null;
  const menu = await getMenu(r.id);
  const revs = await db
    .select({ rv: reviews, author: users.name, resp: reviews.id })
    .from(reviews)
    .leftJoin(users, eq(users.id, reviews.authorId))
    .where(and(eq(reviews.targetId, r.id), eq(reviews.status, "PUBLISHED")))
    .orderBy(desc(reviews.createdAt))
    .limit(20);
  const responses = revs.length ? await db.select().from(reviewResponses).where(inArray(reviewResponses.reviewId, revs.map((x) => x.rv.id))) : [];
  const media = await db.select().from(mediaPosts).where(and(eq(mediaPosts.ownerType, "RESTAURANT"), eq(mediaPosts.ownerId, r.id), eq(mediaPosts.status, "PUBLISHED"))).orderBy(desc(mediaPosts.publishedAt));
  const [stat] = await db
    .select({ n: sql<number>`count(*)::int`, done: sql<number>`count(*) filter (where ${orders.status}='DELIVERED')::int`, avg: sql<number>`coalesce(avg(${orders.totalMinor}) filter (where ${orders.status}='DELIVERED'),0)::bigint` })
    .from(orders)
    .where(eq(orders.restaurantId, r.id));
  const cats = await db.select().from(menuCategories).where(eq(menuCategories.restaurantId, r.id)).orderBy(asc(menuCategories.position));
  const allProds = await db.select().from(products).where(and(eq(products.restaurantId, r.id), eq(products.status, "PUBLISHED")));
  return {
    restaurant: { ...publicRestaurant(r), openNow: isOpenNow(r), etaMinutes: r.prepMinutes + DELIVERY_MINUTES, categoryCount: cats.length, productCount: allProds.length, allergens: [...new Set(allProds.flatMap((p) => p.allergens))].sort() },
    menu,
    reviews: revs.map((x) => ({
      id: x.rv.id,
      rating: x.rv.rating,
      body: x.rv.body,
      createdAt: x.rv.createdAt,
      author: maskName(x.author ?? "Müşteri"),
      response: responses.find((rr) => rr.reviewId === x.rv.id)?.body ?? null,
    })),
    media,
    stats: { totalOrders: stat?.n ?? 0, delivered: stat?.done ?? 0, avgBasket: Number(stat?.avg ?? 0) },
  };
}

function maskName(n: string) {
  const [first, ...rest] = n.split(" ");
  return [first, ...rest.map((r) => r[0] + ".")].join(" ");
}

/* ---------------- Sepet ---------------- */
export type CartView = {
  cart: { id: string; restaurantId: string; restaurant: { name: string; slug: string; isOpen: boolean; openNow: boolean; opensAt: string; closesAt: string; minBasketMinor: number; deliveryFeeMinor: number; smallBasketFeeMinor: number; smallBasketThresholdMinor: number; prepMinutes: number; deliveryAreas: string[] } };
  items: { id: string; productId: string; name: string; options: string; qty: number; note: string | null; unitPriceMinor: number; lineTotalMinor: number; stock: number; available: boolean }[];
  subtotalMinor: number;
  itemCount: number;
};

async function loadCart(tx: Tx | typeof db, customerId: string): Promise<CartView | null> {
  const [cart] = await tx.select().from(carts).where(eq(carts.customerId, customerId)).limit(1);
  if (!cart) return null;
  const [rest] = await tx.select().from(restaurants).where(eq(restaurants.id, cart.restaurantId)).limit(1);
  if (!rest) return null;
  const rows = await tx.select().from(cartItems).where(eq(cartItems.cartId, cart.id)).orderBy(asc(cartItems.createdAt));
  const prods = rows.length ? await tx.select().from(products).where(inArray(products.id, rows.map((r) => r.productId))) : [];
  const items = rows.map((r) => {
    const p = prods.find((x) => x.id === r.productId);
    const available = !!p && p.status === "PUBLISHED" && p.stock >= r.qty;
    return {
      id: r.id,
      productId: r.productId,
      name: p?.name ?? r.nameSnapshot,
      options: r.optionsSnapshot,
      qty: r.qty,
      note: r.note,
      unitPriceMinor: r.unitPriceMinor,
      lineTotalMinor: r.unitPriceMinor * r.qty,
      stock: p?.stock ?? 0,
      available,
    };
  });
  const subtotalMinor = items.filter((i) => i.available).reduce((s, i) => s + i.lineTotalMinor, 0);
  return {
    cart: {
      id: cart.id,
      restaurantId: rest.id,
      restaurant: {
        name: rest.name,
        slug: rest.slug,
        isOpen: rest.isOpen,
        openNow: isOpenNow(rest),
        opensAt: rest.opensAt,
        closesAt: rest.closesAt,
        minBasketMinor: rest.minBasketMinor,
        deliveryFeeMinor: rest.deliveryFeeMinor,
        smallBasketFeeMinor: rest.smallBasketFeeMinor,
        smallBasketThresholdMinor: rest.smallBasketThresholdMinor,
        prepMinutes: rest.prepMinutes,
        deliveryAreas: rest.deliveryAreas,
      },
    },
    items,
    subtotalMinor,
    itemCount: items.reduce((s, i) => s + i.qty, 0),
  };
}

export async function getCartView(s: Session) {
  if (s.user.role !== "CUSTOMER") throw new HttpError(403, "Sepet yalnızca müşteri hesapları içindir.");
  return loadCart(db, s.user.id);
}

/** Birim fiyat her zaman sunucuda hesaplanır; istemciden gelen fiyat yok sayılır. */
async function unitPrice(tx: Tx, productId: string, optionIds: string[]) {
  const [p] = await tx.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!p) throw new HttpError(404, "Ürün bulunamadı.");
  if (p.status !== "PUBLISHED") throw new HttpError(422, "Bu ürün şu anda satışta değil.");
  if (p.stock < 1) throw new HttpError(422, "Bu ürün şu anda tükenmiş görünüyor.");
  const groups = await tx.select().from(productOptionGroups).where(eq(productOptionGroups.productId, productId));
  const opts = groups.length ? await tx.select().from(productOptions).where(inArray(productOptions.groupId, groups.map((g) => g.id))) : [];
  const chosen = new Set(optionIds);
  for (const bad of optionIds.filter((id) => !opts.some((o) => o.id === id))) throw new HttpError(422, "Seçilen seçenek bu ürüne ait değil.");
  for (const g of groups) {
    const inGroup = opts.filter((o) => g.id === o.groupId);
    const sel = inGroup.filter((o) => chosen.has(o.id));
    if (g.required && sel.length < Math.max(1, g.minSelect)) throw new HttpError(422, `“${g.name}” seçimi zorunlu.`);
    if (sel.length > g.maxSelect) throw new HttpError(422, `“${g.name}” için en fazla ${g.maxSelect} seçenek seçilebilir.`);
  }
  const delta = opts.filter((o) => chosen.has(o.id)).reduce((s, o) => s + o.priceDeltaMinor, 0);
  const base = p.discountPriceMinor ?? p.priceMinor;
  const names = groups.map((g) => opts.filter((o) => o.groupId === g.id && chosen.has(o.id)).map((o) => o.name)).flat();
  return { unit: base + delta, product: p, optionsText: names.join(", ") };
}

export async function addToCart(s: Session, input: { restaurantId: string; productId: string; qty: number; optionIds?: string[]; note?: string }) {
  if (s.user.role !== "CUSTOMER") throw new HttpError(403, "Sepet yalnızca müşteri hesapları içindir.");
  if (input.qty < 1 || input.qty > 20) throw new HttpError(422, "Adet 1 ile 20 arasında olmalı.");
  return db.transaction(async (tx) => {
    const [rest] = await tx.select().from(restaurants).where(eq(restaurants.id, input.restaurantId)).limit(1);
    if (!rest) throw new HttpError(404, "İşletme bulunamadı.");
    if (rest.status !== "ACTIVE") throw new HttpError(422, "Bu işletme şu anda siparişe kapalı.");
    const [cart] = await tx.select().from(carts).where(eq(carts.customerId, s.user.id)).limit(1);
    if (cart && cart.restaurantId !== input.restaurantId) {
      // Tek işletme sepeti kuralı — sessizce karıştırmıyoruz, kullanıcıdan onay istiyoruz
      throw new HttpError(409, "Sepetinizde başka bir işletmenin ürünleri var. Yeni işletme için sepeti boşaltın.");
    }
    const { unit, product, optionsText } = await unitPrice(tx, input.productId, input.optionIds ?? []);
    let c = cart;
    if (!c) {
      [c] = await tx.insert(carts).values({ customerId: s.user.id, restaurantId: rest.id }).returning();
    }
    const [item] = await tx.insert(cartItems).values({ cartId: c.id, productId: product.id, qty: input.qty, optionIds: input.optionIds ?? [], note: input.note?.trim() || null, unitPriceMinor: unit, nameSnapshot: product.name, optionsSnapshot: optionsText }).returning();
    await tx.update(products).set({ updatedAt: new Date() }).where(sql`${products.id} = ${product.id} AND 1=0`); // no-op: fiyat/stok siparişte kilitlenir
    return { itemId: item.id, unitPriceMinor: unit };
  });
}

export async function updateCartItem(s: Session, itemId: string, patch: { qty?: number; note?: string }) {
  return db.transaction(async (tx) => {
    const [cart] = await tx.select().from(carts).where(eq(carts.customerId, s.user.id)).limit(1);
    if (!cart) throw new HttpError(404, "Sepet bulunamadı.");
    const [item] = await tx.select().from(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id))).limit(1);
    if (!item) throw new HttpError(404, "Sepet kalemi bulunamadı.");
    const qty = patch.qty ?? item.qty;
    if (qty < 1) throw new HttpError(422, "Adet en az 1 olmalı.");
    if (qty > 20) throw new HttpError(422, "Tek kalemde en fazla 20 adet.");
    const [p] = await tx.select().from(products).where(eq(products.id, item.productId)).limit(1);
    if (!p || p.status !== "PUBLISHED") throw new HttpError(422, "Bu ürün artık satışta değil.");
    if (p.stock < qty) throw new HttpError(422, `Stok yetersiz: en fazla ${p.stock} adet.`);
    await tx.update(cartItems).set({ qty, note: patch.note !== undefined ? patch.note.trim() || null : item.note }).where(eq(cartItems.id, itemId));
    return { ok: true };
  });
}

export async function removeCartItem(s: Session, itemId: string) {
  return db.transaction(async (tx) => {
    const [cart] = await tx.select().from(carts).where(eq(carts.customerId, s.user.id)).limit(1);
    if (!cart) throw new HttpError(404, "Sepet bulunamadı.");
    await tx.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.cartId, cart.id)));
    const left = await tx.select({ n: sql<number>`count(*)::int` }).from(cartItems).where(eq(cartItems.cartId, cart.id));
    if (!left[0]?.n) await tx.delete(carts).where(eq(carts.id, cart.id));
    return { ok: true };
  });
}

export async function clearCart(s: Session) {
  await db.transaction(async (tx) => {
    const [cart] = await tx.select().from(carts).where(eq(carts.customerId, s.user.id)).limit(1);
    if (cart) {
      await tx.delete(cartItems).where(eq(cartItems.cartId, cart.id));
      await tx.delete(carts).where(eq(carts.id, cart.id));
    }
  });
  return { ok: true };
}

/* ---------------- Checkout ---------------- */
export type CheckoutInput = { deliveryArea: string; addressDetail?: string; note?: string; tipMinor?: number; paymentMethod?: string };

export async function checkoutQuote(s: Session, input: CheckoutInput) {
  const cart = await getCartView(s);
  if (!cart || !cart.items.length) throw new HttpError(422, "Sepetiniz boş.");
  const r = cart.cart.restaurant;
  const unavailable = cart.items.filter((i) => !i.available);
  if (unavailable.length) throw new HttpError(409, `${unavailable.map((u) => u.name).join(", ")} şu anda tükendi veya pasif. Sepetten çıkarıp tekrar deneyin.`);
  if (!r.openNow) throw new HttpError(422, "Bu işletme şu anda siparişe kapalı.");
  const area = getArea(input.deliveryArea);
  if (!area) throw new HttpError(422, "Geçersiz teslimat bölgesi.");
  if (!r.deliveryAreas.includes(input.deliveryArea)) throw new HttpError(422, "Bu adrese şu anda teslimat yapılamıyor.");
  if (cart.subtotalMinor < r.minBasketMinor) throw new HttpError(422, `Minimum sepet tutarı ${Math.round(r.minBasketMinor / 100)} TL.`);
  const smallBasketFeeMinor = cart.subtotalMinor < r.smallBasketThresholdMinor ? r.smallBasketFeeMinor : 0;
  const tipMinor = Math.max(0, Math.min(50000, Math.round((input.tipMinor ?? 0) / 100) * 100));
  const totalMinor = cart.subtotalMinor + r.deliveryFeeMinor + smallBasketFeeMinor + tipMinor;
  return {
    subtotalMinor: cart.subtotalMinor,
    deliveryFeeMinor: r.deliveryFeeMinor,
    smallBasketFeeMinor,
    discountMinor: 0,
    serviceFeeMinor: 0,
    tipMinor,
    totalMinor,
    minBasketMinor: r.minBasketMinor,
    etaMinutes: r.prepMinutes + DELIVERY_MINUTES,
    etaLabel: `~${r.prepMinutes + DELIVERY_MINUTES} dk`,
    restaurantName: r.name,
    itemCount: cart.itemCount,
  };
}

export async function placeOrder(s: Session, input: CheckoutInput & { idempotencyKey: string; courierPreference?: string; preferredProviderId?: string; preferredFleetId?: string }) {
  const key = input.idempotencyKey;
  if (!key || key.length < 8) throw new HttpError(400, "Idempotency-Key zorunlu.");
  const [dupe] = await db.select({ id: orders.id, customerId: orders.customerId }).from(orders).where(eq(orders.idempotencyKey, key)).limit(1);
  if (dupe) {
    if (dupe.customerId !== s.user.id) throw new HttpError(409, "Geçersiz idempotency anahtarı.");
    return { id: dupe.id };
  }
  const quote = await checkoutQuote(s, input);

  return db.transaction(async (tx) => {
    const [cart] = await tx.select().from(carts).where(eq(carts.customerId, s.user.id)).limit(1);
    if (!cart) throw new HttpError(422, "Sepetiniz boş.");
    const rows = await tx.select().from(cartItems).where(eq(cartItems.cartId, cart.id));
    if (!rows.length) throw new HttpError(422, "Sepetiniz boş.");
    // Stok kontrolü satır kilidi ile — ürün bazında TOPLAM adet kontrol edilir (aynı ürün birden çok
    // sepette satırında olsa bile fazla satış olmaz)
    const wanted = new Map<string, number>();
    for (const r of rows) wanted.set(r.productId, (wanted.get(r.productId) ?? 0) + r.qty);
    const locked = await tx.select().from(products).where(inArray(products.id, [...wanted.keys()])).for("update");
    for (const [pid, qty] of wanted) {
      const p = locked.find((x) => x.id === pid);
      const label = rows.find((r) => r.productId === pid)?.nameSnapshot ?? "Ürün";
      if (!p || p.status !== "PUBLISHED") throw new HttpError(409, `${label} artık satışta değil. Sepetinizi güncelleyin.`);
      if (p.stock < qty) throw new HttpError(409, `${label} için stok yetersiz (kalan ${Math.max(0, p.stock)}).`);
    }
    for (const [pid, qty] of wanted) {
      await tx.update(products).set({ stock: sql`GREATEST(0, ${products.stock} - ${qty})`, updatedAt: new Date() }).where(eq(products.id, pid));
    }
    const [rest] = await tx.select().from(restaurants).where(eq(restaurants.id, cart.restaurantId)).limit(1);
    const [o] = await tx
      .insert(orders)
      .values({
        code: `SP-${String(Date.now()).slice(-6)}`,
        customerId: s.user.id,
        restaurantId: rest.id,
        status: "ORDER_PLACED",
        subtotalMinor: quote.subtotalMinor,
        deliveryFeeMinor: quote.deliveryFeeMinor,
        smallBasketFeeMinor: quote.smallBasketFeeMinor,
        tipMinor: quote.tipMinor,
        totalMinor: quote.totalMinor,
        deliveryArea: input.deliveryArea,
        addressDetail: input.addressDetail?.trim() || null,
        note: input.note?.trim() || null,
        paymentMethod: input.paymentMethod === "CASH_ON_DELIVERY" ? "CASH_ON_DELIVERY" : "SANDBOX_CARD",
        deliveryOtp: String(Math.floor(1000 + Math.random() * 9000)),
        etaMinutes: quote.etaMinutes,
        courierPreference: input.courierPreference ?? "AUTO",
        preferredProviderId: input.preferredProviderId ?? null,
        preferredFleetId: input.preferredFleetId ?? null,
        idempotencyKey: key,
      })
      .returning();
    await tx.insert(orderItems).values(
      rows.map((r) => ({
        orderId: o.id,
        productId: r.productId,
        nameSnapshot: r.nameSnapshot,
        optionsSnapshot: r.optionsSnapshot,
        qty: r.qty,
        unitPriceMinor: r.unitPriceMinor,
        lineTotalMinor: r.unitPriceMinor * r.qty,
        note: r.note,
      })),
    );
    await tx.insert(orderEvents).values({ orderId: o.id, toState: "ORDER_PLACED", actorId: s.user.id, actorRole: s.user.role, message: `${quote.itemCount} ürün · ${Math.round(quote.totalMinor / 100)} TL` });
    await tx.delete(cartItems).where(eq(cartItems.cartId, cart.id));
    await tx.delete(carts).where(eq(carts.id, cart.id));
    await tx.insert(notifications).values({ userId: rest.ownerUserId, title: "Yeni sipariş", body: `${o.code} · ${quote.itemCount} ürün · ${areaName(input.deliveryArea)}`, link: "/isletme/siparisler" });
    return { id: o.id, code: o.code, totalMinor: o.totalMinor };
  });
}

/* ---------------- Sipariş durum makinesi ---------------- */
const ORDER_MATRIX: Record<string, string[]> = {
  ORDER_PLACED: ["RESTAURANT_ACCEPTED", "RESTAURANT_REJECTED", "CANCELLED", "UNDER_REVIEW"],
  RESTAURANT_ACCEPTED: ["PREPARING", "CANCELLED", "REFUND_PENDING"],
  PREPARING: ["READY_FOR_PICKUP", "CANCELLED", "REFUND_PENDING"],
  READY_FOR_PICKUP: ["COURIER_ASSIGNED", "CANCELLED"],
  COURIER_ASSIGNED: ["OUT_FOR_DELIVERY", "READY_FOR_PICKUP", "CANCELLED"],
  OUT_FOR_DELIVERY: ["DELIVERED", "UNDER_REVIEW"],
  DELIVERED: [],
  RESTAURANT_REJECTED: ["REFUNDED"],
  CANCELLED: ["REFUND_PENDING", "REFUNDED"],
  REFUND_PENDING: ["REFUNDED", "UNDER_REVIEW"],
  REFUNDED: [],
  UNDER_REVIEW: ["CANCELLED", "REFUND_PENDING", "OUT_FOR_DELIVERY", "DELIVERED"],
};

export function assertOrderTransition(from: string, to: string) {
  if (!(ORDER_MATRIX[from] ?? []).includes(to)) throw new HttpError(409, `Sipariş ${ORDER_STATUS[from]?.label ?? from} durumundan ${ORDER_STATUS[to]?.label ?? to} durumuna geçemez.`);
}

async function setOrderState(tx: Tx, orderId: string, to: string, actor: { id: string | null; role: string }, message?: string) {
  const [o] = await tx.select().from(orders).where(eq(orders.id, orderId)).for("update").limit(1);
  if (!o) throw new HttpError(404, "Sipariş bulunamadı.");
  assertOrderTransition(o.status, to);
  await tx.update(orders).set({ status: to, updatedAt: new Date() }).where(eq(orders.id, orderId));
  await tx.insert(orderEvents).values({ orderId, fromState: o.status, toState: to, actorId: actor.id, actorRole: actor.role, message: message ?? null });
  return o;
}

export async function getOrderView(s: Session, id: string) {
  const [o] = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  if (!o) return null;
  const [rest] = await db.select().from(restaurants).where(eq(restaurants.id, o.restaurantId)).limit(1);
  const isCustomer = o.customerId === s.user.id;
  const isMerchant = s.restaurantId === o.restaurantId;
  const isAdmin = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role);
  let courier: { name: string; slug: string; hue: number; ratingAvg: number; ratingCount: number; headline: string | null } | null = null;
  let requestId: string | null = null;
  const [req] = await db.select().from(serviceRequests).where(eq(serviceRequests.linkedOrderId, o.id)).limit(1);
  if (req) {
    requestId = req.id;
    const [a] = await db.select().from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
    if (a) {
      const [p] = await db.select().from(providers).where(eq(providers.id, a.providerId)).limit(1);
      if (p) courier = { name: p.displayName, slug: p.slug, hue: p.hue, ratingAvg: p.ratingAvg, ratingCount: p.ratingCount, headline: p.headline };
    }
  }
  if (!isCustomer && !isMerchant && !(isAdmin || (s.providerId && requestId))) return null;
  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
  const events = await db.select().from(orderEvents).where(eq(orderEvents.orderId, o.id)).orderBy(asc(orderEvents.createdAt));
  const [review] = await db.select().from(reviews).where(and(eq(reviews.targetId, o.restaurantId), eq(reviews.sourceId, o.id))).limit(1);
  return {
    viewer: { isCustomer, isMerchant, isAdmin },
    order: { ...o, deliveryOtp: isCustomer ? o.deliveryOtp : null },
    restaurant: rest ? publicRestaurant(rest) : null,
    items,
    events,
    courier,
    requestId,
    review: review ? { rating: review.rating, body: review.body } : null,
    canReview: isCustomer && o.status === "DELIVERED" && !review && Date.now() - o.updatedAt.getTime() <= REVIEW_WINDOW_DAYS * 86400000,
  };
}
export type OrderView = NonNullable<Awaited<ReturnType<typeof getOrderView>>>;

export async function listCustomerOrders(customerId: string) {
  const rows = await db.select().from(orders).where(eq(orders.customerId, customerId)).orderBy(desc(orders.placedAt)).limit(40);
  const rests = await db.select().from(restaurants);
  return rows.map((o) => ({ ...o, restaurantName: rests.find((r) => r.id === o.restaurantId)?.name ?? "İşletme", restaurantSlug: rests.find((r) => r.id === o.restaurantId)?.slug ?? "#" }));
}

export async function listMerchantOrders(restaurantId: string) {
  const rows = await db.select().from(orders).where(eq(orders.restaurantId, restaurantId)).orderBy(desc(orders.placedAt)).limit(60);
  const custs = await db.select({ id: users.id, name: users.name }).from(users);
  const items = await db.select().from(orderItems).where(inArray(orderItems.orderId, rows.map((r) => r.id)));
  return rows.map((o) => ({ ...o, customerName: custs.find((c) => c.id === o.customerId)?.name ?? "Müşteri", itemCount: items.filter((i) => i.orderId === o.id).reduce((s, i) => s + i.qty, 0) }));
}

/** Restoran sahibi/operasyon: kabul, red, hazırlık, hazır */
export async function merchantOrderAction(s: Session, orderId: string, action: "accept" | "reject" | "prepare" | "ready" | "reopen", reason?: string) {
  const isOps = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role);
  if (!isOps && !s.restaurantId) throw new HttpError(403, "Bu işlem işletme hesabına özeldir.");
  if (action === "reject" && (!reason || reason.trim().length < 5)) throw new HttpError(422, "Ret için gerekçe zorunlu (en az 5 karakter).");
  return db.transaction(async (tx) => {
    const [o] = await tx.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (!o) throw new HttpError(404, "Sipariş bulunamadı.");
    if (!isOps && o.restaurantId !== s.restaurantId) throw new HttpError(404, "Sipariş bulunamadı.");
    const actor = { id: s.user.id, role: s.user.role };
    if (action === "accept") await setOrderState(tx, o.id, "RESTAURANT_ACCEPTED", actor);
    if (action === "prepare") await setOrderState(tx, o.id, "PREPARING", actor);
    if (action === "reject") {
      await setOrderState(tx, o.id, "RESTAURANT_REJECTED", actor, reason);
      await tx.insert(notifications).values({ userId: o.customerId, title: "Siparişiniz reddedildi", body: `${o.code}: ${reason}`, link: `/siparis/${o.id}` });
    }
    if (action === "ready") {
      await setOrderState(tx, o.id, "READY_FOR_PICKUP", actor, "Hazır — kurye ataması başlatıldı");
      await createCourierRequest(tx, o, s);
      await tx.insert(notifications).values({ userId: o.customerId, title: "Siparişiniz hazır 🍽️", body: `${o.code} için kurye aranıyor.`, link: `/siparis/${o.id}` });
    }
    if (action === "reopen") await setOrderState(tx, o.id, "UNDER_REVIEW", actor, reason ?? "Operasyon incelemesi");
    return { ok: true };
  });
}

/** READY_FOR_PICKUP → mevcut eşleştirme motoruyla ServiceRequest oluşturur (müşterinin kurye tercihi korunur). */
async function createCourierRequest(tx: Tx, o: typeof orders.$inferSelect, actor: Session) {
  const [rest] = await tx.select().from(restaurants).where(eq(restaurants.id, o.restaurantId)).limit(1);
  const [existing] = await tx.select().from(serviceRequests).where(eq(serviceRequests.linkedOrderId, o.id)).limit(1);
  if (existing) return existing.id;
  const input: MatchInput = { mode: "INSTANT_CALL", serviceType: "FOOD", pickupArea: o.deliveryArea, dropoffArea: o.deliveryArea, vehicleTypeReq: null };
  const favs = await findFavorites(tx, o.customerId);
  const cands = await findCandidates({ ...input, favoriteProviderIds: favs }, 6);
  const [req] = await tx
    .insert(serviceRequests)
    .values({
      code: `YK-${String(Date.now()).slice(-6)}`,
      customerId: o.customerId,
      mode: "INSTANT_CALL",
      status: "QUOTED",
      serviceType: "FOOD",
      pickupArea: o.deliveryArea,
      pickupDetail: rest ? `${rest.name} — ${rest.addressPublic ?? ""}` : "İşletme",
      dropoffArea: o.deliveryArea,
      dropoffDetail: o.addressDetail,
      note: o.note,
      linkedOrderId: o.id,
      deliveryOtp: o.deliveryOtp,
      idempotencyKey: `order-${o.id}`,
      quotedPriceMinor: cands[0]?.priceMinor ?? null,
      strategy: (o.courierPreference as string) ?? "AUTO",
      preferredProviderId: o.preferredProviderId,
      preferredFleetId: o.preferredFleetId,
    })
    .returning();
  if (cands.length) {
    await tx.insert(matchingCandidates).values(
      cands.map((c, i) => ({
        requestId: req.id,
        providerId: c.provider.id,
        fleetId: c.provider.fleetId,
        score: c.score,
        breakdown: c.breakdown,
        etaSeconds: c.etaSeconds,
        distanceM: c.distanceM,
        priceMinor: c.priceMinor,
        rank: i + 1,
      })),
    );
  }
  await tx.insert(requestEvents).values({ requestId: req.id, actorId: actor.user.id, actorRole: actor.user.role, toState: "QUOTED", message: `${rest?.name ?? "İşletme"} siparişi için ${cands.length} aday` });
  // Tercih doğrulanabilirse otomatik iletime geç; aksi halde müşteri/ops seçer
  const pref = cands.find((c) => c.provider.id === o.preferredProviderId);
  const target = pref ?? (o.courierPreference === "MANUAL_FLEET" ? cands.find((c) => c.provider.fleetId === o.preferredFleetId) : null) ?? cands[0];
  if (target) {
    await tx.update(matchingCandidates).set({ response: "OFFERED", offeredAt: new Date(), offerExpiresAt: new Date(Date.now() + 60000) }).where(and(eq(matchingCandidates.requestId, req.id), eq(matchingCandidates.providerId, target.provider.id)));
    await tx.update(serviceRequests).set({ status: "OFFERED" }).where(eq(serviceRequests.id, req.id));
    await tx.insert(requestEvents).values({ requestId: req.id, actorRole: "system", fromState: "QUOTED", toState: "OFFERED", message: `${target.provider.displayName} adlı sağlayıcıya teklif iletildi` });
    await tx.insert(notifications).values({ userId: target.provider.userId, title: "Yeni yemek teslimatı teklifi", body: `${rest?.name ?? "İşletme"} · ${areaName(o.deliveryArea)} · ${etaBand(target.etaSeconds)}`, link: "/panel" });
  } else {
    await tx.update(serviceRequests).set({ status: "EXPIRED" }).where(eq(serviceRequests.id, req.id));
    await tx.insert(requestEvents).values({ requestId: req.id, actorRole: "system", fromState: "QUOTED", toState: "EXPIRED", message: "Uygun kurye bulunamadı — operasyon bilgilendirildi" });
    await tx.insert(notifications).values({ userId: o.customerId, title: "Kurye bulunamadı", body: `${o.code} için şu an uygun kurye yok. İşletme ile iletişime geçebilirsiniz.`, link: `/siparis/${o.id}` });
  }
  await tx.update(orders).set({ courierRequestId: req.id }).where(eq(orders.id, o.id));
  return req.id;
}

/** Atama olaylarından sipariş durumunu senkronize eder (CONFIRMED → COURIER_ASSIGNED vb.) */
export async function syncOrderFromRequest(tx: Tx, requestId: string, newState: "CONFIRMED" | "IN_PROGRESS" | "COMPLETED" | "CANCELLED", actor: { id: string | null; role: string }) {
  const [req] = await tx.select().from(serviceRequests).where(eq(serviceRequests.id, requestId)).limit(1);
  if (!req?.linkedOrderId) return;
  const [o] = await tx.select().from(orders).where(eq(orders.id, req.linkedOrderId)).limit(1);
  if (!o) return;
  const map: Record<string, string> = { CONFIRMED: "COURIER_ASSIGNED", IN_PROGRESS: "OUT_FOR_DELIVERY", COMPLETED: "DELIVERED", CANCELLED: "READY_FOR_PICKUP" };
  const to = map[newState];
  if (!to || o.status === to) return;
  if (!(ORDER_MATRIX[o.status] ?? []).includes(to)) return;
  await tx.update(orders).set({ status: to, updatedAt: new Date() }).where(eq(orders.id, o.id));
  await tx.insert(orderEvents).values({ orderId: o.id, fromState: o.status, toState: to, actorId: actor.id, actorRole: actor.role, message: newState === "CANCELLED" ? "Kurye görevi iptal edildi — yeni atama bekleniyor" : undefined });
  if (to === "DELIVERED") await tx.insert(notifications).values({ userId: o.customerId, title: "Siparişiniz teslim edildi ⭐", body: `${o.code} · Deneyiminizi değerlendirin (14 gün).`, link: `/siparis/${o.id}` });
  if (to === "COURIER_ASSIGNED") await tx.insert(notifications).values({ userId: o.customerId, title: "Kuryeniz atandı 🛵", body: `${o.code} · Teslimde kodu paylaşın.`, link: `/siparis/${o.id}` });
}

export async function cancelOrder(s: Session, orderId: string, reason?: string) {
  const isAdmin = ["ADMIN", "SUPER_ADMIN"].includes(s.user.role);
  if (isAdmin && (!reason || reason.trim().length < 5)) throw new HttpError(422, "Operasyon iptali için gerekçe zorunlu.");
  return db.transaction(async (tx) => {
    const [o] = await tx.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (!o) throw new HttpError(404, "Sipariş bulunamadı.");
    if (!isAdmin && o.customerId !== s.user.id) throw new HttpError(404, "Sipariş bulunamadı.");
    if (!isAdmin && !["ORDER_PLACED"].includes(o.status)) throw new HttpError(409, "İşletme onayından sonra iptal için destek ekibiyle iletişime geçin.");
    await setOrderState(tx, o.id, "CANCELLED", { id: s.user.id, role: s.user.role }, reason ?? (isAdmin ? "Operasyon iptali" : "Müşteri iptali"));
    // Stok geri yüklenir
    const items = await tx.select().from(orderItems).where(eq(orderItems.orderId, o.id));
    for (const it of items) await tx.update(products).set({ stock: sql`${products.stock} + ${it.qty}`, updatedAt: new Date() }).where(eq(products.id, it.productId));
    const [req] = await tx.select().from(serviceRequests).where(eq(serviceRequests.linkedOrderId, o.id)).limit(1);
    if (req && ["QUOTED", "MATCHING", "OFFERED", "CONFIRMED"].includes(req.status)) {
      await tx.update(matchingCandidates).set({ response: "SKIPPED" }).where(and(eq(matchingCandidates.requestId, req.id), sql`(${matchingCandidates.response} IS NULL OR ${matchingCandidates.response} IN ('OFFERED','FLEET_PENDING'))`));
      await tx.update(serviceRequests).set({ status: "CANCELLED_BY_CUSTOMER", updatedAt: new Date() }).where(eq(serviceRequests.id, req.id));
      await closeRequestConversations(tx, req.id, "Sipariş iptal edildi — sohbet arşivlendi.");
      await tx.insert(requestEvents).values({ requestId: req.id, actorId: s.user.id, actorRole: s.user.role, fromState: req.status, toState: "CANCELLED_BY_CUSTOMER", message: "Bağlı sipariş iptal edildi" });
      const [a] = await tx.select().from(assignments).where(eq(assignments.requestId, req.id)).limit(1);
      if (a) {
        await tx.update(assignments).set({ state: "CANCELLED", cancelledAt: new Date() }).where(eq(assignments.id, a.id));
        await tx.update(providers).set({ status: "AVAILABLE" }).where(and(eq(providers.id, a.providerId), inArray(providers.status, ["BUSY", "ON_TASK"])));
        const [p] = await tx.select().from(providers).where(eq(providers.id, a.providerId)).limit(1);
        if (p) await tx.insert(notifications).values({ userId: p.userId, title: "Görev iptal edildi", body: `${o.code} numaralı sipariş iptal edildiği için görev kapatıldı.`, link: "/panel" });
      }
    }
    await tx.insert(notifications).values({ userId: o.restaurantId ? (await tx.select({ id: restaurants.ownerUserId }).from(restaurants).where(eq(restaurants.id, o.restaurantId)).limit(1))[0]?.id ?? "" : "", title: "Sipariş iptal edildi", body: `${o.code} iptal edildi.`, link: "/isletme/siparisler" }).catch(() => {});
    return { ok: true };
  });
}

export async function rateOrder(s: Session, orderId: string, input: { rating: number; catTime?: number; catCommunication?: number; catCare?: number; catProfessionalism?: number; body?: string }) {
  return db.transaction(async (tx) => {
    const [o] = await tx.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (!o || o.customerId !== s.user.id) throw new HttpError(404, "Sipariş bulunamadı.");
    if (o.status !== "DELIVERED") throw new HttpError(422, "Yalnızca teslim edilen siparişler değerlendirilebilir.");
    if (Date.now() - o.updatedAt.getTime() > REVIEW_WINDOW_DAYS * 86400000) throw new HttpError(422, "Değerlendirme süresi (14 gün) doldu.");
    const [existing] = await tx.select({ id: reviews.id }).from(reviews).where(and(eq(reviews.authorId, s.user.id), eq(reviews.sourceId, o.id))).limit(1);
    if (existing) throw new HttpError(409, "Bu siparişi zaten değerlendirdiniz.");
    await tx.insert(reviews).values({ authorId: s.user.id, targetType: "RESTAURANT", targetId: o.restaurantId, sourceId: o.id, ...input, body: input.body?.trim() || null });
    const [agg] = await tx
      .select({ avg: sql<number>`coalesce(avg(${reviews.rating}),0)::float`, n: sql<number>`count(*)::int` })
      .from(reviews)
      .where(and(eq(reviews.targetId, o.restaurantId), eq(reviews.targetType, "RESTAURANT"), eq(reviews.status, "PUBLISHED")));
    await tx.update(restaurants).set({ ratingAvg: Math.round(agg.avg * 100) / 100, ratingCount: agg.n }).where(eq(restaurants.id, o.restaurantId));
    const [rest] = await tx.select().from(restaurants).where(eq(restaurants.id, o.restaurantId)).limit(1);
    if (rest) await tx.insert(notifications).values({ userId: rest.ownerUserId, title: "Yeni değerlendirme", body: `${o.code} için ${input.rating}★ aldınız.`, link: `/restoranlar/${rest.slug}` });
    return { ok: true };
  });
}

/* ---------------- İşletme paneli: menü yönetimi ---------------- */
async function ownRestaurant(tx: Tx | typeof db, s: Session) {
  if (["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) {
    const [r] = await tx.select().from(restaurants).limit(1);
    return r ?? null;
  }
  if (!s.restaurantId) throw new HttpError(403, "Bu işlem işletme hesabına özeldir.");
  const [r] = await tx.select().from(restaurants).where(eq(restaurants.id, s.restaurantId)).limit(1);
  if (!r) throw new HttpError(404, "İşletme bulunamadı.");
  return r;
}

export async function merchantCreateCategory(s: Session, input: { name: string; description?: string; position?: number; timeFrom?: string; timeTo?: string }) {
  const r = await ownRestaurant(db, s);
  if (!r) throw new HttpError(404, "İşletme bulunamadı.");
  const [c] = await db.insert(menuCategories).values({ restaurantId: r.id, name: input.name.trim(), description: input.description?.trim() || null, position: input.position ?? 0, timeFrom: input.timeFrom ?? null, timeTo: input.timeTo ?? null }).returning();
  return { id: c.id };
}

export async function merchantSaveProduct(s: Session, input: { id?: string; categoryId: string; name: string; description?: string; priceMinor: number; discountPriceMinor?: number | null; stock?: number; allergens?: string[]; calories?: number | null; prepMinutes?: number | null; isVegan?: boolean; isVegetarian?: boolean; isSpicy?: boolean; imageUrl?: string | null; status?: string }) {
  const r = await ownRestaurant(db, s);
  if (!r) throw new HttpError(404, "İşletme bulunamadı.");
  const [cat] = await db.select().from(menuCategories).where(and(eq(menuCategories.id, input.categoryId), eq(menuCategories.restaurantId, r.id))).limit(1);
  if (!cat) throw new HttpError(422, "Kategori bu işletmeye ait değil.");
  if (input.priceMinor < 100) throw new HttpError(422, "Fiyat en az 1 TL olmalı.");
  if (input.discountPriceMinor != null && input.discountPriceMinor >= input.priceMinor) throw new HttpError(422, "İndirimli fiyat normal fiyattan düşük olmalı.");
  const values = {
    restaurantId: r.id,
    categoryId: cat.id,
    name: input.name.trim(),
    description: input.description?.trim() || null,
    imageUrl: input.imageUrl?.trim() || null,
    priceMinor: input.priceMinor,
    discountPriceMinor: input.discountPriceMinor ?? null,
    allergens: input.allergens ?? [],
    calories: input.calories ?? null,
    prepMinutes: input.prepMinutes ?? null,
    stock: Math.max(0, input.stock ?? 50),
    status: input.status === "DRAFT" || input.status === "OFF" || input.status === "ARCHIVED" ? input.status : "PUBLISHED",
    isVegan: !!input.isVegan,
    isVegetarian: !!input.isVegetarian,
    isSpicy: !!input.isSpicy,
    updatedAt: new Date(),
  };
  if (input.id) {
    const [ex] = await db.select().from(products).where(and(eq(products.id, input.id), eq(products.restaurantId, r.id))).limit(1);
    if (!ex) throw new HttpError(404, "Ürün bulunamadı.");
    const [p] = await db.update(products).set(values).where(eq(products.id, ex.id)).returning();
    if (p.isVegan) await db.update(restaurants).set({ hasVegan: true }).where(eq(restaurants.id, r.id));
    return { id: p.id };
  }
  const [p] = await db.insert(products).values(values).returning();
  if (p.isVegan) await db.update(restaurants).set({ hasVegan: true }).where(eq(restaurants.id, r.id));
  return { id: p.id };
}

export async function merchantProductAction(s: Session, productId: string, action: "publish" | "off" | "archive" | "soldout" | "instock") {
  const r = await ownRestaurant(db, s);
  if (!r) throw new HttpError(404, "İşletme bulunamadı.");
  const [p] = await db.select().from(products).where(and(eq(products.id, productId), eq(products.restaurantId, r.id))).limit(1);
  if (!p) throw new HttpError(404, "Ürün bulunamadı.");
  const patch =
    action === "publish" ? { status: "PUBLISHED" }
      : action === "off" ? { status: "OFF" }
        : action === "archive" ? { status: "ARCHIVED" }
          : action === "soldout" ? { stock: 0 }
            : { stock: Math.max(1, p.stock) || 25 };
  await db.update(products).set({ ...patch, updatedAt: new Date() }).where(eq(products.id, p.id));
  return { ok: true };
}

export async function merchantDeleteOptionGroup(s: Session, groupId: string) {
  const r = await ownRestaurant(db, s);
  if (!r) throw new HttpError(404, "İşletme bulunamadı.");
  const [g] = await db.select({ id: productOptionGroups.id, productId: productOptionGroups.productId }).from(productOptionGroups).where(eq(productOptionGroups.id, groupId)).limit(1);
  if (!g) throw new HttpError(404, "Seçenek grubu bulunamadı.");
  const [p] = await db.select({ id: products.id }).from(products).where(and(eq(products.id, g.productId), eq(products.restaurantId, r.id))).limit(1);
  if (!p) throw new HttpError(404, "Seçenek grubu bulunamadı.");
  await db.delete(productOptions).where(eq(productOptions.groupId, groupId));
  await db.delete(productOptionGroups).where(eq(productOptionGroups.id, groupId));
  return { ok: true };
}

export async function merchantAddOptionGroup(s: Session, productId: string, input: { name: string; required: boolean; maxSelect: number; options: { name: string; priceDeltaMinor: number; isDefault?: boolean }[] }) {
  const r = await ownRestaurant(db, s);
  if (!r) throw new HttpError(404, "İşletme bulunamadı.");
  const [p] = await db.select().from(products).where(and(eq(products.id, productId), eq(products.restaurantId, r.id))).limit(1);
  if (!p) throw new HttpError(404, "Ürün bulunamadı.");
  if (!input.options.length) throw new HttpError(422, "En az bir seçenek ekleyin.");
  const [g] = await db.insert(productOptionGroups).values({ productId: p.id, name: input.name.trim(), required: input.required, minSelect: input.required ? 1 : 0, maxSelect: Math.max(1, input.maxSelect) }).returning();
  let pos = 0;
  for (const o of input.options) await db.insert(productOptions).values({ groupId: g.id, name: o.name.trim(), priceDeltaMinor: o.priceDeltaMinor, isDefault: !!o.isDefault, position: pos++ });
  return { id: g.id };
}

export async function merchantToggleOpen(s: Session, isOpen: boolean) {
  const r = await ownRestaurant(db, s);
  if (!r) throw new HttpError(404, "İşletme bulunamadı.");
  await db.update(restaurants).set({ isOpen }).where(eq(restaurants.id, r.id));
  return { ok: true, isOpen };
}

export async function merchantDashboard(s: Session) {
  const r = await ownRestaurant(db, s);
  if (!r) return null;
  const cats = await db.select().from(menuCategories).where(eq(menuCategories.restaurantId, r.id)).orderBy(asc(menuCategories.position));
  const prods = await db.select().from(products).where(eq(products.restaurantId, r.id));
  const groups = prods.length ? await db.select().from(productOptionGroups).where(inArray(productOptionGroups.productId, prods.map((p) => p.id))) : [];
  const opts = groups.length ? await db.select().from(productOptions).where(inArray(productOptions.groupId, groups.map((g) => g.id))) : [];
  const ords = await listMerchantOrders(r.id);
  const [rev] = await db.select({ n: sql<number>`count(*)::int` }).from(reviews).where(eq(reviews.targetId, r.id));
  return {
    restaurant: { ...publicRestaurant(r), openNow: isOpenNow(r), status: r.status },
    categories: cats,
    products: prods.map((p) => ({ ...p, category: cats.find((c) => c.id === p.categoryId)?.name ?? "—", optionGroups: groups.filter((g) => g.productId === p.id).map((g) => ({ ...g, options: opts.filter((o) => o.groupId === g.id) })) })),
    orders: ords,
    reviewCount: rev?.n ?? 0,
  };
}

export { isOpenNow as restaurantOpenNow };
