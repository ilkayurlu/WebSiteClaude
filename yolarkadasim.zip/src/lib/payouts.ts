import { and, desc, eq, gte, inArray, isNull, lt } from "drizzle-orm";
import { db } from "@/db";
import { fleets, notifications, payoutAccounts, payouts, providerEarnings, providers } from "@/db/schema";
import { audit } from "./engine";
import { ensureLedgerBackfill, weekStartIstanbul } from "./finance";
import { HttpError } from "./http";
import type { Session } from "./session";

export type BeneficiaryType = "COURIER" | "FLEET";
export type PayoutStatus = "PENDING" | "PAID" | "HOLD";
export type PeriodGranularity = "week" | "month";

export interface PayoutRecord {
  /** Kalıcı ödeme kimliği (varsa). Henüz emir oluşmamış satırlarda "draft:" ön ekli sanal kimlik. */
  id: string;
  beneficiaryId: string;
  beneficiaryName: string;
  beneficiaryType: BeneficiaryType;
  /** Yalnızca maskeli IBAN. Ham IBAN istemciye asla gönderilmez. */
  ibanMasked: string | null;
  totalOrders: number;
  grossMinor: number;
  platformFeeMinor: number;
  netMinor: number;
  period: string;
  periodStart: string;
  periodEnd: string;
  status: PayoutStatus;
  processedAt: string | null;
  reference: string | null;
  note: string | null;
}

export interface FinanceSummary {
  grossMinor: number;
  commissionMinor: number;
  netMinor: number;
  courierNetMinor: number;
  fleetNetMinor: number;
  pendingNetMinor: number;
  paidNetMinor: number;
  holdNetMinor: number;
  recordCount: number;
}

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

/* ---------------- IBAN ---------------- */
export function normalizeIban(raw: string) {
  return raw.replace(/\s+/g, "").toUpperCase();
}

/** TR IBAN: TR + 2 kontrol + 5 banka + 1 rezerv + 16 hesap = 26 karakter; mod-97 doğrulaması. */
export function isValidTrIban(raw: string) {
  const iban = normalizeIban(raw);
  if (!/^TR\d{24}$/.test(iban)) return false;
  const rearranged = iban.slice(4) + iban.slice(0, 4);
  const numeric = rearranged.replace(/[A-Z]/g, (ch) => String(ch.charCodeAt(0) - 55));
  let remainder = 0;
  for (const digit of numeric) remainder = (remainder * 10 + Number(digit)) % 97;
  return remainder === 1;
}

export function maskIban(raw: string) {
  const iban = normalizeIban(raw);
  if (iban.length < 8) return "****";
  return `${iban.slice(0, 4)} **** **** ${iban.slice(-4)}`;
}

/* ---------------- Periyot ---------------- */
function isoWeekLabel(weekStart: Date) {
  const utc = new Date(Date.UTC(weekStart.getUTCFullYear(), weekStart.getUTCMonth(), weekStart.getUTCDate() + 1));
  const dayNum = utc.getUTCDay() || 7;
  utc.setUTCDate(utc.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(utc.getUTCFullYear(), 0, 1));
  const week = Math.ceil(((utc.getTime() - yearStart.getTime()) / 86_400_000 + 1) / 7);
  return `${utc.getUTCFullYear()}-W${String(week).padStart(2, "0")}`;
}

function monthStartIstanbul(d: Date) {
  const ym = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Istanbul", year: "numeric", month: "2-digit" }).format(d);
  return new Date(`${ym}-01T00:00:00+03:00`);
}

export function periodOf(d: Date, granularity: PeriodGranularity) {
  if (granularity === "month") {
    const start = monthStartIstanbul(d);
    const end = new Date(start.getTime());
    end.setUTCMonth(end.getUTCMonth() + 1);
    return { label: start.toISOString().slice(0, 7), start, end };
  }
  const start = weekStartIstanbul(d);
  return { label: isoWeekLabel(start), start, end: new Date(start.getTime() + 7 * 86_400_000) };
}

/* ---------------- Periyot özeti ---------------- */
async function accountMap() {
  const rows = await db.select().from(payoutAccounts);
  return new Map(rows.map((r) => [`${r.beneficiaryType}:${r.beneficiaryId}`, r]));
}

/**
 * Hakediş kalemlerini periyot + hak sahibi bazında gruplar.
 * Kural: filo üyesinin kazancı FİLO hakedişi olarak; bağımsız kuryenin kazancı KURYE hakedişi olarak ayrıştırılır.
 */
export async function listPayoutRecords(granularity: PeriodGranularity = "week"): Promise<PayoutRecord[]> {
  await ensureLedgerBackfill();
  const [ledger, orders, provs, fls, accounts] = await Promise.all([
    db.select().from(providerEarnings).orderBy(desc(providerEarnings.earnedAt)),
    db.select().from(payouts),
    db.select({ id: providers.id, name: providers.displayName }).from(providers),
    db.select({ id: fleets.id, name: fleets.name }).from(fleets),
    accountMap(),
  ]);
  const orderMap = new Map(orders.map((o) => [`${o.beneficiaryType}:${o.beneficiaryId}:${o.period}`, o]));
  const groups = new Map<string, PayoutRecord>();

  for (const e of ledger) {
    const beneficiaryType: BeneficiaryType = e.fleetId ? "FLEET" : "COURIER";
    const beneficiaryId = e.fleetId ?? e.providerId;
    const p = periodOf(e.earnedAt, granularity);
    const key = `${beneficiaryType}:${beneficiaryId}:${p.label}`;
    const existingOrder = orderMap.get(key);
    const account = accounts.get(`${beneficiaryType}:${beneficiaryId}`);
    const cur = groups.get(key) ?? {
      id: existingOrder?.id ?? `draft:${key}`,
      beneficiaryId,
      beneficiaryType,
      beneficiaryName: beneficiaryType === "FLEET" ? fls.find((f) => f.id === beneficiaryId)?.name ?? "Filo" : provs.find((x) => x.id === beneficiaryId)?.name ?? "Kurye",
      ibanMasked: existingOrder?.ibanMasked ?? (account ? maskIban(account.ibanPrivate) : null),
      totalOrders: 0,
      grossMinor: 0,
      platformFeeMinor: 0,
      netMinor: 0,
      period: p.label,
      periodStart: p.start.toISOString(),
      periodEnd: p.end.toISOString(),
      status: (existingOrder?.status as PayoutStatus | undefined) ?? "PENDING",
      processedAt: existingOrder?.processedAt?.toISOString() ?? null,
      reference: existingOrder?.reference ?? null,
      note: existingOrder?.note ?? null,
    };
    cur.totalOrders += 1;
    cur.grossMinor += e.grossMinor;
    cur.platformFeeMinor += e.commissionMinor;
    cur.netMinor += e.netMinor;
    groups.set(key, cur);
  }
  return [...groups.values()].sort((a, b) => b.periodStart.localeCompare(a.periodStart) || b.netMinor - a.netMinor);
}

export function summarize(records: PayoutRecord[]): FinanceSummary {
  const sum = (xs: PayoutRecord[], k: "grossMinor" | "platformFeeMinor" | "netMinor") => xs.reduce((a, r) => a + r[k], 0);
  return {
    grossMinor: sum(records, "grossMinor"),
    commissionMinor: sum(records, "platformFeeMinor"),
    netMinor: sum(records, "netMinor"),
    courierNetMinor: sum(records.filter((r) => r.beneficiaryType === "COURIER"), "netMinor"),
    fleetNetMinor: sum(records.filter((r) => r.beneficiaryType === "FLEET"), "netMinor"),
    pendingNetMinor: sum(records.filter((r) => r.status === "PENDING"), "netMinor"),
    paidNetMinor: sum(records.filter((r) => r.status === "PAID"), "netMinor"),
    holdNetMinor: sum(records.filter((r) => r.status === "HOLD"), "netMinor"),
    recordCount: records.length,
  };
}

/* ---------------- Ödeme işleme ---------------- */
export interface PayoutTarget {
  beneficiaryType: BeneficiaryType;
  beneficiaryId: string;
  period: string;
  granularity: PeriodGranularity;
}

function requireSuper(s: Session) {
  if (s.user.role !== "SUPER_ADMIN") throw new HttpError(403, "Yetkisiz işlem: Süper Admin yetkisi gereklidir.");
}

function periodBounds(period: string, granularity: PeriodGranularity) {
  if (granularity === "month") {
    if (!/^\d{4}-\d{2}$/.test(period)) throw new HttpError(422, "Geçersiz dönem.");
    const start = new Date(`${period}-01T00:00:00+03:00`);
    const end = new Date(start.getTime());
    end.setUTCMonth(end.getUTCMonth() + 1);
    return { start, end };
  }
  const m = /^(\d{4})-W(\d{2})$/.exec(period);
  if (!m) throw new HttpError(422, "Geçersiz dönem.");
  // ISO haftasının Pazartesi'si: 4 Ocak her zaman 1. haftadadır.
  const jan4 = new Date(`${m[1]}-01-04T00:00:00+03:00`);
  const jan4Week = weekStartIstanbul(jan4);
  const start = new Date(jan4Week.getTime() + (Number(m[2]) - 1) * 7 * 86_400_000);
  return { start, end: new Date(start.getTime() + 7 * 86_400_000) };
}

async function ledgerFor(tx: Tx, t: PayoutTarget) {
  const { start, end } = periodBounds(t.period, t.granularity);
  const scope = t.beneficiaryType === "FLEET" ? eq(providerEarnings.fleetId, t.beneficiaryId) : and(eq(providerEarnings.providerId, t.beneficiaryId), isNull(providerEarnings.fleetId));
  const rows = await tx
    .select()
    .from(providerEarnings)
    .where(and(scope, gte(providerEarnings.earnedAt, start), lt(providerEarnings.earnedAt, end)))
    .for("update");
  return { rows, start, end };
}

async function beneficiaryUser(tx: Tx, type: BeneficiaryType, id: string) {
  if (type === "FLEET") {
    const [f] = await tx.select({ userId: fleets.ownerUserId, name: fleets.name }).from(fleets).where(eq(fleets.id, id)).limit(1);
    return f ?? null;
  }
  const [p] = await tx.select({ userId: providers.userId, name: providers.displayName }).from(providers).where(eq(providers.id, id)).limit(1);
  return p ?? null;
}

/**
 * Tek periyot için ödeme emri. Ön koşullar: SUPER_ADMIN, kayıtlı IBAN, ödenmemiş kalem.
 * PAID: kalemler bu emre bağlanır ve tekrar ödenemez. Para transferi yapılmaz; kayıt ve dekont referansı üretilir.
 */
export async function processPayout(s: Session, target: PayoutTarget, note?: string): Promise<{ id: string; reference: string; netMinor: number }> {
  requireSuper(s);
  return db.transaction(async (tx) => {
    const [account] = await tx.select().from(payoutAccounts).where(and(eq(payoutAccounts.beneficiaryType, target.beneficiaryType), eq(payoutAccounts.beneficiaryId, target.beneficiaryId))).limit(1);
    if (!account) throw new HttpError(422, "Hak sahibinin kayıtlı IBAN'ı yok; ödeme emri oluşturulamaz.");
    const { rows, start, end } = await ledgerFor(tx, target);
    const payable = rows.filter((r) => r.status !== "PAID");
    if (!rows.length) throw new HttpError(404, "Bu dönemde hakediş kaydı yok.");
    if (!payable.length) throw new HttpError(409, "Bu dönem zaten ödendi.");

    const [existing] = await tx.select().from(payouts).where(and(eq(payouts.beneficiaryType, target.beneficiaryType), eq(payouts.beneficiaryId, target.beneficiaryId), eq(payouts.period, target.period))).for("update").limit(1);
    if (existing?.status === "HOLD") throw new HttpError(409, "Bu ödeme blokta (HOLD). Önce bloğu kaldırın.");
    if (existing?.status === "PAID") throw new HttpError(409, "Bu dönem zaten ödendi.");

    const gross = rows.reduce((a, r) => a + r.grossMinor, 0);
    const commission = rows.reduce((a, r) => a + r.commissionMinor, 0);
    const net = rows.reduce((a, r) => a + r.netMinor, 0);
    const reference = `PO-${target.period.replace(/[^0-9W]/g, "")}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
    const now = new Date();
    const values = {
      beneficiaryType: target.beneficiaryType,
      beneficiaryId: target.beneficiaryId,
      period: target.period,
      periodStart: start,
      periodEnd: end,
      totalOrders: rows.length,
      grossMinor: gross,
      commissionMinor: commission,
      netMinor: net,
      status: "PAID" as const,
      ibanMasked: maskIban(account.ibanPrivate),
      reference,
      note: note?.trim() || null,
      processedBy: s.user.id,
      processedAt: now,
    };
    let payoutId: string;
    if (existing) {
      await tx.update(payouts).set(values).where(eq(payouts.id, existing.id));
      payoutId = existing.id;
    } else {
      const [created] = await tx.insert(payouts).values(values).returning({ id: payouts.id });
      payoutId = created.id;
    }
    await tx.update(providerEarnings).set({ status: "PAID", payoutId, approvedBy: s.user.id, approvedAt: now }).where(inArray(providerEarnings.id, payable.map((r) => r.id)));

    const user = await beneficiaryUser(tx, target.beneficiaryType, target.beneficiaryId);
    if (user) await tx.insert(notifications).values({ userId: user.userId, title: "Hakediş ödemesi kayda alındı", body: `${target.period} dönemi · ${rows.length} görev · net ${(net / 100).toFixed(2)} TL · referans ${reference}. Banka transferi muhasebe tarafından ayrıca yürütülür.`, link: target.beneficiaryType === "FLEET" ? "/dashboard/filo/raporlar" : "/dashboard/kurye/kazanc" });
    await audit(tx, s.user.id, "finance.payout_paid", "payout", payoutId, note?.trim() || "Ödeme emri", { beneficiaryType: target.beneficiaryType, beneficiaryId: target.beneficiaryId, period: target.period, netMinor: net, reference });
    return { id: payoutId, reference, netMinor: net };
  });
}

/** HOLD: ödemeyi geçici bloke eder (ör. uyuşmazlık). Kalemler ACCRUED kalır. */
export async function holdPayout(s: Session, target: PayoutTarget, reason: string): Promise<{ id: string }> {
  requireSuper(s);
  if (reason.trim().length < 10) throw new HttpError(422, "Blok gerekçesi en az 10 karakter olmalı.");
  return db.transaction(async (tx) => {
    const { rows, start, end } = await ledgerFor(tx, target);
    if (!rows.length) throw new HttpError(404, "Bu dönemde hakediş kaydı yok.");
    if (rows.every((r) => r.status === "PAID")) throw new HttpError(409, "Ödenmiş dönem bloke edilemez.");
    const [existing] = await tx.select().from(payouts).where(and(eq(payouts.beneficiaryType, target.beneficiaryType), eq(payouts.beneficiaryId, target.beneficiaryId), eq(payouts.period, target.period))).for("update").limit(1);
    const values = { beneficiaryType: target.beneficiaryType, beneficiaryId: target.beneficiaryId, period: target.period, periodStart: start, periodEnd: end, totalOrders: rows.length, grossMinor: rows.reduce((a, r) => a + r.grossMinor, 0), commissionMinor: rows.reduce((a, r) => a + r.commissionMinor, 0), netMinor: rows.reduce((a, r) => a + r.netMinor, 0), status: "HOLD" as const, note: reason.trim(), processedBy: s.user.id, processedAt: new Date() };
    let id: string;
    if (existing) { await tx.update(payouts).set(values).where(eq(payouts.id, existing.id)); id = existing.id; }
    else { const [c] = await tx.insert(payouts).values(values).returning({ id: payouts.id }); id = c.id; }
    await audit(tx, s.user.id, "finance.payout_hold", "payout", id, reason.trim(), { period: target.period });
    return { id };
  });
}

export async function releasePayout(s: Session, target: PayoutTarget, reason: string): Promise<{ id: string }> {
  requireSuper(s);
  if (reason.trim().length < 10) throw new HttpError(422, "Blok kaldırma gerekçesi en az 10 karakter olmalı.");
  return db.transaction(async (tx) => {
    const [existing] = await tx.select().from(payouts).where(and(eq(payouts.beneficiaryType, target.beneficiaryType), eq(payouts.beneficiaryId, target.beneficiaryId), eq(payouts.period, target.period))).for("update").limit(1);
    if (!existing || existing.status !== "HOLD") throw new HttpError(409, "Bu dönemde aktif blok yok.");
    await tx.update(payouts).set({ status: "PENDING", note: reason.trim(), processedBy: s.user.id, processedAt: new Date() }).where(eq(payouts.id, existing.id));
    await audit(tx, s.user.id, "finance.payout_release", "payout", existing.id, reason.trim(), { period: target.period });
    return { id: existing.id };
  });
}

/* ---------------- IBAN kaydı ---------------- */
export async function upsertPayoutAccount(s: Session, input: { beneficiaryType: BeneficiaryType; beneficiaryId: string; iban: string; holderName: string }) {
  const own =
    (input.beneficiaryType === "COURIER" && s.providerId === input.beneficiaryId) ||
    (input.beneficiaryType === "FLEET" && s.fleetId === input.beneficiaryId);
  if (!own && s.user.role !== "SUPER_ADMIN") throw new HttpError(403, "Yalnızca hak sahibi veya platform yöneticisi IBAN tanımlayabilir.");
  if (!isValidTrIban(input.iban)) throw new HttpError(422, "Geçerli bir TR IBAN girin (TR + 24 hane).");
  const holder = input.holderName.trim();
  if (holder.length < 3) throw new HttpError(422, "Hesap sahibi adı en az 3 karakter olmalı.");
  const iban = normalizeIban(input.iban);
  await db.transaction(async (tx) => {
    await tx
      .insert(payoutAccounts)
      .values({ beneficiaryType: input.beneficiaryType, beneficiaryId: input.beneficiaryId, ibanPrivate: iban, holderName: holder, updatedBy: s.user.id })
      .onConflictDoUpdate({ target: [payoutAccounts.beneficiaryType, payoutAccounts.beneficiaryId], set: { ibanPrivate: iban, holderName: holder, updatedBy: s.user.id, updatedAt: new Date() } });
    // Denetim izine ham IBAN yazılmaz; yalnızca maskeli hali.
    await audit(tx, s.user.id, "finance.payout_account_upsert", input.beneficiaryType === "FLEET" ? "fleet" : "provider", input.beneficiaryId, "Ödeme hesabı güncellendi", { ibanMasked: maskIban(iban) });
  });
  return { ok: true, ibanMasked: maskIban(iban) };
}

export async function getOwnPayoutAccount(type: BeneficiaryType, id: string) {
  const [row] = await db.select().from(payoutAccounts).where(and(eq(payoutAccounts.beneficiaryType, type), eq(payoutAccounts.beneficiaryId, id))).limit(1);
  return row ? { ibanMasked: maskIban(row.ibanPrivate), holderName: row.holderName, updatedAt: row.updatedAt } : null;
}

