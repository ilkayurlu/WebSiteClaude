import { createHash, timingSafeEqual } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users, type User } from "@/db/schema";
import { audit } from "./engine";
import { HttpError } from "./http";
import { normalizedEnvValue } from "./auth-mode";

/**
 * Acil durum kök girişi (Root Auth).
 * Demo moddan bağımsız çalışır, ancak yalnızca sunucu tarafında ADMIN_ROOT_PASSWORD
 * tanımlıysa ve parola yeterince güçlüyse etkindir. Parola hiçbir zaman istemciye,
 * loga veya JSON yanıtına yazılmaz; yalnızca SHA-256 özeti karşılaştırılır.
 */

export const ROOT_MIN_PASSWORD_LENGTH = 8;
/** Başarısız denemelerde kilit: 5 hata / 15 dakika (IP + e-posta bazında). */
const ROOT_FAIL_LIMIT = 5;
const ROOT_FAIL_WINDOW_MS = 15 * 60_000;

const attempts = new Map<string, { n: number; firstAt: number }>();

export function rootAuthEmail(): string | undefined {
  const email = normalizedEnvValue(process.env.ADMIN_ROOT_EMAIL).toLowerCase();
  return email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : undefined;
}

/** Kapı yalnızca parola tanımlı VE yeterince güçlüyse açılır. Zayıf parola = kapı kapalı. */
export function rootAuthConfigured(): boolean {
  const password = process.env.ADMIN_ROOT_PASSWORD;
  return !!password && password.length >= ROOT_MIN_PASSWORD_LENGTH;
}

export function rootAuthDisabledReason(): string | null {
  const password = process.env.ADMIN_ROOT_PASSWORD;
  if (!password) return "Sunucu tarafında ADMIN_ROOT_PASSWORD tanımlanmamış.";
  if (password.length < ROOT_MIN_PASSWORD_LENGTH) {
    return `ADMIN_ROOT_PASSWORD en az ${ROOT_MIN_PASSWORD_LENGTH} karakter olmalı; mevcut parola çok kısa olduğu için kök girişi devre dışı bırakıldı.`;
  }
  return null;
}

function digest(value: string) {
  return createHash("sha256").update(value, "utf8").digest();
}

/** Zaman-sabit karşılaştırma:-buffer uzunlukları hash sonrası eşit olduğu için güvenlidir. */
function safeEqual(a: string, b: string) {
  return timingSafeEqual(digest(a), digest(b));
}

export function rootFailures(key: string): number {
  const entry = attempts.get(key);
  if (!entry) return 0;
  if (Date.now() - entry.firstAt > ROOT_FAIL_WINDOW_MS) {
    attempts.delete(key);
    return 0;
  }
  return entry.n;
}

function registerFailure(key: string) {
  const entry = attempts.get(key);
  if (!entry || Date.now() - entry.firstAt > ROOT_FAIL_WINDOW_MS) {
    attempts.set(key, { n: 1, firstAt: Date.now() });
    return;
  }
  entry.n += 1;
}

function clearFailures(key: string) {
  attempts.delete(key);
  if (attempts.size > 2000) attempts.clear();
}

export interface RootLoginInput {
  email: string;
  password: string;
  ip: string;
}

/**
 * Kök kimlik doğrulama. Başarılıysa veritabanındaki SUPER_ADMIN kullanıcısını döner;
 * oturum açma (token üretimi) çağıran tarafa aittir. Hiçbir koşulda rolü istemciden okumaz.
 */
export async function authenticateRoot(input: RootLoginInput): Promise<User> {
  const expectedEmail = rootAuthEmail();
  const expectedPassword = process.env.ADMIN_ROOT_PASSWORD;
  const email = input.email.trim().toLowerCase();

  if (!expectedPassword) throw new HttpError(503, "Kök girişi yapılandırılmamış.");
  if (passwordTooWeak(expectedPassword)) {
    throw new HttpError(503, `Kök girişi devre dışı: ADMIN_ROOT_PASSWORD en az ${ROOT_MIN_PASSWORD_LENGTH} karakter olmalı.`);
  }
  if (!expectedEmail) throw new HttpError(503, "Kök girişi devre dışı: ADMIN_ROOT_EMAIL tanımlı değil.");

  const key = `${input.ip}|${email}`;
  if (rootFailures(key) >= ROOT_FAIL_LIMIT) {
    await audit(db, null, "root_auth.locked_out", "auth", "root", "Çok fazla başarısız kök giriş denemesi", { email, ip: input.ip });
    throw new HttpError(429, "Çok fazla başarısız deneme. 15 dakika sonra tekrar deneyin.");
  }

  const emailOk = safeEqual(email, expectedEmail);
  const passwordOk = safeEqual(input.password, expectedPassword);

  if (!emailOk || !passwordOk) {
    registerFailure(key);
    // Parolayı asla loglamayız; yalnızca deneme sayısını kaydederiz.
    await audit(db, null, "root_auth.failed", "auth", "root", "Hatalı kök giriş denemesi", { email, attempts: rootFailures(key) });
    throw new HttpError(401, "Geçersiz e-posta veya admin parolası.");
  }

  // Parola doğrulandı: SUPER_ADMIN kaydı yoksa oluşturulur, farklı roldeyse yükseltilir.
  const user = await ensureRootSuperAdmin(expectedEmail);

  clearFailures(key);
  return user;
}

function passwordTooWeak(password: string) {
  return password.length < ROOT_MIN_PASSWORD_LENGTH;
}


/** Kök yönetici hesabını garanti eder: yoksa oluşturur, farklı roldeyse SUPER_ADMIN'e yükseltir. */
export async function ensureRootSuperAdmin(email: string): Promise<User> {
  const normalized = normalizedEnvValue(email).toLowerCase();
  let [user] = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
  if (!user) {
    // Aynı anda gelen doğru PIN girişleri email unique sınırında çakışmasın.
    const [created] = await db
      .insert(users)
      .values({ name: "Platform Yöneticisi", email: normalized, role: "SUPER_ADMIN" })
      .onConflictDoNothing({ target: users.email })
      .returning();
    if (created) {
      await audit(db, created.id, "auth.root_bootstrap_user", "user", created.id, "Acil erişimle SUPER_ADMIN hesabı oluşturuldu", { email: normalized });
      return created;
    }
    [user] = await db.select().from(users).where(eq(users.email, normalized)).limit(1);
    if (!user) throw new HttpError(503, "Yönetici hesabı şu anda açılamadı; lütfen tekrar deneyin.");
  }
  if (user.role !== "SUPER_ADMIN") {
    const previousRole = user.role;
    [user] = await db.update(users).set({ role: "SUPER_ADMIN" }).where(eq(users.id, user.id)).returning();
    await audit(db, user.id, "auth.root_promote_user", "user", user.id, "Acil erişimle rol SUPER_ADMIN'e yükseltildi", { previousRole });
  }
  return user;
}
