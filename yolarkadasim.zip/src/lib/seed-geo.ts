import { sql } from "drizzle-orm";
import { db } from "@/db";
import { partnerApplications, providers, restaurants, serviceRequests, users } from "@/db/schema";
import { getDistrict, normalizeAreaSlug } from "./geo-data";

const g = globalThis as typeof globalThis & { __yaGeoMigrate?: Promise<void> };

/** Eski sabit İstanbul anahtarlarını kanonik il-ilçe slug'larına taşır ve ülke geneli örnek sağlayıcıları ekler. */
export function ensureGeoMigration(): Promise<void> {
  if (!g.__yaGeoMigrate) {
    g.__yaGeoMigrate = run().catch((error) => { g.__yaGeoMigrate = undefined; throw error; });
  }
  return g.__yaGeoMigrate;
}

function canonicalList(values: string[] | null | undefined): string[] {
  const out: string[] = [];
  for (const value of values ?? []) {
    const slug = normalizeAreaSlug(value);
    if (slug && !out.includes(slug)) out.push(slug);
  }
  return out;
}

const NATIONWIDE = [
  { slug: "ankara-cankaya-moto", name: "Onur Şen", city: "ankara-cankaya", areas: ["ankara-cankaya", "ankara-cankaya", "ankara-yenimahalle", "ankara-etimesgut"], vehicle: "MOTORCYCLE", label: "Honda CB 250", hue: 8, headline: "Başkent Ekspres Kurye", services: ["PACKAGE", "FOOD"], base: 5200, perKm: 1350 },
  { slug: "izmir-konak-van", name: "Deniz Bayrak", city: "izmir-konak", areas: ["izmir-konak", "izmir-karsiyaka", "izmir-bornova", "izmir-buca"], vehicle: "VAN", label: "Fiat Ducato", hue: 190, headline: "Ege Panelvan · Mağaza Dağıtımı", services: ["PACKAGE", "RENTAL"], base: 12500, perKm: 2400, rental: 62000 },
  { slug: "edirne-merkez-moto", name: "Sinan Trakya", city: "edirne-merkez", areas: ["edirne-merkez", "edirne-kesan", "edirne-uzunkopru"], vehicle: "MOTORCYCLE", label: "Yamaha XMAX 250", hue: 132, headline: "Trakya Kurye · Şehirler Arası", services: ["PACKAGE", "FOOD"], base: 4800, perKm: 1250 },
  { slug: "kirklareli-luleburgaz-car", name: "Pınar Yıldırım", city: "kirklareli-luleburgaz", areas: ["kirklareli-luleburgaz", "kirklareli-babaeski", "kirklareli-merkez"], vehicle: "CAR", label: "Renault Clio", hue: 268, headline: "Lüleburgaz Sürücü · Transfer", services: ["PASSENGER", "PACKAGE", "RENTAL"], base: 11000, perKm: 1950, rental: 38000 },
  { slug: "antalya-muratpasa-moto", name: "Kaan Akdeniz", city: "antalya-muratpasa", areas: ["antalya-muratpasa", "antalya-konyaalti", "antalya-kepez"], vehicle: "MOTORCYCLE", label: "Honda PCX 150", hue: 42, headline: "Akdeniz Kurye · Otel Teslimatı", services: ["PACKAGE", "FOOD"], base: 5000, perKm: 1300 },
  { slug: "bursa-nilufer-van", name: "Hakan Uludağ", city: "bursa-nilufer", areas: ["bursa-nilufer", "bursa-osmangazi", "bursa-yildirim"], vehicle: "COLD_CHAIN_VAN", label: "Ford Transit Frigo", hue: 205, headline: "Soğuk Zincir · Gıda & İlaç", services: ["PACKAGE", "FOOD"], base: 14500, perKm: 2700 },
] as const;

async function run() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(424246)`);

    for (const p of await tx.select({ id: providers.id, areas: providers.serviceAreas }).from(providers)) {
      const next = canonicalList(p.areas);
      if (next.length && next.join("|") !== (p.areas ?? []).join("|")) {
        await tx.update(providers).set({ serviceAreas: next }).where(sql`${providers.id} = ${p.id}`);
      }
    }
    for (const r of await tx.select({ id: restaurants.id, areas: restaurants.deliveryAreas }).from(restaurants)) {
      const next = canonicalList(r.areas);
      if (next.length && next.join("|") !== (r.areas ?? []).join("|")) {
        await tx.update(restaurants).set({ deliveryAreas: next }).where(sql`${restaurants.id} = ${r.id}`);
      }
    }
    for (const q of await tx.select({ id: serviceRequests.id, pickup: serviceRequests.pickupArea, dropoff: serviceRequests.dropoffArea }).from(serviceRequests)) {
      const pickup = normalizeAreaSlug(q.pickup);
      const dropoff = normalizeAreaSlug(q.dropoff);
      if ((pickup && pickup !== q.pickup) || (dropoff && dropoff !== q.dropoff)) {
        await tx.update(serviceRequests)
          .set({ pickupArea: pickup ?? q.pickup, dropoffArea: dropoff ?? q.dropoff })
          .where(sql`${serviceRequests.id} = ${q.id}`);
      }
    }
    for (const a of await tx.select({ id: partnerApplications.id, areas: partnerApplications.areas }).from(partnerApplications)) {
      const next = canonicalList(a.areas);
      if (next.length && next.join("|") !== (a.areas ?? []).join("|")) {
        await tx.update(partnerApplications).set({ areas: next }).where(sql`${partnerApplications.id} = ${a.id}`);
      }
    }

    // Ülke geneli örnek sağlayıcılar: yalnızca demo veri mevcutsa ve kayıt yoksa eklenir.
    const [anyProvider] = await tx.select({ id: providers.id }).from(providers).limit(1);
    if (!anyProvider) return;
    for (const seed of NATIONWIDE) {
      const [exists] = await tx.select({ id: providers.id }).from(providers).where(sql`${providers.slug} = ${seed.slug}`).limit(1);
      if (exists) continue;
      const district = getDistrict(seed.city);
      if (!district) continue;
      const areas = canonicalList([...seed.areas]);
      const [user] = await tx.insert(users)
        .values({ name: seed.name, email: `${seed.slug}@demo.yolarkadasi.app`, role: "PROVIDER" })
        .onConflictDoNothing({ target: users.email })
        .returning();
      const userId = user?.id ?? (await tx.select({ id: users.id }).from(users).where(sql`${users.email} = ${`${seed.slug}@demo.yolarkadasi.app`}`).limit(1))[0]?.id;
      if (!userId) continue;
      await tx.insert(providers).values({
        userId,
        slug: seed.slug,
        kind: seed.vehicle === "CAR" ? "DRIVER" : seed.vehicle === "MOTORCYCLE" ? "COURIER" : "VEHICLE_OPERATOR",
        displayName: seed.name,
        headline: seed.headline,
        bio: `${district.cityName} / ${district.name} merkezli çalışıyorum. Şehir içi ve çevre ilçelere teslimat yapıyorum.`,
        vehicleType: seed.vehicle,
        vehicleLabel: seed.label,
        serviceTypes: [...seed.services],
        serviceAreas: areas,
        highlights: ["Şehirler arası gönderi", "Termal çanta"],
        isVerified: true,
        status: "AVAILABLE",
        completedCount: 0,
        ratingAvg: 0,
        ratingCount: 0,
        acceptsRental: "rental" in seed,
        rentalHourlyMinor: "rental" in seed ? seed.rental : null,
        baseFareMinor: seed.base,
        perKmMinor: seed.perKm,
        lastLat: district.lat,
        lastLng: district.lng,
        lastSeenAt: new Date(),
        hue: seed.hue,
      }).onConflictDoNothing({ target: providers.slug });
    }
  });
}
