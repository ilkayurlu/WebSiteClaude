import { redirect } from "next/navigation";
import { HttpError } from "@/lib/http";
import { getSession, type Session } from "@/lib/session";
import { dashboardHome, roleAllowed, type DashboardRole } from "@/lib/dashboard-routes";

/** Dashboard sayfa/layout koruması. Proxy'ye ek ikinci yetki denetimi. */
export async function requireDashboardSession(): Promise<Session> {
  try {
    return await getSession();
  } catch (error) {
    if (error instanceof HttpError && error.status === 401) redirect("/giris?next=/dashboard");
    throw error;
  }
}

export async function requireDashboardRole(expected: DashboardRole): Promise<Session> {
  const session = await requireDashboardSession();
  if (!roleAllowed(session.user.role, expected)) redirect(dashboardHome(session.user.role));
  return session;
}
