import { eq } from "drizzle-orm";
import { db } from "@/db";
import { favorites } from "@/db/schema";

type Exec = Tx | typeof db;
type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

/** Favori sağlayıcı id'leri — eşleştirme skorunda bonus için. */
export async function findFavorites(exec: Exec, customerId: string): Promise<string[]> {
  const rows = await exec.select({ targetId: favorites.targetId }).from(favorites).where(eq(favorites.customerId, customerId));
  return rows.map((r) => r.targetId);
}
