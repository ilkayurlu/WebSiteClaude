import type { ZodType } from "zod";

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

/** Ortak route sarmalayıcı: beklenen hatalar kullanıcı mesajıyla, beklenmeyenler PII'siz 500. */
export async function handle(fn: () => Promise<unknown>) {
  try {
    const data = await fn();
    if (data instanceof Response) return data; // ikili/özel yanıtlar olduğu gibi geçirilir
    return Response.json(data ?? { ok: true });
  } catch (e) {
    if (e instanceof HttpError) return Response.json({ error: e.message }, { status: e.status });
    const code = (e as { code?: string; cause?: { code?: string } })?.code ?? (e as { cause?: { code?: string } })?.cause?.code;
    if (code === "23505") return Response.json({ error: "Bu işlem zaten yapılmış (çakışma)." }, { status: 409 });
    console.error("[api] unexpected", e instanceof Error ? e.message : "unknown");
    return Response.json({ error: "Bir şeyler ters gitti. Lütfen tekrar deneyin." }, { status: 500 });
  }
}

/** Basit kayan pencere hız sınırı (process içi) — kötüye kullanımı ve spam'i azaltır. */
const buckets = new Map<string, number[]>();
export function rateLimit(key: string, max = 20, windowMs = 60_000) {
  const now = Date.now();
  const arr = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (arr.length >= max) throw new HttpError(429, "Çok fazla istek gönderdiniz. Lütfen biraz bekleyin.");
  arr.push(now);
  buckets.set(key, arr);
  if (buckets.size > 5000) for (const [k, v] of buckets) if (!v.length || now - v[v.length - 1] > windowMs) buckets.delete(k);
}

export function assertSameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  if (origin && origin !== new URL(req.url).origin) throw new HttpError(403, "Güvenli olmayan istek kaynağı.");
}

export async function parseBody<T>(req: Request, schema: ZodType<T>): Promise<T> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    throw new HttpError(400, "Geçersiz istek gövdesi.");
  }
  const r = schema.safeParse(raw);
  if (!r.success) throw new HttpError(422, r.error.issues[0]?.message ?? "Geçersiz veri.");
  return r.data;
}
