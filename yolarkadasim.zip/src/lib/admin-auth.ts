import { redirect } from "next/navigation";
import { HttpError } from "@/lib/http";
import { getSession, type Session } from "@/lib/session";
import { dashboardHome } from "@/lib/dashboard-routes";

/** /admin alanı: operasyon (ADMIN) moderasyon ekranlarına, platform yöneticisi (SUPER_ADMIN) tüm panele erişir. */
export async function requireAdminArea(next = "/admin"): Promise<Session> {
  let s: Session;
  try {
    s = await getSession();
  } catch (error) {
    if (error instanceof HttpError && error.status === 401) redirect(`/giris?next=${encodeURIComponent(next)}`);
    throw error;
  }
  if (!["ADMIN", "SUPER_ADMIN"].includes(s.user.role)) redirect(dashboardHome(s.user.role));
  return s;
}

/** Çekirdek yönetim ekranları (KPI, kurye, filo, görev, uyuşmazlık, finans, ayar) yalnızca SUPER_ADMIN. */
export async function requireSuperAdminPage(next = "/admin"): Promise<Session> {
  const s = await requireAdminArea(next);
  if (s.user.role !== "SUPER_ADMIN") redirect("/dashboard/admin");
  return s;
}
