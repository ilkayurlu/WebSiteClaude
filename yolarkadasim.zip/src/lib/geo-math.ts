/** İstemci ve sunucuda ortak, veri içermeyen saf coğrafi yardımcılar. */

export function slugify(input: string): string {
  return input
    .toLowerCase()
    .replaceAll("ı", "i").replaceAll("İ", "i").replaceAll("ş", "s").replaceAll("ğ", "g")
    .replaceAll("ü", "u").replaceAll("ö", "o").replaceAll("ç", "c")
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function haversineM(aLat: number, aLng: number, bLat: number, bLng: number) {
  const R = 6371000;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(bLat - aLat);
  const dLng = toRad(bLng - aLng);
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(aLat)) * Math.cos(toRad(bLat)) * Math.sin(dLng / 2) ** 2;
  return Math.round(2 * R * Math.asin(Math.sqrt(h)));
}

/** Kuş uçuşu mesafeye yol kıvrım katsayısı (şehir içi ortalama). */
export function roadDistanceM(straightM: number) {
  const factor = straightM > 50_000 ? 1.18 : straightM > 12_000 ? 1.25 : 1.32;
  return Math.round(straightM * factor);
}

const SPEED: Record<string, number> = {
  BICYCLE: 14, MOTORCYCLE: 28, CAR: 24, VAN: 21, TRUCK: 18, COLD_CHAIN_VAN: 20, MINIBUS: 20,
};

export function etaSeconds(straightM: number, vehicle: string) {
  const km = roadDistanceM(straightM) / 1000;
  const speed = SPEED[vehicle] ?? 22;
  const highwayBoost = km > 40 ? 1.7 : km > 15 ? 1.25 : 1;
  return Math.max(180, Math.round((km / (speed * highwayBoost)) * 3600) + 120);
}

export function etaBand(seconds: number) {
  const m = Math.round(seconds / 60);
  if (m <= 5) return "~5 dk";
  if (m <= 60) return `~${Math.ceil(m / 5) * 5} dk`;
  const h = Math.floor(m / 60);
  const r = Math.ceil((m % 60) / 15) * 15;
  return r && r < 60 ? `~${h} sa ${r} dk` : `~${r === 60 ? h + 1 : h} sa`;
}

export function distanceBand(m: number) {
  const km = m / 1000;
  if (km < 1) return "1 km'den yakın";
  if (km < 10) return `${km.toFixed(1).replace(".", ",")} km`;
  if (km < 100) return `${Math.round(km)} km`;
  return `~${Math.round(km / 5) * 5} km`;
}
