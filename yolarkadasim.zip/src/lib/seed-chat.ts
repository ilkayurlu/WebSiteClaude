import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments,
  conversationParticipants,
  conversations,
  fleets,
  messages,
  providers,
  serviceRequests,
  users,
} from "@/db/schema";

const g = globalThis as typeof globalThis & { __yaSeedChat?: Promise<void> };

export function ensureSeedChat() {
  if (!g.__yaSeedChat) {
    g.__yaSeedChat = runChatSeed().catch((e) => {
      g.__yaSeedChat = undefined;
      throw e;
    });
  }
  return g.__yaSeedChat;
}

const pair = (a: string, b: string) => [a, b].sort().join(":");
const ago = (min: number) => new Date(Date.now() - min * 60_000);

async function runChatSeed() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(424244)`);
    const [chk] = await tx.select({ id: conversations.id }).from(conversations).limit(1);
    if (chk) return;

    const [fleet] = await tx.select().from(fleets).where(eq(fleets.slug, "hizli-lojistik")).limit(1);
    const [burak] = await tx.select().from(providers).where(eq(providers.slug, "burak-moto")).limit(1);
    const [selin] = await tx.select().from(providers).where(eq(providers.slug, "selin-van")).limit(1);
    const [ahmet] = await tx.select().from(providers).where(eq(providers.slug, "ahmet-moto")).limit(1);
    const [elif] = await tx.select().from(users).where(eq(users.email, "elif@demo.yolarkadasi.app")).limit(1);
    if (!fleet || !burak || !selin || !ahmet || !elif) return;

    // 1) Filo içi: Murat ↔ Burak (aktif, vardiya planı)
    const [c1] = await tx
      .insert(conversations)
      .values({ contextType: "FLEET_INTERNAL", contextId: fleet.id, pairKey: pair(fleet.ownerUserId, burak.userId), status: "ACTIVE", lastMessageAt: ago(6) })
      .returning();
    await tx.insert(conversationParticipants).values([
      { conversationId: c1.id, userId: fleet.ownerUserId, role: "FLEET_OWNER", lastReadAt: ago(30) },
      { conversationId: c1.id, userId: burak.userId, role: "PROVIDER", lastReadAt: ago(6) },
    ]);
    await tx.insert(messages).values([
      { conversationId: c1.id, senderId: null, type: "SYSTEM_NOTICE", body: "🏢 Filo içi kanal açıldı. Görevden bağımsızdır; kişisel veri paylaşımı otomatik maskelenir.", isRead: true, deliveredAt: ago(180), readAt: ago(180), createdAt: ago(180) },
      { conversationId: c1.id, senderId: fleet.ownerUserId, type: "TEXT", body: "Burak selam, yarın 09:00–14:00 Beşiktaş vardiyası sana uygun mu?", isRead: true, deliveredAt: ago(40), readAt: ago(35), createdAt: ago(42) },
      { conversationId: c1.id, senderId: burak.userId, type: "TEXT", body: "UygunMurat abi, termal çantayı da yeniledim. 08:45'te depoda olurum.", isRead: true, deliveredAt: ago(30), readAt: ago(28), createdAt: ago(31) },
      { conversationId: c1.id, senderId: burak.userId, type: "LOCATION_PIN", body: JSON.stringify({ area: "besiktas", label: "Depo önü — vardiya başlangıcı" }), isRead: false, deliveredAt: ago(6), createdAt: ago(6) },
    ]);

    // 2) Filo içi: Murat ↔ Selin (aktif, okunmuş)
    const [c2] = await tx
      .insert(conversations)
      .values({ contextType: "FLEET_INTERNAL", contextId: fleet.id, pairKey: pair(fleet.ownerUserId, selin.userId), status: "ACTIVE", lastMessageAt: ago(95) })
      .returning();
    await tx.insert(conversationParticipants).values([
      { conversationId: c2.id, userId: fleet.ownerUserId, role: "FLEET_OWNER", lastReadAt: ago(90) },
      { conversationId: c2.id, userId: selin.userId, role: "PROVIDER", lastReadAt: ago(95) },
    ]);
    await tx.insert(messages).values([
      { conversationId: c2.id, senderId: null, type: "SYSTEM_NOTICE", body: "🏢 Filo içi kanal açıldı. Görevden bağımsızdır; kişisel veri paylaşımı otomatik maskelenir.", isRead: true, deliveredAt: ago(300), readAt: ago(300), createdAt: ago(300) },
      { conversationId: c2.id, senderId: selin.userId, type: "TEXT", body: "Rampa bakımı tamamlandı, yarınki çoklu durak rotasına hazırız. Ödeme bilgisi için 0532 111 22 33 numaramı…", masked: true, isRead: true, deliveredAt: ago(100), readAt: ago(98), createdAt: ago(100) },
      { conversationId: c2.id, senderId: fleet.ownerUserId, type: "TEXT", body: "Harika 👏 Not: telefon paylaşımları sistem tarafından otomatik gizlenir, finans işleri panel üzerinden yürür.", isRead: true, deliveredAt: ago(95), readAt: ago(95), createdAt: ago(95) },
    ]);
    // Maskelenmiş demo gövdeyi gerçek maskeleme çıktısıyla değiştir
    await tx
      .update(messages)
      .set({ body: "Rampa bakımı tamamlandı, yarınki çoklu durak rotasına hazırız. Ödeme bilgisi için [telefon gizlendi] numaramı…" })
      .where(and(eq(messages.conversationId, c2.id), eq(messages.masked, true)));

    // 3) Arşivlenmiş görev sohbeti: Elif ↔ Ahmet (tamamlanmış geçmiş görev)
    const [doneAsg] = await tx
      .select({ requestId: assignments.requestId })
      .from(assignments)
      .innerJoin(serviceRequests, eq(serviceRequests.id, assignments.requestId))
      .where(and(eq(assignments.providerId, ahmet.id), eq(serviceRequests.customerId, elif.id), eq(assignments.state, "COMPLETED")))
      .limit(1);
    if (doneAsg) {
      const [req] = await tx.select().from(serviceRequests).where(eq(serviceRequests.id, doneAsg.requestId)).limit(1);
      const base = req.updatedAt;
      const t = (min: number) => new Date(base.getTime() - min * 60_000);
      const [c3] = await tx
        .insert(conversations)
        .values({ contextType: "REQUEST", contextId: req.id, pairKey: pair(elif.id, ahmet.userId), status: "CLOSED", closedReason: "Görev tamamlandı — sohbet arşivlendi.", lastMessageAt: t(0) })
        .returning();
      await tx.insert(conversationParticipants).values([
        { conversationId: c3.id, userId: elif.id, role: "CUSTOMER", lastReadAt: t(4) },
        { conversationId: c3.id, userId: ahmet.userId, role: "PROVIDER", lastReadAt: t(0) },
      ]);
      await tx.insert(messages).values([
        { conversationId: c3.id, senderId: null, type: "SYSTEM_NOTICE", body: `✅ ${req.code} görevi onaylandı. Bu sohbet görev süresince açıktır; telefon, adres ve IBAN paylaşımları otomatik gizlenir.`, isRead: true, deliveredAt: t(18), readAt: t(18), createdAt: t(18) },
        { conversationId: c3.id, senderId: ahmet.userId, type: "TEXT", body: "Merhaba, paketi aldım. Trafiğe takılmadan ~15 dk içinde oradayım 🛵", isRead: true, deliveredAt: t(12), readAt: t(11), createdAt: t(12) },
        { conversationId: c3.id, senderId: elif.id, type: "TEXT", body: "Süper, kodu hazırlıyorum. Kapıda bekliyor olacağım.", isRead: true, deliveredAt: t(10), readAt: t(9), createdAt: t(10) },
        { conversationId: c3.id, senderId: ahmet.userId, type: "LOCATION_PIN", body: JSON.stringify({ area: req.dropoffArea ?? "besiktas", label: "Binaya yaklaştım" }), isRead: true, deliveredAt: t(5), readAt: t(4), createdAt: t(5) },
        { conversationId: c3.id, senderId: ahmet.userId, type: "TEXT", body: "Teslim tamamlandı, iyi günler! Değerlendirirseniz çok sevinirim ⭐", isRead: false, deliveredAt: t(1), createdAt: t(1) },
        { conversationId: c3.id, senderId: null, type: "SYSTEM_NOTICE", body: "🔒 Görev tamamlandı — sohbet arşivlendi.", isRead: true, deliveredAt: t(0), readAt: t(0), createdAt: t(0) },
      ]);
    }
  });
}
