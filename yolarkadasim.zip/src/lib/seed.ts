import { sql } from "drizzle-orm";
import { db } from "@/db";
import {
  assignments,
  fleets,
  providers,
  requestEvents,
  reviews,
  serviceRequests,
  users,
} from "@/db/schema";
import { getArea } from "./geo";
import { ensureSeedFood } from "./seed-food";
import { demoEnabled } from "./auth-mode";
import { ensureSeedChat } from "./seed-chat";
import { ensureSeedDocuments } from "./seed-docs";
import { ensureGeoMigration } from "./seed-geo";

const g = globalThis as typeof globalThis & { __yaSeed?: Promise<void> };

/** Demo verisi: yalnızca tablo boşsa ve advisory lock altında bir kez eklenir. */
export function ensureSeed() {
  // Bölge normalizasyonu demo kapalıyken de çalışır: eski anahtarlar kanonik slug'a taşınır.
  if (!demoEnabled()) return ensureGeoMigration();
  if (!g.__yaSeed) {
    g.__yaSeed = runSeed()
      .then(() => ensureGeoMigration())
      .then(() => ensureSeedFood())
      .then(() => ensureSeedChat())
      .then(() => ensureSeedDocuments())
      .catch((e) => {
        g.__yaSeed = undefined;
        throw e;
      });
  }
  return g.__yaSeed;
}

function rnd(seed: number) {
  const x = Math.sin(seed * 9301 + 49297) * 233280;
  return x - Math.floor(x);
}

type P = {
  key: string;
  name: string;
  kind: "COURIER" | "DRIVER" | "VEHICLE_OPERATOR";
  headline: string;
  bio: string;
  vehicle: string;
  vehicleLabel: string;
  services: string[];
  areas: string[];
  highlights: string[];
  fleet?: string;
  verified: boolean;
  status: string;
  rental?: number;
  base: number;
  perKm: number;
  hue: number;
  onTime: number;
  reviews: number[];
};

const PROVIDERS: P[] = [
  { key: "ahmet-moto", name: "Ahmet Kaya", kind: "COURIER", headline: "Moto Kurye · Ekspres Paket", bio: "8 yıldır Anadolu yakasında paket ve evrak taşıyorum. Hızlı, özenli ve iletişimi açık bir yol arkadaşıyım.", vehicle: "MOTORCYCLE", vehicleLabel: "Yamaha NMAX 155", services: ["PACKAGE", "FOOD"], areas: ["kadikoy", "uskudar", "atasehir", "maltepe"], highlights: ["SRC belgeli", "Evrak teslimi", "Termal çanta"], verified: true, status: "AVAILABLE", base: 5500, perKm: 1400, hue: 18, onTime: 0.96, reviews: [5, 5, 4, 5, 5] },
  { key: "zeynep-bisiklet", name: "Zeynep Arslan", kind: "COURIER", headline: "Bisikletli Kurye · Sıfır Emisyon", bio: "Kısa mesafelerde trafiğe takılmadan, çevreci teslimat. Kadıköy ve Beşiktaş vapur hattı benim rotam.", vehicle: "BICYCLE", vehicleLabel: "Elektrikli kargo bisikleti", services: ["PACKAGE", "FOOD"], areas: ["kadikoy", "uskudar", "besiktas"], highlights: ["Karbon nötr", "Kısa mesafe uzmanı"], verified: true, status: "AVAILABLE", base: 4000, perKm: 1200, hue: 150, onTime: 0.93, reviews: [5, 4, 5] },
  { key: "mehmet-transfer", name: "Mehmet Öztürk", kind: "DRIVER", headline: "VIP Transfer · Havalimanı", bio: "Havalimanı transferi ve şehir içi özel yolculuklarda güvenli, dakik sürüş. Bagaj yardımı dahil.", vehicle: "CAR", vehicleLabel: "Volkswagen Passat · Siyah", services: ["PASSENGER", "RENTAL"], areas: ["besiktas", "sisli", "sariyer", "ist", "beyoglu"], highlights: ["10+ yıl deneyim", "İngilizce", "Bagaj yardımı"], fleet: "bogaz-transfer", verified: true, status: "AVAILABLE", rental: 45000, base: 15000, perKm: 2200, hue: 220, onTime: 0.98, reviews: [5, 5, 5, 4, 5, 5] },
  { key: "selin-van", name: "Selin Çelik", kind: "VEHICLE_OPERATOR", headline: "Panelvan · Mağaza Dağıtımı", bio: "E-ticaret ve mağaza dağıtımlarında saatlik kiralama. Rota planlaması ve çoklu durak deneyimi.", vehicle: "VAN", vehicleLabel: "Ford Transit Custom", services: ["PACKAGE", "RENTAL"], areas: ["bakirkoy", "fatih", "basaksehir", "esenyurt", "sisli"], highlights: ["Çoklu durak", "1.2 ton kapasite", "Rampa"], fleet: "hizli-lojistik", verified: true, status: "AVAILABLE", rental: 60000, base: 12000, perKm: 2500, hue: 280, onTime: 0.91, reviews: [4, 5, 4, 4] },
  { key: "burak-moto", name: "Burak Şahin", kind: "COURIER", headline: "Moto Kurye · Yemek & Market", bio: "Restoran ve market teslimatlarında sıcak-soğuk ayrımına dikkat eden, güler yüzlü kurye.", vehicle: "MOTORCYCLE", vehicleLabel: "Honda PCX 125", services: ["FOOD", "PACKAGE"], areas: ["besiktas", "sisli", "beyoglu", "fatih"], highlights: ["Termal çanta", "Gece vardiyası"], fleet: "hizli-lojistik", verified: true, status: "AVAILABLE", base: 5000, perKm: 1300, hue: 35, onTime: 0.94, reviews: [5, 4, 4, 5, 4] },
  { key: "ayse-soguk", name: "Ayşe Demirtaş", kind: "VEHICLE_OPERATOR", headline: "Soğuk Zincir · İlaç & Gıda", bio: "+2/+8°C kontrollü taşıma. Eczane, laboratuvar ve gıda tedarikinde kayıt altında sıcaklık takibi.", vehicle: "COLD_CHAIN_VAN", vehicleLabel: "Fiat Doblo Frigo", services: ["PACKAGE", "FOOD"], areas: ["kadikoy", "atasehir", "uskudar", "maltepe", "kartal"], highlights: ["Sıcaklık kaydı", "ATP belgeli"], fleet: "soguk-hat", verified: true, status: "AVAILABLE", base: 14000, perKm: 2800, hue: 195, onTime: 0.97, reviews: [5, 5, 5] },
  { key: "emre-kamyonet", name: "Emre Yıldız", kind: "VEHICLE_OPERATOR", headline: "Kamyonet · Ev & Ofis Taşıma", bio: "Küçük ev taşıma, mobilya ve ofis ekipmanı. Yükleme yardımı ile saatlik ya da tek seferlik.", vehicle: "TRUCK", vehicleLabel: "Isuzu NPR 3.5t", services: ["PACKAGE", "RENTAL"], areas: ["kartal", "pendik", "maltepe", "atasehir", "saw"], highlights: ["Yükleme yardımı", "Battaniye & kayış"], verified: false, status: "AVAILABLE", rental: 85000, base: 25000, perKm: 3000, hue: 5, onTime: 0.88, reviews: [4, 4] },
  { key: "deniz-minibus", name: "Deniz Koç", kind: "DRIVER", headline: "Minibüs · Grup Transferi", bio: "Etkinlik, okul ve kurumsal grup taşımaları. 16 kişilik konforlu araç.", vehicle: "MINIBUS", vehicleLabel: "Mercedes Sprinter 16+1", services: ["PASSENGER", "RENTAL"], areas: ["kadikoy", "atasehir", "saw", "uskudar", "pendik"], highlights: ["16 koltuk", "Klima", "Kurumsal fatura"], fleet: "bogaz-transfer", verified: true, status: "OFFLINE", rental: 110000, base: 30000, perKm: 3200, hue: 255, onTime: 0.95, reviews: [5, 4] },
  { key: "kerem-yeni", name: "Kerem Aydın", kind: "COURIER", headline: "Moto Kurye · Yeni Katıldı", bio: "Platforma yeni katıldım; hızlı ve dikkatli teslimat sözü veriyorum.", vehicle: "MOTORCYCLE", vehicleLabel: "Kymco Agility 125", services: ["PACKAGE", "FOOD"], areas: ["kadikoy", "maltepe", "kartal", "atasehir"], highlights: ["Yeni sağlayıcı"], verified: false, status: "AVAILABLE", base: 4800, perKm: 1300, hue: 330, onTime: 0.9, reviews: [] },
  { key: "elvan-sedan", name: "Elvan Güneş", kind: "DRIVER", headline: "Şehir İçi Sürücü · Kadın Sürücü", bio: "Şehir içi güvenli yolculuk ve saatlik özel şoförlük. Çocuk koltuğu mevcut.", vehicle: "CAR", vehicleLabel: "Toyota Corolla Hybrid", services: ["PASSENGER", "RENTAL", "PACKAGE"], areas: ["uskudar", "kadikoy", "besiktas", "sisli", "atasehir"], highlights: ["Çocuk koltuğu", "Hibrit araç"], verified: true, status: "AVAILABLE", rental: 40000, base: 12000, perKm: 2000, hue: 300, onTime: 0.97, reviews: [5, 5, 5, 5] },
];

const COMMENTS = [
  "Paketi özenle getirdi, iletişimi çok iyiydi.",
  "Söylenen saatte kapıdaydı, teşekkürler!",
  "Gayet profesyonel, tekrar çalışırım.",
  "Biraz gecikti ama haber verdi, nazikti.",
  "Harika bir deneyim, favorilerime ekledim.",
  "Araç temiz, sürüş güvenliydi.",
];

async function runSeed() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(424242)`);
    const existing = await tx.select({ id: users.id }).from(users).limit(1);
    if (existing.length) return;

    const [elif, can] = await tx
      .insert(users)
      .values([
        { name: "Elif Yılmaz", email: "elif@demo.yolarkadasi.app", role: "CUSTOMER" },
        { name: "Can Demir", email: "can@demo.yolarkadasi.app", role: "CUSTOMER" },
      ])
      .returning();
    const [ops] = await tx
      .insert(users)
      .values({ name: "Platform Yöneticisi", email: "ops@demo.yolarkadasi.app", role: "SUPER_ADMIN" })
      .returning();
    await tx.insert(users).values({ name: "Operasyon Ekibi", email: "operasyon@demo.yolarkadasi.app", role: "ADMIN" });
    void ops;

    const fleetDefs = [
      { slug: "hizli-lojistik", name: "Hızlı Lojistik A.Ş.", owner: "Murat Hızlı", policy: "FLEET_APPROVAL_REQUIRED", desc: "Avrupa yakasında e-ticaret, mağaza dağıtımı ve restoran teslimatları.", accent: "#ff6b35" },
      { slug: "bogaz-transfer", name: "Boğaz Transfer", owner: "Sena Boğaz", policy: "DIRECT_ALLOWED", desc: "Havalimanı, VIP ve grup transferlerinde 7/24 hizmet.", accent: "#3b82f6" },
      { slug: "soguk-hat", name: "Soğuk Hat Lojistik", owner: "Oğuz Soğuk", policy: "FLEET_ONLY", desc: "İlaç, laboratuvar ve taze gıda için kontrollü sıcaklıkta taşıma.", accent: "#06b6d4" },
    ];
    const fleetIds: Record<string, string> = {};
    for (const f of fleetDefs) {
      const [u] = await tx
        .insert(users)
        .values({ name: f.owner, email: `${f.slug}@demo.yolarkadasi.app`, role: "FLEET_OWNER" })
        .returning();
      const [fl] = await tx
        .insert(fleets)
        .values({
          slug: f.slug,
          name: f.name,
          ownerUserId: u.id,
          description: f.desc,
          directPolicy: f.policy,
          isVerified: true,
          accent: f.accent,
        })
        .returning();
      fleetIds[f.slug] = fl.id;
    }

    let n = 1;
    let reqNo = 1000;
    for (const p of PROVIDERS) {
      const [u] = await tx
        .insert(users)
        .values({ name: p.name, email: `${p.key}@demo.yolarkadasi.app`, role: "PROVIDER" })
        .returning();
      const home = getArea(p.areas[0])!;
      const avg = p.reviews.length ? p.reviews.reduce((a, b) => a + b, 0) / p.reviews.length : 0;
      const [prov] = await tx
        .insert(providers)
        .values({
          userId: u.id,
          slug: p.key,
          kind: p.kind,
          displayName: p.name,
          headline: p.headline,
          bio: p.bio,
          vehicleType: p.vehicle,
          vehicleLabel: p.vehicleLabel,
          serviceTypes: p.services,
          serviceAreas: p.areas,
          highlights: p.highlights,
          fleetId: p.fleet ? fleetIds[p.fleet] : null,
          isVerified: p.verified,
          status: p.status,
          ratingAvg: Math.round(avg * 100) / 100,
          ratingCount: p.reviews.length,
          completedCount: p.reviews.length + Math.floor(rnd(n) * 40),
          onTimeRate: p.onTime,
          acceptsRental: !!p.rental,
          rentalHourlyMinor: p.rental ?? null,
          baseFareMinor: p.base,
          perKmMinor: p.perKm,
          lastLat: home.lat + (rnd(n + 3) - 0.5) * 0.02,
          lastLng: home.lng + (rnd(n + 7) - 0.5) * 0.02,
          lastSeenAt: new Date(),
          phonePrivate: `+90 5${30 + n} ${100 + n}${n} ${10 + n} ${20 + n}`,
          hue: p.hue,
        })
        .returning();

      // Geçmiş tamamlanmış görevler + gerçek kaynaklı değerlendirmeler
      for (let i = 0; i < p.reviews.length; i++) {
        const author = i % 2 === 0 ? elif : can;
        const when = new Date(Date.now() - (i + 2) * 86400000 * (1 + rnd(n + i)));
        const [r] = await tx
          .insert(serviceRequests)
          .values({
            code: `YA-${reqNo++}`,
            customerId: author.id,
            mode: "INSTANT_CALL",
            strategy: "AUTO",
            status: "COMPLETED",
            serviceType: p.services[0],
            vehicleTypeReq: p.vehicle,
            pickupArea: p.areas[0],
            dropoffArea: p.areas[1] ?? p.areas[0],
            quotedPriceMinor: p.base + p.perKm * 6,
            finalPriceMinor: p.base + p.perKm * 6,
            deliveryOtp: "0000",
            idempotencyKey: `seed-${p.key}-${i}`,
            createdAt: when,
            updatedAt: when,
          })
          .returning();
        await tx.insert(assignments).values({
          requestId: r.id,
          providerId: prov.id,
          fleetId: prov.fleetId,
          state: "COMPLETED",
          acceptedAt: when,
          startedAt: when,
          completedAt: when,
        });
        await tx.insert(requestEvents).values({ requestId: r.id, toState: "COMPLETED", actorRole: "system", message: "Demo geçmiş kayıt", createdAt: when });
        const rating = p.reviews[i];
        await tx.insert(reviews).values({
          authorId: author.id,
          targetId: prov.id,
          sourceId: r.id,
          rating,
          catTime: Math.max(1, rating - (i % 3 === 2 ? 1 : 0)),
          catCommunication: rating,
          catCare: Math.max(1, rating - (i % 4 === 3 ? 1 : 0)),
          catProfessionalism: rating,
          body: COMMENTS[(n + i) % COMMENTS.length],
          createdAt: when,
        });
      }
      n++;
    }
  });
}
