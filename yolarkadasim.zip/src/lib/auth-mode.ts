import { createHash, timingSafeEqual } from "node:crypto";
import type { AccessMode } from "./auth-mode-types";

/** Yalnızca sunucu tarafında kullanılır; PIN veya parola istemciye taşınmaz. */
export const DEMO_ROLES = ["CUSTOMER", "PROVIDER", "FLEET_OWNER", "RESTAURANT_OWNER"] as const;
export const PIN_LENGTH = 4;
export const PIN_COOLDOWN_MS = 3_000;
export const PIN_MAX_FAILS = 5;
export const PIN_FAIL_WINDOW_MS = 15 * 60_000;
export const PIN_GLOBAL_FAIL_LIMIT = 40;

/** Dotenv tırnakları genelde kendisi temizler; bazı barındırıcıların literal '"2"' değerlerini de tolere eder. */
export function normalizedEnvValue(raw: string | undefined): string {
  let value = String(raw ?? "").trim();
  if (value.length >= 2 && ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'")))) {
    value = value.slice(1, -1).trim();
  }
  return value;
}

export function demoEnvFlag(): boolean {
  return normalizedEnvValue(process.env.DISABLE_DEMO_ACCOUNTS).toLowerCase() !== "true";
}

export function getAccessMode(): AccessMode {
  const raw = normalizedEnvValue(process.env.AUTH_ACCESS_LEVEL);
  if (raw === "0" || raw === "1" || raw === "2") return raw;
  // Geriye dönük uyumluluk: açıkça ayarlanmamışsa eski demo bayrağına göre davran.
  return demoEnvFlag() ? "0" : "1";
}

export function demoEnabled(): boolean { return getAccessMode() === "0"; }
export function credentialsEnabled(): boolean { return getAccessMode() === "1"; }
export function pinModeEnabled(): boolean { return getAccessMode() === "2"; }

export function adminRootPin(): string | undefined {
  const pin = normalizedEnvValue(process.env.ADMIN_ROOT_PIN);
  return /^\d{4}$/.test(pin) ? pin : undefined;
}

export function pinConfigured(): boolean {
  const email = normalizedEnvValue(process.env.ADMIN_ROOT_EMAIL).toLowerCase();
  return !!adminRootPin() && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function pinDisabledReason(): string | null {
  if (!pinModeEnabled()) return null;
  if (!normalizedEnvValue(process.env.ADMIN_ROOT_PIN)) return "ADMIN_ROOT_PIN tanımlı değil. Sunucu ortamında dört haneli PIN ayarlayın.";
  if (!adminRootPin()) return "ADMIN_ROOT_PIN tam olarak dört rakam olmalı; PIN girişi kapalı.";
  if (!pinConfigured()) return "ADMIN_ROOT_EMAIL tanımlı veya geçerli değil; PIN girişi kapalı.";
  return null;
}

function digest(value: string): Buffer { return createHash("sha256").update(value, "utf8").digest(); }

/** PIN'i string olarak karşılaştırır; hash sonrası timingSafeEqual ile karşılaştırma zamanı sabittir. */
export function verifyAdminPin(inputPin: string): boolean {
  const expected = adminRootPin();
  const input = String(inputPin ?? "").trim();
  if (!expected || !/^\d{4}$/.test(input)) return false;
  return timingSafeEqual(digest(input), digest(expected));
}
