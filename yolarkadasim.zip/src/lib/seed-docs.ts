import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { providerDocuments, providers } from "@/db/schema";

const g = globalThis as typeof globalThis & { __yaSeedDocs?: Promise<void> };
const LABELS: Record<string, string> = { LICENSE: "SÜRÜCÜ BELGESİ", REGISTRATION: "ARAÇ RUHSATI", CRIMINAL_RECORD: "ADLİ SİCİL KAYDI" };

function svg(name: string, docType: string) {
  const safe = name.replace(/[<>&"]/g, "");
  return `<svg xmlns="http://www.w3.org/2000/svg" width="640" height="400" viewBox="0 0 640 400"><rect width="640" height="400" rx="24" fill="#f6f3ec"/><rect x="20" y="20" width="600" height="360" rx="18" fill="#fff" stroke="#e2dccd" stroke-width="2"/><rect x="20" y="20" width="600" height="64" rx="18" fill="#0e1324"/><text x="44" y="62" font-family="Arial" font-size="24" font-weight="700" fill="#ff5b23">${LABELS[docType]}</text><text x="44" y="150" font-family="Arial" font-size="18" fill="#6b7080">Ad Soyad</text><text x="44" y="182" font-family="Arial" font-size="26" font-weight="700" fill="#0e1324">${safe}</text><text x="44" y="240" font-family="Arial" font-size="18" fill="#6b7080">Belge No</text><text x="44" y="272" font-family="Arial" font-size="22" fill="#0e1324">DEMO-•••-•••</text><text x="320" y="355" font-family="Arial" font-size="40" font-weight="900" fill="#ff5b23" opacity="0.18" text-anchor="middle" transform="rotate(-12 320 340)">DEMO · GERÇEK BELGE DEĞİL</text></svg>`;
}

/** Demo ortamı: doğrulanmamış sağlayıcılar için örnek evrak (açıkça "DEMO" damgalı). */
export function ensureSeedDocuments() {
  if (!g.__yaSeedDocs) g.__yaSeedDocs = run().catch((e) => { g.__yaSeedDocs = undefined; throw e; });
  return g.__yaSeedDocs;
}

async function run() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`select pg_advisory_xact_lock(424245)`);
    const [chk] = await tx.select({ id: providerDocuments.id }).from(providerDocuments).limit(1);
    if (chk) return;
    const dir = path.join(process.cwd(), "storage", "private", "documents");
    await mkdir(dir, { recursive: true });
    const targets = await tx.select().from(providers).where(eq(providers.isVerified, false));
    for (const p of targets) {
      const types = p.slug === "emre-kamyonet" ? ["LICENSE", "REGISTRATION", "CRIMINAL_RECORD"] : ["LICENSE", "CRIMINAL_RECORD"];
      for (const t of types) {
        const file = path.join(dir, `demo-${p.slug}-${t}.svg`);
        await writeFile(file, svg(p.displayName, t));
        await tx.insert(providerDocuments).values({ providerId: p.id, docType: t, privatePath: path.relative(process.cwd(), file), mime: "image/svg+xml", status: "SUBMITTED" });
      }
    }
  });
}
