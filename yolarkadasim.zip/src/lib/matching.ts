import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { assignments, fleets, providers, type Fleet, type Provider } from "@/db/schema";
import { etaSeconds, getArea, haversineM, roadDistanceM } from "./geo";

export const WEIGHTS = { zone: 30, distance: 25, vehicle: 15, load: 10, onTime: 8, rating: 5, cancel: 4, favorite: 3 };
const MAX_RADIUS_M = 25000;

const SIZE: Record<string, number> = { BICYCLE: 1, MOTORCYCLE: 2, CAR: 3, MINIBUS: 4, VAN: 4, COLD_CHAIN_VAN: 4, TRUCK: 5 };

export type MatchInput = {
  mode: "INSTANT_CALL" | "SCHEDULED" | "INSTANT_RENT";
  serviceType: string;
  vehicleTypeReq?: string | null;
  pickupArea: string;
  dropoffArea?: string | null;
  rentalHours?: number | null;
  favoriteProviderIds?: string[];
};

export type ScoredCandidate = {
  provider: Provider;
  fleet: Fleet | null;
  score: number;
  breakdown: Record<string, number>;
  distanceM: number;
  etaSeconds: number;
  priceMinor: number;
};

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

/** Bayes ortalaması: az değerlendirmeli yeni sağlayıcı görünmez olmaz, tek 5 yıldız da şişmez. */
export function ratingBayes(avg: number, count: number, prior = 4.5, m = 10) {
  return (avg * count + prior * m) / (count + m);
}

function vehicleFit(provVehicle: string, req?: string | null): number {
  if (!req) return 1;
  if (provVehicle === req) return 1;
  if (req === "COLD_CHAIN_VAN") return -1; // soğuk zincir yalnızca birebir
  if (req === "MINIBUS" && provVehicle !== "MINIBUS") return -1;
  if ((SIZE[provVehicle] ?? 0) >= (SIZE[req] ?? 0)) return 0.5;
  return -1;
}

/** Sunucu fiyatı — istemciden gelen fiyat asla kullanılmaz. */
export function computePrice(p: Provider, input: MatchInput) {
  if (input.mode === "INSTANT_RENT") {
    const hours = clamp(input.rentalHours ?? 1, 1, 12);
    return (p.rentalHourlyMinor ?? 0) * hours;
  }
  const a = getArea(input.pickupArea)!;
  const b = getArea(input.dropoffArea) ?? a;
  const km = Math.max(1, roadDistanceM(haversineM(a.lat, a.lng, b.lat, b.lng)) / 1000);
  return Math.round((p.baseFareMinor + p.perKmMinor * km) / 50) * 50;
}

export function isEligible(p: Provider, input: MatchInput): string | null {
  if (p.status === "SUSPENDED" || p.visibility === "HIDDEN") return "Sağlayıcı şu anda hizmet vermiyor.";
  if (!p.serviceAreas.includes(input.pickupArea)) return "Alış noktası sağlayıcının hizmet bölgesi dışında.";
  if (input.mode === "INSTANT_RENT") {
    if (!p.acceptsRental || !p.rentalHourlyMinor) return "Sağlayıcı kiralama kabul etmiyor.";
  } else if (!p.serviceTypes.includes(input.serviceType)) return "Sağlayıcı bu hizmet tipini vermiyor.";
  if (input.mode === "SCHEDULED" && !p.acceptsScheduled) return "Sağlayıcı randevu kabul etmiyor.";
  if (input.mode !== "SCHEDULED" && p.status !== "AVAILABLE") return "Sağlayıcı şu anda müsait değil.";
  if (vehicleFit(p.vehicleType, input.vehicleTypeReq) < 0) return "Araç tipi talebe uygun değil.";
  return null;
}

export async function findCandidates(input: MatchInput, limit = 6): Promise<ScoredCandidate[]> {
  const pickup = getArea(input.pickupArea);
  if (!pickup) return [];

  const pool = await db
    .select()
    .from(providers)
    .where(sql`${input.pickupArea} = ANY(${providers.serviceAreas})`);
  const eligible = pool.filter((p) => !isEligible(p, input));
  if (!eligible.length) return [];

  const fleetIds = [...new Set(eligible.map((p) => p.fleetId).filter(Boolean))] as string[];
  const fleetRows = fleetIds.length ? await db.select().from(fleets).where(inArray(fleets.id, fleetIds)) : [];
  const fleetMap = new Map(fleetRows.map((f) => [f.id, f]));

  const loads = await db
    .select({ providerId: assignments.providerId, n: sql<number>`count(*)::int` })
    .from(assignments)
    .where(and(inArray(assignments.providerId, eligible.map((p) => p.id)), inArray(assignments.state, ["CONFIRMED", "IN_PROGRESS"])))
    .groupBy(assignments.providerId);
  const loadMap = new Map(loads.map((l) => [l.providerId, l.n]));

  const favs = new Set(input.favoriteProviderIds ?? []);
  const scored: ScoredCandidate[] = [];
  for (const p of eligible) {
    const straight =
      p.lastLat != null && p.lastLng != null ? haversineM(p.lastLat, p.lastLng, pickup.lat, pickup.lng) : MAX_RADIUS_M;
    const fit = vehicleFit(p.vehicleType, input.vehicleTypeReq);
    const active = loadMap.get(p.id) ?? 0;
    const b: Record<string, number> = {
      zone: WEIGHTS.zone,
      distance: WEIGHTS.distance * clamp(1 - straight / MAX_RADIUS_M, 0, 1),
      vehicle: WEIGHTS.vehicle * fit,
      load: WEIGHTS.load * clamp(1 - active / Math.max(1, p.maxConcurrent), 0, 1),
      onTime: WEIGHTS.onTime * p.onTimeRate,
      rating: WEIGHTS.rating * (ratingBayes(p.ratingAvg, p.ratingCount) / 5),
      cancel: -WEIGHTS.cancel * p.lateCancelRate,
      favorite: favs.has(p.id) ? WEIGHTS.favorite : 0,
    };
    for (const k of Object.keys(b)) b[k] = Math.round(b[k] * 100) / 100;
    const total = Object.values(b).reduce((a, v) => a + v, 0);
    scored.push({
      provider: p,
      fleet: p.fleetId ? fleetMap.get(p.fleetId) ?? null : null,
      score: Math.round(total * 100) / 100,
      breakdown: b,
      distanceM: roadDistanceM(straight),
      etaSeconds: etaSeconds(straight, p.vehicleType),
      priceMinor: computePrice(p, input),
    });
  }
  return scored.sort((a, b) => b.score - a.score).slice(0, limit);
}

export async function providerById(id: string) {
  const [p] = await db.select().from(providers).where(eq(providers.id, id)).limit(1);
  return p;
}
