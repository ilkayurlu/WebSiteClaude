import { createHash } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { authPinAttempts, type User } from "@/db/schema";
import {
  PIN_COOLDOWN_MS, PIN_FAIL_WINDOW_MS, PIN_GLOBAL_FAIL_LIMIT, PIN_MAX_FAILS, normalizedEnvValue,
  pinConfigured, pinDisabledReason, pinModeEnabled, verifyAdminPin,
} from "./auth-mode";
import { audit } from "./engine";
import { HttpError } from "./http";
import { ensureRootSuperAdmin, rootAuthEmail } from "./root-auth";

type Attempt = typeof authPinAttempts.$inferSelect;
type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];

const GLOBAL_KEY = "pin:global";
const IP_PREFIX = "pin:ip:";

function ipKey(ip: string): string {
  const hash = createHash("sha256").update(ip, "utf8").digest("hex");
  return `${IP_PREFIX}${hash}`;
}

function windowFailures(row: Attempt, now: number): number {
  return now - row.windowStartedAt.getTime() >= PIN_FAIL_WINDOW_MS ? 0 : row.failures;
}

function lockRemaining(row: Attempt, now: number): number {
  if (windowFailures(row, now) < PIN_MAX_FAILS) return 0;
  return Math.max(0, row.windowStartedAt.getTime() + PIN_FAIL_WINDOW_MS - now);
}

function globalRemaining(row: Attempt, now: number): number {
  if (windowFailures(row, now) < PIN_GLOBAL_FAIL_LIMIT) return 0;
  return Math.max(0, row.windowStartedAt.getTime() + PIN_FAIL_WINDOW_MS - now);
}

async function ensureAndLock(tx: Tx, key: string): Promise<Attempt> {
  await tx.insert(authPinAttempts).values({ key }).onConflictDoNothing();
  const [row] = await tx.select().from(authPinAttempts).where(eq(authPinAttempts.key, key)).for("update").limit(1);
  if (!row) throw new HttpError(503, "PIN kilit kaydı okunamadı; lütfen tekrar deneyin.");
  return row;
}

/** İstemcinin göstereceği kilit/bekleme süresi. PIN hiçbir zaman dönmez. */
export async function pinCooldownForIp(ip: string): Promise<number> {
  const now = Date.now();
  const rows = await db.select().from(authPinAttempts).where(eq(authPinAttempts.key, GLOBAL_KEY));
  const global = rows[0];
  const [local] = await db.select().from(authPinAttempts).where(eq(authPinAttempts.key, ipKey(ip))).limit(1);
  return Math.max(
    global ? globalRemaining(global, now) : 0,
    local ? lockRemaining(local, now) : 0,
    local?.cooldownUntil ? Math.max(0, local.cooldownUntil.getTime() - now) : 0,
  );
}

export type PinVerification =
  | { ok: true; user: User }
  | { ok: false; error: string; cooldownMs?: number };

/**
 * PIN doğrulaması ve başarısızlık sayacı aynı transaction'da yapılır.
 * Satır kilidiyle eşzamanlı istekler sayacı atlayamaz; global sayaç IP sahteciliğine karşı korur.
 */
export async function verifyPinAndGetAdmin(pinInput: string, ip: string): Promise<PinVerification> {
  if (!pinModeEnabled()) return { ok: false, error: "PIN girişi bu ortamda kapalı." };
  if (!pinConfigured()) return { ok: false, error: pinDisabledReason() ?? "PIN girişi yapılandırılmamış." };

  const pin = String(pinInput ?? "").trim();
  const matched = verifyAdminPin(pin);
  const providedLength = Math.min(pin.length, 100);
  const configuredLength = normalizedEnvValue(process.env.ADMIN_ROOT_PIN).length;
  // Kayıtlarda PIN'in kendisi asla bulunmaz; yalnızca uzunluk ve eşleşme durumu.
  console.info("[admin-pin] doğrulama", { providedLength, configuredLength, matched });

  const key = ipKey(ip);
  const result = await db.transaction(async (tx) => {
    const global = await ensureAndLock(tx, GLOBAL_KEY);
    const now = Date.now();
    const globalLockedMs = globalRemaining(global, now);
    if (globalLockedMs > 0) {
      return { ok: false, error: "Çok fazla hatalı deneme. 15 dakika sonra tekrar deneyin.", cooldownMs: globalLockedMs } as const;
    }
    const local = await ensureAndLock(tx, key);
    const localLockedMs = lockRemaining(local, now);
    if (localLockedMs > 0) {
      return { ok: false, error: "Çok fazla hatalı deneme. 15 dakika sonra tekrar deneyin.", cooldownMs: localLockedMs } as const;
    }
    const cooldownMs = local.cooldownUntil ? Math.max(0, local.cooldownUntil.getTime() - now) : 0;
    if (cooldownMs > 0) {
      return { ok: false, error: "Çok hızlı deneme. Kısa bir süre bekleyin.", cooldownMs } as const;
    }

    if (!matched) {
      const localExpired = now - local.windowStartedAt.getTime() >= PIN_FAIL_WINDOW_MS;
      const globalExpired = now - global.windowStartedAt.getTime() >= PIN_FAIL_WINDOW_MS;
      const localFailures = (localExpired ? 0 : local.failures) + 1;
      const globalFailures = (globalExpired ? 0 : global.failures) + 1;
      await tx.update(authPinAttempts).set({
        failures: localFailures,
        windowStartedAt: localExpired ? new Date(now) : local.windowStartedAt,
        cooldownUntil: new Date(now + PIN_COOLDOWN_MS),
      }).where(eq(authPinAttempts.key, key));
      await tx.update(authPinAttempts).set({
        failures: globalFailures,
        windowStartedAt: globalExpired ? new Date(now) : global.windowStartedAt,
      }).where(eq(authPinAttempts.key, GLOBAL_KEY));
      const attemptsLeft = Math.max(0, PIN_MAX_FAILS - localFailures);
      // Yalnızca kimliği belirlenemeyen bir kaynak: IP'nin özetinden kısa parça audit'e yazılır.
      try {
        await audit(tx, null, "auth.pin_failed", "auth", "pin", `Hatalı veya eksik PIN kodu (${localFailures}/${PIN_MAX_FAILS})`, { ipHashPrefix: key.slice(-10), attemptsLeft });
      } catch {
        // Deneme sayacı güvenlik-kritik; audit geçici hata verse bile sayacın transaction'ını geri almayın.
        console.error("[admin-pin] başarısız giriş audit kaydı yazılamadı");
      }
      if (attemptsLeft === 0 || globalFailures >= PIN_GLOBAL_FAIL_LIMIT) {
        return { ok: false, error: "Çok fazla hatalı deneme. 15 dakika sonra tekrar deneyin.", cooldownMs: PIN_FAIL_WINDOW_MS } as const;
      }
      return { ok: false, error: `Hatalı veya eksik PIN kodu. Kalan deneme hakkı: ${attemptsLeft}.`, cooldownMs: PIN_COOLDOWN_MS } as const;
    }
    // Başarılı doğrulamada IP sayacı sıfırlanır; global hatalı girişler 15 dakika boyunca kalır.
    await tx.update(authPinAttempts).set({ failures: 0, windowStartedAt: new Date(now), cooldownUntil: null }).where(eq(authPinAttempts.key, key));
    return { ok: true } as const;
  });

  if (!result.ok) return result;

  // PIN sunucu tarafından doğrulandı; kullanıcı rolü istemci girdisinden alınmaz.
  const email = rootAuthEmail();
  if (!email) return { ok: false, error: "ADMIN_ROOT_EMAIL tanımlı değil; yönetici oturumu açılamadı." };
  const user = await ensureRootSuperAdmin(email);
  if (user.isSuspended) return { ok: false, error: "Yönetici hesabı askıda. Operasyon ekibiyle iletişime geçin." };
  return { ok: true, user };
}
