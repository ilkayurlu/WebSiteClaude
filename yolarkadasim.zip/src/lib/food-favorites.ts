import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { restaurants } from "@/db/schema";

export async function getFavoriteRestaurants(ids: string[]) {
  if (!ids.length) return [];
  return db.select({ id: restaurants.id, slug: restaurants.slug, name: restaurants.name, logoHue: restaurants.logoHue, isOpen: restaurants.isOpen, deliveryAreas: restaurants.deliveryAreas }).from(restaurants).where(inArray(restaurants.id, ids));
}

export { getCartView } from "./food";
