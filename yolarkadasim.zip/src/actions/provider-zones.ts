"use server";

import { revalidatePath } from "next/cache";
import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { providers } from "@/db/schema";
import { audit } from "@/lib/engine";
import { isValidAreaSlug, normalizeAreaSlug } from "@/lib/geo-data";
import { getSession } from "@/lib/session";

export interface ZoneResult { success: boolean; error?: string; zones?: string[] }

const schema = z.array(z.string().min(2)).max(200, "En fazla 200 ilçe ekleyebilirsiniz.");

/** Kuryenin hizmet bölgelerini kanonik il-ilçe slug'larıyla kalıcı olarak kaydeder. */
export async function saveServiceZones(input: string[]): Promise<ZoneResult> {
  try {
    const session = await getSession();
    if (!session.providerId) return { success: false, error: "Bu işlem için kurye/sürücü hesabı gerekir." };
    const parsed = schema.safeParse(input);
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz bölge listesi." };

    const zones: string[] = [];
    for (const raw of parsed.data) {
      if (!isValidAreaSlug(raw)) return { success: false, error: "Listede tanımsız bir il/ilçe var. Seçimi yenileyin." };
      const canonical = normalizeAreaSlug(raw);
      if (canonical && !zones.includes(canonical)) zones.push(canonical);
    }
    if (!zones.length) return { success: false, error: "Çağrı alabilmek için en az bir ilçe seçmelisiniz." };

    const [before] = await db.select({ areas: providers.serviceAreas, slug: providers.slug }).from(providers).where(eq(providers.id, session.providerId)).limit(1);
    await db.update(providers).set({ serviceAreas: zones }).where(eq(providers.id, session.providerId));
    await audit(db, session.user.id, "provider.zones_update", "provider", session.providerId, "Hizmet bölgeleri güncellendi", {
      before: before?.areas?.length ?? 0, after: zones.length,
    });
    revalidatePath("/dashboard/kurye/profil-yonetimi");
    revalidatePath("/dashboard/kurye");
    revalidatePath("/kesfet");
    if (before?.slug) revalidatePath(`/kuryeler/${before.slug}`);
    return { success: true, zones };
  } catch {
    return { success: false, error: "Bölgeler kaydedilemedi. Lütfen tekrar deneyin." };
  }
}
