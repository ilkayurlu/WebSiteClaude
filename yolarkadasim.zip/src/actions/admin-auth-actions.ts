"use server";

import { cookies, headers } from "next/headers";
import { db } from "@/db";
import { redirect } from "next/navigation";
import { z } from "zod";
import { audit } from "@/lib/engine";
import { HttpError } from "@/lib/http";
import { authenticateRoot } from "@/lib/root-auth";
import { credentialsEnabled } from "@/lib/auth-mode";
import { closeProviderAvailability, demoEnabled, issueSession, lookupSessionUser, revokeSession, SESSION_COOKIE, SESSION_TTL_SECONDS } from "@/lib/session";

export interface AdminLoginResponse {
  success: boolean;
  error?: string;
  home?: string;
}

const schema = z.object({
  email: z.string().trim().min(3, "E-posta gerekli.").max(180),
  password: z.string().min(1, "Parola gerekli.").max(200),
});

function clientIp(raw: Headers): string {
  const forwarded = raw.get("x-forwarded-for")?.split(",")[0]?.trim();
  return forwarded || raw.get("x-real-ip")?.trim() || "unknown";
}

/**
 * Acil durum yönetici girişi (Root Auth).
 * - Demo modundan bağımsız: kapalıyken de çalışır, açıkken de kullanılabilir.
 * - Yalnızca ADMIN_ROOT_EMAIL + ADMIN_ROOT_PASSWORD ile; rol istemciden asla alınmaz.
 * - Başarılıysa mevcut token-tabanlı oturum altyapısıyla (auth_sessions, SHA-256 hash)
 *   gerçek bir SUPER_ADMIN oturumu açar. İmzalanmamış JSON çerezi basılmaz.
 */
export async function adminDirectLoginAction(_prev: AdminLoginResponse | null, formData: FormData): Promise<AdminLoginResponse> {
  try {
    if (!credentialsEnabled()) return { success: false, error: "Parola girişi bu ortamda kapalı." };
    const parsed = schema.safeParse({ email: String(formData.get("email") ?? ""), password: String(formData.get("password") ?? "") });
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz giriş." };

    const ip = clientIp(await headers());
    const user = await authenticateRoot({ email: parsed.data.email, password: parsed.data.password, ip });

    const jar = await cookies();
    const oldToken = jar.get(SESSION_COOKIE)?.value;
    const previous = await lookupSessionUser(oldToken);
    if (previous && previous.id !== user.id && previous.role === "PROVIDER") await closeProviderAvailability(previous.id);
    await revokeSession(oldToken);

    const token = await issueSession(user.id);
    jar.set(SESSION_COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: SESSION_TTL_SECONDS,
    });
    await audit(db, user.id, "root_auth.success", "auth", user.id, "Kök girişle SUPER_ADMIN oturumu açıldı", { email: user.email, previousRole: previous?.role ?? null, demoMode: demoEnabled() });
    return { success: true, home: "/admin" };
  } catch (error) {
    if (error instanceof HttpError) return { success: false, error: error.message };
    console.error("[root-auth] unexpected", error instanceof Error ? error.message : "unknown");
    return { success: false, error: "Giriş sırasında beklenmeyen bir hata oluştu." };
  }
}

/** Oturumu kapatır ve giriş ekranına döner (Server Action içinde redirect). */
export async function adminLogoutAction(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  const user = await lookupSessionUser(token);
  if (user?.role === "PROVIDER") await closeProviderAvailability(user.id);
  await revokeSession(token);
  jar.delete(SESSION_COOKIE);
  redirect("/giris");
}
