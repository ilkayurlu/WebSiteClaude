"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { adminAssignProvider, cancelRequest } from "@/lib/engine";
import { HttpError, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

/**
 * Canlı operasyon havuzu için sunucu eylemleri (SUPER_ADMIN only).
 * Gizlilik: telefon, açık adres ve ham koordinat taşınmaz; yalnızca
 * bölge düzeyi alanlar ve maskeli isimler kullanılır. Aynı talebe
 * ikinci kesin atama engine katmanında UNIQUE + transaction ile engellenir.
 */

export type LivePoolStatus = "WAITING" | "ASSIGNED" | "DELAYED";

export interface LiveTaskItem {
  id: string;
  code: string;
  /** Müşteri adı maskeli (örn. "A. K."). Ham ad asla taşınmaz. */
  customerMasked: string;
  /** Genel bölge düzeyi; açık adres detayı taşınmaz. */
  pickupArea: string;
  dropoffArea: string;
  createdAt: string;
  elapsedMinutes: number;
  status: LivePoolStatus;
  amountMinor: number | null;
  providerName: string | null;
}

export interface AvailableCourierCandidate {
  id: string;
  name: string;
  vehicleType: string;
  /** ETA bandı (örn. "~12 dk"); ham mesafe/konum taşınmaz. */
  etaBand: string;
  ratingAvg: number;
  ratingCount: number;
}

interface AssignSuccess {
  success: true;
}

interface AssignFailure {
  success: false;
  error: string;
}

export type ManualAssignResult = AssignSuccess | AssignFailure;
export type CancelTaskResult = AssignSuccess | AssignFailure;

const assignSchema = z.object({
  orderId: z.uuid("Geçersiz görev kimliği."),
  providerId: z.uuid("Kurye seçin."),
  reason: z.string().trim().min(10, "Atama gerekçesi en az 10 karakter olmalı.").max(500).default("Operasyon manuel atama (canlı takip)."),
});

const cancelSchema = z.object({
  orderId: z.uuid("Geçersiz görev kimliği."),
  reason: z.string().trim().min(5, "İptal gerekçesi en az 5 karakter olmalı.").max(500),
});

async function requireSuperAdmin() {
  const session = await getSession();
  if (!session.user || session.user.role !== "SUPER_ADMIN") {
    return { session: null, error: "Yetkisiz işlem: Süper Admin yetkisi gereklidir." as const };
  }
  return { session, error: null };
}

/** Havuzda bekleyen/geciken çağrıyı müsait, uygun kurye ile zorunlu eşleştirir. */
export async function manualAssignCourierAction(
  orderId: string,
  providerId: string,
  reason?: string,
): Promise<ManualAssignResult> {
  try {
    const parsed = assignSchema.safeParse({ orderId, providerId, reason: reason ?? "Operasyon manuel atama (canlı takip)." });
    if (!parsed.success) {
      return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz giriş." };
    }
    const { session, error } = await requireSuperAdmin();
    if (!session) return { success: false, error };
    try {
      rateLimit(`manual-assign:${session.user.id}`, 30, 60_000);
    } catch (err) {
      if (err instanceof HttpError) return { success: false, error: err.message };
      throw err;
    }
    await adminAssignProvider(session, parsed.data.orderId, parsed.data.providerId, parsed.data.reason);
    revalidatePath("/admin/talepler");
    return { success: true };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    console.error("[manual-assign] unexpected", err instanceof Error ? err.message : "unknown");
    return { success: false, error: "Atama gerçekleştirilemedi. Lütfen tekrar deneyin." };
  }
}

/** Canlı havuzdaki çağrıyı gerekçeyle iptal eder; müşteri ve (varsa) kurye bilgilendirilir. */
export async function cancelTaskByAdminAction(orderId: string, reason: string): Promise<CancelTaskResult> {
  try {
    const parsed = cancelSchema.safeParse({ orderId, reason });
    if (!parsed.success) {
      return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz giriş." };
    }
    const { session, error } = await requireSuperAdmin();
    if (!session) return { success: false, error };
    await cancelRequest(session, parsed.data.orderId, parsed.data.reason);
    revalidatePath("/admin/talepler");
    return { success: true };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    console.error("[admin-cancel] unexpected", err instanceof Error ? err.message : "unknown");
    return { success: false, error: "İptal gerçekleştirilemedi. Lütfen tekrar deneyin." };
  }
}
