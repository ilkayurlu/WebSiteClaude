"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { MAX_OTP_ATTEMPTS, verifyDeliveryCode } from "@/lib/delivery";
import { HttpError, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export interface VerifyDeliveryInput {
  orderId: string;
  inputCode: string;
}

export type VerifyDeliveryResult =
  | { success: true; message: string }
  | { success: false; error: string; attemptsLeft: number; locked: boolean };

const schema = z.object({
  orderId: z.uuid("Geçersiz teslimat kimliği."),
  inputCode: z.string().regex(/^\d{4}$/, "Teslim kodu 4 haneli rakamlardan oluşur."),
});

/** Kurye teslim kodu doğrulaması. Doğruysa görev tamamlanır ve hakediş deftere tahakkuk eder; hatalıysa kalan hak döner. */
export async function verifyDeliveryCodeAction(input: VerifyDeliveryInput): Promise<VerifyDeliveryResult> {
  try {
    const parsed = schema.safeParse(input);
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz giriş.", attemptsLeft: MAX_OTP_ATTEMPTS, locked: false };
    const session = await getSession();
    if (session.user.role !== "PROVIDER" || !session.providerId) {
      return { success: false, error: "Yetkisiz işlem: Kurye girişi gerekli.", attemptsLeft: 0, locked: false };
    }
    rateLimit(`otp:${session.user.id}`, 12, 60_000);
    const result = await verifyDeliveryCode(session, parsed.data.orderId, parsed.data.inputCode);
    revalidatePath("/dashboard", "layout");
    if (!result.ok) return { success: false, error: result.error, attemptsLeft: result.attemptsLeft, locked: result.locked };
    return { success: true, message: "Teslimat onaylandı. Hakedişiniz deftere işlendi." };
  } catch (error) {
    if (error instanceof HttpError) return { success: false, error: error.message, attemptsLeft: 0, locked: error.status === 423 };
    console.error("[delivery] unexpected", error instanceof Error ? error.message : "unknown");
    return { success: false, error: "Teslimat doğrulanırken bir hata oluştu.", attemptsLeft: 0, locked: false };
  }
}
