"use server";

import { z } from "zod";
import { createOrGetConversation, sendMessage, type MessageWithSender } from "@/lib/chat";
import { HttpError, rateLimit } from "@/lib/http";
import { getSession } from "@/lib/session";

export type OrderChatResult = { success: true; conversationId: string; status: "ACTIVE" | "CLOSED" } | { success: false; error: string };
export type SendMessageResult = { success: true; message: MessageWithSender; warning: string | null } | { success: false; error: string };

/**
 * Sipariş/görev bazlı sohbet. Mevcut bağlama duyarlı altyapıyı kullanır:
 * - orderId bir yemek siparişi ise bağlı kurye görevine çözümlenir.
 * - Sohbet yalnızca kesin atamadan sonra açılır; görev bitince salt okunur olur.
 */
export async function getOrCreateOrderChat(orderId: string): Promise<OrderChatResult> {
  try {
    const id = z.uuid().safeParse(orderId);
    if (!id.success) return { success: false, error: "Geçersiz sipariş kimliği." };
    const session = await getSession();
    let result: { id: string; status: "ACTIVE" | "CLOSED" };
    try {
      result = await createOrGetConversation(session, { requestId: id.data });
    } catch (error) {
      if (error instanceof HttpError && error.status === 404) result = await createOrGetConversation(session, { orderId: id.data });
      else throw error;
    }
    return { success: true, conversationId: result.id, status: result.status };
  } catch (error) {
    if (error instanceof HttpError) return { success: false, error: error.message };
    console.error("[chat-action] unexpected", error instanceof Error ? error.message : "unknown");
    return { success: false, error: "Sohbet açılamadı." };
  }
}

/** Telefon / IBAN / e-posta sunucuda maskelenir. */
export async function sendMessageAction(conversationId: string, text: string): Promise<SendMessageResult> {
  try {
    const parsed = z.object({ conversationId: z.uuid(), text: z.string().trim().min(1, "Boş mesaj gönderilemez.").max(1000) }).safeParse({ conversationId, text });
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz mesaj." };
    const session = await getSession();
    rateLimit(`chat-send:${session.user.id}`, 30, 60_000);
    const res = await sendMessage(session, { conversationId: parsed.data.conversationId, senderId: session.user.id, content: parsed.data.text, type: "TEXT" });
    return { success: true, message: res.message, warning: res.warning };
  } catch (error) {
    if (error instanceof HttpError) return { success: false, error: error.message };
    console.error("[chat-action] unexpected", error instanceof Error ? error.message : "unknown");
    return { success: false, error: "Mesaj gönderilemedi." };
  }
}
