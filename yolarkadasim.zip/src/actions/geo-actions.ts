"use server";

import {
  getCities as cities, getDistricts as districts, getNeighborhoods as neighborhoods,
  searchStreets as streets, resolveArea,
  type CityOption, type DistrictOption, type NeighborhoodOption, type StreetOption,
} from "@/lib/geo-data";

/** Sunucu tarafı tüketim için ince sarmalayıcılar; istemci `/api/geo/*` uçlarını önbellekli kullanır. */
export async function getCities(): Promise<CityOption[]> { return cities(); }
export async function getDistricts(cityCode: string): Promise<DistrictOption[]> { return districts(cityCode); }
export async function getNeighborhoods(districtId: string, query?: string): Promise<NeighborhoodOption[]> { return neighborhoods(districtId, query); }
export async function searchStreets(neighborhoodId: string, query: string): Promise<StreetOption[]> { return streets(neighborhoodId, query); }
export async function resolveAreaSlug(slug: string) { return resolveArea(slug) ?? null; }
