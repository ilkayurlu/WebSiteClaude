"use server";

import { headers } from "next/headers";
import { db } from "@/db";
import { audit } from "@/lib/engine";
import { openSessionForUser } from "@/lib/auth-session";
import { pinConfigured, pinDisabledReason, pinModeEnabled } from "@/lib/auth-mode";
import type { AuthResult } from "@/lib/auth-mode-types";
import { pinCooldownForIp, verifyPinAndGetAdmin } from "@/lib/admin-pin";
import { HttpError } from "@/lib/http";

function requesterIp(headersList: Headers): string {
  return headersList.get("x-forwarded-for")?.split(",")[0]?.trim() || headersList.get("x-real-ip")?.trim() || "unknown";
}

/** Geri sayım ekranı için sunucu durumunu döner. PIN veya kullanıcı bilgisi dönmez. */
export async function getPinCooldownAction(): Promise<{ cooldownMs: number }> {
  if (!pinModeEnabled() || !pinConfigured()) return { cooldownMs: 0 };
  try {
    const ip = requesterIp(await headers());
    return { cooldownMs: await pinCooldownForIp(ip) };
  } catch {
    // Gösterim yedeği; doğrulama esnasında kilit tekrar DB'den kontrol edilir.
    return { cooldownMs: 0 };
  }
}

/**
 * PIN yalnızca Seviye 2'de kabul edilir. DB tabanlı 3 sn bekleme + 5 hata/15 dk kilit
 * altında doğrulanır; gerçek SUPER_ADMIN kullanıcısı için opak DB oturumu açılır.
 * PIN loglanmaz. Açılan çerez mevcut getSession/proxy ile birebir uyumludur.
 */
export async function loginWithPinAction(inputPin: string): Promise<AuthResult> {
  try {
    if (!pinModeEnabled()) return { success: false, error: "PIN girişi bu ortamda kapalı." };
    if (!pinConfigured()) return { success: false, error: pinDisabledReason() ?? "Yönetici PIN'i yapılandırılmamış." };

    const ip = requesterIp(await headers());
    const verification = await verifyPinAndGetAdmin(inputPin, ip);
    if (!verification.ok) return { success: false, error: verification.error, ...(verification.cooldownMs ? { cooldownMs: verification.cooldownMs } : {}) };

    await openSessionForUser(verification.user.id); // await cookies() + HttpOnly/Secure/SameSite via shared helper
    try {
      await audit(db, verification.user.id, "auth.login_pin", "auth", verification.user.id, "PIN ile SUPER_ADMIN oturumu açıldı");
    } catch {
      // Kimlik doğrulaması ve çerez başarılı; audit kesintisi oturumu bozmasın, ancak PIN asla loglanmaz.
      console.error("[admin-pin] audit yazılamadı");
    }
    return { success: true, redirectTo: "/admin", role: "SUPER_ADMIN" };
  } catch (error) {
    if (error instanceof HttpError) return { success: false, error: error.message };
    console.error("[admin-pin] beklenmeyen hata", error instanceof Error ? error.name : "unknown");
    return { success: false, error: "PIN doğrulanırken bir hata oluştu. Lütfen tekrar deneyin." };
  }
}
