"use server";

import { cookies, headers } from "next/headers";
import { z } from "zod";
import { db } from "@/db";
import { audit } from "@/lib/engine";
import { HttpError } from "@/lib/http";
import { closeProviderAvailability, issueSession, lookupSessionUser, revokeSession, SESSION_COOKIE, SESSION_TTL_SECONDS } from "@/lib/session";
import { authenticateUniversal } from "@/lib/universal-auth";
import type { UserRole } from "@/lib/dashboard-routes";

export interface SessionPayload {
  userId: string;
  role: UserRole;
  expiresAt: string;
}

export type AuthResponse =
  | { success: true; redirectTo: string; role: UserRole; via: "root" | "password" }
  | { success: false; error: string };

const schema = z.object({
  email: z.string().trim().min(3, "E-posta gerekli.").max(180),
  password: z.string().min(1, "Parola gerekli.").max(200),
  next: z.string().max(200).optional(),
});

function clientIp(raw: Headers): string {
  return raw.get("x-forwarded-for")?.split(",")[0]?.trim() || raw.get("x-real-ip")?.trim() || "unknown";
}

async function runLogin(formData: FormData): Promise<AuthResponse> {
  try {
    const parsed = schema.safeParse({
      email: String(formData.get("email") ?? ""),
      password: String(formData.get("password") ?? ""),
      next: formData.get("next") ? String(formData.get("next")) : undefined,
    });
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz giriş." };

    const ip = clientIp(await headers());
    const { user, redirectTo, via } = await authenticateUniversal({
      email: parsed.data.email,
      password: parsed.data.password,
      ip,
      next: parsed.data.next,
    });

    const jar = await cookies();
    const oldToken = jar.get(SESSION_COOKIE)?.value;
    const prev = await lookupSessionUser(oldToken);
    if (prev && prev.id !== user.id && prev.role === "PROVIDER") await closeProviderAvailability(prev.id);
    await revokeSession(oldToken);

    // Çerezde rol veya JSON taşınmaz; yalnızca DB'de SHA-256 özeti saklanan opak token.
    const token = await issueSession(user.id);
    jar.set(SESSION_COOKIE, token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: SESSION_TTL_SECONDS,
    });

    await audit(db, user.id, via === "root" ? "auth.login_root" : "auth.login_password", "user", user.id, "Ortak giriş kapısıyla oturum açıldı", { role: user.role, via });
    return { success: true, redirectTo, role: user.role as UserRole, via };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    console.error("[universal-auth] unexpected", err instanceof Error ? err.message : "unknown");
    return { success: false, error: "Giriş sırasında bir hata oluştu. Lütfen tekrar deneyin." };
  }
}

/** Hem doğrudan `universalLoginAction(formData)` hem de `useActionState(universalLoginAction, null)` ile çağrılabilir. */
export async function universalLoginAction(
  first: FormData | AuthResponse | null,
  second?: FormData,
): Promise<AuthResponse> {
  const formData = first instanceof FormData ? first : second;
  if (!(formData instanceof FormData)) return { success: false, error: "Form verisi eksik." };
  return runLogin(formData);
}
