"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { HttpError, rateLimit } from "@/lib/http";
import { applyProviderPresence } from "@/lib/provider-presence";
import { serverStatusToUi, uiStatusToDb, type ProviderCoords, type UiProviderStatus } from "@/lib/provider-status-ui";
import { getSession } from "@/lib/session";

export type ProviderStatus = UiProviderStatus;

export interface UpdateStatusPayload {
  status: ProviderStatus;
  coords?: ProviderCoords;
}

interface UpdateStatusSuccess {
  success: true;
  status: ProviderStatus;
  serverStatus: string;
}

interface UpdateStatusFailure {
  success: false;
  error: string;
}

export type UpdateStatusResult = UpdateStatusSuccess | UpdateStatusFailure;

const coordsSchema = z.object({
  lat: z.number().refine((v) => Number.isFinite(v), "Geçersiz konum bilgisi.").min(-90, "Geçersiz konum bilgisi.").max(90, "Geçersiz konum bilgisi."),
  lng: z
    .number()
    .refine((v) => Number.isFinite(v), "Geçersiz konum bilgisi.")
    .min(-180, "Geçersiz konum bilgisi.")
    .max(180, "Geçersiz konum bilgisi."),
});

const payloadSchema = z.object({
  status: z.enum(["ONLINE", "BUSY", "OFFLINE"]),
  coords: coordsSchema.optional(),
});

/** Kuryenin durum değişikliği: oturum + rol doğrulanır, koordinat doğrulanır, DB'ye yazılır. Koordinat loglanmaz ve yanıtta dönmez. */
export async function updateProviderStatusAction(payload: UpdateStatusPayload): Promise<UpdateStatusResult> {
  try {
    const parsed = payloadSchema.safeParse(payload);
    if (!parsed.success) {
      return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz durum bilgisi." };
    }
    const session = await getSession();
    if (session.user.role !== "PROVIDER" || !session.providerId) {
      return { success: false, error: "Yetkisiz işlem: Sağlayıcı girişi gerekli." };
    }
    try {
      rateLimit(`provider-status:${session.user.id}`, 30, 60_000);
    } catch (error) {
      if (error instanceof HttpError) return { success: false, error: error.message };
      throw error;
    }
    const result = await applyProviderPresence(session.providerId, {
      status: uiStatusToDb(parsed.data.status),
      ...(parsed.data.coords ? { coords: parsed.data.coords } : {}),
    });
    revalidatePath("/dashboard", "layout");
    return { success: true, status: serverStatusToUi(result.status), serverStatus: result.status };
  } catch (error) {
    if (error instanceof HttpError) return { success: false, error: error.message };
    console.error("[provider-status] unexpected", error instanceof Error ? error.message : "unknown");
    return { success: false, error: "Durum güncellenirken bir hata oluştu." };
  }
}

/** Sessiz konum/heartbeat güncellemesi: revalidate yapılmaz, yalnızca son görülme ve (uygunsa) konum yazılır. */
export async function updateProviderLocationAction(coords: ProviderCoords): Promise<{ success: true } | { success: false; error: string }> {
  try {
    const parsed = coordsSchema.safeParse(coords);
    if (!parsed.success) {
      return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz konum bilgisi." };
    }
    const session = await getSession();
    if (session.user.role !== "PROVIDER" || !session.providerId) {
      return { success: false, error: "Yetkisiz işlem: Sağlayıcı girişi gerekli." };
    }
    try {
      rateLimit(`provider-location:${session.user.id}`, 40, 60_000);
    } catch (error) {
      if (error instanceof HttpError) return { success: false, error: error.message };
      throw error;
    }
    await applyProviderPresence(session.providerId, { coords: parsed.data });
    return { success: true };
  } catch (error) {
    if (error instanceof HttpError) return { success: false, error: error.message };
    console.error("[provider-location] unexpected", error instanceof Error ? error.message : "unknown");
    return { success: false, error: "Konum güncellenirken bir hata oluştu." };
  }
}
