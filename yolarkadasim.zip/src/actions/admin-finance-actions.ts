"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { HttpError, rateLimit } from "@/lib/http";
import { holdPayout, processPayout, releasePayout, upsertPayoutAccount, type PayoutTarget } from "@/lib/payouts";
import { getSession } from "@/lib/session";

export type { BeneficiaryType, PayoutRecord, PayoutStatus } from "@/lib/payouts";

export interface ActionResponse {
  success: boolean;
  error?: string;
  reference?: string;
  processed?: number;
  failures?: { period: string; beneficiaryId: string; error: string }[];
}

const targetSchema = z.object({
  beneficiaryType: z.enum(["COURIER", "FLEET"]),
  beneficiaryId: z.uuid("Geçersiz hak sahibi."),
  period: z.string().regex(/^\d{4}-(W\d{2}|\d{2})$/, "Geçersiz dönem."),
  granularity: z.enum(["week", "month"]).default("week"),
});

async function requireSuper() {
  const session = await getSession();
  if (session.user.role !== "SUPER_ADMIN") return { session: null, error: "Yetkisiz işlem: Süper Admin yetkisi gereklidir." };
  return { session, error: undefined };
}

/** Tek hakediş dönemi için ödeme emri. Banka API'si bağlı değildir; emir kayda alınır, dekont referansı üretilir. */
export async function processSinglePayoutAction(target: PayoutTarget, note?: string): Promise<ActionResponse> {
  try {
    const parsed = targetSchema.safeParse(target);
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz istek." };
    const { session, error } = await requireSuper();
    if (!session) return { success: false, error };
    rateLimit(`payout:${session.user.id}`, 60, 60_000);
    const result = await processPayout(session, parsed.data, note);
    revalidatePath("/admin/finans");
    return { success: true, reference: result.reference, processed: 1 };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    console.error("[payout] unexpected", err instanceof Error ? err.message : "unknown");
    return { success: false, error: "Ödeme işlemi gerçekleştirilemedi." };
  }
}

/** Toplu ödeme: her dönem ayrı transaction'da işlenir; başarısız olanlar raporlanır, diğerleri geri alınmaz. */
export async function processBulkPayoutAction(targets: PayoutTarget[], note?: string): Promise<ActionResponse> {
  try {
    const parsed = z.array(targetSchema).min(1, "En az bir kayıt seçin.").max(200, "Tek seferde en fazla 200 kayıt.").safeParse(targets);
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz istek." };
    const { session, error } = await requireSuper();
    if (!session) return { success: false, error };
    rateLimit(`payout-bulk:${session.user.id}`, 10, 60_000);
    const failures: NonNullable<ActionResponse["failures"]> = [];
    let processed = 0;
    for (const t of parsed.data) {
      try {
        await processPayout(session, t, note);
        processed += 1;
      } catch (err) {
        failures.push({ period: t.period, beneficiaryId: t.beneficiaryId, error: err instanceof HttpError ? err.message : "İşlenemedi." });
      }
    }
    revalidatePath("/admin/finans");
    if (!processed) return { success: false, error: failures[0]?.error ?? "Hiçbir kayıt işlenemedi.", failures };
    return { success: true, processed, failures };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    console.error("[payout-bulk] unexpected", err instanceof Error ? err.message : "unknown");
    return { success: false, error: "Toplu ödeme gerçekleştirilemedi." };
  }
}

export async function holdPayoutAction(target: PayoutTarget, reason: string): Promise<ActionResponse> {
  try {
    const parsed = targetSchema.safeParse(target);
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz istek." };
    const { session, error } = await requireSuper();
    if (!session) return { success: false, error };
    await holdPayout(session, parsed.data, reason);
    revalidatePath("/admin/finans");
    return { success: true };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    return { success: false, error: "Blok işlemi gerçekleştirilemedi." };
  }
}

export async function releasePayoutAction(target: PayoutTarget, reason: string): Promise<ActionResponse> {
  try {
    const parsed = targetSchema.safeParse(target);
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz istek." };
    const { session, error } = await requireSuper();
    if (!session) return { success: false, error };
    await releasePayout(session, parsed.data, reason);
    revalidatePath("/admin/finans");
    return { success: true };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    return { success: false, error: "Blok kaldırılamadı." };
  }
}

/** Hak sahibi (kurye/filo) veya SUPER_ADMIN; IBAN doğrulanır, yalnızca maskeli hali döner. */
export async function savePayoutAccountAction(input: { beneficiaryType: "COURIER" | "FLEET"; beneficiaryId: string; iban: string; holderName: string }): Promise<ActionResponse & { ibanMasked?: string }> {
  try {
    const parsed = z.object({ beneficiaryType: z.enum(["COURIER", "FLEET"]), beneficiaryId: z.uuid(), iban: z.string().min(26).max(40), holderName: z.string().min(3).max(120) }).safeParse(input);
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz IBAN bilgisi." };
    const session = await getSession();
    rateLimit(`iban:${session.user.id}`, 10, 60_000);
    const r = await upsertPayoutAccount(session, parsed.data);
    revalidatePath("/admin/finans");
    return { success: true, ibanMasked: r.ibanMasked };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    return { success: false, error: "IBAN kaydedilemedi." };
  }
}
