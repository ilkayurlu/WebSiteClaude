"use server";

import { headers } from "next/headers";
import { asc, inArray } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  DEMO_ROLES, getAccessMode, pinDisabledReason, pinConfigured, demoEnabled, credentialsEnabled,
} from "@/lib/auth-mode";
import type { AccessMode, AuthAccessSnapshot, AuthResult, DemoAccount } from "@/lib/auth-mode-types";
import { openSessionForUser } from "@/lib/auth-session";
import type { UserRole } from "@/lib/dashboard-routes";
import { audit } from "@/lib/engine";
import { HttpError, rateLimit } from "@/lib/http";
import { ensureSeed } from "@/lib/seed";
import { authenticateUniversal } from "@/lib/universal-auth";

/* ---------------- Yardımcılar ---------------- */
async function clientIp(): Promise<string> {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip")?.trim() || "unknown";
}

async function auditSafe(actorId: string | null, action: string, entityId: string, reason: string, meta?: Record<string, unknown>) {
  try {
    await audit(db, actorId, action, "auth", entityId, reason, meta);
  } catch {
    // Denetim kaydı yazılamasa bile oturum kararı bozulmaz; hata istemciye sızdırılmaz.
  }
}

/* ---------------- 1) Mod okuma ---------------- */
/** Sunucudaki AUTH_ACCESS_LEVEL değerini ve yalnızca istemcinin ihtiyaç duyduğu yetenek bayraklarını döner. */
export async function getAuthAccessLevelAction(): Promise<AuthAccessSnapshot> {
  try {
    const mode: AccessMode = getAccessMode();
    return { success: true, mode, pinReady: pinConfigured(), pinReason: pinDisabledReason() };
  } catch {
    return { success: false, error: "Giriş modu okunamadı." };
  }
}

/* ---------------- 3) E-posta & şifre (seviye 1) ---------------- */
export async function loginWithCredentialsAction(formData: FormData): Promise<AuthResult> {
  try {
    if (!credentialsEnabled()) return { success: false, error: "E-posta ve parola girişi bu ortamda kapalı." };
    const parsed = z
      .object({ email: z.string().trim().min(3, "E-posta gerekli.").max(180), password: z.string().min(1, "Parola gerekli.").max(200), next: z.string().max(200).optional() })
      .safeParse({
        email: String(formData.get("email") ?? ""),
        password: String(formData.get("password") ?? ""),
        next: formData.get("next") ? String(formData.get("next")) : undefined,
      });
    if (!parsed.success) return { success: false, error: parsed.error.issues[0]?.message ?? "Geçersiz giriş." };

    const ip = await clientIp();
    rateLimit(`login:${ip}`, 15, 60_000);
    const { user, redirectTo } = await authenticateUniversal({ email: parsed.data.email, password: parsed.data.password, ip, next: parsed.data.next });
    await openSessionForUser(user.id);
    await auditSafe(user.id, "auth.login_password", user.id, "E-posta ve parola ile oturum açıldı", { role: user.role });
    return { success: true, redirectTo, role: user.role as UserRole };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    console.error("[auth-mode] credentials unexpected", err instanceof Error ? err.message : "unknown");
    return { success: false, error: "Giriş sırasında bir hata oluştu." };
  }
}

/* ---------------- 4) Demo hızlı giriş (seviye 0) ---------------- */
export async function getDemoAccountsAction(): Promise<DemoAccount[]> {
  if (!demoEnabled()) return [];
  await ensureSeed();
  const rows = await db
    .select({ id: users.id, name: users.name, role: users.role })
    .from(users)
    .where(inArray(users.role, [...DEMO_ROLES]))
    .orderBy(asc(users.createdAt));
  return rows.map((r) => ({ ...r, role: r.role as UserRole }));
}

export async function loginWithDemoAction(role: string): Promise<AuthResult> {
  try {
    if (!demoEnabled()) return { success: false, error: "Demo girişi bu ortamda kapalı." };
    const parsed = z.enum(DEMO_ROLES).safeParse(role);
    // Demo modda yönetici rolleri tek tıkla açılmaz; yönetici erişimi yalnızca yetkili yollardan yapılır.
    if (!parsed.success) return { success: false, error: "Bu rol için demo hızlı girişi kapalı. Yönetici erişimi için yetkili giriş yöntemini kullanın." };

    await ensureSeed();
    const [user] = await db.select().from(users).where(inArray(users.role, [parsed.data])).orderBy(asc(users.createdAt)).limit(1);
    if (!user) return { success: false, error: "Bu rol için demo hesap bulunamadı." };
    if (user.isSuspended) return { success: false, error: "Demo hesap askıya alınmış." };

    await openSessionForUser(user.id);
    await auditSafe(user.id, "auth.login_demo", user.id, "Demo hızlı giriş kullanıldı", { role: user.role });
    const home = { CUSTOMER: "/dashboard/musteri", PROVIDER: "/dashboard/kurye", FLEET_OWNER: "/dashboard/filo", RESTAURANT_OWNER: "/dashboard/isletme" } as Record<string, string>;
    return { success: true, redirectTo: home[user.role] ?? "/giris", role: user.role as UserRole };
  } catch (err) {
    if (err instanceof HttpError) return { success: false, error: err.message };
    console.error("[auth-mode] demo unexpected", err instanceof Error ? err.message : "unknown");
    return { success: false, error: "Demo giriş yapılamadı." };
  }
}
