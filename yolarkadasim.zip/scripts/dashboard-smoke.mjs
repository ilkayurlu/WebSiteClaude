import "dotenv/config";
import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { createHash, randomBytes } from "node:crypto";
import pg from "pg";

// DASHBOARD_BASE_URL tanımsız veya göreceli (ör. "admin") olsa da betik çökmez.
const configuredBase = process.env.DASHBOARD_BASE_URL?.trim() ?? "";
const BASE = /^https?:\/\/[^/]+/i.test(configuredBase) ? configuredBase.replace(/\/$/, "") : "http://localhost:3000";
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const cookies = new Map();
let customerId = "";
let otherCustomerRequestId = "";

async function request(path, { cookie, method = "GET", body, origin } = {}) {
  const headers = {};
  if (cookie) headers.Cookie = cookie;
  if (body) headers["Content-Type"] = "application/json";
  if (origin) headers.Origin = origin;
  return fetch(`${BASE}${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined, redirect: "manual" });
}

before(async () => {
  const userRows = await pool.query("select id, email, role from users where email in ($1,$2,$3,$4,$5,$6)", [
    "elif@demo.yolarkadasi.app", "ahmet-moto@demo.yolarkadasi.app", "hizli-lojistik@demo.yolarkadasi.app", "ops@demo.yolarkadasi.app", "operasyon@demo.yolarkadasi.app", "ocakbasi-moda@demo.yolarkadasi.app",
  ]);
  const ids = new Map(userRows.rows.map((r) => [r.role, r.id]));
  customerId = ids.get("CUSTOMER") ?? "";
  assert.equal(userRows.rows.length, 6);
  const demoOff = process.env.DISABLE_DEMO_ACCOUNTS === "true";
  for (const [role, id] of ids) {
    if (demoOff) {
      // Demo girişi kapalı: gerçek oturum tablosuna hash'li token yazılır (üretim auth yolu).
      const token = randomBytes(32).toString("hex");
      await pool.query("insert into auth_sessions(token_hash,user_id,expires_at) values ($1,$2, now()+interval '1 hour')", [createHash("sha256").update(token).digest("hex"), id]);
      cookies.set(role, `ya_session=${token}`);
      continue;
    }
    const res = await request("/api/session", { method: "POST", body: { userId: id } });
    assert.equal(res.status, 200);
    const c = res.headers.get("set-cookie")?.match(/ya_session=([a-f0-9]{64})/);
    assert.ok(c, `${role} should receive opaque 64-char token`);
    assert.notEqual(c[1], id);
    cookies.set(role, `ya_session=${c[1]}`);
  }
  const other = await pool.query("select id from service_requests where customer_id<>$1 order by created_at limit 1", [customerId]);
  otherCustomerRequestId = other.rows[0]?.id ?? "00000000-0000-0000-0000-000000000000";
});
after(async () => { await pool.end(); });

test("guest can view site but is redirected away from private pages", async () => {
  for (const path of ["/", "/yemek", "/kesfet", "/giris", "/filolar"]) assert.equal((await request(path)).status, 200, path);
  for (const path of ["/dashboard", "/dashboard/musteri", "/taleplerim", "/panel", "/admin", "/mesajlar"]) {
    const res = await request(path);
    assert.equal(res.status, 307, path);
    assert.ok(res.headers.get("location")?.includes("/giris"));
  }
  const api = await request("/api/dashboard/pulse");
  assert.equal(api.status, 401);
});

test("all roles reach their own screens and cannot open other role screens", async () => {
  const routes = new Map([
    ["CUSTOMER", ["/dashboard/musteri", "/dashboard/musteri/taleplerim", "/dashboard/musteri/gecmis", "/dashboard/musteri/favorilerim", "/dashboard/musteri/cuzdan"]],
    ["PROVIDER", ["/dashboard/kurye", "/dashboard/kurye/canli-panel", "/dashboard/kurye/gorevler", "/dashboard/kurye/kazanc", "/dashboard/kurye/profil-yonetimi", "/dashboard/kurye/filom"]],
    ["FLEET_OWNER", ["/dashboard/filo", "/dashboard/filo/operasyon", "/dashboard/filo/ekip", "/dashboard/filo/direkt-talepler", "/dashboard/filo/raporlar"]],
    ["ADMIN", ["/dashboard/admin", "/dashboard/admin/onay-kuyrugu", "/dashboard/admin/uyusmazliklar", "/dashboard/admin/metrikler", "/admin/medya-moderasyon", "/admin/audit"]],
    ["SUPER_ADMIN", ["/admin", "/admin/kuryeler", "/admin/filolar", "/admin/talepler", "/admin/uyusmazliklar", "/admin/finans", "/admin/ayarlar", "/dashboard/admin"]],
    ["RESTAURANT_OWNER", ["/dashboard/isletme"]],
  ]);
  for (const [role, pages] of routes) {
    for (const page of pages) {
      const res = await request(page, { cookie: cookies.get(role) });
      assert.equal(res.status, 200, `${role} ${page}`);
      const html = await res.text();
      assert.ok(!html.includes("Panel yüklenemedi"), `render error on ${page}`);
      assert.ok(!html.includes("phonePrivate") && !html.includes("lastLat") && !html.includes("lastLng"), `private fields on ${page}`);
      assert.ok(!html.includes("© 2026 YolArkadaşı"), `site footer leaked into ${page}`);
      assert.ok(!html.includes("Bir şeyler ters gitti"), `error boundary on ${page}`);
    }
    const foreign = [...routes.keys()].find((r) => r !== role);
    assert.equal((await request(routes.get(foreign)[0], { cookie: cookies.get(role) })).status, 307, `${role} cross-role guard`);
  }
});

test("tampered and revoked tokens are rejected", async () => {
  const forged = await request("/dashboard/admin", { cookie: "ya_session=" + "a".repeat(64) });
  assert.equal(forged.status, 307);
  assert.ok(forged.headers.get("location")?.includes("/giris"));
  let raw;
  if (process.env.DISABLE_DEMO_ACCOUNTS === "true") {
    raw = randomBytes(32).toString("hex");
    await pool.query("insert into auth_sessions(token_hash,user_id,expires_at) values ($1,$2, now()+interval '1 hour')", [createHash("sha256").update(raw).digest("hex"), customerId]);
  } else {
    const login = await request("/api/session", { method: "POST", body: { userId: customerId } });
    raw = login.headers.get("set-cookie")?.match(/ya_session=([a-f0-9]{64})/)?.[1];
  }
  assert.ok(raw);
  const old = `ya_session=${raw}`;
  assert.equal((await request("/dashboard/musteri", { cookie: old })).status, 200);
  assert.equal((await request("/api/session", { cookie: old, method: "DELETE" })).status, 200);
  assert.equal((await request("/dashboard/musteri", { cookie: old })).status, 307);
});

test("role-scoped pulse returns only counters, not OTP/address/coordinates", async () => {
  for (const role of cookies.keys()) {
    const res = await request("/api/dashboard/pulse", { cookie: cookies.get(role) });
    assert.equal(res.status, 200);
    const data = await res.json();
    assert.equal(typeof data.signature, "string");
    assert.equal(typeof data.active, "number");
    assert.equal(typeof data.messages, "number");
    assert.ok(!JSON.stringify(data).match(/deliveryOtp|lastLat|lastLng|phonePrivate|pickupDetail|addressDetail/));
  }
});

test("customer cannot invite fleet members or resolve support cases", async () => {
  const invite = await request("/api/dashboard/fleet/invitations", { cookie: cookies.get("CUSTOMER"), method: "POST", body: { email: "zeynep-bisiklet@demo.yolarkadasi.app" } });
  assert.equal(invite.status, 403);
  const forbiddenCase = await request("/api/dashboard/support", { cookie: cookies.get("CUSTOMER"), method: "POST", body: { sourceType: "REQUEST", sourceId: otherCustomerRequestId, category: "OTP", detail: "Başkasının işlemine kayıt açılmamalıdır." } });
  assert.equal(forbiddenCase.status, 404);
  const origin = await request("/api/dashboard/support", { cookie: cookies.get("CUSTOMER"), method: "POST", origin: "https://attacker.invalid", body: { sourceType: "REQUEST", sourceId: otherCustomerRequestId, category: "OTP", detail: "Kötü amaçlı kaynak reddedilmeli." } });
  assert.equal(origin.status, 403);
});

test("dashboard SSE uses authorized role-scoped events", async () => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const res = await fetch(`${BASE}/api/dashboard/stream`, { headers: { Cookie: cookies.get("PROVIDER") }, signal: controller.signal });
    assert.equal(res.status, 200);
    assert.ok(res.headers.get("content-type")?.includes("text/event-stream"));
    const reader = res.body.getReader();
    let text = "";
    for (let i = 0; i < 4 && !text.includes("event: dashboard"); i++) {
      const { value, done } = await reader.read();
      if (done) break;
      text += new TextDecoder().decode(value);
    }
    assert.ok(text.includes("event: dashboard"));
    assert.ok(!text.includes("deliveryOtp") && !text.includes("lastLat"));
    controller.abort();
  } finally { clearTimeout(timer); }
});

test("SUPER_ADMIN-only admin core is closed to ADMIN, customers and guests", async () => {
  for (const page of ["/admin", "/admin/kuryeler", "/admin/finans", "/admin/ayarlar", "/admin/talepler"]) {
    assert.equal((await request(page)).status, 307, `guest ${page}`);
    assert.equal((await request(page, { cookie: cookies.get("CUSTOMER") })).status, 307, `customer ${page}`);
    const adm = await request(page, { cookie: cookies.get("ADMIN") });
    assert.equal(adm.status, 307, `admin ${page}`);
    assert.ok(adm.headers.get("location")?.includes("/dashboard/admin"));
  }
  const mutate = await request("/api/admin/settings", { cookie: cookies.get("ADMIN"), method: "PATCH", body: { commissionBps: 1000, reason: "Yetkisiz değişiklik denemesi." } });
  assert.equal(mutate.status, 403);
});
