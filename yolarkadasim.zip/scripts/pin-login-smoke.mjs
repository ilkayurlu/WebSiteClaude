import "dotenv/config";
import { config as loadEnv } from "dotenv";
import assert from "node:assert/strict";
import { createHash, randomBytes } from "node:crypto";
import { readFileSync } from "node:fs";
import { after, before, test } from "node:test";
import pg from "pg";

loadEnv({ path: ".env.local", override: true, quiet: true });
// Göreli/bozuk değer gelirse betik çökmesin; yalnızca mutlak http(s) adresi kabul edilir.
const configuredBase = (process.env.PIN_SMOKE_BASE_URL ?? "").trim();
const BASE = /^https?:\/\/[^/]+/i.test(configuredBase) ? configuredBase.replace(/\/$/, "") : "http://localhost:3000";
const configured = String(process.env.ADMIN_ROOT_PIN ?? "").trim().replace(/^(?:"([^"]+)"|'([^']+)')$/, (_m, double, single) => double || single).trim();
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
let actionId = "";

function parseActionResult(text) {
  const line = text.split("\n").find((s) => /^1:\{/.test(s));
  assert.ok(line, "Server Action should serialize its result");
  return JSON.parse(line.slice(2));
}

async function callPin(pin, ip) {
  const res = await fetch(`${BASE}/giris`, {
    method: "POST",
    headers: {
      "Next-Action": actionId,
      "Content-Type": "text/plain;charset=UTF-8",
      Accept: "text/x-component",
      Origin: BASE,
      "X-Forwarded-For": ip,
    },
    body: JSON.stringify([pin]),
    redirect: "manual",
  });
  const body = await res.text();
  assert.notEqual(res.status, 500, "PIN action must not throw a 500");
  return { status: res.status, setCookie: res.headers.get("set-cookie"), result: parseActionResult(body) };
}

before(() => {
  assert.equal(process.env.AUTH_ACCESS_LEVEL, "2", "Smoke test requires AUTH_ACCESS_LEVEL=2");
  assert.match(configured, /^\d{4}$/, "Smoke test requires a valid ADMIN_ROOT_PIN");
  const manifest = JSON.parse(readFileSync(".next/server/server-reference-manifest.json", "utf8"));
  const entry = Object.entries(manifest.node ?? {}).find(([_id, meta]) =>
    Object.values(meta.workers ?? {}).some((worker) => worker.exportedName === "loginWithPinAction" && worker.filename === "src/actions/admin-pin-auth.ts"),
  );
  assert.ok(entry, "Server Action should be present in the production build");
  actionId = entry[0];
});
after(async () => { await pool.end(); });

test("mode two shows exactly four PIN fields, no email/password, no PIN leak", async () => {
  const response = await fetch(`${BASE}/giris`);
  assert.equal(response.status, 200);
  const html = await response.text();
  for (const index of [1, 2, 3, 4]) assert.ok(html.includes(`PIN hanesi ${index}`));
  assert.ok(html.includes("Admin Girişi Yap"));
  assert.ok(!html.includes('name="email"'));
  assert.ok(!html.includes('name="password"'));
  assert.ok(!html.includes(configured), "raw PIN must not appear in rendered page");
});

test("invalid PIN triggers 3-second cooldown, correct PIN creates compatible cookie", async () => {
  const ip = `198.51.100.${2 + randomBytes(1)[0] % 240}`;
  const wrong = configured === "0000" ? "1111" : "0000";
  const invalid = await callPin(wrong, ip);
  assert.equal(invalid.status, 200);
  assert.equal(invalid.result.success, false);
  assert.match(invalid.result.error, /Hatalı veya eksik PIN kodu/);
  assert.ok(invalid.result.cooldownMs >= 2500);
  assert.equal(invalid.setCookie, null);
  const duringWait = await callPin(configured, ip);
  assert.equal(duringWait.result.success, false);
  assert.ok(duringWait.result.cooldownMs > 0);
  await new Promise((resolve) => setTimeout(resolve, 3300));
  const valid = await callPin(configured, ip);
  assert.equal(valid.result.success, true);
  assert.equal(valid.result.redirectTo, "/admin");
  assert.equal(valid.result.role, "SUPER_ADMIN");
  const cookie = valid.setCookie?.match(/ya_session=([a-f0-9]{64})/);
  assert.ok(cookie, "opaque ya_session cookie should be issued");
  assert.match(valid.setCookie, /httponly/i);
  assert.match(valid.setCookie, /samesite=lax/i);
  assert.match(valid.setCookie, /secure/i);
  const tokenHash = createHash("sha256").update(cookie[1]).digest("hex");
  const dbRow = await pool.query("select u.role from auth_sessions s join users u on u.id=s.user_id where s.token_hash=$1 and s.expires_at>now()", [tokenHash]);
  assert.equal(dbRow.rows[0]?.role, "SUPER_ADMIN");
  const admin = await fetch(`${BASE}/admin`, { headers: { Cookie: `ya_session=${cookie[1]}` }, redirect: "manual" });
  assert.equal(admin.status, 200, "full navigation must reach admin with same cookie");
});

test("database-backed global lock persists and blocks even the right PIN", async () => {
  const key = "pin:global";
  const previous = await pool.query("select failures, window_started_at, cooldown_until from auth_pin_attempts where key=$1", [key]);
  try {
    await pool.query("insert into auth_pin_attempts (key, failures, window_started_at) values ($1, 40, now()) on conflict (key) do update set failures=40,window_started_at=now(),cooldown_until=null", [key]);
    const blocked = await callPin(configured, `203.0.113.${2 + randomBytes(1)[0] % 240}`);
    assert.equal(blocked.result.success, false);
    assert.match(blocked.result.error, /Çok fazla hatalı deneme/);
    assert.ok(blocked.result.cooldownMs > 60_000);
    assert.equal(blocked.setCookie, null);
  } finally {
    if (previous.rows[0]) {
      const row = previous.rows[0];
      await pool.query("update auth_pin_attempts set failures=$2,window_started_at=$3,cooldown_until=$4 where key=$1", [key, row.failures, row.window_started_at, row.cooldown_until]);
    } else {
      await pool.query("delete from auth_pin_attempts where key=$1", [key]);
    }
  }
});
